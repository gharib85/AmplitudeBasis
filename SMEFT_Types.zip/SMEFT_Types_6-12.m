{<|FL^3 -> {"GL"^3, "BL"*"GL"^2, "WL"^3, "BL"*"WL"^2, "BL"^3}, 
  \[Psi]^4 -> {"L"*"Q"^3, "dc"*"Q"^2*"uc", "ec"*"L"*"Q"*"uc", 
    "dc"*"ec"*"uc"^2}, FL*\[Phi]*\[Psi]^2 -> {"GL"*"H"*"Q"*"uc", 
    "dc"*"GL"*"H\[Dagger]"*"Q", "H"*"Q"*"uc"*"WL", 
    "dc"*"H\[Dagger]"*"Q"*"WL", "ec"*"H\[Dagger]"*"L"*"WL", 
    "BL"*"H"*"Q"*"uc", "BL"*"dc"*"H\[Dagger]"*"Q", 
    "BL"*"ec"*"H\[Dagger]"*"L"}, FL^2*\[Phi]^2 -> 
   {"GL"^2*"H"*"H\[Dagger]", "H"*"H\[Dagger]"*"WL"^2, 
    "BL"*"H"*"H\[Dagger]"*"WL", "BL"^2*"H"*"H\[Dagger]"}, 
  \[Psi]^2*OverBar[\[Psi]]^2 -> {"Q"^2*"Q\[Dagger]"^2, 
    "ec\[Dagger]"*"Q"^2*"uc\[Dagger]", "Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]", "dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q", 
    "L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", "dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]", 
    "ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]", "uc"^2*"uc\[Dagger]"^2, 
    "dc"*"dc\[Dagger]"*"uc"*"uc\[Dagger]", "L"*"L\[Dagger]"*"uc"*
     "uc\[Dagger]", "ec"*"ec\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2, "dc"*"dc\[Dagger]"*"L"*"L\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]", "L"^2*"L\[Dagger]"^2, 
    "ec"*"ec\[Dagger]"*"L"*"L\[Dagger]", "ec"^2*"ec\[Dagger]"^2}, 
  D*\[Phi]^2*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", "D"*"dc\[Dagger]"*"H"^2*"uc", 
    "D"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"H"*
     "H\[Dagger]", "D"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"}, 
  D^2*\[Phi]^4 -> {"D"^2*"H"^2*"H\[Dagger]"^2}, 
  \[Phi]^3*\[Psi]^2 -> {"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "dc"*"H"*"H\[Dagger]"^2*"Q", "ec"*"H"*"H\[Dagger]"^2*"L"}, 
  \[Phi]^6 -> {"H"^3*"H\[Dagger]"^3}|>, <|FL^2*\[Psi]^2 -> {}, 
  FL^3*\[Phi] -> {}, FL^2*OverBar[\[Psi]]^2 -> {}, 
  D*\[Psi]^3*OverBar[\[Psi]] -> {"D"*"dc"^3*"ec\[Dagger]", 
    "D"*"dc"^2*"L"*"Q\[Dagger]", "D"*"dc"*"L"^2*"uc\[Dagger]"}, 
  D*FL*\[Phi]*\[Psi]*OverBar[\[Psi]] -> {}, D^2*\[Phi]^2*\[Psi]^2 -> 
   {"D"^2*"H"^2*"L"^2}, D^2*FL*\[Phi]^3 -> {}, 
  \[Phi]*\[Psi]^4 -> {"dc"*"H"*"L"^2*"Q", "dc"^2*"H"*"L"*"uc", 
    "dc"^3*"H\[Dagger]"*"L", "ec"*"H"*"L"^3}, FL*\[Phi]^2*\[Psi]^2 -> 
   {"H"^2*"L"^2*"WL", "BL"*"H"^2*"L"^2}, FL^2*\[Phi]^3 -> {}, 
  \[Phi]*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc", "dc\[Dagger]"^2*"ec"*"H\[Dagger]"*
     "Q", "dc\[Dagger]"*"ec"*"H\[Dagger]"*"L\[Dagger]"*"uc"}, 
  D*\[Phi]^3*\[Psi]*OverBar[\[Psi]] -> {"D"*"ec\[Dagger]"*"H"^3*"L"}, 
  D^2*\[Phi]^5 -> {}, \[Phi]^4*\[Psi]^2 -> {"H"^3*"H\[Dagger]"*"L"^2, 
    "ec"^2*"H\[Dagger]"^4}, \[Phi]^7 -> {}|>, 
 <|FL^4 -> {"GL"^4, "BL"*"GL"^3, "GL"^2*"WL"^2, "BL"^2*"GL"^2, "WL"^4, 
    "BL"*"WL"^3, "BL"^2*"WL"^2, "BL"^4}, D*FL^2*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"GL"^2*"Q"*"Q\[Dagger]", "D"*"GL"^2*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"^2, "D"*"GL"^2*"L"*"L\[Dagger]", 
    "D"*"ec"*"ec\[Dagger]"*"GL"^2, "D"*"GL"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"D"*"GL"*"Q"*"Q\[Dagger]", "BL"*"D"*"GL"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"GL", "D"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "D"*"uc"*"uc\[Dagger]"*"WL"^2, "D"*"dc"*"dc\[Dagger]"*"WL"^2, 
    "D"*"L"*"L\[Dagger]"*"WL"^2, "D"*"ec"*"ec\[Dagger]"*"WL"^2, 
    "BL"*"D"*"Q"*"Q\[Dagger]"*"WL", "BL"*"D"*"L"*"L\[Dagger]"*"WL", 
    "BL"^2*"D"*"Q"*"Q\[Dagger]", "BL"^2*"D"*"uc"*"uc\[Dagger]", 
    "BL"^2*"D"*"dc"*"dc\[Dagger]", "BL"^2*"D"*"L"*"L\[Dagger]", 
    "BL"^2*"D"*"ec"*"ec\[Dagger]"}, D^2*\[Psi]^4 -> 
   {"D"^2*"L"*"Q"^3, "D"^2*"dc"*"Q"^2*"uc", "D"^2*"ec"*"L"*"Q"*"uc", 
    "D"^2*"dc"*"ec"*"uc"^2}, D^2*FL*\[Phi]*\[Psi]^2 -> 
   {"D"^2*"GL"*"H"*"Q"*"uc", "D"^2*"dc"*"GL"*"H\[Dagger]"*"Q", 
    "D"^2*"H"*"Q"*"uc"*"WL", "D"^2*"dc"*"H\[Dagger]"*"Q"*"WL", 
    "D"^2*"ec"*"H\[Dagger]"*"L"*"WL", "BL"*"D"^2*"H"*"Q"*"uc", 
    "BL"*"D"^2*"dc"*"H\[Dagger]"*"Q", "BL"*"D"^2*"ec"*"H\[Dagger]"*"L"}, 
  D^2*FL^2*\[Phi]^2 -> {"D"^2*"GL"^2*"H"*"H\[Dagger]", 
    "D"^2*"H"*"H\[Dagger]"*"WL"^2, "BL"*"D"^2*"H"*"H\[Dagger]"*"WL", 
    "BL"^2*"D"^2*"H"*"H\[Dagger]"}, FL^2*FR^2 -> 
   {"GL"^2*"GR"^2, "BR"*"GL"^2*"GR", "GL"^2*"WR"^2, "BR"^2*"GL"^2, 
    "GL"*"GR"*"WL"*"WR", "BL"*"BR"*"GL"*"GR", "WL"^2*"WR"^2, 
    "BR"*"WL"^2*"WR", "BR"^2*"WL"^2, "BL"*"BR"*"WL"*"WR", "BL"^2*"BR"^2}, 
  D*FL*FR*\[Psi]*OverBar[\[Psi]] -> {"D"*"GL"*"GR"*"Q"*"Q\[Dagger]", 
    "D"*"GL"*"Q"*"Q\[Dagger]"*"WR", "BR"*"D"*"GL"*"Q"*"Q\[Dagger]", 
    "D"*"GL"*"GR"*"uc"*"uc\[Dagger]", "BR"*"D"*"GL"*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"GR", "BR"*"D"*"dc"*"dc\[Dagger]"*"GL", 
    "D"*"GL"*"GR"*"L"*"L\[Dagger]", "D"*"ec"*"ec\[Dagger]"*"GL"*"GR", 
    "D"*"Q"*"Q\[Dagger]"*"WL"*"WR", "BR"*"D"*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"uc"*"uc\[Dagger]"*"WL"*"WR", "D"*"dc"*"dc\[Dagger]"*"WL"*"WR", 
    "D"*"L"*"L\[Dagger]"*"WL"*"WR", "BR"*"D"*"L"*"L\[Dagger]"*"WL", 
    "D"*"ec"*"ec\[Dagger]"*"WL"*"WR", "BL"*"BR"*"D"*"Q"*"Q\[Dagger]", 
    "BL"*"BR"*"D"*"uc"*"uc\[Dagger]", "BL"*"BR"*"D"*"dc"*"dc\[Dagger]", 
    "BL"*"BR"*"D"*"L"*"L\[Dagger]", "BL"*"BR"*"D"*"ec"*"ec\[Dagger]"}, 
  D^2*\[Psi]^2*OverBar[\[Psi]]^2 -> {"D"^2*"Q"^2*"Q\[Dagger]"^2, 
    "D"^2*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]", "D"^2*"Q"*"Q\[Dagger]"*"uc"*
     "uc\[Dagger]", "D"^2*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"^2*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q", "D"^2*"L"*"L\[Dagger]"*"Q"*
     "Q\[Dagger]", "D"^2*"dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]", 
    "D"^2*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]", "D"^2*"uc"^2*"uc\[Dagger]"^2, 
    "D"^2*"dc"*"dc\[Dagger]"*"uc"*"uc\[Dagger]", "D"^2*"L"*"L\[Dagger]"*"uc"*
     "uc\[Dagger]", "D"^2*"ec"*"ec\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"dc"^2*"dc\[Dagger]"^2, "D"^2*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]", 
    "D"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]", "D"^2*"L"^2*"L\[Dagger]"^2, 
    "D"^2*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]", "D"^2*"ec"^2*"ec\[Dagger]"^2}, 
  D^2*FR*\[Phi]*\[Psi]^2 -> {"D"^2*"GR"*"H"*"Q"*"uc", 
    "D"^2*"H"*"Q"*"uc"*"WR", "BR"*"D"^2*"H"*"Q"*"uc", 
    "D"^2*"dc"*"GR"*"H\[Dagger]"*"Q", "D"^2*"dc"*"H\[Dagger]"*"Q"*"WR", 
    "BR"*"D"^2*"dc"*"H\[Dagger]"*"Q", "D"^2*"ec"*"H\[Dagger]"*"L"*"WR", 
    "BR"*"D"^2*"ec"*"H\[Dagger]"*"L"}, D^2*FL*FR*\[Phi]^2 -> 
   {"D"^2*"GL"*"GR"*"H"*"H\[Dagger]", "D"^2*"H"*"H\[Dagger]"*"WL"*"WR", 
    "BR"*"D"^2*"H"*"H\[Dagger]"*"WL", "BL"*"BR"*"D"^2*"H"*"H\[Dagger]"}, 
  D^3*\[Phi]^2*\[Psi]*OverBar[\[Psi]] -> 
   {"D"^3*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", "D"^3*"dc\[Dagger]"*"H"^2*"uc", 
    "D"^3*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", "D"^3*"dc"*"dc\[Dagger]"*"H"*
     "H\[Dagger]", "D"^3*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "D"^3*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"}, 
  D^4*\[Phi]^4 -> {"D"^4*"H"^2*"H\[Dagger]"^2}, 
  FL*\[Psi]^4 -> {"GL"*"L"*"Q"^3, "dc"*"GL"*"Q"^2*"uc", 
    "ec"*"GL"*"L"*"Q"*"uc", "dc"*"ec"*"GL"*"uc"^2, "L"*"Q"^3*"WL", 
    "dc"*"Q"^2*"uc"*"WL", "ec"*"L"*"Q"*"uc"*"WL", "BL"*"L"*"Q"^3, 
    "BL"*"dc"*"Q"^2*"uc", "BL"*"ec"*"L"*"Q"*"uc", "BL"*"dc"*"ec"*"uc"^2}, 
  FL^2*\[Phi]*\[Psi]^2 -> {"GL"^2*"H"*"Q"*"uc", "dc"*"GL"^2*"H\[Dagger]"*"Q", 
    "ec"*"GL"^2*"H\[Dagger]"*"L", "GL"*"H"*"Q"*"uc"*"WL", 
    "dc"*"GL"*"H\[Dagger]"*"Q"*"WL", "BL"*"GL"*"H"*"Q"*"uc", 
    "BL"*"dc"*"GL"*"H\[Dagger]"*"Q", "H"*"Q"*"uc"*"WL"^2, 
    "dc"*"H\[Dagger]"*"Q"*"WL"^2, "ec"*"H\[Dagger]"*"L"*"WL"^2, 
    "BL"*"H"*"Q"*"uc"*"WL", "BL"*"dc"*"H\[Dagger]"*"Q"*"WL", 
    "BL"*"ec"*"H\[Dagger]"*"L"*"WL", "BL"^2*"H"*"Q"*"uc", 
    "BL"^2*"dc"*"H\[Dagger]"*"Q", "BL"^2*"ec"*"H\[Dagger]"*"L"}, 
  FL^3*\[Phi]^2 -> {"GL"^3*"H"*"H\[Dagger]", "GL"^2*"H"*"H\[Dagger]"*"WL", 
    "BL"*"GL"^2*"H"*"H\[Dagger]", "H"*"H\[Dagger]"*"WL"^3, 
    "BL"*"H"*"H\[Dagger]"*"WL"^2, "BL"^2*"H"*"H\[Dagger]"*"WL", 
    "BL"^3*"H"*"H\[Dagger]"}, FL*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"GL"*"Q"^2*"Q\[Dagger]"^2, "ec\[Dagger]"*"GL"*"Q"^2*"uc\[Dagger]", 
    "GL"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", "dc"*"dc\[Dagger]"*"GL"*"Q"*
     "Q\[Dagger]", "dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q", 
    "GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", "dc\[Dagger]"*"GL"*"L"*"Q"*
     "uc\[Dagger]", "ec"*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]", 
    "GL"*"uc"^2*"uc\[Dagger]"^2, "dc"*"GL"*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "dc"*"dc\[Dagger]"*"GL"*"uc"*"uc\[Dagger]", "GL"*"L"*"L\[Dagger]"*"uc"*
     "uc\[Dagger]", "ec"*"GL"*"Q\[Dagger]"^2*"uc", 
    "ec"*"ec\[Dagger]"*"GL"*"uc"*"uc\[Dagger]", "dc"^2*"dc\[Dagger]"^2*"GL", 
    "dc"*"dc\[Dagger]"*"GL"*"L"*"L\[Dagger]", "dc"*"dc\[Dagger]"*"ec"*
     "ec\[Dagger]"*"GL", "dc\[Dagger]"*"ec"*"GL"*"L"*"Q\[Dagger]", 
    "Q"^2*"Q\[Dagger]"^2*"WL", "ec\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL", 
    "Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", "dc"*"dc\[Dagger]"*"Q"*
     "Q\[Dagger]"*"WL", "dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"WL", 
    "L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", "dc\[Dagger]"*"L"*"Q"*
     "uc\[Dagger]"*"WL", "ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "dc"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", "L"*"L\[Dagger]"*"uc"*
     "uc\[Dagger]"*"WL", "ec"*"Q\[Dagger]"^2*"uc"*"WL", 
    "dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*"WL", "L"^2*"L\[Dagger]"^2*"WL", 
    "dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]"*"WL", "ec"*"ec\[Dagger]"*"L"*
     "L\[Dagger]"*"WL", "BL"*"Q"^2*"Q\[Dagger]"^2, 
    "BL"*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]", "BL"*"Q"*"Q\[Dagger]"*"uc"*
     "uc\[Dagger]", "BL"*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q", "BL"*"L"*"L\[Dagger]"*"Q"*
     "Q\[Dagger]", "BL"*"dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]", 
    "BL"*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]", "BL"*"uc"^2*"uc\[Dagger]"^2, 
    "BL"*"dc"*"L\[Dagger]"*"Q\[Dagger]"*"uc", "BL"*"dc"*"dc\[Dagger]"*"uc"*
     "uc\[Dagger]", "BL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"ec"*"Q\[Dagger]"^2*"uc", "BL"*"ec"*"ec\[Dagger]"*"uc"*
     "uc\[Dagger]", "BL"*"dc"^2*"dc\[Dagger]"^2, "BL"*"dc"*"dc\[Dagger]"*"L"*
     "L\[Dagger]", "BL"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]", 
    "BL"*"L"^2*"L\[Dagger]"^2, "BL"*"dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]", 
    "BL"*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]", "BL"*"ec"^2*"ec\[Dagger]"^2}, 
  FL^2*\[Phi]*OverBar[\[Psi]]^2 -> {"dc\[Dagger]"*"GL"^2*"H"*"Q\[Dagger]", 
    "ec\[Dagger]"*"GL"^2*"H"*"L\[Dagger]", "GL"^2*"H\[Dagger]"*"Q\[Dagger]"*
     "uc\[Dagger]", "dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]"*"WL", 
    "GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]", "BL"*"GL"*"H\[Dagger]"*
     "Q\[Dagger]"*"uc\[Dagger]", "dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL"^2, 
    "ec\[Dagger]"*"H"*"L\[Dagger]"*"WL"^2, "H\[Dagger]"*"Q\[Dagger]"*
     "uc\[Dagger]"*"WL"^2, "BL"*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL", 
    "BL"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"WL", "BL"*"H\[Dagger]"*"Q\[Dagger]"*
     "uc\[Dagger]"*"WL", "BL"^2*"dc\[Dagger]"*"H"*"Q\[Dagger]", 
    "BL"^2*"ec\[Dagger]"*"H"*"L\[Dagger]", "BL"^2*"H\[Dagger]"*"Q\[Dagger]"*
     "uc\[Dagger]"}, D*\[Phi]*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"*"ec\[Dagger]"*"H"*"Q"^3, "D"*"H"*"Q"^2*"Q\[Dagger]"*"uc", 
    "D"*"dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", "D"*"dc\[Dagger]"*"H"*"L"*
     "Q"^2, "D"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]", 
    "D"*"H"*"Q"*"uc"^2*"uc\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc", 
    "D"*"dc"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", "D"*"H"*"L"*"L\[Dagger]"*
     "Q"*"uc", "D"*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc", 
    "D"*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q", "D"*"dc"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q", "D"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q", 
    "D"*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", "D"*"dc"*"H"*"L\[Dagger]"*
     "uc"^2, "D"*"ec"*"H"*"Q\[Dagger]"*"uc"^2, "D"*"dc"^2*"H\[Dagger]"*
     "L\[Dagger]"*"uc", "D"*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "D"*"dc\[Dagger]"*"ec"*"H"*"L"*"uc", "D"*"ec"*"H\[Dagger]"*"L"*"uc"*
     "uc\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L", 
    "D"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]", "D"*"ec"^2*"ec\[Dagger]"*
     "H\[Dagger]"*"L"}, D*FL*\[Phi]^2*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", "D"*"dc\[Dagger]"*"GL"*"H"^2*
     "uc", "D"*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]", 
    "D"*"dc"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]", "D"*"H"*"H\[Dagger]"*"Q"*
     "Q\[Dagger]"*"WL", "D"*"dc\[Dagger]"*"H"^2*"uc"*"WL", 
    "D"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", "D"*"dc"*"dc\[Dagger]"*"H"*
     "H\[Dagger]"*"WL", "D"*"dc"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "D"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL", "D"*"ec"*"ec\[Dagger]"*"H"*
     "H\[Dagger]"*"WL", "BL"*"D"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"*"H"^2*"uc", "BL"*"D"*"H"*"H\[Dagger]"*"uc"*
     "uc\[Dagger]", "BL"*"D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]", 
    "BL"*"D"*"dc"*"H\[Dagger]"^2*"uc\[Dagger]", "BL"*"D"*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]", "BL"*"D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"}, 
  D^2*\[Phi]^3*\[Psi]^2 -> {"D"^2*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "D"^2*"dc"*"H"*"H\[Dagger]"^2*"Q", "D"^2*"ec"*"H"*"H\[Dagger]"^2*"L"}, 
  D^2*FL*\[Phi]^4 -> {"D"^2*"H"^2*"H\[Dagger]"^2*"WL", 
    "BL"*"D"^2*"H"^2*"H\[Dagger]"^2}, \[Phi]^2*\[Psi]^4 -> 
   {"H"*"H\[Dagger]"*"L"*"Q"^3, "H"^2*"Q"^2*"uc"^2, 
    "dc"*"H"*"H\[Dagger]"*"Q"^2*"uc", "dc"^2*"H\[Dagger]"^2*"Q"^2, 
    "ec"*"H"*"H\[Dagger]"*"L"*"Q"*"uc", "dc"*"ec"*"H\[Dagger]"^2*"L"*"Q", 
    "ec"*"H"^2*"uc"^3, "dc"*"ec"*"H"*"H\[Dagger]"*"uc"^2, 
    "dc"^2*"ec"*"H\[Dagger]"^2*"uc", "ec"^2*"H\[Dagger]"^2*"L"^2}, 
  FL*\[Phi]^3*\[Psi]^2 -> {"GL"*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "dc"*"GL"*"H"*"H\[Dagger]"^2*"Q", "H"^2*"H\[Dagger]"*"Q"*"uc"*"WL", 
    "dc"*"H"*"H\[Dagger]"^2*"Q"*"WL", "ec"*"H"*"H\[Dagger]"^2*"L"*"WL", 
    "BL"*"H"^2*"H\[Dagger]"*"Q"*"uc", "BL"*"dc"*"H"*"H\[Dagger]"^2*"Q", 
    "BL"*"ec"*"H"*"H\[Dagger]"^2*"L"}, FL^2*\[Phi]^4 -> 
   {"GL"^2*"H"^2*"H\[Dagger]"^2, "H"^2*"H\[Dagger]"^2*"WL"^2, 
    "BL"*"H"^2*"H\[Dagger]"^2*"WL", "BL"^2*"H"^2*"H\[Dagger]"^2}, 
  \[Phi]^2*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"Q"^2, "H"*"H\[Dagger]"*"Q"^2*
     "Q\[Dagger]"^2, "ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "dc\[Dagger]"*"H"^2*"Q"*"Q\[Dagger]"*"uc", "ec\[Dagger]"*"H"^2*
     "L\[Dagger]"*"Q"*"uc", "H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*
     "uc\[Dagger]", "dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "dc"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q", 
    "dc\[Dagger]"^2*"H"^2*"L"*"Q", "H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*
     "Q\[Dagger]", "dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"Q"*"uc\[Dagger]", 
    "H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"^2, "ec"*"ec\[Dagger]"*"H"*
     "H\[Dagger]"*"Q"*"Q\[Dagger]", "dc\[Dagger]"*"H"^2*"uc"^2*"uc\[Dagger]", 
    "H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, "dc"*"dc\[Dagger]"^2*"H"^2*"uc", 
    "dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc\[Dagger]"*"H"^2*"L"*"L\[Dagger]"*"uc", "H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"uc"*"uc\[Dagger]", "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*
     "uc", "ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2*"H"*"H\[Dagger]", "dc"*"dc\[Dagger]"*"H"*
     "H\[Dagger]"*"L"*"L\[Dagger]", "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*
     "H\[Dagger]", "H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2, 
    "ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "ec"^2*"ec\[Dagger]"^2*"H"*"H\[Dagger]"}, 
  D*\[Phi]^4*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", "D"*"dc\[Dagger]"*"H"^3*
     "H\[Dagger]"*"uc", "D"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2, "D"*"H"^2*"H\[Dagger]"^2*"L"*
     "L\[Dagger]", "D"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2}, 
  D^2*\[Phi]^6 -> {"D"^2*"H"^3*"H\[Dagger]"^3}, 
  \[Phi]^5*\[Psi]^2 -> {"H"^3*"H\[Dagger]"^2*"Q"*"uc", 
    "dc"*"H"^2*"H\[Dagger]"^3*"Q", "ec"*"H"^2*"H\[Dagger]"^3*"L"}, 
  \[Phi]^8 -> {"H"^4*"H\[Dagger]"^4}|>, <|D^2*FL^2*\[Psi]^2 -> {}, 
  D^2*FL^3*\[Phi] -> {}, D^2*FL*FR*\[Psi]^2 -> {}, 
  D^2*FL^2*OverBar[\[Psi]]^2 -> {}, D^2*FL^2*FR*\[Phi] -> {}, 
  D^3*\[Psi]^3*OverBar[\[Psi]] -> {"D"^3*"dc"^3*"ec\[Dagger]", 
    "D"^3*"dc"^2*"L"*"Q\[Dagger]", "D"^3*"dc"*"L"^2*"uc\[Dagger]"}, 
  D^3*FL*\[Phi]*\[Psi]*OverBar[\[Psi]] -> {}, D^4*\[Phi]^2*\[Psi]^2 -> 
   {"D"^4*"H"^2*"L"^2}, D^4*FL*\[Phi]^3 -> {}, FL^3*\[Psi]^2 -> {}, 
  FL^4*\[Phi] -> {}, FL^3*OverBar[\[Psi]]^2 -> {}, 
  D*FL*\[Psi]^3*OverBar[\[Psi]] -> {"D"*"dc"^3*"ec\[Dagger]"*"GL", 
    "D"*"dc"^2*"GL"*"L"*"Q\[Dagger]", "D"*"dc"*"GL"*"L"^2*"uc\[Dagger]", 
    "D"*"dc"^2*"L"*"Q\[Dagger]"*"WL", "D"*"dc"*"L"^2*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"dc"^3*"ec\[Dagger]", "BL"*"D"*"dc"^2*"L"*"Q\[Dagger]", 
    "BL"*"D"*"dc"*"L"^2*"uc\[Dagger]"}, 
  D*FL^2*\[Phi]*\[Psi]*OverBar[\[Psi]] -> {}, D^2*\[Phi]*\[Psi]^4 -> 
   {"D"^2*"dc"*"H"*"L"^2*"Q", "D"^2*"dc"^2*"H"*"L"*"uc", 
    "D"^2*"dc"^3*"H\[Dagger]"*"L", "D"^2*"ec"*"H"*"L"^3}, 
  D^2*FL*\[Phi]^2*\[Psi]^2 -> {"D"^2*"H"^2*"L"^2*"WL", 
    "BL"*"D"^2*"H"^2*"L"^2}, D^2*FL^2*\[Phi]^3 -> {}, FL*FR^2*\[Psi]^2 -> {}, 
  FL^2*FR^2*\[Phi] -> {}, D*FR*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"*"dc"^3*"ec\[Dagger]"*"GR", "BR"*"D"*"dc"^3*"ec\[Dagger]", 
    "D"*"dc"^2*"GR"*"L"*"Q\[Dagger]", "D"*"dc"^2*"L"*"Q\[Dagger]"*"WR", 
    "BR"*"D"*"dc"^2*"L"*"Q\[Dagger]", "D"*"dc"*"GR"*"L"^2*"uc\[Dagger]", 
    "D"*"dc"*"L"^2*"uc\[Dagger]"*"WR", "BR"*"D"*"dc"*"L"^2*"uc\[Dagger]"}, 
  D*FL*FR*\[Phi]*\[Psi]*OverBar[\[Psi]] -> {}, 
  D^2*\[Phi]*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"D"^2*"dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "D"^2*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc", "D"^2*"dc\[Dagger]"^2*"ec"*
     "H\[Dagger]"*"Q", "D"^2*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L\[Dagger]"*
     "uc"}, D^2*FR*\[Phi]^2*\[Psi]^2 -> {"D"^2*"H"^2*"L"^2*"WR", 
    "BR"*"D"^2*"H"^2*"L"^2}, D^2*FL*FR*\[Phi]^3 -> {}, 
  D^3*\[Phi]^3*\[Psi]*OverBar[\[Psi]] -> {"D"^3*"ec\[Dagger]"*"H"^3*"L"}, 
  D^4*\[Phi]^5 -> {}, \[Psi]^6 -> {"dc"^2*"L"^2*"Q"^2, "dc"^3*"L"*"Q"*"uc", 
    "dc"*"ec"*"L"^3*"Q", "dc"^4*"uc"^2, "dc"^2*"ec"*"L"^2*"uc", 
    "ec"^2*"L"^4}, FL*\[Phi]*\[Psi]^4 -> {"dc"*"GL"*"H"*"L"^2*"Q", 
    "dc"^2*"GL"*"H"*"L"*"uc", "dc"^3*"GL"*"H\[Dagger]"*"L", 
    "dc"*"H"*"L"^2*"Q"*"WL", "dc"^2*"H"*"L"*"uc"*"WL", 
    "dc"^3*"H\[Dagger]"*"L"*"WL", "ec"*"H"*"L"^3*"WL", 
    "BL"*"dc"*"H"*"L"^2*"Q", "BL"*"dc"^2*"H"*"L"*"uc", 
    "BL"*"dc"^3*"H\[Dagger]"*"L", "BL"*"ec"*"H"*"L"^3}, 
  FL^2*\[Phi]^2*\[Psi]^2 -> {"GL"^2*"H"^2*"L"^2, "H"^2*"L"^2*"WL"^2, 
    "BL"*"H"^2*"L"^2*"WL", "BL"^2*"H"^2*"L"^2}, FL^3*\[Phi]^3 -> {}, 
  \[Psi]^4*OverBar[\[Psi]]^2 -> {"dc\[Dagger]"^2*"Q"^4, 
    "dc\[Dagger]"*"L\[Dagger]"*"Q"^3*"uc", "L\[Dagger]"^2*"Q"^2*"uc"^2, 
    "dc\[Dagger]"^2*"ec"*"Q"^2*"uc", "dc\[Dagger]"*"ec"*"L\[Dagger]"*"Q"*
     "uc"^2, "dc"^3*"ec\[Dagger]"*"Q"*"Q\[Dagger]", 
    "dc"^2*"L"*"Q"*"Q\[Dagger]"^2, "dc"^2*"ec\[Dagger]"*"L"*"Q"*
     "uc\[Dagger]", "dc"*"L"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]", 
    "L"^3*"Q"*"uc\[Dagger]"^2, "ec"*"L\[Dagger]"^2*"uc"^3, 
    "dc\[Dagger]"^2*"ec"^2*"uc"^2, "dc"^3*"Q\[Dagger]"^2*"uc", 
    "dc"^3*"ec\[Dagger]"*"uc"*"uc\[Dagger]", "dc"^2*"L"*"Q\[Dagger]"*"uc"*
     "uc\[Dagger]", "dc"*"L"^2*"uc"*"uc\[Dagger]"^2, 
    "dc"^4*"dc\[Dagger]"*"ec\[Dagger]", "dc"^3*"dc\[Dagger]"*"L"*
     "Q\[Dagger]", "dc"^3*"ec\[Dagger]"*"L"*"L\[Dagger]", 
    "dc"^3*"ec"*"ec\[Dagger]"^2, "dc"^2*"L"^2*"L\[Dagger]"*"Q\[Dagger]", 
    "dc"^2*"dc\[Dagger]"*"L"^2*"uc\[Dagger]", "dc"^2*"ec"*"ec\[Dagger]"*"L"*
     "Q\[Dagger]", "dc"*"L"^3*"L\[Dagger]"*"uc\[Dagger]", 
    "dc"*"ec"*"L"^2*"Q\[Dagger]"^2, "dc"*"ec"*"ec\[Dagger]"*"L"^2*
     "uc\[Dagger]", "ec"*"L"^3*"Q\[Dagger]"*"uc\[Dagger]"}, 
  FL*\[Phi]*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"*"GL"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "GL"*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc", "dc\[Dagger]"^2*"ec"*"GL"*
     "H\[Dagger]"*"Q", "dc\[Dagger]"*"ec"*"GL"*"H\[Dagger]"*"L\[Dagger]"*
     "uc", "dc"^2*"ec\[Dagger]"*"GL"*"H"*"Q\[Dagger]", 
    "dc"*"GL"*"H"*"L"*"Q\[Dagger]"^2, "dc"*"ec\[Dagger]"*"GL"*"H"*"L"*
     "uc\[Dagger]", "GL"*"H"*"L"^2*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2*"WL", 
    "H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc"*"WL", "dc\[Dagger]"^2*"ec"*
     "H\[Dagger]"*"Q"*"WL", "dc\[Dagger]"*"ec"*"H\[Dagger]"*"L\[Dagger]"*"uc"*
     "WL", "dc"^2*"ec\[Dagger]"*"H"*"Q\[Dagger]"*"WL", 
    "dc"*"H"*"L"*"Q\[Dagger]"^2*"WL", "dc"*"ec\[Dagger]"*"H"*"L"*
     "uc\[Dagger]"*"WL", "H"*"L"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "BL"*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc", "BL"*"dc\[Dagger]"^2*"ec"*
     "H\[Dagger]"*"Q", "BL"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L\[Dagger]"*
     "uc", "BL"*"dc"^2*"ec\[Dagger]"*"H"*"Q\[Dagger]", 
    "BL"*"dc"*"H"*"L"*"Q\[Dagger]"^2, "BL"*"dc"*"ec\[Dagger]"*"H"*"L"*
     "uc\[Dagger]", "BL"*"H"*"L"^2*"Q\[Dagger]"*"uc\[Dagger]"}, 
  FL^2*\[Phi]^2*OverBar[\[Psi]]^2 -> {"GL"^2*"H\[Dagger]"^2*"L\[Dagger]"^2, 
    "H\[Dagger]"^2*"L\[Dagger]"^2*"WL"^2, "BL"*"H\[Dagger]"^2*"L\[Dagger]"^2*
     "WL", "BL"^2*"H\[Dagger]"^2*"L\[Dagger]"^2}, 
  D*\[Phi]^2*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"^3, "D"*"dc\[Dagger]"*"ec"*
     "H\[Dagger]"^2*"Q"^2, "D"*"ec"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"*"uc", 
    "D"*"dc"*"ec\[Dagger]"*"H"^2*"L"*"Q", "D"*"H"^2*"L"^2*"Q"*"Q\[Dagger]", 
    "D"*"dc"^2*"ec\[Dagger]"*"H"^2*"uc", "D"*"dc"*"H"^2*"L"*"Q\[Dagger]"*
     "uc", "D"*"H"^2*"L"^2*"uc"*"uc\[Dagger]", "D"*"dc\[Dagger]"*"ec"^2*
     "H\[Dagger]"^2*"uc", "D"*"dc"^3*"ec\[Dagger]"*"H"*"H\[Dagger]", 
    "D"*"dc"^2*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]", "D"*"dc"*"dc\[Dagger]"*
     "H"^2*"L"^2, "D"*"dc"*"H"*"H\[Dagger]"*"L"^2*"uc\[Dagger]", 
    "D"*"H"^2*"L"^3*"L\[Dagger]", "D"*"ec"*"ec\[Dagger]"*"H"^2*"L"^2}, 
  D*FL*\[Phi]^3*\[Psi]*OverBar[\[Psi]] -> {"D"*"ec\[Dagger]"*"H"^3*"L"*"WL", 
    "D"*"ec"*"H\[Dagger]"^3*"L\[Dagger]"*"WL", "BL"*"D"*"ec\[Dagger]"*"H"^3*
     "L", "BL"*"D"*"ec"*"H\[Dagger]"^3*"L\[Dagger]"}, 
  D^2*\[Phi]^4*\[Psi]^2 -> {"D"^2*"H"^3*"H\[Dagger]"*"L"^2, 
    "D"^2*"ec"^2*"H\[Dagger]"^4}, D^2*FL*\[Phi]^5 -> {}, 
  \[Phi]^3*\[Psi]^4 -> {"ec"*"H\[Dagger]"^3*"Q"^3, "H"^3*"L"^2*"Q"*"uc", 
    "ec"^2*"H\[Dagger]"^3*"Q"*"uc", "dc"*"H"^2*"H\[Dagger]"*"L"^2*"Q", 
    "dc"*"H"^3*"L"*"uc"^2, "dc"^2*"H"^2*"H\[Dagger]"*"L"*"uc", 
    "dc"^3*"H"*"H\[Dagger]"^2*"L", "ec"*"H"^2*"H\[Dagger]"*"L"^3}, 
  FL*\[Phi]^4*\[Psi]^2 -> {"H"^3*"H\[Dagger]"*"L"^2*"WL", 
    "ec"^2*"H\[Dagger]"^4*"WL", "BL"*"H"^3*"H\[Dagger]"*"L"^2, 
    "BL"*"ec"^2*"H\[Dagger]"^4}, FL^2*\[Phi]^5 -> {}, 
  \[Phi]^3*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"*"H"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"^2, 
    "H\[Dagger]"^3*"L\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "H"*"H\[Dagger]"^2*"L\[Dagger]"^2*"Q"*"uc", "dc"*"ec\[Dagger]"^2*"H"^3*
     "Q", "dc"*"H\[Dagger]"^3*"L\[Dagger]"^2*"Q", "ec\[Dagger]"*"H"^3*"L"*"Q"*
     "Q\[Dagger]", "dc\[Dagger]"^2*"ec"*"H"*"H\[Dagger]"^2*"Q", 
    "dc\[Dagger]"*"ec"*"H\[Dagger]"^3*"Q"*"uc\[Dagger]", 
    "ec\[Dagger]"*"H"^3*"L"*"uc"*"uc\[Dagger]", "dc\[Dagger]"*"ec"*"H"*
     "H\[Dagger]"^2*"L\[Dagger]"*"uc", "dc"*"dc\[Dagger]"*"ec\[Dagger]"*"H"^3*
     "L", "ec\[Dagger]"*"H"^3*"L"^2*"L\[Dagger]", "ec"*"ec\[Dagger]"^2*"H"^3*
     "L"}, D*\[Phi]^5*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"ec\[Dagger]"*"H"^4*"H\[Dagger]"*"L"}, D^2*\[Phi]^7 -> {}, 
  \[Phi]^6*\[Psi]^2 -> {"H"^4*"H\[Dagger]"^2*"L"^2, 
    "ec"^2*"H"*"H\[Dagger]"^5}, \[Phi]^9 -> {}|>, 
 <|D^2*FL^4 -> {"D"^2*"GL"^4, "BL"*"D"^2*"GL"^3, "D"^2*"GL"^2*"WL"^2, 
    "BL"^2*"D"^2*"GL"^2, "D"^2*"WL"^4, "BL"*"D"^2*"WL"^3, 
    "BL"^2*"D"^2*"WL"^2, "BL"^4*"D"^2}, D^2*FL^3*FR -> 
   {"D"^2*"GL"^3*"GR", "BR"*"D"^2*"GL"^3, "D"^2*"GL"^2*"WL"*"WR", 
    "BL"*"D"^2*"GL"^2*"GR", "BL"*"BR"*"D"^2*"GL"^2, "D"^2*"GL"*"GR"*"WL"^2, 
    "BL"^2*"D"^2*"GL"*"GR", "D"^2*"WL"^3*"WR", "BR"*"D"^2*"WL"^3, 
    "BL"*"D"^2*"WL"^2*"WR", "BL"*"BR"*"D"^2*"WL"^2, "BL"^2*"D"^2*"WL"*"WR", 
    "BL"^3*"BR"*"D"^2}, D^3*FL^2*\[Psi]*OverBar[\[Psi]] -> 
   {"D"^3*"GL"^2*"Q"*"Q\[Dagger]", "D"^3*"GL"^2*"uc"*"uc\[Dagger]", 
    "D"^3*"dc"*"dc\[Dagger]"*"GL"^2, "D"^3*"GL"^2*"L"*"L\[Dagger]", 
    "D"^3*"ec"*"ec\[Dagger]"*"GL"^2, "D"^3*"GL"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"D"^3*"GL"*"Q"*"Q\[Dagger]", "BL"*"D"^3*"GL"*"uc"*"uc\[Dagger]", 
    "BL"*"D"^3*"dc"*"dc\[Dagger]"*"GL", "D"^3*"Q"*"Q\[Dagger]"*"WL"^2, 
    "D"^3*"uc"*"uc\[Dagger]"*"WL"^2, "D"^3*"dc"*"dc\[Dagger]"*"WL"^2, 
    "D"^3*"L"*"L\[Dagger]"*"WL"^2, "D"^3*"ec"*"ec\[Dagger]"*"WL"^2, 
    "BL"*"D"^3*"Q"*"Q\[Dagger]"*"WL", "BL"*"D"^3*"L"*"L\[Dagger]"*"WL", 
    "BL"^2*"D"^3*"Q"*"Q\[Dagger]", "BL"^2*"D"^3*"uc"*"uc\[Dagger]", 
    "BL"^2*"D"^3*"dc"*"dc\[Dagger]", "BL"^2*"D"^3*"L"*"L\[Dagger]", 
    "BL"^2*"D"^3*"ec"*"ec\[Dagger]"}, D^4*\[Psi]^4 -> 
   {"D"^4*"L"*"Q"^3, "D"^4*"dc"*"Q"^2*"uc", "D"^4*"ec"*"L"*"Q"*"uc", 
    "D"^4*"dc"*"ec"*"uc"^2}, D^4*FL*\[Phi]*\[Psi]^2 -> 
   {"D"^4*"GL"*"H"*"Q"*"uc", "D"^4*"dc"*"GL"*"H\[Dagger]"*"Q", 
    "D"^4*"H"*"Q"*"uc"*"WL", "D"^4*"dc"*"H\[Dagger]"*"Q"*"WL", 
    "D"^4*"ec"*"H\[Dagger]"*"L"*"WL", "BL"*"D"^4*"H"*"Q"*"uc", 
    "BL"*"D"^4*"dc"*"H\[Dagger]"*"Q", "BL"*"D"^4*"ec"*"H\[Dagger]"*"L"}, 
  D^4*FL^2*\[Phi]^2 -> {"D"^4*"GL"^2*"H"*"H\[Dagger]", 
    "D"^4*"H"*"H\[Dagger]"*"WL"^2, "BL"*"D"^4*"H"*"H\[Dagger]"*"WL", 
    "BL"^2*"D"^4*"H"*"H\[Dagger]"}, D^2*FL^2*FR^2 -> 
   {"D"^2*"GL"^2*"GR"^2, "BR"*"D"^2*"GL"^2*"GR", "D"^2*"GL"^2*"WR"^2, 
    "BR"^2*"D"^2*"GL"^2, "D"^2*"GL"*"GR"*"WL"*"WR", 
    "BL"*"BR"*"D"^2*"GL"*"GR", "D"^2*"WL"^2*"WR"^2, "BR"*"D"^2*"WL"^2*"WR", 
    "BR"^2*"D"^2*"WL"^2, "BL"*"BR"*"D"^2*"WL"*"WR", "BL"^2*"BR"^2*"D"^2}, 
  D^3*FL*FR*\[Psi]*OverBar[\[Psi]] -> {"D"^3*"GL"*"GR"*"Q"*"Q\[Dagger]", 
    "D"^3*"GL"*"Q"*"Q\[Dagger]"*"WR", "BR"*"D"^3*"GL"*"Q"*"Q\[Dagger]", 
    "D"^3*"GL"*"GR"*"uc"*"uc\[Dagger]", "BR"*"D"^3*"GL"*"uc"*"uc\[Dagger]", 
    "D"^3*"dc"*"dc\[Dagger]"*"GL"*"GR", "BR"*"D"^3*"dc"*"dc\[Dagger]"*"GL", 
    "D"^3*"GL"*"GR"*"L"*"L\[Dagger]", "D"^3*"ec"*"ec\[Dagger]"*"GL"*"GR", 
    "D"^3*"Q"*"Q\[Dagger]"*"WL"*"WR", "BR"*"D"^3*"Q"*"Q\[Dagger]"*"WL", 
    "D"^3*"uc"*"uc\[Dagger]"*"WL"*"WR", "D"^3*"dc"*"dc\[Dagger]"*"WL"*"WR", 
    "D"^3*"L"*"L\[Dagger]"*"WL"*"WR", "BR"*"D"^3*"L"*"L\[Dagger]"*"WL", 
    "D"^3*"ec"*"ec\[Dagger]"*"WL"*"WR", "BL"*"BR"*"D"^3*"Q"*"Q\[Dagger]", 
    "BL"*"BR"*"D"^3*"uc"*"uc\[Dagger]", "BL"*"BR"*"D"^3*"dc"*"dc\[Dagger]", 
    "BL"*"BR"*"D"^3*"L"*"L\[Dagger]", "BL"*"BR"*"D"^3*"ec"*"ec\[Dagger]"}, 
  D^4*\[Psi]^2*OverBar[\[Psi]]^2 -> {"D"^4*"Q"^2*"Q\[Dagger]"^2, 
    "D"^4*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]", "D"^4*"Q"*"Q\[Dagger]"*"uc"*
     "uc\[Dagger]", "D"^4*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"^4*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q", "D"^4*"L"*"L\[Dagger]"*"Q"*
     "Q\[Dagger]", "D"^4*"dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]", 
    "D"^4*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]", "D"^4*"uc"^2*"uc\[Dagger]"^2, 
    "D"^4*"dc"*"dc\[Dagger]"*"uc"*"uc\[Dagger]", "D"^4*"L"*"L\[Dagger]"*"uc"*
     "uc\[Dagger]", "D"^4*"ec"*"ec\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^4*"dc"^2*"dc\[Dagger]"^2, "D"^4*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]", 
    "D"^4*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]", "D"^4*"L"^2*"L\[Dagger]"^2, 
    "D"^4*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]", "D"^4*"ec"^2*"ec\[Dagger]"^2}, 
  D^4*FR*\[Phi]*\[Psi]^2 -> {"D"^4*"GR"*"H"*"Q"*"uc", 
    "D"^4*"H"*"Q"*"uc"*"WR", "BR"*"D"^4*"H"*"Q"*"uc", 
    "D"^4*"dc"*"GR"*"H\[Dagger]"*"Q", "D"^4*"dc"*"H\[Dagger]"*"Q"*"WR", 
    "BR"*"D"^4*"dc"*"H\[Dagger]"*"Q", "D"^4*"ec"*"H\[Dagger]"*"L"*"WR", 
    "BR"*"D"^4*"ec"*"H\[Dagger]"*"L"}, D^4*FL*FR*\[Phi]^2 -> 
   {"D"^4*"GL"*"GR"*"H"*"H\[Dagger]", "D"^4*"H"*"H\[Dagger]"*"WL"*"WR", 
    "BR"*"D"^4*"H"*"H\[Dagger]"*"WL", "BL"*"BR"*"D"^4*"H"*"H\[Dagger]"}, 
  D^5*\[Phi]^2*\[Psi]*OverBar[\[Psi]] -> 
   {"D"^5*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", "D"^5*"dc\[Dagger]"*"H"^2*"uc", 
    "D"^5*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", "D"^5*"dc"*"dc\[Dagger]"*"H"*
     "H\[Dagger]", "D"^5*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "D"^5*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"}, 
  D^6*\[Phi]^4 -> {"D"^6*"H"^2*"H\[Dagger]"^2}, 
  FL^5 -> {"GL"^5, "BL"*"GL"^4, "GL"^3*"WL"^2, "BL"^2*"GL"^3, "GL"^2*"WL"^3, 
    "BL"*"GL"^2*"WL"^2, "BL"^3*"GL"^2, "WL"^5, "BL"*"WL"^4, "BL"^2*"WL"^3, 
    "BL"^3*"WL"^2, "BL"^5}, D*FL^3*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"GL"^3*"Q"*"Q\[Dagger]", "D"*"GL"^3*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"^3, "D"*"GL"^3*"L"*"L\[Dagger]", 
    "D"*"ec"*"ec\[Dagger]"*"GL"^3, "D"*"GL"^2*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"GL"^2*"L"*"L\[Dagger]"*"WL", "BL"*"D"*"GL"^2*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"GL"^2*"uc"*"uc\[Dagger]", "BL"*"D"*"dc"*"dc\[Dagger]"*"GL"^2, 
    "BL"*"D"*"GL"^2*"L"*"L\[Dagger]", "BL"*"D"*"ec"*"ec\[Dagger]"*"GL"^2, 
    "D"*"GL"*"Q"*"Q\[Dagger]"*"WL"^2, "D"*"GL"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"WL"^2, "BL"*"D"*"GL"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"^2*"D"*"GL"*"Q"*"Q\[Dagger]", "BL"^2*"D"*"GL"*"uc"*"uc\[Dagger]", 
    "BL"^2*"D"*"dc"*"dc\[Dagger]"*"GL", "D"*"Q"*"Q\[Dagger]"*"WL"^3, 
    "D"*"uc"*"uc\[Dagger]"*"WL"^3, "D"*"dc"*"dc\[Dagger]"*"WL"^3, 
    "D"*"L"*"L\[Dagger]"*"WL"^3, "D"*"ec"*"ec\[Dagger]"*"WL"^3, 
    "BL"*"D"*"Q"*"Q\[Dagger]"*"WL"^2, "BL"*"D"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"WL"^2, "BL"*"D"*"L"*"L\[Dagger]"*"WL"^2, 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"WL"^2, "BL"^2*"D"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"^2*"D"*"L"*"L\[Dagger]"*"WL", "BL"^3*"D"*"Q"*"Q\[Dagger]", 
    "BL"^3*"D"*"uc"*"uc\[Dagger]", "BL"^3*"D"*"dc"*"dc\[Dagger]", 
    "BL"^3*"D"*"L"*"L\[Dagger]", "BL"^3*"D"*"ec"*"ec\[Dagger]"}, 
  D^2*FL*\[Psi]^4 -> {"D"^2*"GL"*"L"*"Q"^3, "D"^2*"dc"*"GL"*"Q"^2*"uc", 
    "D"^2*"ec"*"GL"*"L"*"Q"*"uc", "D"^2*"dc"*"ec"*"GL"*"uc"^2, 
    "D"^2*"L"*"Q"^3*"WL", "D"^2*"dc"*"Q"^2*"uc"*"WL", 
    "D"^2*"ec"*"L"*"Q"*"uc"*"WL", "BL"*"D"^2*"L"*"Q"^3, 
    "BL"*"D"^2*"dc"*"Q"^2*"uc", "BL"*"D"^2*"ec"*"L"*"Q"*"uc", 
    "BL"*"D"^2*"dc"*"ec"*"uc"^2}, D^2*FL^2*\[Phi]*\[Psi]^2 -> 
   {"D"^2*"GL"^2*"H"*"Q"*"uc", "D"^2*"dc"*"GL"^2*"H\[Dagger]"*"Q", 
    "D"^2*"ec"*"GL"^2*"H\[Dagger]"*"L", "D"^2*"GL"*"H"*"Q"*"uc"*"WL", 
    "D"^2*"dc"*"GL"*"H\[Dagger]"*"Q"*"WL", "BL"*"D"^2*"GL"*"H"*"Q"*"uc", 
    "BL"*"D"^2*"dc"*"GL"*"H\[Dagger]"*"Q", "D"^2*"H"*"Q"*"uc"*"WL"^2, 
    "D"^2*"dc"*"H\[Dagger]"*"Q"*"WL"^2, "D"^2*"ec"*"H\[Dagger]"*"L"*"WL"^2, 
    "BL"*"D"^2*"H"*"Q"*"uc"*"WL", "BL"*"D"^2*"dc"*"H\[Dagger]"*"Q"*"WL", 
    "BL"*"D"^2*"ec"*"H\[Dagger]"*"L"*"WL", "BL"^2*"D"^2*"H"*"Q"*"uc", 
    "BL"^2*"D"^2*"dc"*"H\[Dagger]"*"Q", "BL"^2*"D"^2*"ec"*"H\[Dagger]"*"L"}, 
  D^2*FL^3*\[Phi]^2 -> {"D"^2*"GL"^3*"H"*"H\[Dagger]", 
    "D"^2*"GL"^2*"H"*"H\[Dagger]"*"WL", "BL"*"D"^2*"GL"^2*"H"*"H\[Dagger]", 
    "D"^2*"H"*"H\[Dagger]"*"WL"^3, "BL"*"D"^2*"H"*"H\[Dagger]"*"WL"^2, 
    "BL"^2*"D"^2*"H"*"H\[Dagger]"*"WL", "BL"^3*"D"^2*"H"*"H\[Dagger]"}, 
  FL^3*FR^2 -> {"GL"^3*"GR"^2, "BR"*"GL"^3*"GR", "GL"^3*"WR"^2, 
    "BR"^2*"GL"^3, "GL"^2*"GR"*"WL"*"WR", "GL"^2*"WL"*"WR"^2, 
    "BR"*"GL"^2*"WL"*"WR", "BL"*"GL"^2*"GR"^2, "BL"*"BR"*"GL"^2*"GR", 
    "BL"*"GL"^2*"WR"^2, "BL"*"BR"^2*"GL"^2, "GL"*"GR"^2*"WL"^2, 
    "GL"*"GR"*"WL"^2*"WR", "BR"*"GL"*"GR"*"WL"^2, "BL"*"GL"*"GR"*"WL"*"WR", 
    "BL"^2*"GL"*"GR"^2, "BL"^2*"BR"*"GL"*"GR", "GR"^2*"WL"^3, "WL"^3*"WR"^2, 
    "BR"*"WL"^3*"WR", "BR"^2*"WL"^3, "BL"*"GR"^2*"WL"^2, "BL"*"WL"^2*"WR"^2, 
    "BL"*"BR"*"WL"^2*"WR", "BL"*"BR"^2*"WL"^2, "BL"^2*"WL"*"WR"^2, 
    "BL"^2*"BR"*"WL"*"WR", "BL"^3*"GR"^2, "BL"^3*"WR"^2, "BL"^3*"BR"^2}, 
  D*FL^2*FR*\[Psi]*OverBar[\[Psi]] -> {"D"*"GL"^2*"GR"*"Q"*"Q\[Dagger]", 
    "D"*"GL"^2*"Q"*"Q\[Dagger]"*"WR", "BR"*"D"*"GL"^2*"Q"*"Q\[Dagger]", 
    "D"*"GL"^2*"GR"*"uc"*"uc\[Dagger]", "BR"*"D"*"GL"^2*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"^2*"GR", "BR"*"D"*"dc"*"dc\[Dagger]"*"GL"^2, 
    "D"*"GL"^2*"GR"*"L"*"L\[Dagger]", "D"*"GL"^2*"L"*"L\[Dagger]"*"WR", 
    "BR"*"D"*"GL"^2*"L"*"L\[Dagger]", "D"*"ec"*"ec\[Dagger]"*"GL"^2*"GR", 
    "BR"*"D"*"ec"*"ec\[Dagger]"*"GL"^2, "D"*"GL"*"GR"*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"GL"*"Q"*"Q\[Dagger]"*"WL"*"WR", "BR"*"D"*"GL"*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"GL"*"uc"*"uc\[Dagger]"*"WL"*"WR", "D"*"dc"*"dc\[Dagger]"*"GL"*"WL"*
     "WR", "D"*"GL"*"GR"*"L"*"L\[Dagger]"*"WL", "BL"*"D"*"GL"*"GR"*"Q"*
     "Q\[Dagger]", "BL"*"D"*"GL"*"Q"*"Q\[Dagger]"*"WR", 
    "BL"*"BR"*"D"*"GL"*"Q"*"Q\[Dagger]", "BL"*"D"*"GL"*"GR"*"uc"*
     "uc\[Dagger]", "BL"*"BR"*"D"*"GL"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"GL"*"GR", "BL"*"BR"*"D"*"dc"*"dc\[Dagger]"*
     "GL", "BL"*"D"*"GL"*"GR"*"L"*"L\[Dagger]", "BL"*"D"*"ec"*"ec\[Dagger]"*
     "GL"*"GR", "D"*"GR"*"Q"*"Q\[Dagger]"*"WL"^2, "D"*"Q"*"Q\[Dagger]"*"WL"^2*
     "WR", "BR"*"D"*"Q"*"Q\[Dagger]"*"WL"^2, "D"*"GR"*"uc"*"uc\[Dagger]"*
     "WL"^2, "D"*"uc"*"uc\[Dagger]"*"WL"^2*"WR", "BR"*"D"*"uc"*"uc\[Dagger]"*
     "WL"^2, "D"*"dc"*"dc\[Dagger]"*"GR"*"WL"^2, "D"*"dc"*"dc\[Dagger]"*
     "WL"^2*"WR", "BR"*"D"*"dc"*"dc\[Dagger]"*"WL"^2, 
    "D"*"L"*"L\[Dagger]"*"WL"^2*"WR", "BR"*"D"*"L"*"L\[Dagger]"*"WL"^2, 
    "D"*"ec"*"ec\[Dagger]"*"WL"^2*"WR", "BR"*"D"*"ec"*"ec\[Dagger]"*"WL"^2, 
    "BL"*"D"*"GR"*"Q"*"Q\[Dagger]"*"WL", "BL"*"D"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"D"*"Q"*"Q\[Dagger]"*"WL", "BL"*"D"*"uc"*"uc\[Dagger]"*"WL"*
     "WR", "BL"*"D"*"dc"*"dc\[Dagger]"*"WL"*"WR", "BL"*"D"*"L"*"L\[Dagger]"*
     "WL"*"WR", "BL"*"BR"*"D"*"L"*"L\[Dagger]"*"WL", 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"WL"*"WR", "BL"^2*"D"*"GR"*"Q"*"Q\[Dagger]", 
    "BL"^2*"D"*"Q"*"Q\[Dagger]"*"WR", "BL"^2*"BR"*"D"*"Q"*"Q\[Dagger]", 
    "BL"^2*"D"*"GR"*"uc"*"uc\[Dagger]", "BL"^2*"BR"*"D"*"uc"*"uc\[Dagger]", 
    "BL"^2*"D"*"dc"*"dc\[Dagger]"*"GR", "BL"^2*"BR"*"D"*"dc"*"dc\[Dagger]", 
    "BL"^2*"D"*"L"*"L\[Dagger]"*"WR", "BL"^2*"BR"*"D"*"L"*"L\[Dagger]", 
    "BL"^2*"BR"*"D"*"ec"*"ec\[Dagger]"}, D^2*FR*\[Psi]^4 -> 
   {"D"^2*"GR"*"L"*"Q"^3, "D"^2*"L"*"Q"^3*"WR", "BR"*"D"^2*"L"*"Q"^3, 
    "D"^2*"dc"*"GR"*"Q"^2*"uc", "D"^2*"dc"*"Q"^2*"uc"*"WR", 
    "BR"*"D"^2*"dc"*"Q"^2*"uc", "D"^2*"ec"*"GR"*"L"*"Q"*"uc", 
    "D"^2*"ec"*"L"*"Q"*"uc"*"WR", "BR"*"D"^2*"ec"*"L"*"Q"*"uc", 
    "D"^2*"dc"*"ec"*"GR"*"uc"^2, "BR"*"D"^2*"dc"*"ec"*"uc"^2}, 
  D^2*FL*\[Psi]^2*OverBar[\[Psi]]^2 -> {"D"^2*"GL"*"Q"^2*"Q\[Dagger]"^2, 
    "D"^2*"ec\[Dagger]"*"GL"*"Q"^2*"uc\[Dagger]", "D"^2*"GL"*"Q"*"Q\[Dagger]"*
     "uc"*"uc\[Dagger]", "D"^2*"dc"*"dc\[Dagger]"*"GL"*"Q"*"Q\[Dagger]", 
    "D"^2*"dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q", 
    "D"^2*"GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", "D"^2*"dc\[Dagger]"*"GL"*
     "L"*"Q"*"uc\[Dagger]", "D"^2*"ec"*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]", 
    "D"^2*"GL"*"uc"^2*"uc\[Dagger]"^2, "D"^2*"dc"*"GL"*"L\[Dagger]"*
     "Q\[Dagger]"*"uc", "D"^2*"dc"*"dc\[Dagger]"*"GL"*"uc"*"uc\[Dagger]", 
    "D"^2*"GL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"ec"*"GL"*"Q\[Dagger]"^2*"uc", "D"^2*"ec"*"ec\[Dagger]"*"GL"*"uc"*
     "uc\[Dagger]", "D"^2*"dc"^2*"dc\[Dagger]"^2*"GL", 
    "D"^2*"dc"*"dc\[Dagger]"*"GL"*"L"*"L\[Dagger]", 
    "D"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL", 
    "D"^2*"dc\[Dagger]"*"ec"*"GL"*"L"*"Q\[Dagger]", 
    "D"^2*"Q"^2*"Q\[Dagger]"^2*"WL", "D"^2*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]"*
     "WL", "D"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"^2*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"^2*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"WL", 
    "D"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", "D"^2*"dc\[Dagger]"*"L"*"Q"*
     "uc\[Dagger]"*"WL", "D"^2*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"^2*"dc"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "D"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"^2*"ec"*"Q\[Dagger]"^2*"uc"*"WL", "D"^2*"dc"*"dc\[Dagger]"*"L"*
     "L\[Dagger]"*"WL", "D"^2*"L"^2*"L\[Dagger]"^2*"WL", 
    "D"^2*"dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]"*"WL", 
    "D"^2*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "BL"*"D"^2*"Q"^2*"Q\[Dagger]"^2, "BL"*"D"^2*"ec\[Dagger]"*"Q"^2*
     "uc\[Dagger]", "BL"*"D"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"^2*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"D"^2*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q", 
    "BL"*"D"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", "BL"*"D"^2*"dc\[Dagger]"*
     "L"*"Q"*"uc\[Dagger]", "BL"*"D"^2*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"D"^2*"uc"^2*"uc\[Dagger]"^2, "BL"*"D"^2*"dc"*"L\[Dagger]"*
     "Q\[Dagger]"*"uc", "BL"*"D"^2*"dc"*"dc\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"^2*"ec"*"Q\[Dagger]"^2*"uc", "BL"*"D"^2*"ec"*"ec\[Dagger]"*"uc"*
     "uc\[Dagger]", "BL"*"D"^2*"dc"^2*"dc\[Dagger]"^2, 
    "BL"*"D"^2*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"*"D"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]", 
    "BL"*"D"^2*"L"^2*"L\[Dagger]"^2, "BL"*"D"^2*"dc\[Dagger]"*"ec"*"L"*
     "Q\[Dagger]", "BL"*"D"^2*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"*"D"^2*"ec"^2*"ec\[Dagger]"^2}, D^2*FL*FR*\[Phi]*\[Psi]^2 -> 
   {"D"^2*"GL"*"GR"*"H"*"Q"*"uc", "D"^2*"GL"*"H"*"Q"*"uc"*"WR", 
    "BR"*"D"^2*"GL"*"H"*"Q"*"uc", "D"^2*"dc"*"GL"*"GR"*"H\[Dagger]"*"Q", 
    "D"^2*"dc"*"GL"*"H\[Dagger]"*"Q"*"WR", "BR"*"D"^2*"dc"*"GL"*"H\[Dagger]"*
     "Q", "D"^2*"ec"*"GL"*"GR"*"H\[Dagger]"*"L", "D"^2*"GR"*"H"*"Q"*"uc"*
     "WL", "D"^2*"H"*"Q"*"uc"*"WL"*"WR", "BR"*"D"^2*"H"*"Q"*"uc"*"WL", 
    "D"^2*"dc"*"GR"*"H\[Dagger]"*"Q"*"WL", "D"^2*"dc"*"H\[Dagger]"*"Q"*"WL"*
     "WR", "BR"*"D"^2*"dc"*"H\[Dagger]"*"Q"*"WL", "D"^2*"ec"*"H\[Dagger]"*"L"*
     "WL"*"WR", "BR"*"D"^2*"ec"*"H\[Dagger]"*"L"*"WL", 
    "BL"*"D"^2*"GR"*"H"*"Q"*"uc", "BL"*"D"^2*"H"*"Q"*"uc"*"WR", 
    "BL"*"BR"*"D"^2*"H"*"Q"*"uc", "BL"*"D"^2*"dc"*"GR"*"H\[Dagger]"*"Q", 
    "BL"*"D"^2*"dc"*"H\[Dagger]"*"Q"*"WR", "BL"*"BR"*"D"^2*"dc"*"H\[Dagger]"*
     "Q", "BL"*"D"^2*"ec"*"H\[Dagger]"*"L"*"WR", "BL"*"BR"*"D"^2*"ec"*
     "H\[Dagger]"*"L"}, D^2*FL^2*\[Phi]*OverBar[\[Psi]]^2 -> 
   {"D"^2*"dc\[Dagger]"*"GL"^2*"H"*"Q\[Dagger]", "D"^2*"ec\[Dagger]"*"GL"^2*
     "H"*"L\[Dagger]", "D"^2*"GL"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]"*"WL", 
    "D"^2*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"D"^2*"dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]", 
    "BL"*"D"^2*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL"^2, "D"^2*"ec\[Dagger]"*"H"*
     "L\[Dagger]"*"WL"^2, "D"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*
     "WL"^2, "BL"*"D"^2*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL", 
    "BL"*"D"^2*"ec\[Dagger]"*"H"*"L\[Dagger]"*"WL", 
    "BL"*"D"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"^2*"D"^2*"dc\[Dagger]"*"H"*"Q\[Dagger]", "BL"^2*"D"^2*"ec\[Dagger]"*
     "H"*"L\[Dagger]", "BL"^2*"D"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"}, 
  D^2*FL^2*FR*\[Phi]^2 -> {"D"^2*"GL"^2*"GR"*"H"*"H\[Dagger]", 
    "D"^2*"GL"^2*"H"*"H\[Dagger]"*"WR", "BR"*"D"^2*"GL"^2*"H"*"H\[Dagger]", 
    "D"^2*"GL"*"GR"*"H"*"H\[Dagger]"*"WL", "BL"*"D"^2*"GL"*"GR"*"H"*
     "H\[Dagger]", "D"^2*"H"*"H\[Dagger]"*"WL"^2*"WR", 
    "BR"*"D"^2*"H"*"H\[Dagger]"*"WL"^2, "BL"*"D"^2*"H"*"H\[Dagger]"*"WL"*
     "WR", "BL"*"BR"*"D"^2*"H"*"H\[Dagger]"*"WL", 
    "BL"^2*"D"^2*"H"*"H\[Dagger]"*"WR", "BL"^2*"BR"*"D"^2*"H"*"H\[Dagger]"}, 
  D^3*\[Phi]*\[Psi]^3*OverBar[\[Psi]] -> {"D"^3*"ec\[Dagger]"*"H"*"Q"^3, 
    "D"^3*"H"*"Q"^2*"Q\[Dagger]"*"uc", "D"^3*"dc"*"H\[Dagger]"*"Q"^2*
     "Q\[Dagger]", "D"^3*"dc\[Dagger]"*"H"*"L"*"Q"^2, 
    "D"^3*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]", "D"^3*"H"*"Q"*"uc"^2*
     "uc\[Dagger]", "D"^3*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc", 
    "D"^3*"dc"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "D"^3*"H"*"L"*"L\[Dagger]"*"Q"*"uc", "D"^3*"ec"*"ec\[Dagger]"*"H"*"Q"*
     "uc", "D"^3*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q", 
    "D"^3*"dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "D"^3*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q", 
    "D"^3*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", "D"^3*"dc"*"H"*"L\[Dagger]"*
     "uc"^2, "D"^3*"ec"*"H"*"Q\[Dagger]"*"uc"^2, "D"^3*"dc"^2*"H\[Dagger]"*
     "L\[Dagger]"*"uc", "D"^3*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "D"^3*"dc\[Dagger]"*"ec"*"H"*"L"*"uc", "D"^3*"ec"*"H\[Dagger]"*"L"*"uc"*
     "uc\[Dagger]", "D"^3*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L", 
    "D"^3*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]", "D"^3*"ec"^2*"ec\[Dagger]"*
     "H\[Dagger]"*"L"}, D^3*FL*\[Phi]^2*\[Psi]*OverBar[\[Psi]] -> 
   {"D"^3*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", "D"^3*"dc\[Dagger]"*"GL"*
     "H"^2*"uc", "D"^3*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^3*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]", 
    "D"^3*"dc"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]", "D"^3*"H"*"H\[Dagger]"*"Q"*
     "Q\[Dagger]"*"WL", "D"^3*"dc\[Dagger]"*"H"^2*"uc"*"WL", 
    "D"^3*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"^3*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"WL", 
    "D"^3*"dc"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", "D"^3*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"WL", "D"^3*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL", 
    "BL"*"D"^3*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", "BL"*"D"^3*"dc\[Dagger]"*
     "H"^2*"uc", "BL"*"D"^3*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"^3*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]", 
    "BL"*"D"^3*"dc"*"H\[Dagger]"^2*"uc\[Dagger]", "BL"*"D"^3*"H"*"H\[Dagger]"*
     "L"*"L\[Dagger]", "BL"*"D"^3*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"}, 
  D^4*\[Phi]^3*\[Psi]^2 -> {"D"^4*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "D"^4*"dc"*"H"*"H\[Dagger]"^2*"Q", "D"^4*"ec"*"H"*"H\[Dagger]"^2*"L"}, 
  D^4*FL*\[Phi]^4 -> {"D"^4*"H"^2*"H\[Dagger]"^2*"WL", 
    "BL"*"D"^4*"H"^2*"H\[Dagger]"^2}, FL^2*\[Psi]^4 -> 
   {"GL"^2*"L"*"Q"^3, "dc"*"GL"^2*"Q"^2*"uc", "ec"*"GL"^2*"L"*"Q"*"uc", 
    "dc"*"ec"*"GL"^2*"uc"^2, "GL"*"L"*"Q"^3*"WL", "dc"*"GL"*"Q"^2*"uc"*"WL", 
    "ec"*"GL"*"L"*"Q"*"uc"*"WL", "BL"*"GL"*"L"*"Q"^3, 
    "BL"*"dc"*"GL"*"Q"^2*"uc", "BL"*"ec"*"GL"*"L"*"Q"*"uc", 
    "BL"*"dc"*"ec"*"GL"*"uc"^2, "L"*"Q"^3*"WL"^2, "dc"*"Q"^2*"uc"*"WL"^2, 
    "ec"*"L"*"Q"*"uc"*"WL"^2, "dc"*"ec"*"uc"^2*"WL"^2, "BL"*"L"*"Q"^3*"WL", 
    "BL"*"dc"*"Q"^2*"uc"*"WL", "BL"*"ec"*"L"*"Q"*"uc"*"WL", "BL"^2*"L"*"Q"^3, 
    "BL"^2*"dc"*"Q"^2*"uc", "BL"^2*"ec"*"L"*"Q"*"uc", 
    "BL"^2*"dc"*"ec"*"uc"^2}, FL^3*\[Phi]*\[Psi]^2 -> 
   {"GL"^3*"H"*"Q"*"uc", "dc"*"GL"^3*"H\[Dagger]"*"Q", 
    "ec"*"GL"^3*"H\[Dagger]"*"L", "GL"^2*"H"*"Q"*"uc"*"WL", 
    "dc"*"GL"^2*"H\[Dagger]"*"Q"*"WL", "ec"*"GL"^2*"H\[Dagger]"*"L"*"WL", 
    "BL"*"GL"^2*"H"*"Q"*"uc", "BL"*"dc"*"GL"^2*"H\[Dagger]"*"Q", 
    "BL"*"ec"*"GL"^2*"H\[Dagger]"*"L", "GL"*"H"*"Q"*"uc"*"WL"^2, 
    "dc"*"GL"*"H\[Dagger]"*"Q"*"WL"^2, "BL"*"GL"*"H"*"Q"*"uc"*"WL", 
    "BL"*"dc"*"GL"*"H\[Dagger]"*"Q"*"WL", "BL"^2*"GL"*"H"*"Q"*"uc", 
    "BL"^2*"dc"*"GL"*"H\[Dagger]"*"Q", "H"*"Q"*"uc"*"WL"^3, 
    "dc"*"H\[Dagger]"*"Q"*"WL"^3, "ec"*"H\[Dagger]"*"L"*"WL"^3, 
    "BL"*"H"*"Q"*"uc"*"WL"^2, "BL"*"dc"*"H\[Dagger]"*"Q"*"WL"^2, 
    "BL"*"ec"*"H\[Dagger]"*"L"*"WL"^2, "BL"^2*"H"*"Q"*"uc"*"WL", 
    "BL"^2*"dc"*"H\[Dagger]"*"Q"*"WL", "BL"^2*"ec"*"H\[Dagger]"*"L"*"WL", 
    "BL"^3*"H"*"Q"*"uc", "BL"^3*"dc"*"H\[Dagger]"*"Q", 
    "BL"^3*"ec"*"H\[Dagger]"*"L"}, FL^4*\[Phi]^2 -> 
   {"GL"^4*"H"*"H\[Dagger]", "GL"^3*"H"*"H\[Dagger]"*"WL", 
    "BL"*"GL"^3*"H"*"H\[Dagger]", "GL"^2*"H"*"H\[Dagger]"*"WL"^2, 
    "BL"*"GL"^2*"H"*"H\[Dagger]"*"WL", "BL"^2*"GL"^2*"H"*"H\[Dagger]", 
    "H"*"H\[Dagger]"*"WL"^4, "BL"*"H"*"H\[Dagger]"*"WL"^3, 
    "BL"^2*"H"*"H\[Dagger]"*"WL"^2, "BL"^3*"H"*"H\[Dagger]"*"WL", 
    "BL"^4*"H"*"H\[Dagger]"}, FL^2*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"GL"^2*"Q"^2*"Q\[Dagger]"^2, "ec\[Dagger]"*"GL"^2*"Q"^2*"uc\[Dagger]", 
    "GL"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", "dc"*"dc\[Dagger]"*"GL"^2*"Q"*
     "Q\[Dagger]", "dc"*"ec\[Dagger]"*"GL"^2*"L\[Dagger]"*"Q", 
    "GL"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", "dc\[Dagger]"*"GL"^2*"L"*"Q"*
     "uc\[Dagger]", "ec"*"ec\[Dagger]"*"GL"^2*"Q"*"Q\[Dagger]", 
    "GL"^2*"uc"^2*"uc\[Dagger]"^2, "dc"*"GL"^2*"L\[Dagger]"*"Q\[Dagger]"*
     "uc", "dc"*"dc\[Dagger]"*"GL"^2*"uc"*"uc\[Dagger]", 
    "GL"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", "ec"*"GL"^2*"Q\[Dagger]"^2*
     "uc", "ec"*"ec\[Dagger]"*"GL"^2*"uc"*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2*"GL"^2, "dc"*"dc\[Dagger]"*"GL"^2*"L"*
     "L\[Dagger]", "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"^2, 
    "GL"^2*"L"^2*"L\[Dagger]"^2, "dc\[Dagger]"*"ec"*"GL"^2*"L"*"Q\[Dagger]", 
    "ec"*"ec\[Dagger]"*"GL"^2*"L"*"L\[Dagger]", "ec"^2*"ec\[Dagger]"^2*
     "GL"^2, "GL"*"Q"^2*"Q\[Dagger]"^2*"WL", "ec\[Dagger]"*"GL"*"Q"^2*
     "uc\[Dagger]"*"WL", "GL"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"GL"*"Q"*"Q\[Dagger]"*"WL", 
    "dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q"*"WL", 
    "GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", "dc\[Dagger]"*"GL"*"L"*"Q"*
     "uc\[Dagger]"*"WL", "ec"*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]"*"WL", 
    "dc"*"GL"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "GL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "ec"*"GL"*"Q\[Dagger]"^2*"uc"*"WL", "dc"*"dc\[Dagger]"*"GL"*"L"*
     "L\[Dagger]"*"WL", "dc\[Dagger]"*"ec"*"GL"*"L"*"Q\[Dagger]"*"WL", 
    "BL"*"GL"*"Q"^2*"Q\[Dagger]"^2, "BL"*"ec\[Dagger]"*"GL"*"Q"^2*
     "uc\[Dagger]", "BL"*"GL"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"GL"*"Q"*"Q\[Dagger]", 
    "BL"*"dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q", 
    "BL"*"GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", "BL"*"dc\[Dagger]"*"GL"*"L"*
     "Q"*"uc\[Dagger]", "BL"*"ec"*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]", 
    "BL"*"GL"*"uc"^2*"uc\[Dagger]"^2, "BL"*"dc"*"GL"*"L\[Dagger]"*
     "Q\[Dagger]"*"uc", "BL"*"dc"*"dc\[Dagger]"*"GL"*"uc"*"uc\[Dagger]", 
    "BL"*"GL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"ec"*"GL"*"Q\[Dagger]"^2*"uc", "BL"*"ec"*"ec\[Dagger]"*"GL"*"uc"*
     "uc\[Dagger]", "BL"*"dc"^2*"dc\[Dagger]"^2*"GL", 
    "BL"*"dc"*"dc\[Dagger]"*"GL"*"L"*"L\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL", 
    "BL"*"dc\[Dagger]"*"ec"*"GL"*"L"*"Q\[Dagger]", 
    "Q"^2*"Q\[Dagger]"^2*"WL"^2, "ec\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL"^2, 
    "Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, "dc"*"dc\[Dagger]"*"Q"*
     "Q\[Dagger]"*"WL"^2, "dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"WL"^2, 
    "L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, "dc\[Dagger]"*"L"*"Q"*
     "uc\[Dagger]"*"WL"^2, "ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "uc"^2*"uc\[Dagger]"^2*"WL"^2, "dc"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*
     "WL"^2, "dc"*"dc\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, "ec"*"Q\[Dagger]"^2*"uc"*
     "WL"^2, "ec"*"ec\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "dc"^2*"dc\[Dagger]"^2*"WL"^2, "dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*
     "WL"^2, "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"WL"^2, 
    "L"^2*"L\[Dagger]"^2*"WL"^2, "dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]"*"WL"^2, 
    "ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"WL"^2, "ec"^2*"ec\[Dagger]"^2*
     "WL"^2, "BL"*"Q"^2*"Q\[Dagger]"^2*"WL", "BL"*"ec\[Dagger]"*"Q"^2*
     "uc\[Dagger]"*"WL", "BL"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"WL", 
    "BL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", "BL"*"dc\[Dagger]"*"L"*"Q"*
     "uc\[Dagger]"*"WL", "BL"*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"dc"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "BL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"ec"*"Q\[Dagger]"^2*"uc"*"WL", "BL"*"dc"*"dc\[Dagger]"*"L"*
     "L\[Dagger]"*"WL", "BL"*"L"^2*"L\[Dagger]"^2*"WL", 
    "BL"*"dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]"*"WL", 
    "BL"*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "BL"^2*"Q"^2*"Q\[Dagger]"^2, "BL"^2*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "BL"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", "BL"^2*"dc"*"dc\[Dagger]"*"Q"*
     "Q\[Dagger]", "BL"^2*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q", 
    "BL"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", "BL"^2*"dc\[Dagger]"*"L"*"Q"*
     "uc\[Dagger]", "BL"^2*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"^2*"uc"^2*"uc\[Dagger]"^2, "BL"^2*"dc"*"L\[Dagger]"*"Q\[Dagger]"*
     "uc", "BL"^2*"dc"*"dc\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", "BL"^2*"ec"*"Q\[Dagger]"^2*
     "uc", "BL"^2*"ec"*"ec\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"dc"^2*"dc\[Dagger]"^2, "BL"^2*"dc"*"dc\[Dagger]"*"L"*
     "L\[Dagger]", "BL"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]", 
    "BL"^2*"L"^2*"L\[Dagger]"^2, "BL"^2*"dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]", 
    "BL"^2*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"^2*"ec"^2*"ec\[Dagger]"^2}, FL^3*\[Phi]*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"*"GL"^3*"H"*"Q\[Dagger]", "ec\[Dagger]"*"GL"^3*"H"*
     "L\[Dagger]", "GL"^3*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"GL"^2*"H"*"Q\[Dagger]"*"WL", "ec\[Dagger]"*"GL"^2*"H"*
     "L\[Dagger]"*"WL", "GL"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"*"GL"^2*"H"*"Q\[Dagger]", "BL"*"ec\[Dagger]"*"GL"^2*"H"*
     "L\[Dagger]", "BL"*"GL"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]"*"WL"^2, "GL"*"H\[Dagger]"*
     "Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, "BL"*"dc\[Dagger]"*"GL"*"H"*
     "Q\[Dagger]"*"WL", "BL"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*
     "WL", "BL"^2*"dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]", 
    "BL"^2*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL"^3, "ec\[Dagger]"*"H"*"L\[Dagger]"*
     "WL"^3, "H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^3, 
    "BL"*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL"^2, "BL"*"ec\[Dagger]"*"H"*
     "L\[Dagger]"*"WL"^2, "BL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*
     "WL"^2, "BL"^2*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL", 
    "BL"^2*"ec\[Dagger]"*"H"*"L\[Dagger]"*"WL", "BL"^2*"H\[Dagger]"*
     "Q\[Dagger]"*"uc\[Dagger]"*"WL", "BL"^3*"dc\[Dagger]"*"H"*"Q\[Dagger]", 
    "BL"^3*"ec\[Dagger]"*"H"*"L\[Dagger]", "BL"^3*"H\[Dagger]"*"Q\[Dagger]"*
     "uc\[Dagger]"}, D*\[Psi]^5*OverBar[\[Psi]] -> 
   {"D"*"dc"*"ec\[Dagger]"*"Q"^4, "D"*"L"*"Q"^4*"Q\[Dagger]", 
    "D"*"dc"*"Q"^3*"Q\[Dagger]"*"uc", "D"*"L"*"Q"^3*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"L"*"Q"^3, "D"*"L"^2*"L\[Dagger]"*"Q"^3, 
    "D"*"ec"*"ec\[Dagger]"*"L"*"Q"^3, "D"*"dc"*"Q"^2*"uc"^2*"uc\[Dagger]", 
    "D"*"dc"^2*"dc\[Dagger]"*"Q"^2*"uc", "D"*"dc"*"L"*"L\[Dagger]"*"Q"^2*
     "uc", "D"*"dc"*"ec"*"ec\[Dagger]"*"Q"^2*"uc", 
    "D"*"ec"*"L"*"Q"^2*"Q\[Dagger]"*"uc", "D"*"dc\[Dagger]"*"ec"*"L"^2*"Q"^2, 
    "D"*"dc"^2*"L\[Dagger]"*"Q"*"uc"^2, "D"*"dc"*"ec"*"Q"*"Q\[Dagger]"*
     "uc"^2, "D"*"ec"*"L"*"Q"*"uc"^2*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"L"*"Q"*"uc", "D"*"ec"*"L"^2*"L\[Dagger]"*"Q"*
     "uc", "D"*"ec"^2*"ec\[Dagger]"*"L"*"Q"*"uc", 
    "D"*"dc"*"ec"*"uc"^3*"uc\[Dagger]", "D"*"dc"^2*"dc\[Dagger]"*"ec"*"uc"^2, 
    "D"*"dc"*"ec"*"L"*"L\[Dagger]"*"uc"^2, "D"*"dc"*"ec"^2*"ec\[Dagger]"*
     "uc"^2, "D"*"ec"^2*"L"*"Q\[Dagger]"*"uc"^2, "D"*"dc\[Dagger]"*"ec"^2*
     "L"^2*"uc"}, D*FL*\[Phi]*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"*"ec\[Dagger]"*"GL"*"H"*"Q"^3, "D"*"GL"*"H"*"Q"^2*"Q\[Dagger]"*"uc", 
    "D"*"dc"*"GL"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"*"GL"*"H"*"L"*"Q"^2, "D"*"GL"*"H\[Dagger]"*"L"*"Q"^2*
     "uc\[Dagger]", "D"*"GL"*"H"*"Q"*"uc"^2*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"H"*"Q"*"uc", "D"*"dc"*"GL"*"H\[Dagger]"*"Q"*
     "uc"*"uc\[Dagger]", "D"*"GL"*"H"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "D"*"ec"*"ec\[Dagger]"*"GL"*"H"*"Q"*"uc", "D"*"dc"^2*"dc\[Dagger]"*"GL"*
     "H\[Dagger]"*"Q", "D"*"dc"*"GL"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "D"*"dc"*"ec"*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"Q", 
    "D"*"ec"*"GL"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "D"*"dc"*"GL"*"H"*"L\[Dagger]"*"uc"^2, "D"*"ec"*"GL"*"H"*"Q\[Dagger]"*
     "uc"^2, "D"*"dc"^2*"GL"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "D"*"dc"*"ec"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "D"*"dc\[Dagger]"*"ec"*"GL"*"H"*"L"*"uc", "D"*"ec"*"GL"*"H\[Dagger]"*"L"*
     "uc"*"uc\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"ec"*"GL"*"H\[Dagger]"*"L", 
    "D"*"ec\[Dagger]"*"H"*"Q"^3*"WL", "D"*"H"*"Q"^2*"Q\[Dagger]"*"uc"*"WL", 
    "D"*"dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"H"*"L"*"Q"^2*"WL", "D"*"H\[Dagger]"*"L"*"Q"^2*
     "uc\[Dagger]"*"WL", "D"*"H"*"Q"*"uc"^2*"uc\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc"*"WL", "D"*"dc"*"H\[Dagger]"*"Q"*"uc"*
     "uc\[Dagger]"*"WL", "D"*"H"*"L"*"L\[Dagger]"*"Q"*"uc"*"WL", 
    "D"*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc"*"WL", "D"*"dc"^2*"dc\[Dagger]"*
     "H\[Dagger]"*"Q"*"WL", "D"*"dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"WL", 
    "D"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"*"WL", 
    "D"*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"dc"*"H"*"L\[Dagger]"*"uc"^2*"WL", "D"*"ec"*"H"*"Q\[Dagger]"*"uc"^2*
     "WL", "D"*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WL", 
    "D"*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "D"*"dc\[Dagger]"*"ec"*"H"*"L"*"uc"*"WL", "D"*"ec"*"H\[Dagger]"*"L"*"uc"*
     "uc\[Dagger]"*"WL", "D"*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"*"WL", 
    "D"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"WL", 
    "D"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"WL", 
    "BL"*"D"*"ec\[Dagger]"*"H"*"Q"^3, "BL"*"D"*"H"*"Q"^2*"Q\[Dagger]"*"uc", 
    "BL"*"D"*"dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"*"H"*"L"*"Q"^2, "BL"*"D"*"H\[Dagger]"*"L"*"Q"^2*
     "uc\[Dagger]", "BL"*"D"*"H"*"Q"*"uc"^2*"uc\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc", "BL"*"D"*"dc"*"H\[Dagger]"*"Q"*
     "uc"*"uc\[Dagger]", "BL"*"D"*"H"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc", "BL"*"D"*"dc"^2*"dc\[Dagger]"*
     "H\[Dagger]"*"Q", "BL"*"D"*"dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "BL"*"D"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q", 
    "BL"*"D"*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"dc"*"H"*"L\[Dagger]"*"uc"^2, "BL"*"D"*"ec"*"H"*"Q\[Dagger]"*
     "uc"^2, "BL"*"D"*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "BL"*"D"*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "BL"*"D"*"dc\[Dagger]"*"ec"*"H"*"L"*"uc", "BL"*"D"*"ec"*"H\[Dagger]"*"L"*
     "uc"*"uc\[Dagger]", "BL"*"D"*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L", 
    "BL"*"D"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]", 
    "BL"*"D"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"}, 
  D*FL^2*\[Phi]^2*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"GL"^2*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", "D"*"dc\[Dagger]"*"GL"^2*
     "H"^2*"uc", "D"*"GL"^2*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"^2*"H"*"H\[Dagger]", 
    "D"*"dc"*"GL"^2*"H\[Dagger]"^2*"uc\[Dagger]", "D"*"GL"^2*"H"*"H\[Dagger]"*
     "L"*"L\[Dagger]", "D"*"ec"*"ec\[Dagger]"*"GL"^2*"H"*"H\[Dagger]", 
    "D"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"GL"*"H"^2*"uc"*"WL", "D"*"GL"*"H"*"H\[Dagger]"*"uc"*
     "uc\[Dagger]"*"WL", "D"*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"WL", 
    "D"*"dc"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"*"GL"*"H"^2*"uc", "BL"*"D"*"GL"*"H"*"H\[Dagger]"*
     "uc"*"uc\[Dagger]", "BL"*"D"*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]", 
    "BL"*"D"*"dc"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "D"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, "D"*"dc\[Dagger]"*"H"^2*
     "uc"*"WL"^2, "D"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"WL"^2, 
    "D"*"dc"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL"^2, "D"*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"WL"^2, "D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL"^2, 
    "BL"*"D"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"D"*"dc\[Dagger]"*"H"^2*"uc"*"WL", "BL"*"D"*"H"*"H\[Dagger]"*"uc"*
     "uc\[Dagger]"*"WL", "BL"*"D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"WL", 
    "BL"*"D"*"dc"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL", 
    "BL"^2*"D"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", "BL"^2*"D"*"dc\[Dagger]"*
     "H"^2*"uc", "BL"^2*"D"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]", 
    "BL"^2*"D"*"dc"*"H\[Dagger]"^2*"uc\[Dagger]", "BL"^2*"D"*"H"*"H\[Dagger]"*
     "L"*"L\[Dagger]", "BL"^2*"D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"}, 
  D^2*\[Phi]^2*\[Psi]^4 -> {"D"^2*"H"*"H\[Dagger]"*"L"*"Q"^3, 
    "D"^2*"H"^2*"Q"^2*"uc"^2, "D"^2*"dc"*"H"*"H\[Dagger]"*"Q"^2*"uc", 
    "D"^2*"dc"^2*"H\[Dagger]"^2*"Q"^2, "D"^2*"ec"*"H"*"H\[Dagger]"*"L"*"Q"*
     "uc", "D"^2*"dc"*"ec"*"H\[Dagger]"^2*"L"*"Q", "D"^2*"ec"*"H"^2*"uc"^3, 
    "D"^2*"dc"*"ec"*"H"*"H\[Dagger]"*"uc"^2, "D"^2*"dc"^2*"ec"*"H\[Dagger]"^2*
     "uc", "D"^2*"ec"^2*"H\[Dagger]"^2*"L"^2}, D^2*FL*\[Phi]^3*\[Psi]^2 -> 
   {"D"^2*"GL"*"H"^2*"H\[Dagger]"*"Q"*"uc", "D"^2*"dc"*"GL"*"H"*
     "H\[Dagger]"^2*"Q", "D"^2*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WL", 
    "D"^2*"dc"*"H"*"H\[Dagger]"^2*"Q"*"WL", "D"^2*"ec"*"H"*"H\[Dagger]"^2*"L"*
     "WL", "BL"*"D"^2*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "BL"*"D"^2*"dc"*"H"*"H\[Dagger]"^2*"Q", "BL"*"D"^2*"ec"*"H"*
     "H\[Dagger]"^2*"L"}, D^2*FL^2*\[Phi]^4 -> 
   {"D"^2*"GL"^2*"H"^2*"H\[Dagger]"^2, "D"^2*"H"^2*"H\[Dagger]"^2*"WL"^2, 
    "BL"*"D"^2*"H"^2*"H\[Dagger]"^2*"WL", "BL"^2*"D"^2*"H"^2*"H\[Dagger]"^2}, 
  FR^2*\[Psi]^4 -> {"GR"^2*"L"*"Q"^3, "GR"*"L"*"Q"^3*"WR", 
    "BR"*"GR"*"L"*"Q"^3, "L"*"Q"^3*"WR"^2, "BR"*"L"*"Q"^3*"WR", 
    "BR"^2*"L"*"Q"^3, "dc"*"GR"^2*"Q"^2*"uc", "dc"*"GR"*"Q"^2*"uc"*"WR", 
    "BR"*"dc"*"GR"*"Q"^2*"uc", "dc"*"Q"^2*"uc"*"WR"^2, 
    "BR"*"dc"*"Q"^2*"uc"*"WR", "BR"^2*"dc"*"Q"^2*"uc", 
    "ec"*"GR"^2*"L"*"Q"*"uc", "ec"*"GR"*"L"*"Q"*"uc"*"WR", 
    "BR"*"ec"*"GR"*"L"*"Q"*"uc", "ec"*"L"*"Q"*"uc"*"WR"^2, 
    "BR"*"ec"*"L"*"Q"*"uc"*"WR", "BR"^2*"ec"*"L"*"Q"*"uc", 
    "dc"*"ec"*"GR"^2*"uc"^2, "BR"*"dc"*"ec"*"GR"*"uc"^2, 
    "dc"*"ec"*"uc"^2*"WR"^2, "BR"^2*"dc"*"ec"*"uc"^2}, 
  FL*FR*\[Psi]^2*OverBar[\[Psi]]^2 -> {"GL"*"GR"*"Q"^2*"Q\[Dagger]"^2, 
    "GL"*"Q"^2*"Q\[Dagger]"^2*"WR", "BR"*"GL"*"Q"^2*"Q\[Dagger]"^2, 
    "ec\[Dagger]"*"GL"*"GR"*"Q"^2*"uc\[Dagger]", "ec\[Dagger]"*"GL"*"Q"^2*
     "uc\[Dagger]"*"WR", "BR"*"ec\[Dagger]"*"GL"*"Q"^2*"uc\[Dagger]", 
    "GL"*"GR"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "GL"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"GL"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"GL"*"GR"*"Q"*"Q\[Dagger]", 
    "dc"*"dc\[Dagger]"*"GL"*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"GL"*"Q"*"Q\[Dagger]", 
    "dc"*"ec\[Dagger]"*"GL"*"GR"*"L\[Dagger]"*"Q", 
    "dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q"*"WR", 
    "BR"*"dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q", 
    "GL"*"GR"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", "GL"*"L"*"L\[Dagger]"*"Q"*
     "Q\[Dagger]"*"WR", "BR"*"GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "dc\[Dagger]"*"GL"*"GR"*"L"*"Q"*"uc\[Dagger]", 
    "dc\[Dagger]"*"GL"*"L"*"Q"*"uc\[Dagger]"*"WR", 
    "BR"*"dc\[Dagger]"*"GL"*"L"*"Q"*"uc\[Dagger]", 
    "ec"*"ec\[Dagger]"*"GL"*"GR"*"Q"*"Q\[Dagger]", 
    "ec"*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"ec"*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]", 
    "GL"*"GR"*"uc"^2*"uc\[Dagger]"^2, "BR"*"GL"*"uc"^2*"uc\[Dagger]"^2, 
    "dc"*"GL"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"dc"*"GL"*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "dc"*"dc\[Dagger]"*"GL"*"GR"*"uc"*"uc\[Dagger]", 
    "BR"*"dc"*"dc\[Dagger]"*"GL"*"uc"*"uc\[Dagger]", 
    "GL"*"GR"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "GL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"GL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "ec"*"GL"*"Q\[Dagger]"^2*"uc"*"WR", "BR"*"ec"*"GL"*"Q\[Dagger]"^2*"uc", 
    "ec"*"ec\[Dagger]"*"GL"*"GR"*"uc"*"uc\[Dagger]", 
    "BR"*"ec"*"ec\[Dagger]"*"GL"*"uc"*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2*"GL"*"GR", "BR"*"dc"^2*"dc\[Dagger]"^2*"GL", 
    "dc"*"dc\[Dagger]"*"GL"*"GR"*"L"*"L\[Dagger]", 
    "dc"*"dc\[Dagger]"*"GL"*"L"*"L\[Dagger]"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"GL"*"L"*"L\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"GR", 
    "BR"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL", 
    "GL"*"GR"*"L"^2*"L\[Dagger]"^2, "dc\[Dagger]"*"ec"*"GL"*"L"*"Q\[Dagger]"*
     "WR", "BR"*"dc\[Dagger]"*"ec"*"GL"*"L"*"Q\[Dagger]", 
    "ec"*"ec\[Dagger]"*"GL"*"GR"*"L"*"L\[Dagger]", 
    "ec"^2*"ec\[Dagger]"^2*"GL"*"GR", "Q"^2*"Q\[Dagger]"^2*"WL"*"WR", 
    "BR"*"Q"^2*"Q\[Dagger]"^2*"WL", "ec\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL"*
     "WR", "BR"*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL", 
    "Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"WL"*"WR", 
    "BR"*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"WL", 
    "L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"*"WR", "BR"*"L"*"L\[Dagger]"*"Q"*
     "Q\[Dagger]"*"WL", "dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*"WL", 
    "ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BR"*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "uc"^2*"uc\[Dagger]"^2*"WL"*"WR", "BR"*"dc"*"L\[Dagger]"*"Q\[Dagger]"*
     "uc"*"WL", "dc"*"dc\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BR"*"ec"*"Q\[Dagger]"^2*"uc"*"WL", "ec"*"ec\[Dagger]"*"uc"*"uc\[Dagger]"*
     "WL"*"WR", "dc"^2*"dc\[Dagger]"^2*"WL"*"WR", "dc"*"dc\[Dagger]"*"L"*
     "L\[Dagger]"*"WL"*"WR", "BR"*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"WL"*"WR", 
    "L"^2*"L\[Dagger]"^2*"WL"*"WR", "BR"*"L"^2*"L\[Dagger]"^2*"WL", 
    "BR"*"dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]"*"WL", 
    "ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"WL"*"WR", 
    "BR"*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "ec"^2*"ec\[Dagger]"^2*"WL"*"WR", "BL"*"BR"*"Q"^2*"Q\[Dagger]"^2, 
    "BL"*"BR"*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]", "BL"*"BR"*"Q"*"Q\[Dagger]"*
     "uc"*"uc\[Dagger]", "BL"*"BR"*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"BR"*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q", 
    "BL"*"BR"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", "BL"*"BR"*"dc\[Dagger]"*"L"*
     "Q"*"uc\[Dagger]", "BL"*"BR"*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"BR"*"uc"^2*"uc\[Dagger]"^2, "BL"*"BR"*"dc"*"dc\[Dagger]"*"uc"*
     "uc\[Dagger]", "BL"*"BR"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"BR"*"ec"*"ec\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"BR"*"dc"^2*"dc\[Dagger]"^2, "BL"*"BR"*"dc"*"dc\[Dagger]"*"L"*
     "L\[Dagger]", "BL"*"BR"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]", 
    "BL"*"BR"*"L"^2*"L\[Dagger]"^2, "BL"*"BR"*"ec"*"ec\[Dagger]"*"L"*
     "L\[Dagger]", "BL"*"BR"*"ec"^2*"ec\[Dagger]"^2}, 
  FL*FR^2*\[Phi]*\[Psi]^2 -> {"GL"*"GR"^2*"H"*"Q"*"uc", 
    "GL"*"GR"*"H"*"Q"*"uc"*"WR", "BR"*"GL"*"GR"*"H"*"Q"*"uc", 
    "GL"*"H"*"Q"*"uc"*"WR"^2, "BR"*"GL"*"H"*"Q"*"uc"*"WR", 
    "BR"^2*"GL"*"H"*"Q"*"uc", "dc"*"GL"*"GR"^2*"H\[Dagger]"*"Q", 
    "dc"*"GL"*"GR"*"H\[Dagger]"*"Q"*"WR", "BR"*"dc"*"GL"*"GR"*"H\[Dagger]"*
     "Q", "dc"*"GL"*"H\[Dagger]"*"Q"*"WR"^2, "BR"*"dc"*"GL"*"H\[Dagger]"*"Q"*
     "WR", "BR"^2*"dc"*"GL"*"H\[Dagger]"*"Q", "ec"*"GL"*"GR"^2*"H\[Dagger]"*
     "L", "ec"*"GL"*"GR"*"H\[Dagger]"*"L"*"WR", "BR"*"ec"*"GL"*"GR"*
     "H\[Dagger]"*"L", "GR"^2*"H"*"Q"*"uc"*"WL", "GR"*"H"*"Q"*"uc"*"WL"*"WR", 
    "BR"*"GR"*"H"*"Q"*"uc"*"WL", "H"*"Q"*"uc"*"WL"*"WR"^2, 
    "BR"*"H"*"Q"*"uc"*"WL"*"WR", "BR"^2*"H"*"Q"*"uc"*"WL", 
    "dc"*"GR"^2*"H\[Dagger]"*"Q"*"WL", "dc"*"GR"*"H\[Dagger]"*"Q"*"WL"*"WR", 
    "BR"*"dc"*"GR"*"H\[Dagger]"*"Q"*"WL", "dc"*"H\[Dagger]"*"Q"*"WL"*"WR"^2, 
    "BR"*"dc"*"H\[Dagger]"*"Q"*"WL"*"WR", "BR"^2*"dc"*"H\[Dagger]"*"Q"*"WL", 
    "ec"*"GR"^2*"H\[Dagger]"*"L"*"WL", "ec"*"H\[Dagger]"*"L"*"WL"*"WR"^2, 
    "BR"*"ec"*"H\[Dagger]"*"L"*"WL"*"WR", "BR"^2*"ec"*"H\[Dagger]"*"L"*"WL", 
    "BL"*"GR"^2*"H"*"Q"*"uc", "BL"*"GR"*"H"*"Q"*"uc"*"WR", 
    "BL"*"BR"*"GR"*"H"*"Q"*"uc", "BL"*"H"*"Q"*"uc"*"WR"^2, 
    "BL"*"BR"*"H"*"Q"*"uc"*"WR", "BL"*"BR"^2*"H"*"Q"*"uc", 
    "BL"*"dc"*"GR"^2*"H\[Dagger]"*"Q", "BL"*"dc"*"GR"*"H\[Dagger]"*"Q"*"WR", 
    "BL"*"BR"*"dc"*"GR"*"H\[Dagger]"*"Q", "BL"*"dc"*"H\[Dagger]"*"Q"*"WR"^2, 
    "BL"*"BR"*"dc"*"H\[Dagger]"*"Q"*"WR", "BL"*"BR"^2*"dc"*"H\[Dagger]"*"Q", 
    "BL"*"ec"*"GR"^2*"H\[Dagger]"*"L", "BL"*"ec"*"H\[Dagger]"*"L"*"WR"^2, 
    "BL"*"BR"*"ec"*"H\[Dagger]"*"L"*"WR", "BL"*"BR"^2*"ec"*"H\[Dagger]"*"L"}, 
  FL^2*FR^2*\[Phi]^2 -> {"GL"^2*"GR"^2*"H"*"H\[Dagger]", 
    "GL"^2*"GR"*"H"*"H\[Dagger]"*"WR", "BR"*"GL"^2*"GR"*"H"*"H\[Dagger]", 
    "GL"^2*"H"*"H\[Dagger]"*"WR"^2, "BR"*"GL"^2*"H"*"H\[Dagger]"*"WR", 
    "BR"^2*"GL"^2*"H"*"H\[Dagger]", "GL"*"GR"*"H"*"H\[Dagger]"*"WL"*"WR", 
    "BR"*"GL"*"GR"*"H"*"H\[Dagger]"*"WL", "BL"*"BR"*"GL"*"GR"*"H"*
     "H\[Dagger]", "H"*"H\[Dagger]"*"WL"^2*"WR"^2, 
    "BR"*"H"*"H\[Dagger]"*"WL"^2*"WR", "BR"^2*"H"*"H\[Dagger]"*"WL"^2, 
    "BL"*"BR"*"H"*"H\[Dagger]"*"WL"*"WR", "BL"*"BR"^2*"H"*"H\[Dagger]"*"WL", 
    "BL"^2*"BR"^2*"H"*"H\[Dagger]"}, D*\[Psi]^3*OverBar[\[Psi]]^3 -> 
   {"D"*"Q"^3*"Q\[Dagger]"^3, "D"*"ec\[Dagger]"*"Q"^3*"Q\[Dagger]"*
     "uc\[Dagger]", "D"*"Q"^2*"Q\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"*"ec\[Dagger]"*"Q"^2*"uc"*"uc\[Dagger]"^2, "D"*"dc"*"dc\[Dagger]"*
     "Q"^2*"Q\[Dagger]"^2, "D"*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"^2*
     "Q\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "D"*"L"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, "D"*"dc\[Dagger]"*"L"*"Q"^2*
     "Q\[Dagger]"*"uc\[Dagger]", "D"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"Q"^2*
     "uc\[Dagger]", "D"*"ec"*"ec\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, 
    "D"*"ec"*"ec\[Dagger]"^2*"Q"^2*"uc\[Dagger]", "D"*"Q"*"Q\[Dagger]"*"uc"^2*
     "uc\[Dagger]"^2, "D"*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*
     "uc\[Dagger]", "D"*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"uc"*
     "uc\[Dagger]", "D"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"*"dc\[Dagger]"*"L"*"Q"*"uc"*"uc\[Dagger]"^2, 
    "D"*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"*"dc"^2*"dc\[Dagger]"^2*"Q"*"Q\[Dagger]", "D"*"dc"^2*"dc\[Dagger]"*
     "ec\[Dagger]"*"L\[Dagger]"*"Q", "D"*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*
     "Q"*"Q\[Dagger]", "D"*"dc"*"dc\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]", 
    "D"*"dc"*"ec\[Dagger]"*"L"*"L\[Dagger]"^2*"Q", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"*"dc"*"ec"*"ec\[Dagger]"^2*"L\[Dagger]"*"Q", 
    "D"*"L"^2*"L\[Dagger]"^2*"Q"*"Q\[Dagger]", "D"*"dc\[Dagger]"*"L"^2*
     "L\[Dagger]"*"Q"*"uc\[Dagger]", "D"*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*
     "Q"*"Q\[Dagger]", "D"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"L"*"Q"*
     "uc\[Dagger]", "D"*"ec"^2*"ec\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "D"*"uc"^3*"uc\[Dagger]"^3, "D"*"dc"*"dc\[Dagger]"*"uc"^2*
     "uc\[Dagger]"^2, "D"*"L"*"L\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "D"*"ec"*"ec\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "D"*"dc"^2*"dc\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"*"dc"^2*"ec\[Dagger]"*"L\[Dagger]"^2*"uc", "D"*"dc"*"dc\[Dagger]"*"L"*
     "L\[Dagger]"*"uc"*"uc\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"ec"*
     "ec\[Dagger]"*"uc"*"uc\[Dagger]", "D"*"L"^2*"L\[Dagger]"^2*"uc"*
     "uc\[Dagger]", "D"*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"uc"*
     "uc\[Dagger]", "D"*"ec"^2*"ec\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"*"dc"^3*"dc\[Dagger]"^3, "D"*"dc"^2*"dc\[Dagger]"^2*"L"*"L\[Dagger]", 
    "D"*"dc"^2*"dc\[Dagger]"^2*"ec"*"ec\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"L"^2*"L\[Dagger]"^2, "D"*"dc"*"dc\[Dagger]"*"ec"*
     "ec\[Dagger]"*"L"*"L\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"ec"^2*
     "ec\[Dagger]"^2, "D"*"L"^3*"L\[Dagger]"^3, "D"*"ec"*"ec\[Dagger]"*"L"^2*
     "L\[Dagger]"^2, "D"*"ec"^2*"ec\[Dagger]"^2*"L"*"L\[Dagger]", 
    "D"*"ec"^3*"ec\[Dagger]"^3}, D*FR*\[Phi]*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"*"ec\[Dagger]"*"GR"*"H"*"Q"^3, "D"*"ec\[Dagger]"*"H"*"Q"^3*"WR", 
    "BR"*"D"*"ec\[Dagger]"*"H"*"Q"^3, "D"*"GR"*"H"*"Q"^2*"Q\[Dagger]"*"uc", 
    "D"*"H"*"Q"^2*"Q\[Dagger]"*"uc"*"WR", "BR"*"D"*"H"*"Q"^2*"Q\[Dagger]"*
     "uc", "D"*"dc"*"GR"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "D"*"dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"WR", 
    "BR"*"D"*"dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"*"GR"*"H"*"L"*"Q"^2, "D"*"dc\[Dagger]"*"H"*"L"*"Q"^2*
     "WR", "BR"*"D"*"dc\[Dagger]"*"H"*"L"*"Q"^2, "D"*"GR"*"H\[Dagger]"*"L"*
     "Q"^2*"uc\[Dagger]", "D"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]", 
    "D"*"GR"*"H"*"Q"*"uc"^2*"uc\[Dagger]", "D"*"H"*"Q"*"uc"^2*"uc\[Dagger]"*
     "WR", "BR"*"D"*"H"*"Q"*"uc"^2*"uc\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"GR"*
     "H"*"Q"*"uc", "D"*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc"*"WR", 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc", "D"*"dc"*"GR"*"H\[Dagger]"*"Q"*
     "uc"*"uc\[Dagger]", "D"*"dc"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"dc"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "D"*"GR"*"H"*"L"*"L\[Dagger]"*"Q"*"uc", "D"*"H"*"L"*"L\[Dagger]"*"Q"*"uc"*
     "WR", "BR"*"D"*"H"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "D"*"ec"*"ec\[Dagger]"*"GR"*"H"*"Q"*"uc", "D"*"ec"*"ec\[Dagger]"*"H"*"Q"*
     "uc"*"WR", "BR"*"D"*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc", 
    "D"*"dc"^2*"dc\[Dagger]"*"GR"*"H\[Dagger]"*"Q", 
    "D"*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q"*"WR", 
    "BR"*"D"*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q", 
    "D"*"dc"*"GR"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "D"*"dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"WR", 
    "BR"*"D"*"dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "D"*"dc"*"ec"*"ec\[Dagger]"*"GR"*"H\[Dagger]"*"Q", 
    "D"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"*"WR", 
    "BR"*"D"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q", 
    "D"*"ec"*"GR"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "D"*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"D"*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "D"*"dc"*"GR"*"H"*"L\[Dagger]"*"uc"^2, "D"*"dc"*"H"*"L\[Dagger]"*"uc"^2*
     "WR", "BR"*"D"*"dc"*"H"*"L\[Dagger]"*"uc"^2, 
    "D"*"ec"*"GR"*"H"*"Q\[Dagger]"*"uc"^2, "D"*"ec"*"H"*"Q\[Dagger]"*"uc"^2*
     "WR", "BR"*"D"*"ec"*"H"*"Q\[Dagger]"*"uc"^2, 
    "D"*"dc"^2*"GR"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "D"*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WR", 
    "BR"*"D"*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "D"*"dc"*"ec"*"GR"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "D"*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"D"*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "D"*"dc\[Dagger]"*"ec"*"GR"*"H"*"L"*"uc", "D"*"dc\[Dagger]"*"ec"*"H"*"L"*
     "uc"*"WR", "BR"*"D"*"dc\[Dagger]"*"ec"*"H"*"L"*"uc", 
    "D"*"ec"*"GR"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", 
    "D"*"ec"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"ec"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"GR"*"H\[Dagger]"*"L", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"*"WR", 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L", 
    "D"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"WR", 
    "BR"*"D"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]", 
    "D"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"WR", 
    "BR"*"D"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"}, 
  D*FL*FR*\[Phi]^2*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"GL"*"GR"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"D"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"*"GL"*"GR"*"H"^2*"uc", "D"*"dc\[Dagger]"*"GL"*"H"^2*"uc"*
     "WR", "BR"*"D"*"dc\[Dagger]"*"GL"*"H"^2*"uc", 
    "D"*"GL"*"GR"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"GR"*"H"*"H\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"WR", 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]", 
    "D"*"dc"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"dc"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "D"*"GL"*"GR"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "D"*"ec"*"ec\[Dagger]"*"GL"*"GR"*"H"*"H\[Dagger]", 
    "D"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BR"*"D"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"H"^2*"uc"*"WL"*"WR", "BR"*"D"*"dc\[Dagger]"*"H"^2*"uc"*
     "WL", "D"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"D"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"WL"*"WR", 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"WL", 
    "BR"*"D"*"dc"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "D"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL"*"WR", 
    "BR"*"D"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL"*"WR", 
    "BR"*"D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL", 
    "BL"*"BR"*"D"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"BR"*"D"*"dc\[Dagger]"*"H"^2*"uc", "BL"*"BR"*"D"*"H"*"H\[Dagger]"*
     "uc"*"uc\[Dagger]", "BL"*"BR"*"D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]", 
    "BL"*"BR"*"D"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"*"BR"*"D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"}, 
  D^2*\[Phi]^2*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"D"^2*"dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"Q"^2, 
    "D"^2*"H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, "D"^2*"ec\[Dagger]"*"H"*
     "H\[Dagger]"*"Q"^2*"uc\[Dagger]", "D"^2*"dc\[Dagger]"*"H"^2*"Q"*
     "Q\[Dagger]"*"uc", "D"^2*"ec\[Dagger]"*"H"^2*"L\[Dagger]"*"Q"*"uc", 
    "D"^2*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"^2*"dc"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q", 
    "D"^2*"dc\[Dagger]"^2*"H"^2*"L"*"Q", "D"^2*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"*"Q\[Dagger]", "D"^2*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*
     "Q"*"uc\[Dagger]", "D"^2*"H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"^2, 
    "D"^2*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"H"^2*"uc"^2*"uc\[Dagger]", 
    "D"^2*"H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "D"^2*"dc"*"dc\[Dagger]"^2*"H"^2*"uc", "D"^2*"dc"*"dc\[Dagger]"*"H"*
     "H\[Dagger]"*"uc"*"uc\[Dagger]", "D"^2*"dc\[Dagger]"*"H"^2*"L"*
     "L\[Dagger]"*"uc", "D"^2*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*
     "uc\[Dagger]", "D"^2*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*"uc", 
    "D"^2*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"dc"^2*"dc\[Dagger]"^2*"H"*"H\[Dagger]", 
    "D"^2*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "D"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]", 
    "D"^2*"H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2, "D"^2*"ec"*"ec\[Dagger]"*"H"*
     "H\[Dagger]"*"L"*"L\[Dagger]", "D"^2*"ec"^2*"ec\[Dagger]"^2*"H"*
     "H\[Dagger]"}, D^2*FR*\[Phi]^3*\[Psi]^2 -> 
   {"D"^2*"GR"*"H"^2*"H\[Dagger]"*"Q"*"uc", "D"^2*"H"^2*"H\[Dagger]"*"Q"*"uc"*
     "WR", "BR"*"D"^2*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "D"^2*"dc"*"GR"*"H"*"H\[Dagger]"^2*"Q", "D"^2*"dc"*"H"*"H\[Dagger]"^2*"Q"*
     "WR", "BR"*"D"^2*"dc"*"H"*"H\[Dagger]"^2*"Q", 
    "D"^2*"ec"*"H"*"H\[Dagger]"^2*"L"*"WR", "BR"*"D"^2*"ec"*"H"*
     "H\[Dagger]"^2*"L"}, D^2*FL*FR*\[Phi]^4 -> 
   {"D"^2*"GL"*"GR"*"H"^2*"H\[Dagger]"^2, "D"^2*"H"^2*"H\[Dagger]"^2*"WL"*
     "WR", "BR"*"D"^2*"H"^2*"H\[Dagger]"^2*"WL", "BL"*"BR"*"D"^2*"H"^2*
     "H\[Dagger]"^2}, D^3*\[Phi]^4*\[Psi]*OverBar[\[Psi]] -> 
   {"D"^3*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", "D"^3*"dc\[Dagger]"*"H"^3*
     "H\[Dagger]"*"uc", "D"^3*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"^3*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2, 
    "D"^3*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]", "D"^3*"ec"*"ec\[Dagger]"*
     "H"^2*"H\[Dagger]"^2}, D^4*\[Phi]^6 -> {"D"^4*"H"^3*"H\[Dagger]"^3}, 
  \[Phi]*\[Psi]^6 -> {"H"*"L"*"Q"^4*"uc", "dc"*"H\[Dagger]"*"L"*"Q"^4, 
    "dc"*"H"*"Q"^3*"uc"^2, "dc"^2*"H\[Dagger]"*"Q"^3*"uc", 
    "ec"*"H\[Dagger]"*"L"^2*"Q"^3, "ec"*"H"*"L"*"Q"^2*"uc"^2, 
    "dc"*"ec"*"H\[Dagger]"*"L"*"Q"^2*"uc", "dc"*"ec"*"H"*"Q"*"uc"^3, 
    "dc"^2*"ec"*"H\[Dagger]"*"Q"*"uc"^2, "ec"^2*"H\[Dagger]"*"L"^2*"Q"*"uc", 
    "ec"^2*"H"*"L"*"uc"^3, "dc"*"ec"^2*"H\[Dagger]"*"L"*"uc"^2, 
    "dc"^3*"H"*"L"^3}, FL*\[Phi]^2*\[Psi]^4 -> 
   {"GL"*"H"*"H\[Dagger]"*"L"*"Q"^3, "GL"*"H"^2*"Q"^2*"uc"^2, 
    "dc"*"GL"*"H"*"H\[Dagger]"*"Q"^2*"uc", "dc"^2*"GL"*"H\[Dagger]"^2*"Q"^2, 
    "ec"*"GL"*"H"*"H\[Dagger]"*"L"*"Q"*"uc", "dc"*"ec"*"GL"*"H\[Dagger]"^2*
     "L"*"Q", "ec"*"GL"*"H"^2*"uc"^3, "dc"*"ec"*"GL"*"H"*"H\[Dagger]"*"uc"^2, 
    "dc"^2*"ec"*"GL"*"H\[Dagger]"^2*"uc", "H"*"H\[Dagger]"*"L"*"Q"^3*"WL", 
    "H"^2*"Q"^2*"uc"^2*"WL", "dc"*"H"*"H\[Dagger]"*"Q"^2*"uc"*"WL", 
    "dc"^2*"H\[Dagger]"^2*"Q"^2*"WL", "ec"*"H"*"H\[Dagger]"*"L"*"Q"*"uc"*
     "WL", "dc"*"ec"*"H\[Dagger]"^2*"L"*"Q"*"WL", "ec"*"H"^2*"uc"^3*"WL", 
    "dc"*"ec"*"H"*"H\[Dagger]"*"uc"^2*"WL", "dc"^2*"ec"*"H\[Dagger]"^2*"uc"*
     "WL", "ec"^2*"H\[Dagger]"^2*"L"^2*"WL", "BL"*"H"*"H\[Dagger]"*"L"*"Q"^3, 
    "BL"*"H"^2*"Q"^2*"uc"^2, "BL"*"dc"*"H"*"H\[Dagger]"*"Q"^2*"uc", 
    "BL"*"dc"^2*"H\[Dagger]"^2*"Q"^2, "BL"*"ec"*"H"*"H\[Dagger]"*"L"*"Q"*
     "uc", "BL"*"dc"*"ec"*"H\[Dagger]"^2*"L"*"Q", "BL"*"ec"*"H"^2*"uc"^3, 
    "BL"*"dc"*"ec"*"H"*"H\[Dagger]"*"uc"^2, "BL"*"dc"^2*"ec"*"H\[Dagger]"^2*
     "uc", "BL"*"ec"^2*"H\[Dagger]"^2*"L"^2}, FL^2*\[Phi]^3*\[Psi]^2 -> 
   {"GL"^2*"H"^2*"H\[Dagger]"*"Q"*"uc", "dc"*"GL"^2*"H"*"H\[Dagger]"^2*"Q", 
    "ec"*"GL"^2*"H"*"H\[Dagger]"^2*"L", "GL"*"H"^2*"H\[Dagger]"*"Q"*"uc"*
     "WL", "dc"*"GL"*"H"*"H\[Dagger]"^2*"Q"*"WL", 
    "BL"*"GL"*"H"^2*"H\[Dagger]"*"Q"*"uc", "BL"*"dc"*"GL"*"H"*"H\[Dagger]"^2*
     "Q", "H"^2*"H\[Dagger]"*"Q"*"uc"*"WL"^2, "dc"*"H"*"H\[Dagger]"^2*"Q"*
     "WL"^2, "ec"*"H"*"H\[Dagger]"^2*"L"*"WL"^2, "BL"*"H"^2*"H\[Dagger]"*"Q"*
     "uc"*"WL", "BL"*"dc"*"H"*"H\[Dagger]"^2*"Q"*"WL", 
    "BL"*"ec"*"H"*"H\[Dagger]"^2*"L"*"WL", "BL"^2*"H"^2*"H\[Dagger]"*"Q"*
     "uc", "BL"^2*"dc"*"H"*"H\[Dagger]"^2*"Q", "BL"^2*"ec"*"H"*"H\[Dagger]"^2*
     "L"}, FL^3*\[Phi]^4 -> {"GL"^3*"H"^2*"H\[Dagger]"^2, 
    "GL"^2*"H"^2*"H\[Dagger]"^2*"WL", "BL"*"GL"^2*"H"^2*"H\[Dagger]"^2, 
    "H"^2*"H\[Dagger]"^2*"WL"^3, "BL"*"H"^2*"H\[Dagger]"^2*"WL"^2, 
    "BL"^2*"H"^2*"H\[Dagger]"^2*"WL", "BL"^3*"H"^2*"H\[Dagger]"^2}, 
  \[Phi]*\[Psi]^4*OverBar[\[Psi]]^2 -> {"ec\[Dagger]"*"H"*"Q"^4*"Q\[Dagger]", 
    "H"*"Q"^3*"Q\[Dagger]"^2*"uc", "ec\[Dagger]"*"H"*"Q"^3*"uc"*
     "uc\[Dagger]", "dc"*"dc\[Dagger]"*"ec\[Dagger]"*"H"*"Q"^3, 
    "dc"*"H\[Dagger]"*"Q"^3*"Q\[Dagger]"^2, "dc"*"ec\[Dagger]"*"H\[Dagger]"*
     "Q"^3*"uc\[Dagger]", "dc\[Dagger]"*"H"*"L"*"Q"^3*"Q\[Dagger]", 
    "ec\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q"^3, "H\[Dagger]"*"L"*"Q"^3*
     "Q\[Dagger]"*"uc\[Dagger]", "ec"*"ec\[Dagger]"^2*"H"*"Q"^3, 
    "H"*"Q"^2*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]", "dc"*"dc\[Dagger]"*"H"*"Q"^2*
     "Q\[Dagger]"*"uc", "dc"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"Q"^2*"uc", 
    "dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "H"*"L"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc", "dc\[Dagger]"*"H"*"L"*"Q"^2*
     "uc"*"uc\[Dagger]", "H\[Dagger]"*"L"*"Q"^2*"uc"*"uc\[Dagger]"^2, 
    "ec"*"ec\[Dagger]"*"H"*"Q"^2*"Q\[Dagger]"*"uc", 
    "dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "dc"^2*"ec\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "dc"*"dc\[Dagger]"^2*"H"*"L"*"Q"^2, "dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*
     "Q"^2*"Q\[Dagger]", "dc"*"dc\[Dagger]"*"H\[Dagger]"*"L"*"Q"^2*
     "uc\[Dagger]", "dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "dc\[Dagger]"*"H"*"L"^2*"L\[Dagger]"*"Q"^2, "H\[Dagger]"*"L"^2*
     "L\[Dagger]"*"Q"^2*"uc\[Dagger]", "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*
     "L"*"Q"^2, "ec"*"H\[Dagger]"*"L"*"Q"^2*"Q\[Dagger]"^2, 
    "ec"*"ec\[Dagger]"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]", 
    "H"*"Q"*"uc"^3*"uc\[Dagger]"^2, "dc"*"H"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*
     "uc"^2, "dc"*"dc\[Dagger]"*"H"*"Q"*"uc"^2*"uc\[Dagger]", 
    "dc"*"H\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]"^2, "H"*"L"*"L\[Dagger]"*"Q"*
     "uc"^2*"uc\[Dagger]", "ec"*"H"*"Q"*"Q\[Dagger]"^2*"uc"^2, 
    "ec"*"ec\[Dagger]"*"H"*"Q"*"uc"^2*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2*"H"*"Q"*"uc", "dc"^2*"H\[Dagger]"*"L\[Dagger]"*"Q"*
     "Q\[Dagger]"*"uc", "dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q"*"uc"*
     "uc\[Dagger]", "dc"*"dc\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc", 
    "dc"*"ec"*"H\[Dagger]"*"Q"*"Q\[Dagger]"^2*"uc", 
    "dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "H"*"L"^2*"L\[Dagger]"^2*"Q"*"uc", "dc\[Dagger]"*"ec"*"H"*"L"*"Q"*
     "Q\[Dagger]"*"uc", "ec"*"ec\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "ec"^2*"ec\[Dagger]"^2*"H"*"Q"*"uc", "dc"^3*"dc\[Dagger]"^2*"H\[Dagger]"*
     "Q", "dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "dc"^2*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q", 
    "dc"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2*"Q", "dc"*"dc\[Dagger]"*"ec"*
     "H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", "dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*
     "L"*"L\[Dagger]"*"Q", "dc"*"ec"^2*"ec\[Dagger]"^2*"H\[Dagger]"*"Q", 
    "dc\[Dagger]"^2*"ec"*"H"*"L"^2*"Q", "ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*
     "Q"*"Q\[Dagger]", "dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"^2*"Q"*
     "uc\[Dagger]", "ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "dc"*"H"*"L\[Dagger]"*"uc"^3*"uc\[Dagger]", "ec"*"H"*"Q\[Dagger]"*"uc"^3*
     "uc\[Dagger]", "dc"^2*"dc\[Dagger]"*"H"*"L\[Dagger]"*"uc"^2, 
    "dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "dc"*"H"*"L"*"L\[Dagger]"^2*"uc"^2, "dc"*"dc\[Dagger]"*"ec"*"H"*
     "Q\[Dagger]"*"uc"^2, "dc"*"ec"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"uc"^2, 
    "dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "ec"*"H"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2, 
    "dc\[Dagger]"*"ec"*"H"*"L"*"uc"^2*"uc\[Dagger]", 
    "ec"*"H\[Dagger]"*"L"*"uc"^2*"uc\[Dagger]"^2, "ec"^2*"ec\[Dagger]"*"H"*
     "Q\[Dagger]"*"uc"^2, "dc"^3*"dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*
     "uc", "dc"^2*"H\[Dagger]"*"L"*"L\[Dagger]"^2*"uc", 
    "dc"^2*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "dc"^2*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "dc"*"dc\[Dagger]"^2*"ec"*"H"*"L"*"uc", "dc"*"ec"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q\[Dagger]"*"uc", "dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"*
     "uc"*"uc\[Dagger]", "dc"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"Q\[Dagger]"*
     "uc", "dc\[Dagger]"*"ec"*"H"*"L"^2*"L\[Dagger]"*"uc", 
    "ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"H"*"L"*"uc", 
    "ec"^2*"H\[Dagger]"*"L"*"Q\[Dagger]"^2*"uc", "ec"^2*"ec\[Dagger]"*
     "H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", "dc"^2*"dc\[Dagger]"^2*"ec"*
     "H\[Dagger]"*"L", "dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"^2*
     "L\[Dagger]", "dc"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L", 
    "ec"*"H\[Dagger]"*"L"^3*"L\[Dagger]"^2, "dc\[Dagger]"*"ec"^2*"H\[Dagger]"*
     "L"^2*"Q\[Dagger]", "ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"^2*
     "L\[Dagger]", "ec"^3*"ec\[Dagger]"^2*"H\[Dagger]"*"L"}, 
  FL*\[Phi]^2*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"*"ec\[Dagger]"*"GL"*"H"^2*"Q"^2, "GL"*"H"*"H\[Dagger]"*"Q"^2*
     "Q\[Dagger]"^2, "ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "dc\[Dagger]"*"GL"*"H"^2*"Q"*"Q\[Dagger]"*"uc", 
    "ec\[Dagger]"*"GL"*"H"^2*"L\[Dagger]"*"Q"*"uc", 
    "GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "dc"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q", 
    "dc"*"GL"*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"^2*"GL"*"H"^2*"L"*"Q", "GL"*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"*"Q\[Dagger]", "dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"L"*
     "Q"*"uc\[Dagger]", "GL"*"H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"^2, 
    "ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "GL"*"H"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2, "dc\[Dagger]"*"GL"*"H"^2*
     "uc"^2*"uc\[Dagger]", "GL"*"H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "dc"*"dc\[Dagger]"^2*"GL"*"H"^2*"uc", "dc"*"GL"*"H"*"H\[Dagger]"*
     "L\[Dagger]"*"Q\[Dagger]"*"uc", "dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*
     "uc"*"uc\[Dagger]", "dc"*"GL"*"H\[Dagger]"^2*"uc"*"uc\[Dagger]"^2, 
    "dc\[Dagger]"*"GL"*"H"^2*"L"*"L\[Dagger]"*"uc", 
    "GL"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"H"^2*"uc", 
    "ec"*"GL"*"H"*"H\[Dagger]"*"Q\[Dagger]"^2*"uc", 
    "ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2*"GL"*"H"*"H\[Dagger]", "dc"^2*"GL"*"H\[Dagger]"^2*
     "L\[Dagger]"*"Q\[Dagger]", "dc"^2*"dc\[Dagger]"*"GL"*"H\[Dagger]"^2*
     "uc\[Dagger]", "dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]", "dc"*"GL"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]", 
    "dc"*"ec"*"GL"*"H\[Dagger]"^2*"Q\[Dagger]"^2, "dc"*"ec"*"ec\[Dagger]"*
     "GL"*"H\[Dagger]"^2*"uc\[Dagger]", "dc\[Dagger]"*"ec"*"GL"*"H"*
     "H\[Dagger]"*"L"*"Q\[Dagger]", "ec"*"GL"*"H\[Dagger]"^2*"L"*"Q\[Dagger]"*
     "uc\[Dagger]", "dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"Q"^2*"WL", 
    "H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2*"WL", "ec\[Dagger]"*"H"*
     "H\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL", "dc\[Dagger]"*"H"^2*"Q"*
     "Q\[Dagger]"*"uc"*"WL", "ec\[Dagger]"*"H"^2*"L\[Dagger]"*"Q"*"uc"*"WL", 
    "H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "dc"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q"*"WL", 
    "dc"*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "dc\[Dagger]"^2*"H"^2*"L"*"Q"*"WL", "H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*
     "Q\[Dagger]"*"WL", "dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*
     "WL", "H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"^2*"WL", 
    "ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "H"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2*"WL", "dc\[Dagger]"*"H"^2*"uc"^2*
     "uc\[Dagger]"*"WL", "H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2*"WL", 
    "dc"*"dc\[Dagger]"^2*"H"^2*"uc"*"WL", "dc"*"H"*"H\[Dagger]"*"L\[Dagger]"*
     "Q\[Dagger]"*"uc"*"WL", "dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"uc"*
     "uc\[Dagger]"*"WL", "dc"*"H\[Dagger]"^2*"uc"*"uc\[Dagger]"^2*"WL", 
    "dc\[Dagger]"*"H"^2*"L"*"L\[Dagger]"*"uc"*"WL", 
    "H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*"uc"*"WL", 
    "ec"*"H"*"H\[Dagger]"*"Q\[Dagger]"^2*"uc"*"WL", 
    "ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "dc"^2*"dc\[Dagger]"^2*"H"*"H\[Dagger]"*"WL", 
    "dc"^2*"H\[Dagger]"^2*"L\[Dagger]"*"Q\[Dagger]"*"WL", 
    "dc"^2*"dc\[Dagger]"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "dc"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL", 
    "dc"*"ec"*"H\[Dagger]"^2*"Q\[Dagger]"^2*"WL", "dc"*"ec"*"ec\[Dagger]"*
     "H\[Dagger]"^2*"uc\[Dagger]"*"WL", "H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2*
     "WL", "dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]"*"WL", 
    "ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "ec"*"H\[Dagger]"^2*"L"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "ec"^2*"ec\[Dagger]"^2*"H"*"H\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"Q"^2, "BL"*"H"*"H\[Dagger]"*"Q"^2*
     "Q\[Dagger]"^2, "BL"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "BL"*"dc\[Dagger]"*"H"^2*"Q"*"Q\[Dagger]"*"uc", 
    "BL"*"ec\[Dagger]"*"H"^2*"L\[Dagger]"*"Q"*"uc", 
    "BL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"dc"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q", 
    "BL"*"dc"*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]", 
    "BL"*"dc\[Dagger]"^2*"H"^2*"L"*"Q", "BL"*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"*"Q\[Dagger]", "BL"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*
     "Q"*"uc\[Dagger]", "BL"*"H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"^2, 
    "BL"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"H"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2, "BL"*"dc\[Dagger]"*"H"^2*
     "uc"^2*"uc\[Dagger]", "BL"*"H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "BL"*"dc"*"dc\[Dagger]"^2*"H"^2*"uc", "BL"*"dc"*"H"*"H\[Dagger]"*
     "L\[Dagger]"*"Q\[Dagger]"*"uc", "BL"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*
     "uc"*"uc\[Dagger]", "BL"*"dc"*"H\[Dagger]"^2*"uc"*"uc\[Dagger]"^2, 
    "BL"*"dc\[Dagger]"*"H"^2*"L"*"L\[Dagger]"*"uc", 
    "BL"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*"uc", 
    "BL"*"ec"*"H"*"H\[Dagger]"*"Q\[Dagger]"^2*"uc", 
    "BL"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"dc"^2*"dc\[Dagger]"^2*"H"*"H\[Dagger]", "BL"*"dc"^2*"H\[Dagger]"^2*
     "L\[Dagger]"*"Q\[Dagger]", "BL"*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"^2*
     "uc\[Dagger]", "BL"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]", "BL"*"dc"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]", 
    "BL"*"dc"*"ec"*"H\[Dagger]"^2*"Q\[Dagger]"^2, 
    "BL"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "BL"*"H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2, "BL"*"dc\[Dagger]"*"ec"*"H"*
     "H\[Dagger]"*"L"*"Q\[Dagger]", "BL"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*
     "L"*"L\[Dagger]", "BL"*"ec"*"H\[Dagger]"^2*"L"*"Q\[Dagger]"*
     "uc\[Dagger]", "BL"*"ec"^2*"ec\[Dagger]"^2*"H"*"H\[Dagger]"}, 
  FL^2*\[Phi]^3*OverBar[\[Psi]]^2 -> {"dc\[Dagger]"*"GL"^2*"H"^2*"H\[Dagger]"*
     "Q\[Dagger]", "ec\[Dagger]"*"GL"^2*"H"^2*"H\[Dagger]"*"L\[Dagger]", 
    "GL"^2*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"WL", 
    "GL"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"*"Q\[Dagger]", 
    "BL"*"GL"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"WL"^2, 
    "ec\[Dagger]"*"H"^2*"H\[Dagger]"*"L\[Dagger]"*"WL"^2, 
    "H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, 
    "BL"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"WL", 
    "BL"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"L\[Dagger]"*"WL", 
    "BL"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"^2*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"Q\[Dagger]", 
    "BL"^2*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"L\[Dagger]", 
    "BL"^2*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]"}, 
  D*\[Phi]^3*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"^3, "D"*"H"^2*"H\[Dagger]"*"Q"^2*
     "Q\[Dagger]"*"uc", "D"*"dc"*"H"*"H\[Dagger]"^2*"Q"^2*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"L"*"Q"^2, 
    "D"*"H"*"H\[Dagger]"^2*"L"*"Q"^2*"uc\[Dagger]", 
    "D"*"dc\[Dagger]"*"H"^3*"Q"*"uc"^2, "D"*"H"^2*"H\[Dagger]"*"Q"*"uc"^2*
     "uc\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "D"*"dc"*"H"*"H\[Dagger]"^2*"Q"*"uc"*"uc\[Dagger]", 
    "D"*"H"^2*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "D"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "D"*"dc"^2*"dc\[Dagger]"*"H"*"H\[Dagger]"^2*"Q", 
    "D"*"dc"^2*"H\[Dagger]"^3*"Q"*"uc\[Dagger]", "D"*"dc"*"H"*"H\[Dagger]"^2*
     "L"*"L\[Dagger]"*"Q", "D"*"dc"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*
     "Q", "D"*"ec"*"H"*"H\[Dagger]"^2*"L"*"Q"*"Q\[Dagger]", 
    "D"*"H"^3*"L\[Dagger]"*"uc"^3, "D"*"dc"*"H"^2*"H\[Dagger]"*"L\[Dagger]"*
     "uc"^2, "D"*"ec"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc"^2, 
    "D"*"dc"^2*"H"*"H\[Dagger]"^2*"L\[Dagger]"*"uc", 
    "D"*"dc"*"ec"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc", 
    "D"*"dc\[Dagger]"*"ec"*"H"^2*"H\[Dagger]"*"L"*"uc", 
    "D"*"ec"*"H"*"H\[Dagger]"^2*"L"*"uc"*"uc\[Dagger]", 
    "D"*"dc"^3*"H\[Dagger]"^3*"L\[Dagger]", "D"*"dc"^2*"ec"*"H\[Dagger]"^3*
     "Q\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"^2*"L", 
    "D"*"dc"*"ec"*"H\[Dagger]"^3*"L"*"uc\[Dagger]", 
    "D"*"ec"*"H"*"H\[Dagger]"^2*"L"^2*"L\[Dagger]", 
    "D"*"ec"^2*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"L"}, 
  D*FL*\[Phi]^4*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"GL"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"*"GL"*"H"^3*"H\[Dagger]"*"uc", 
    "D"*"GL"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"^2, 
    "D"*"dc"*"GL"*"H"*"H\[Dagger]"^3*"uc\[Dagger]", 
    "D"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"*"uc"*"WL", 
    "D"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2*"WL", 
    "D"*"dc"*"H"*"H\[Dagger]"^3*"uc\[Dagger]"*"WL", 
    "D"*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"WL", 
    "D"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"WL", 
    "BL"*"D"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"*"uc", 
    "BL"*"D"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2, 
    "BL"*"D"*"dc"*"H"*"H\[Dagger]"^3*"uc\[Dagger]", 
    "BL"*"D"*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]", 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2}, 
  D^2*\[Phi]^5*\[Psi]^2 -> {"D"^2*"H"^3*"H\[Dagger]"^2*"Q"*"uc", 
    "D"^2*"dc"*"H"^2*"H\[Dagger]"^3*"Q", "D"^2*"ec"*"H"^2*"H\[Dagger]"^3*
     "L"}, D^2*FL*\[Phi]^6 -> {"D"^2*"H"^3*"H\[Dagger]"^3*"WL", 
    "BL"*"D"^2*"H"^3*"H\[Dagger]"^3}, \[Phi]^4*\[Psi]^4 -> 
   {"H"^2*"H\[Dagger]"^2*"L"*"Q"^3, "H"^3*"H\[Dagger]"*"Q"^2*"uc"^2, 
    "dc"*"H"^2*"H\[Dagger]"^2*"Q"^2*"uc", "dc"^2*"H"*"H\[Dagger]"^3*"Q"^2, 
    "ec"*"H"^2*"H\[Dagger]"^2*"L"*"Q"*"uc", "dc"*"ec"*"H"*"H\[Dagger]"^3*"L"*
     "Q", "ec"*"H"^3*"H\[Dagger]"*"uc"^3, "dc"*"ec"*"H"^2*"H\[Dagger]"^2*
     "uc"^2, "dc"^2*"ec"*"H"*"H\[Dagger]"^3*"uc", "dc"^3*"ec"*"H\[Dagger]"^4, 
    "H"^4*"L"^4, "ec"^2*"H"*"H\[Dagger]"^3*"L"^2}, 
  FL*\[Phi]^5*\[Psi]^2 -> {"GL"*"H"^3*"H\[Dagger]"^2*"Q"*"uc", 
    "dc"*"GL"*"H"^2*"H\[Dagger]"^3*"Q", "H"^3*"H\[Dagger]"^2*"Q"*"uc"*"WL", 
    "dc"*"H"^2*"H\[Dagger]"^3*"Q"*"WL", "ec"*"H"^2*"H\[Dagger]"^3*"L"*"WL", 
    "BL"*"H"^3*"H\[Dagger]"^2*"Q"*"uc", "BL"*"dc"*"H"^2*"H\[Dagger]"^3*"Q", 
    "BL"*"ec"*"H"^2*"H\[Dagger]"^3*"L"}, FL^2*\[Phi]^6 -> 
   {"GL"^2*"H"^3*"H\[Dagger]"^3, "H"^3*"H\[Dagger]"^3*"WL"^2, 
    "BL"*"H"^3*"H\[Dagger]"^3*"WL", "BL"^2*"H"^3*"H\[Dagger]"^3}, 
  \[Phi]^4*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"*"Q"^2, 
    "H"^2*"H\[Dagger]"^2*"Q"^2*"Q\[Dagger]"^2, "ec\[Dagger]"*"H"^2*
     "H\[Dagger]"^2*"Q"^2*"uc\[Dagger]", "dc\[Dagger]"*"H"^3*"H\[Dagger]"*"Q"*
     "Q\[Dagger]"*"uc", "ec\[Dagger]"*"H"^3*"H\[Dagger]"*"L\[Dagger]"*"Q"*
     "uc", "H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "dc"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"L\[Dagger]"*"Q", 
    "dc\[Dagger]"^2*"H"^3*"H\[Dagger]"*"L"*"Q", "H"^2*"H\[Dagger]"^2*"L"*
     "L\[Dagger]"*"Q"*"Q\[Dagger]", "dc\[Dagger]"*"H"^2*"H\[Dagger]"^2*"L"*
     "Q"*"uc\[Dagger]", "H"*"H\[Dagger]"^3*"L"*"Q"*"uc\[Dagger]"^2, 
    "ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "dc\[Dagger]"^2*"H"^4*"uc"^2, "dc\[Dagger]"*"H"^3*"H\[Dagger]"*"uc"^2*
     "uc\[Dagger]", "H"^2*"H\[Dagger]"^2*"uc"^2*"uc\[Dagger]"^2, 
    "dc"*"dc\[Dagger]"^2*"H"^3*"H\[Dagger]"*"uc", "dc"*"dc\[Dagger]"*"H"^2*
     "H\[Dagger]"^2*"uc"*"uc\[Dagger]", "dc\[Dagger]"*"H"^3*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"uc", "H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc"*
     "uc\[Dagger]", "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"*"uc", 
    "ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2*"H"^2*"H\[Dagger]"^2, "dc"*"dc\[Dagger]"*"H"^2*
     "H\[Dagger]"^2*"L"*"L\[Dagger]", "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*
     "H"^2*"H\[Dagger]"^2, "H"^2*"H\[Dagger]"^2*"L"^2*"L\[Dagger]"^2, 
    "ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]", 
    "ec"^2*"ec\[Dagger]"^2*"H"^2*"H\[Dagger]"^2}, 
  D*\[Phi]^6*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"H"^3*"H\[Dagger]"^3*"Q"*"Q\[Dagger]", "D"*"dc\[Dagger]"*"H"^4*
     "H\[Dagger]"^2*"uc", "D"*"H"^3*"H\[Dagger]"^3*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"^3, "D"*"H"^3*"H\[Dagger]"^3*"L"*
     "L\[Dagger]", "D"*"ec"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"^3}, 
  D^2*\[Phi]^8 -> {"D"^2*"H"^4*"H\[Dagger]"^4}, 
  \[Phi]^7*\[Psi]^2 -> {"H"^4*"H\[Dagger]"^3*"Q"*"uc", 
    "dc"*"H"^3*"H\[Dagger]"^4*"Q", "ec"*"H"^3*"H\[Dagger]"^4*"L"}, 
  \[Phi]^10 -> {"H"^5*"H\[Dagger]"^5}|>, <|D^4*FL^2*\[Psi]^2 -> {}, 
  D^4*FL^3*\[Phi] -> {}, D^4*FL*FR*\[Psi]^2 -> {}, 
  D^4*FL^2*OverBar[\[Psi]]^2 -> {}, D^4*FL^2*FR*\[Phi] -> {}, 
  D^5*\[Psi]^3*OverBar[\[Psi]] -> {"D"^5*"dc"^3*"ec\[Dagger]", 
    "D"^5*"dc"^2*"L"*"Q\[Dagger]", "D"^5*"dc"*"L"^2*"uc\[Dagger]"}, 
  D^5*FL*\[Phi]*\[Psi]*OverBar[\[Psi]] -> {}, D^6*\[Phi]^2*\[Psi]^2 -> 
   {"D"^6*"H"^2*"L"^2}, D^6*FL*\[Phi]^3 -> {}, D^2*FL^3*\[Psi]^2 -> {}, 
  D^2*FL^4*\[Phi] -> {}, D^2*FL^2*FR*\[Psi]^2 -> {}, 
  D^2*FL^3*OverBar[\[Psi]]^2 -> {}, D^2*FL^3*FR*\[Phi] -> {}, 
  D^3*FL*\[Psi]^3*OverBar[\[Psi]] -> {"D"^3*"dc"^3*"ec\[Dagger]"*"GL", 
    "D"^3*"dc"^2*"GL"*"L"*"Q\[Dagger]", "D"^3*"dc"*"GL"*"L"^2*"uc\[Dagger]", 
    "D"^3*"dc"^2*"L"*"Q\[Dagger]"*"WL", "D"^3*"dc"*"L"^2*"uc\[Dagger]"*"WL", 
    "BL"*"D"^3*"dc"^3*"ec\[Dagger]", "BL"*"D"^3*"dc"^2*"L"*"Q\[Dagger]", 
    "BL"*"D"^3*"dc"*"L"^2*"uc\[Dagger]"}, 
  D^3*FL^2*\[Phi]*\[Psi]*OverBar[\[Psi]] -> {}, 
  D^4*\[Phi]*\[Psi]^4 -> {"D"^4*"dc"*"H"*"L"^2*"Q", 
    "D"^4*"dc"^2*"H"*"L"*"uc", "D"^4*"dc"^3*"H\[Dagger]"*"L", 
    "D"^4*"ec"*"H"*"L"^3}, D^4*FL*\[Phi]^2*\[Psi]^2 -> 
   {"D"^4*"H"^2*"L"^2*"WL", "BL"*"D"^4*"H"^2*"L"^2}, D^4*FL^2*\[Phi]^3 -> {}, 
  D^2*FL*FR^2*\[Psi]^2 -> {}, D^2*FL^2*FR^2*\[Phi] -> {}, 
  D^3*FR*\[Psi]^3*OverBar[\[Psi]] -> {"D"^3*"dc"^3*"ec\[Dagger]"*"GR", 
    "BR"*"D"^3*"dc"^3*"ec\[Dagger]", "D"^3*"dc"^2*"GR"*"L"*"Q\[Dagger]", 
    "D"^3*"dc"^2*"L"*"Q\[Dagger]"*"WR", "BR"*"D"^3*"dc"^2*"L"*"Q\[Dagger]", 
    "D"^3*"dc"*"GR"*"L"^2*"uc\[Dagger]", "D"^3*"dc"*"L"^2*"uc\[Dagger]"*"WR", 
    "BR"*"D"^3*"dc"*"L"^2*"uc\[Dagger]"}, 
  D^3*FL*FR*\[Phi]*\[Psi]*OverBar[\[Psi]] -> {}, 
  D^4*\[Phi]*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"D"^4*"dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "D"^4*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc", "D"^4*"dc\[Dagger]"^2*"ec"*
     "H\[Dagger]"*"Q", "D"^4*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L\[Dagger]"*
     "uc"}, D^4*FR*\[Phi]^2*\[Psi]^2 -> {"D"^4*"H"^2*"L"^2*"WR", 
    "BR"*"D"^4*"H"^2*"L"^2}, D^4*FL*FR*\[Phi]^3 -> {}, 
  D^5*\[Phi]^3*\[Psi]*OverBar[\[Psi]] -> {"D"^5*"ec\[Dagger]"*"H"^3*"L"}, 
  D^6*\[Phi]^5 -> {}, FL^4*\[Psi]^2 -> {}, FL^5*\[Phi] -> {}, 
  FL^4*OverBar[\[Psi]]^2 -> {}, D*FL^2*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"*"dc"^3*"ec\[Dagger]"*"GL"^2, "D"*"dc"^2*"GL"^2*"L"*"Q\[Dagger]", 
    "D"*"dc"*"GL"^2*"L"^2*"uc\[Dagger]", "D"*"dc"^2*"GL"*"L"*"Q\[Dagger]"*
     "WL", "D"*"dc"*"GL"*"L"^2*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"dc"^3*"ec\[Dagger]"*"GL", "BL"*"D"*"dc"^2*"GL"*"L"*
     "Q\[Dagger]", "BL"*"D"*"dc"*"GL"*"L"^2*"uc\[Dagger]", 
    "D"*"dc"^3*"ec\[Dagger]"*"WL"^2, "D"*"dc"^2*"L"*"Q\[Dagger]"*"WL"^2, 
    "D"*"dc"*"L"^2*"uc\[Dagger]"*"WL"^2, "BL"*"D"*"dc"^2*"L"*"Q\[Dagger]"*
     "WL", "BL"*"D"*"dc"*"L"^2*"uc\[Dagger]"*"WL", 
    "BL"^2*"D"*"dc"^3*"ec\[Dagger]", "BL"^2*"D"*"dc"^2*"L"*"Q\[Dagger]", 
    "BL"^2*"D"*"dc"*"L"^2*"uc\[Dagger]"}, 
  D*FL^3*\[Phi]*\[Psi]*OverBar[\[Psi]] -> {}, 
  D^2*\[Psi]^6 -> {"D"^2*"dc"^2*"L"^2*"Q"^2, "D"^2*"dc"^3*"L"*"Q"*"uc", 
    "D"^2*"dc"*"ec"*"L"^3*"Q", "D"^2*"dc"^4*"uc"^2, 
    "D"^2*"dc"^2*"ec"*"L"^2*"uc", "D"^2*"ec"^2*"L"^4}, 
  D^2*FL*\[Phi]*\[Psi]^4 -> {"D"^2*"dc"*"GL"*"H"*"L"^2*"Q", 
    "D"^2*"dc"^2*"GL"*"H"*"L"*"uc", "D"^2*"dc"^3*"GL"*"H\[Dagger]"*"L", 
    "D"^2*"dc"*"H"*"L"^2*"Q"*"WL", "D"^2*"dc"^2*"H"*"L"*"uc"*"WL", 
    "D"^2*"dc"^3*"H\[Dagger]"*"L"*"WL", "D"^2*"ec"*"H"*"L"^3*"WL", 
    "BL"*"D"^2*"dc"*"H"*"L"^2*"Q", "BL"*"D"^2*"dc"^2*"H"*"L"*"uc", 
    "BL"*"D"^2*"dc"^3*"H\[Dagger]"*"L", "BL"*"D"^2*"ec"*"H"*"L"^3}, 
  D^2*FL^2*\[Phi]^2*\[Psi]^2 -> {"D"^2*"GL"^2*"H"^2*"L"^2, 
    "D"^2*"H"^2*"L"^2*"WL"^2, "BL"*"D"^2*"H"^2*"L"^2*"WL", 
    "BL"^2*"D"^2*"H"^2*"L"^2}, D^2*FL^3*\[Phi]^3 -> {}, 
  FL^2*FR^2*\[Psi]^2 -> {}, FL^3*FR*OverBar[\[Psi]]^2 -> {}, 
  FL^3*FR^2*\[Phi] -> {}, D*FL*FR*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"*"dc"^3*"ec\[Dagger]"*"GL"*"GR", "BR"*"D"*"dc"^3*"ec\[Dagger]"*"GL", 
    "D"*"dc"^2*"GL"*"GR"*"L"*"Q\[Dagger]", "D"*"dc"^2*"GL"*"L"*"Q\[Dagger]"*
     "WR", "BR"*"D"*"dc"^2*"GL"*"L"*"Q\[Dagger]", "D"*"dc"*"GL"*"GR"*"L"^2*
     "uc\[Dagger]", "D"*"dc"*"GL"*"L"^2*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"dc"*"GL"*"L"^2*"uc\[Dagger]", "D"*"dc"^3*"ec\[Dagger]"*"WL"*
     "WR", "D"*"dc"^2*"GR"*"L"*"Q\[Dagger]"*"WL", "D"*"dc"^2*"L"*"Q\[Dagger]"*
     "WL"*"WR", "BR"*"D"*"dc"^2*"L"*"Q\[Dagger]"*"WL", 
    "D"*"dc"*"GR"*"L"^2*"uc\[Dagger]"*"WL", "D"*"dc"*"L"^2*"uc\[Dagger]"*"WL"*
     "WR", "BR"*"D"*"dc"*"L"^2*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"dc"^3*"ec\[Dagger]"*"GR", "BL"*"BR"*"D"*"dc"^3*"ec\[Dagger]", 
    "BL"*"D"*"dc"^2*"GR"*"L"*"Q\[Dagger]", "BL"*"D"*"dc"^2*"L"*"Q\[Dagger]"*
     "WR", "BL"*"BR"*"D"*"dc"^2*"L"*"Q\[Dagger]", "BL"*"D"*"dc"*"GR"*"L"^2*
     "uc\[Dagger]", "BL"*"D"*"dc"*"L"^2*"uc\[Dagger]"*"WR", 
    "BL"*"BR"*"D"*"dc"*"L"^2*"uc\[Dagger]"}, 
  D*FL^2*\[Psi]*OverBar[\[Psi]]^3 -> {"D"*"dc\[Dagger]"^2*"GL"^2*"L\[Dagger]"*
     "Q", "D"*"dc\[Dagger]"*"GL"^2*"L\[Dagger]"^2*"uc", 
    "D"*"dc\[Dagger]"^3*"ec"*"GL"^2, "D"*"dc\[Dagger]"^2*"GL"*"L\[Dagger]"*
     "Q"*"WL", "D"*"dc\[Dagger]"*"GL"*"L\[Dagger]"^2*"uc"*"WL", 
    "BL"*"D"*"dc\[Dagger]"^2*"GL"*"L\[Dagger]"*"Q", 
    "BL"*"D"*"dc\[Dagger]"*"GL"*"L\[Dagger]"^2*"uc", 
    "BL"*"D"*"dc\[Dagger]"^3*"ec"*"GL", "D"*"dc\[Dagger]"^2*"L\[Dagger]"*"Q"*
     "WL"^2, "D"*"dc\[Dagger]"*"L\[Dagger]"^2*"uc"*"WL"^2, 
    "D"*"dc\[Dagger]"^3*"ec"*"WL"^2, "BL"*"D"*"dc\[Dagger]"^2*"L\[Dagger]"*
     "Q"*"WL", "BL"*"D"*"dc\[Dagger]"*"L\[Dagger]"^2*"uc"*"WL", 
    "BL"^2*"D"*"dc\[Dagger]"^2*"L\[Dagger]"*"Q", "BL"^2*"D"*"dc\[Dagger]"*
     "L\[Dagger]"^2*"uc", "BL"^2*"D"*"dc\[Dagger]"^3*"ec"}, 
  D*FL^2*FR*\[Phi]*\[Psi]*OverBar[\[Psi]] -> {}, 
  D^2*\[Psi]^4*OverBar[\[Psi]]^2 -> {"D"^2*"dc\[Dagger]"^2*"Q"^4, 
    "D"^2*"dc\[Dagger]"*"L\[Dagger]"*"Q"^3*"uc", "D"^2*"L\[Dagger]"^2*"Q"^2*
     "uc"^2, "D"^2*"dc\[Dagger]"^2*"ec"*"Q"^2*"uc", 
    "D"^2*"dc\[Dagger]"*"ec"*"L\[Dagger]"*"Q"*"uc"^2, 
    "D"^2*"dc"^3*"ec\[Dagger]"*"Q"*"Q\[Dagger]", "D"^2*"dc"^2*"L"*"Q"*
     "Q\[Dagger]"^2, "D"^2*"dc"^2*"ec\[Dagger]"*"L"*"Q"*"uc\[Dagger]", 
    "D"^2*"dc"*"L"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"^2*"L"^3*"Q"*"uc\[Dagger]"^2, "D"^2*"ec"*"L\[Dagger]"^2*"uc"^3, 
    "D"^2*"dc\[Dagger]"^2*"ec"^2*"uc"^2, "D"^2*"dc"^3*"Q\[Dagger]"^2*"uc", 
    "D"^2*"dc"^3*"ec\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"dc"^2*"L"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"dc"*"L"^2*"uc"*"uc\[Dagger]"^2, "D"^2*"dc"^4*"dc\[Dagger]"*
     "ec\[Dagger]", "D"^2*"dc"^3*"dc\[Dagger]"*"L"*"Q\[Dagger]", 
    "D"^2*"dc"^3*"ec\[Dagger]"*"L"*"L\[Dagger]", 
    "D"^2*"dc"^3*"ec"*"ec\[Dagger]"^2, "D"^2*"dc"^2*"L"^2*"L\[Dagger]"*
     "Q\[Dagger]", "D"^2*"dc"^2*"dc\[Dagger]"*"L"^2*"uc\[Dagger]", 
    "D"^2*"dc"^2*"ec"*"ec\[Dagger]"*"L"*"Q\[Dagger]", 
    "D"^2*"dc"*"L"^3*"L\[Dagger]"*"uc\[Dagger]", "D"^2*"dc"*"ec"*"L"^2*
     "Q\[Dagger]"^2, "D"^2*"dc"*"ec"*"ec\[Dagger]"*"L"^2*"uc\[Dagger]", 
    "D"^2*"ec"*"L"^3*"Q\[Dagger]"*"uc\[Dagger]"}, 
  D^2*FR*\[Phi]*\[Psi]^4 -> {"D"^2*"dc"*"GR"*"H"*"L"^2*"Q", 
    "D"^2*"dc"*"H"*"L"^2*"Q"*"WR", "BR"*"D"^2*"dc"*"H"*"L"^2*"Q", 
    "D"^2*"dc"^2*"GR"*"H"*"L"*"uc", "D"^2*"dc"^2*"H"*"L"*"uc"*"WR", 
    "BR"*"D"^2*"dc"^2*"H"*"L"*"uc", "D"^2*"dc"^3*"GR"*"H\[Dagger]"*"L", 
    "D"^2*"dc"^3*"H\[Dagger]"*"L"*"WR", "BR"*"D"^2*"dc"^3*"H\[Dagger]"*"L", 
    "D"^2*"ec"*"H"*"L"^3*"WR", "BR"*"D"^2*"ec"*"H"*"L"^3}, 
  D^2*FL*\[Phi]*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"D"^2*"dc\[Dagger]"*"GL"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "D"^2*"GL"*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc", 
    "D"^2*"dc\[Dagger]"^2*"ec"*"GL"*"H\[Dagger]"*"Q", 
    "D"^2*"dc\[Dagger]"*"ec"*"GL"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "D"^2*"dc"^2*"ec\[Dagger]"*"GL"*"H"*"Q\[Dagger]", 
    "D"^2*"dc"*"GL"*"H"*"L"*"Q\[Dagger]"^2, "D"^2*"dc"*"ec\[Dagger]"*"GL"*"H"*
     "L"*"uc\[Dagger]", "D"^2*"GL"*"H"*"L"^2*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2*"WL", 
    "D"^2*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc"*"WL", 
    "D"^2*"dc\[Dagger]"^2*"ec"*"H\[Dagger]"*"Q"*"WL", 
    "D"^2*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WL", 
    "D"^2*"dc"^2*"ec\[Dagger]"*"H"*"Q\[Dagger]"*"WL", 
    "D"^2*"dc"*"H"*"L"*"Q\[Dagger]"^2*"WL", "D"^2*"dc"*"ec\[Dagger]"*"H"*"L"*
     "uc\[Dagger]"*"WL", "D"^2*"H"*"L"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"D"^2*"dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "BL"*"D"^2*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc", 
    "BL"*"D"^2*"dc\[Dagger]"^2*"ec"*"H\[Dagger]"*"Q", 
    "BL"*"D"^2*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "BL"*"D"^2*"dc"^2*"ec\[Dagger]"*"H"*"Q\[Dagger]", 
    "BL"*"D"^2*"dc"*"H"*"L"*"Q\[Dagger]"^2, "BL"*"D"^2*"dc"*"ec\[Dagger]"*"H"*
     "L"*"uc\[Dagger]", "BL"*"D"^2*"H"*"L"^2*"Q\[Dagger]"*"uc\[Dagger]"}, 
  D^2*FL*FR*\[Phi]^2*\[Psi]^2 -> {"D"^2*"GL"*"GR"*"H"^2*"L"^2, 
    "D"^2*"H"^2*"L"^2*"WL"*"WR", "BR"*"D"^2*"H"^2*"L"^2*"WL", 
    "BL"*"D"^2*"H"^2*"L"^2*"WR", "BL"*"BR"*"D"^2*"H"^2*"L"^2}, 
  D^2*FL^2*\[Phi]^2*OverBar[\[Psi]]^2 -> 
   {"D"^2*"GL"^2*"H\[Dagger]"^2*"L\[Dagger]"^2, "D"^2*"H\[Dagger]"^2*
     "L\[Dagger]"^2*"WL"^2, "BL"*"D"^2*"H\[Dagger]"^2*"L\[Dagger]"^2*"WL", 
    "BL"^2*"D"^2*"H\[Dagger]"^2*"L\[Dagger]"^2}, D^2*FL^2*FR*\[Phi]^3 -> {}, 
  D^3*\[Phi]^2*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"^3*"H\[Dagger]"^2*"L\[Dagger]"*"Q"^3, "D"^3*"dc\[Dagger]"*"ec"*
     "H\[Dagger]"^2*"Q"^2, "D"^3*"ec"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"*"uc", 
    "D"^3*"dc"*"ec\[Dagger]"*"H"^2*"L"*"Q", "D"^3*"H"^2*"L"^2*"Q"*
     "Q\[Dagger]", "D"^3*"dc"^2*"ec\[Dagger]"*"H"^2*"uc", 
    "D"^3*"dc"*"H"^2*"L"*"Q\[Dagger]"*"uc", "D"^3*"H"^2*"L"^2*"uc"*
     "uc\[Dagger]", "D"^3*"dc\[Dagger]"*"ec"^2*"H\[Dagger]"^2*"uc", 
    "D"^3*"dc"^3*"ec\[Dagger]"*"H"*"H\[Dagger]", 
    "D"^3*"dc"^2*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]", 
    "D"^3*"dc"*"dc\[Dagger]"*"H"^2*"L"^2, "D"^3*"dc"*"H"*"H\[Dagger]"*"L"^2*
     "uc\[Dagger]", "D"^3*"H"^2*"L"^3*"L\[Dagger]", 
    "D"^3*"ec"*"ec\[Dagger]"*"H"^2*"L"^2}, 
  D^3*FL*\[Phi]^3*\[Psi]*OverBar[\[Psi]] -> 
   {"D"^3*"ec\[Dagger]"*"H"^3*"L"*"WL", "D"^3*"ec"*"H\[Dagger]"^3*
     "L\[Dagger]"*"WL", "BL"*"D"^3*"ec\[Dagger]"*"H"^3*"L", 
    "BL"*"D"^3*"ec"*"H\[Dagger]"^3*"L\[Dagger]"}, 
  D^4*\[Phi]^4*\[Psi]^2 -> {"D"^4*"H"^3*"H\[Dagger]"*"L"^2, 
    "D"^4*"ec"^2*"H\[Dagger]"^4}, D^4*FL*\[Phi]^5 -> {}, 
  FL*\[Psi]^6 -> {"dc"^2*"GL"*"L"^2*"Q"^2, "dc"^3*"GL"*"L"*"Q"*"uc", 
    "dc"*"ec"*"GL"*"L"^3*"Q", "dc"^4*"GL"*"uc"^2, "dc"^2*"ec"*"GL"*"L"^2*
     "uc", "dc"^2*"L"^2*"Q"^2*"WL", "dc"^3*"L"*"Q"*"uc"*"WL", 
    "dc"*"ec"*"L"^3*"Q"*"WL", "dc"^2*"ec"*"L"^2*"uc"*"WL", "ec"^2*"L"^4*"WL", 
    "BL"*"dc"^2*"L"^2*"Q"^2, "BL"*"dc"^3*"L"*"Q"*"uc", 
    "BL"*"dc"*"ec"*"L"^3*"Q", "BL"*"dc"^4*"uc"^2, "BL"*"dc"^2*"ec"*"L"^2*
     "uc", "BL"*"ec"^2*"L"^4}, FL^2*\[Phi]*\[Psi]^4 -> 
   {"dc"*"GL"^2*"H"*"L"^2*"Q", "dc"^2*"GL"^2*"H"*"L"*"uc", 
    "dc"^3*"GL"^2*"H\[Dagger]"*"L", "ec"*"GL"^2*"H"*"L"^3, 
    "dc"*"GL"*"H"*"L"^2*"Q"*"WL", "dc"^2*"GL"*"H"*"L"*"uc"*"WL", 
    "dc"^3*"GL"*"H\[Dagger]"*"L"*"WL", "BL"*"dc"*"GL"*"H"*"L"^2*"Q", 
    "BL"*"dc"^2*"GL"*"H"*"L"*"uc", "BL"*"dc"^3*"GL"*"H\[Dagger]"*"L", 
    "dc"*"H"*"L"^2*"Q"*"WL"^2, "dc"^2*"H"*"L"*"uc"*"WL"^2, 
    "dc"^3*"H\[Dagger]"*"L"*"WL"^2, "ec"*"H"*"L"^3*"WL"^2, 
    "BL"*"dc"*"H"*"L"^2*"Q"*"WL", "BL"*"dc"^2*"H"*"L"*"uc"*"WL", 
    "BL"*"dc"^3*"H\[Dagger]"*"L"*"WL", "BL"*"ec"*"H"*"L"^3*"WL", 
    "BL"^2*"dc"*"H"*"L"^2*"Q", "BL"^2*"dc"^2*"H"*"L"*"uc", 
    "BL"^2*"dc"^3*"H\[Dagger]"*"L", "BL"^2*"ec"*"H"*"L"^3}, 
  FL^3*\[Phi]^2*\[Psi]^2 -> {"GL"^3*"H"^2*"L"^2, "GL"^2*"H"^2*"L"^2*"WL", 
    "BL"*"GL"^2*"H"^2*"L"^2, "H"^2*"L"^2*"WL"^3, "BL"*"H"^2*"L"^2*"WL"^2, 
    "BL"^2*"H"^2*"L"^2*"WL", "BL"^3*"H"^2*"L"^2}, FL^4*\[Phi]^3 -> {}, 
  FL*\[Psi]^4*OverBar[\[Psi]]^2 -> {"dc\[Dagger]"^2*"GL"*"Q"^4, 
    "dc\[Dagger]"*"GL"*"L\[Dagger]"*"Q"^3*"uc", "GL"*"L\[Dagger]"^2*"Q"^2*
     "uc"^2, "dc\[Dagger]"^2*"ec"*"GL"*"Q"^2*"uc", 
    "dc\[Dagger]"*"ec"*"GL"*"L\[Dagger]"*"Q"*"uc"^2, 
    "dc"^3*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]", "dc"^2*"GL"*"L"*"Q"*
     "Q\[Dagger]"^2, "dc"^2*"ec\[Dagger]"*"GL"*"L"*"Q"*"uc\[Dagger]", 
    "dc"*"GL"*"L"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]", 
    "GL"*"L"^3*"Q"*"uc\[Dagger]"^2, "ec"*"GL"*"L\[Dagger]"^2*"uc"^3, 
    "dc\[Dagger]"^2*"ec"^2*"GL"*"uc"^2, "dc"^3*"GL"*"Q\[Dagger]"^2*"uc", 
    "dc"^3*"ec\[Dagger]"*"GL"*"uc"*"uc\[Dagger]", 
    "dc"^2*"GL"*"L"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"*"GL"*"L"^2*"uc"*"uc\[Dagger]"^2, "dc"^4*"dc\[Dagger]"*"ec\[Dagger]"*
     "GL", "dc"^3*"dc\[Dagger]"*"GL"*"L"*"Q\[Dagger]", 
    "dc"^3*"ec\[Dagger]"*"GL"*"L"*"L\[Dagger]", "dc"^3*"ec"*"ec\[Dagger]"^2*
     "GL", "dc"^2*"GL"*"L"^2*"L\[Dagger]"*"Q\[Dagger]", 
    "dc"^2*"dc\[Dagger]"*"GL"*"L"^2*"uc\[Dagger]", 
    "dc"^2*"ec"*"ec\[Dagger]"*"GL"*"L"*"Q\[Dagger]", 
    "dc"*"GL"*"L"^3*"L\[Dagger]"*"uc\[Dagger]", "dc"*"ec"*"GL"*"L"^2*
     "Q\[Dagger]"^2, "dc"*"ec"*"ec\[Dagger]"*"GL"*"L"^2*"uc\[Dagger]", 
    "ec"*"GL"*"L"^3*"Q\[Dagger]"*"uc\[Dagger]", "dc\[Dagger]"^2*"Q"^4*"WL", 
    "dc\[Dagger]"*"L\[Dagger]"*"Q"^3*"uc"*"WL", "L\[Dagger]"^2*"Q"^2*"uc"^2*
     "WL", "dc\[Dagger]"^2*"ec"*"Q"^2*"uc"*"WL", 
    "dc\[Dagger]"*"ec"*"L\[Dagger]"*"Q"*"uc"^2*"WL", 
    "dc"^3*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", "dc"^2*"L"*"Q"*"Q\[Dagger]"^2*
     "WL", "dc"^2*"ec\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*"WL", 
    "dc"*"L"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "L"^3*"Q"*"uc\[Dagger]"^2*"WL", "ec"*"L\[Dagger]"^2*"uc"^3*"WL", 
    "dc"^3*"Q\[Dagger]"^2*"uc"*"WL", "dc"^2*"L"*"Q\[Dagger]"*"uc"*
     "uc\[Dagger]"*"WL", "dc"*"L"^2*"uc"*"uc\[Dagger]"^2*"WL", 
    "dc"^3*"dc\[Dagger]"*"L"*"Q\[Dagger]"*"WL", "dc"^3*"ec\[Dagger]"*"L"*
     "L\[Dagger]"*"WL", "dc"^2*"L"^2*"L\[Dagger]"*"Q\[Dagger]"*"WL", 
    "dc"^2*"dc\[Dagger]"*"L"^2*"uc\[Dagger]"*"WL", 
    "dc"^2*"ec"*"ec\[Dagger]"*"L"*"Q\[Dagger]"*"WL", 
    "dc"*"L"^3*"L\[Dagger]"*"uc\[Dagger]"*"WL", 
    "dc"*"ec"*"L"^2*"Q\[Dagger]"^2*"WL", "dc"*"ec"*"ec\[Dagger]"*"L"^2*
     "uc\[Dagger]"*"WL", "ec"*"L"^3*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"^2*"Q"^4, "BL"*"dc\[Dagger]"*"L\[Dagger]"*"Q"^3*"uc", 
    "BL"*"L\[Dagger]"^2*"Q"^2*"uc"^2, "BL"*"dc\[Dagger]"^2*"ec"*"Q"^2*"uc", 
    "BL"*"dc\[Dagger]"*"ec"*"L\[Dagger]"*"Q"*"uc"^2, 
    "BL"*"dc"^3*"ec\[Dagger]"*"Q"*"Q\[Dagger]", "BL"*"dc"^2*"L"*"Q"*
     "Q\[Dagger]"^2, "BL"*"dc"^2*"ec\[Dagger]"*"L"*"Q"*"uc\[Dagger]", 
    "BL"*"dc"*"L"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]", 
    "BL"*"L"^3*"Q"*"uc\[Dagger]"^2, "BL"*"ec"*"L\[Dagger]"^2*"uc"^3, 
    "BL"*"dc\[Dagger]"^2*"ec"^2*"uc"^2, "BL"*"dc"^3*"Q\[Dagger]"^2*"uc", 
    "BL"*"dc"^3*"ec\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"dc"^2*"L"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"dc"*"L"^2*"uc"*"uc\[Dagger]"^2, "BL"*"dc"^4*"dc\[Dagger]"*
     "ec\[Dagger]", "BL"*"dc"^3*"dc\[Dagger]"*"L"*"Q\[Dagger]", 
    "BL"*"dc"^3*"ec\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"*"dc"^3*"ec"*"ec\[Dagger]"^2, "BL"*"dc"^2*"L"^2*"L\[Dagger]"*
     "Q\[Dagger]", "BL"*"dc"^2*"dc\[Dagger]"*"L"^2*"uc\[Dagger]", 
    "BL"*"dc"^2*"ec"*"ec\[Dagger]"*"L"*"Q\[Dagger]", 
    "BL"*"dc"*"L"^3*"L\[Dagger]"*"uc\[Dagger]", "BL"*"dc"*"ec"*"L"^2*
     "Q\[Dagger]"^2, "BL"*"dc"*"ec"*"ec\[Dagger]"*"L"^2*"uc\[Dagger]", 
    "BL"*"ec"*"L"^3*"Q\[Dagger]"*"uc\[Dagger]"}, 
  FL^2*\[Phi]*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"*"GL"^2*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "GL"^2*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc", "dc\[Dagger]"^2*"ec"*"GL"^2*
     "H\[Dagger]"*"Q", "dc\[Dagger]"*"ec"*"GL"^2*"H\[Dagger]"*"L\[Dagger]"*
     "uc", "dc"^2*"ec\[Dagger]"*"GL"^2*"H"*"Q\[Dagger]", 
    "dc"*"GL"^2*"H"*"L"*"Q\[Dagger]"^2, "dc"*"ec\[Dagger]"*"GL"^2*"H"*"L"*
     "uc\[Dagger]", "GL"^2*"H"*"L"^2*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"GL"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2*"WL", 
    "GL"*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc"*"WL", 
    "dc\[Dagger]"^2*"ec"*"GL"*"H\[Dagger]"*"Q"*"WL", 
    "dc\[Dagger]"*"ec"*"GL"*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WL", 
    "dc"^2*"ec\[Dagger]"*"GL"*"H"*"Q\[Dagger]"*"WL", 
    "dc"*"GL"*"H"*"L"*"Q\[Dagger]"^2*"WL", "dc"*"ec\[Dagger]"*"GL"*"H"*"L"*
     "uc\[Dagger]"*"WL", "GL"*"H"*"L"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"*"GL"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "BL"*"GL"*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc", 
    "BL"*"dc\[Dagger]"^2*"ec"*"GL"*"H\[Dagger]"*"Q", 
    "BL"*"dc\[Dagger]"*"ec"*"GL"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "BL"*"dc"^2*"ec\[Dagger]"*"GL"*"H"*"Q\[Dagger]", 
    "BL"*"dc"*"GL"*"H"*"L"*"Q\[Dagger]"^2, "BL"*"dc"*"ec\[Dagger]"*"GL"*"H"*
     "L"*"uc\[Dagger]", "BL"*"GL"*"H"*"L"^2*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2*"WL"^2, 
    "H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc"*"WL"^2, "dc\[Dagger]"^2*"ec"*
     "H\[Dagger]"*"Q"*"WL"^2, "dc\[Dagger]"*"ec"*"H\[Dagger]"*"L\[Dagger]"*
     "uc"*"WL"^2, "dc"^2*"ec\[Dagger]"*"H"*"Q\[Dagger]"*"WL"^2, 
    "dc"*"H"*"L"*"Q\[Dagger]"^2*"WL"^2, "dc"*"ec\[Dagger]"*"H"*"L"*
     "uc\[Dagger]"*"WL"^2, "H"*"L"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, 
    "BL"*"dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2*"WL", 
    "BL"*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc"*"WL", 
    "BL"*"dc\[Dagger]"^2*"ec"*"H\[Dagger]"*"Q"*"WL", 
    "BL"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WL", 
    "BL"*"dc"^2*"ec\[Dagger]"*"H"*"Q\[Dagger]"*"WL", 
    "BL"*"dc"*"H"*"L"*"Q\[Dagger]"^2*"WL", "BL"*"dc"*"ec\[Dagger]"*"H"*"L"*
     "uc\[Dagger]"*"WL", "BL"*"H"*"L"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"^2*"dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "BL"^2*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc", "BL"^2*"dc\[Dagger]"^2*"ec"*
     "H\[Dagger]"*"Q", "BL"^2*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L\[Dagger]"*
     "uc", "BL"^2*"dc"^2*"ec\[Dagger]"*"H"*"Q\[Dagger]", 
    "BL"^2*"dc"*"H"*"L"*"Q\[Dagger]"^2, "BL"^2*"dc"*"ec\[Dagger]"*"H"*"L"*
     "uc\[Dagger]", "BL"^2*"H"*"L"^2*"Q\[Dagger]"*"uc\[Dagger]"}, 
  FL^3*\[Phi]^2*OverBar[\[Psi]]^2 -> {"GL"^3*"H\[Dagger]"^2*"L\[Dagger]"^2, 
    "GL"^2*"H\[Dagger]"^2*"L\[Dagger]"^2*"WL", "BL"*"GL"^2*"H\[Dagger]"^2*
     "L\[Dagger]"^2, "H\[Dagger]"^2*"L\[Dagger]"^2*"WL"^3, 
    "BL"*"H\[Dagger]"^2*"L\[Dagger]"^2*"WL"^2, "BL"^2*"H\[Dagger]"^2*
     "L\[Dagger]"^2*"WL", "BL"^3*"H\[Dagger]"^2*"L\[Dagger]"^2}, 
  D*\[Phi]*\[Psi]^5*OverBar[\[Psi]] -> {"D"*"dc\[Dagger]"*"H\[Dagger]"*"Q"^5, 
    "D"*"H\[Dagger]"*"L\[Dagger]"*"Q"^4*"uc", "D"*"dc\[Dagger]"*"ec"*
     "H\[Dagger]"*"Q"^3*"uc", "D"*"ec"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2*
     "uc"^2, "D"*"dc"^2*"ec\[Dagger]"*"H"*"L"*"Q"^2, 
    "D"*"dc"*"H"*"L"^2*"Q"^2*"Q\[Dagger]", "D"*"H"*"L"^3*"Q"^2*"uc\[Dagger]", 
    "D"*"dc\[Dagger]"*"ec"^2*"H\[Dagger]"*"Q"*"uc"^2, 
    "D"*"dc"^3*"ec\[Dagger]"*"H"*"Q"*"uc", "D"*"dc"^2*"H"*"L"*"Q"*
     "Q\[Dagger]"*"uc", "D"*"dc"*"H"*"L"^2*"Q"*"uc"*"uc\[Dagger]", 
    "D"*"dc"^4*"ec\[Dagger]"*"H\[Dagger]"*"Q", "D"*"dc"^3*"H\[Dagger]"*"L"*
     "Q"*"Q\[Dagger]", "D"*"dc"^2*"dc\[Dagger]"*"H"*"L"^2*"Q", 
    "D"*"dc"^2*"H\[Dagger]"*"L"^2*"Q"*"uc\[Dagger]", 
    "D"*"dc"*"H"*"L"^3*"L\[Dagger]"*"Q", "D"*"dc"*"ec"*"ec\[Dagger]"*"H"*
     "L"^2*"Q", "D"*"ec"*"H"*"L"^3*"Q"*"Q\[Dagger]", 
    "D"*"ec"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"^3, "D"*"dc"^3*"H"*"Q\[Dagger]"*
     "uc"^2, "D"*"dc"^2*"H"*"L"*"uc"^2*"uc\[Dagger]", 
    "D"*"dc"^4*"H\[Dagger]"*"Q\[Dagger]"*"uc", "D"*"dc"^3*"dc\[Dagger]"*"H"*
     "L"*"uc", "D"*"dc"^3*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", 
    "D"*"dc"^2*"H"*"L"^2*"L\[Dagger]"*"uc", "D"*"dc"^2*"ec"*"ec\[Dagger]"*"H"*
     "L"*"uc", "D"*"dc"*"ec"*"H"*"L"^2*"Q\[Dagger]"*"uc", 
    "D"*"ec"*"H"*"L"^3*"uc"*"uc\[Dagger]", "D"*"dc"^4*"dc\[Dagger]"*
     "H\[Dagger]"*"L", "D"*"dc"^3*"H\[Dagger]"*"L"^2*"L\[Dagger]", 
    "D"*"dc"^3*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"L", 
    "D"*"dc"^2*"ec"*"H\[Dagger]"*"L"^2*"Q\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"H"*"L"^3, "D"*"dc"*"ec"*"H\[Dagger]"*"L"^3*
     "uc\[Dagger]", "D"*"ec"*"H"*"L"^4*"L\[Dagger]", 
    "D"*"ec"^2*"ec\[Dagger]"*"H"*"L"^3}, 
  D*FL*\[Phi]^2*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"*"GL"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"^3, "D"*"dc\[Dagger]"*"ec"*"GL"*
     "H\[Dagger]"^2*"Q"^2, "D"*"ec"*"GL"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"*
     "uc", "D"*"dc"*"ec\[Dagger]"*"GL"*"H"^2*"L"*"Q", 
    "D"*"GL"*"H"^2*"L"^2*"Q"*"Q\[Dagger]", "D"*"dc"^2*"ec\[Dagger]"*"GL"*
     "H"^2*"uc", "D"*"dc"*"GL"*"H"^2*"L"*"Q\[Dagger]"*"uc", 
    "D"*"GL"*"H"^2*"L"^2*"uc"*"uc\[Dagger]", "D"*"dc\[Dagger]"*"ec"^2*"GL"*
     "H\[Dagger]"^2*"uc", "D"*"dc"^3*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]", 
    "D"*"dc"^2*"GL"*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"H"^2*"L"^2, "D"*"dc"*"GL"*"H"*"H\[Dagger]"*
     "L"^2*"uc\[Dagger]", "D"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"^3*"WL", 
    "D"*"dc\[Dagger]"*"ec"*"H\[Dagger]"^2*"Q"^2*"WL", 
    "D"*"ec"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"*"uc"*"WL", 
    "D"*"dc"*"ec\[Dagger]"*"H"^2*"L"*"Q"*"WL", "D"*"H"^2*"L"^2*"Q"*
     "Q\[Dagger]"*"WL", "D"*"dc"^2*"ec\[Dagger]"*"H"^2*"uc"*"WL", 
    "D"*"dc"*"H"^2*"L"*"Q\[Dagger]"*"uc"*"WL", "D"*"H"^2*"L"^2*"uc"*
     "uc\[Dagger]"*"WL", "D"*"dc\[Dagger]"*"ec"^2*"H\[Dagger]"^2*"uc"*"WL", 
    "D"*"dc"^3*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL", 
    "D"*"dc"^2*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"H"^2*"L"^2*"WL", "D"*"dc"*"H"*"H\[Dagger]"*"L"^2*
     "uc\[Dagger]"*"WL", "D"*"H"^2*"L"^3*"L\[Dagger]"*"WL", 
    "D"*"ec"*"ec\[Dagger]"*"H"^2*"L"^2*"WL", "BL"*"D"*"H\[Dagger]"^2*
     "L\[Dagger]"*"Q"^3, "BL"*"D"*"dc\[Dagger]"*"ec"*"H\[Dagger]"^2*"Q"^2, 
    "BL"*"D"*"ec"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"*"uc", 
    "BL"*"D"*"dc"*"ec\[Dagger]"*"H"^2*"L"*"Q", "BL"*"D"*"H"^2*"L"^2*"Q"*
     "Q\[Dagger]", "BL"*"D"*"dc"^2*"ec\[Dagger]"*"H"^2*"uc", 
    "BL"*"D"*"dc"*"H"^2*"L"*"Q\[Dagger]"*"uc", "BL"*"D"*"H"^2*"L"^2*"uc"*
     "uc\[Dagger]", "BL"*"D"*"dc\[Dagger]"*"ec"^2*"H\[Dagger]"^2*"uc", 
    "BL"*"D"*"dc"^3*"ec\[Dagger]"*"H"*"H\[Dagger]", 
    "BL"*"D"*"dc"^2*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"H"^2*"L"^2, "BL"*"D"*"dc"*"H"*"H\[Dagger]"*
     "L"^2*"uc\[Dagger]", "BL"*"D"*"H"^2*"L"^3*"L\[Dagger]", 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"H"^2*"L"^2}, 
  D*FL^2*\[Phi]^3*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"ec\[Dagger]"*"GL"^2*"H"^3*"L", "D"*"ec"*"GL"^2*"H\[Dagger]"^3*
     "L\[Dagger]", "D"*"ec\[Dagger]"*"H"^3*"L"*"WL"^2, 
    "D"*"ec"*"H\[Dagger]"^3*"L\[Dagger]"*"WL"^2, "BL"*"D"*"ec\[Dagger]"*"H"^3*
     "L"*"WL", "BL"*"D"*"ec"*"H\[Dagger]"^3*"L\[Dagger]"*"WL", 
    "BL"^2*"D"*"ec\[Dagger]"*"H"^3*"L", "BL"^2*"D"*"ec"*"H\[Dagger]"^3*
     "L\[Dagger]"}, D^2*\[Phi]^3*\[Psi]^4 -> 
   {"D"^2*"ec"*"H\[Dagger]"^3*"Q"^3, "D"^2*"H"^3*"L"^2*"Q"*"uc", 
    "D"^2*"ec"^2*"H\[Dagger]"^3*"Q"*"uc", "D"^2*"dc"*"H"^2*"H\[Dagger]"*"L"^2*
     "Q", "D"^2*"dc"*"H"^3*"L"*"uc"^2, "D"^2*"dc"^2*"H"^2*"H\[Dagger]"*"L"*
     "uc", "D"^2*"dc"^3*"H"*"H\[Dagger]"^2*"L", "D"^2*"ec"*"H"^2*"H\[Dagger]"*
     "L"^3}, D^2*FL*\[Phi]^4*\[Psi]^2 -> 
   {"D"^2*"H"^3*"H\[Dagger]"*"L"^2*"WL", "D"^2*"ec"^2*"H\[Dagger]"^4*"WL", 
    "BL"*"D"^2*"H"^3*"H\[Dagger]"*"L"^2, "BL"*"D"^2*"ec"^2*"H\[Dagger]"^4}, 
  D^2*FL^2*\[Phi]^5 -> {}, FR*\[Psi]^4*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"^2*"GR"*"Q"^4, "dc\[Dagger]"^2*"Q"^4*"WR", 
    "BR"*"dc\[Dagger]"^2*"Q"^4, "dc\[Dagger]"*"GR"*"L\[Dagger]"*"Q"^3*"uc", 
    "dc\[Dagger]"*"L\[Dagger]"*"Q"^3*"uc"*"WR", "BR"*"dc\[Dagger]"*
     "L\[Dagger]"*"Q"^3*"uc", "GR"*"L\[Dagger]"^2*"Q"^2*"uc"^2, 
    "L\[Dagger]"^2*"Q"^2*"uc"^2*"WR", "BR"*"L\[Dagger]"^2*"Q"^2*"uc"^2, 
    "dc\[Dagger]"^2*"ec"*"GR"*"Q"^2*"uc", "dc\[Dagger]"^2*"ec"*"Q"^2*"uc"*
     "WR", "BR"*"dc\[Dagger]"^2*"ec"*"Q"^2*"uc", "dc\[Dagger]"*"ec"*"GR"*
     "L\[Dagger]"*"Q"*"uc"^2, "dc\[Dagger]"*"ec"*"L\[Dagger]"*"Q"*"uc"^2*
     "WR", "BR"*"dc\[Dagger]"*"ec"*"L\[Dagger]"*"Q"*"uc"^2, 
    "dc"^3*"ec\[Dagger]"*"GR"*"Q"*"Q\[Dagger]", "dc"^3*"ec\[Dagger]"*"Q"*
     "Q\[Dagger]"*"WR", "BR"*"dc"^3*"ec\[Dagger]"*"Q"*"Q\[Dagger]", 
    "dc"^2*"GR"*"L"*"Q"*"Q\[Dagger]"^2, "dc"^2*"L"*"Q"*"Q\[Dagger]"^2*"WR", 
    "BR"*"dc"^2*"L"*"Q"*"Q\[Dagger]"^2, "dc"^2*"ec\[Dagger]"*"GR"*"L"*"Q"*
     "uc\[Dagger]", "dc"^2*"ec\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*"WR", 
    "BR"*"dc"^2*"ec\[Dagger]"*"L"*"Q"*"uc\[Dagger]", 
    "dc"*"GR"*"L"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc"*"L"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]"*"WR", 
    "BR"*"dc"*"L"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]", 
    "GR"*"L"^3*"Q"*"uc\[Dagger]"^2, "L"^3*"Q"*"uc\[Dagger]"^2*"WR", 
    "BR"*"L"^3*"Q"*"uc\[Dagger]"^2, "ec"*"GR"*"L\[Dagger]"^2*"uc"^3, 
    "ec"*"L\[Dagger]"^2*"uc"^3*"WR", "BR"*"ec"*"L\[Dagger]"^2*"uc"^3, 
    "dc\[Dagger]"^2*"ec"^2*"GR"*"uc"^2, "BR"*"dc\[Dagger]"^2*"ec"^2*"uc"^2, 
    "dc"^3*"GR"*"Q\[Dagger]"^2*"uc", "dc"^3*"Q\[Dagger]"^2*"uc"*"WR", 
    "BR"*"dc"^3*"Q\[Dagger]"^2*"uc", "dc"^3*"ec\[Dagger]"*"GR"*"uc"*
     "uc\[Dagger]", "BR"*"dc"^3*"ec\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"^2*"GR"*"L"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"^2*"L"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"dc"^2*"L"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"*"GR"*"L"^2*"uc"*"uc\[Dagger]"^2, "dc"*"L"^2*"uc"*"uc\[Dagger]"^2*
     "WR", "BR"*"dc"*"L"^2*"uc"*"uc\[Dagger]"^2, "dc"^4*"dc\[Dagger]"*
     "ec\[Dagger]"*"GR", "BR"*"dc"^4*"dc\[Dagger]"*"ec\[Dagger]", 
    "dc"^3*"dc\[Dagger]"*"GR"*"L"*"Q\[Dagger]", "dc"^3*"dc\[Dagger]"*"L"*
     "Q\[Dagger]"*"WR", "BR"*"dc"^3*"dc\[Dagger]"*"L"*"Q\[Dagger]", 
    "dc"^3*"ec\[Dagger]"*"GR"*"L"*"L\[Dagger]", "dc"^3*"ec\[Dagger]"*"L"*
     "L\[Dagger]"*"WR", "BR"*"dc"^3*"ec\[Dagger]"*"L"*"L\[Dagger]", 
    "dc"^3*"ec"*"ec\[Dagger]"^2*"GR", "BR"*"dc"^3*"ec"*"ec\[Dagger]"^2, 
    "dc"^2*"GR"*"L"^2*"L\[Dagger]"*"Q\[Dagger]", "dc"^2*"L"^2*"L\[Dagger]"*
     "Q\[Dagger]"*"WR", "BR"*"dc"^2*"L"^2*"L\[Dagger]"*"Q\[Dagger]", 
    "dc"^2*"dc\[Dagger]"*"GR"*"L"^2*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"*"L"^2*"uc\[Dagger]"*"WR", 
    "BR"*"dc"^2*"dc\[Dagger]"*"L"^2*"uc\[Dagger]", 
    "dc"^2*"ec"*"ec\[Dagger]"*"GR"*"L"*"Q\[Dagger]", 
    "dc"^2*"ec"*"ec\[Dagger]"*"L"*"Q\[Dagger]"*"WR", 
    "BR"*"dc"^2*"ec"*"ec\[Dagger]"*"L"*"Q\[Dagger]", 
    "dc"*"GR"*"L"^3*"L\[Dagger]"*"uc\[Dagger]", "dc"*"L"^3*"L\[Dagger]"*
     "uc\[Dagger]"*"WR", "BR"*"dc"*"L"^3*"L\[Dagger]"*"uc\[Dagger]", 
    "dc"*"ec"*"GR"*"L"^2*"Q\[Dagger]"^2, "dc"*"ec"*"L"^2*"Q\[Dagger]"^2*"WR", 
    "BR"*"dc"*"ec"*"L"^2*"Q\[Dagger]"^2, "dc"*"ec"*"ec\[Dagger]"*"GR"*"L"^2*
     "uc\[Dagger]", "dc"*"ec"*"ec\[Dagger]"*"L"^2*"uc\[Dagger]"*"WR", 
    "BR"*"dc"*"ec"*"ec\[Dagger]"*"L"^2*"uc\[Dagger]", 
    "ec"*"GR"*"L"^3*"Q\[Dagger]"*"uc\[Dagger]", "ec"*"L"^3*"Q\[Dagger]"*
     "uc\[Dagger]"*"WR", "BR"*"ec"*"L"^3*"Q\[Dagger]"*"uc\[Dagger]"}, 
  FR^2*\[Phi]*\[Psi]^4 -> {"dc"*"GR"^2*"H"*"L"^2*"Q", 
    "dc"*"GR"*"H"*"L"^2*"Q"*"WR", "BR"*"dc"*"GR"*"H"*"L"^2*"Q", 
    "dc"*"H"*"L"^2*"Q"*"WR"^2, "BR"*"dc"*"H"*"L"^2*"Q"*"WR", 
    "BR"^2*"dc"*"H"*"L"^2*"Q", "dc"^2*"GR"^2*"H"*"L"*"uc", 
    "dc"^2*"GR"*"H"*"L"*"uc"*"WR", "BR"*"dc"^2*"GR"*"H"*"L"*"uc", 
    "dc"^2*"H"*"L"*"uc"*"WR"^2, "BR"*"dc"^2*"H"*"L"*"uc"*"WR", 
    "BR"^2*"dc"^2*"H"*"L"*"uc", "dc"^3*"GR"^2*"H\[Dagger]"*"L", 
    "dc"^3*"GR"*"H\[Dagger]"*"L"*"WR", "BR"*"dc"^3*"GR"*"H\[Dagger]"*"L", 
    "dc"^3*"H\[Dagger]"*"L"*"WR"^2, "BR"*"dc"^3*"H\[Dagger]"*"L"*"WR", 
    "BR"^2*"dc"^3*"H\[Dagger]"*"L", "ec"*"GR"^2*"H"*"L"^3, 
    "ec"*"H"*"L"^3*"WR"^2, "BR"*"ec"*"H"*"L"^3*"WR", "BR"^2*"ec"*"H"*"L"^3}, 
  FL*FR*\[Phi]*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"*"GL"*"GR"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "dc\[Dagger]"*"GL"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2*"WR", 
    "BR"*"dc\[Dagger]"*"GL"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "GL"*"GR"*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc", 
    "GL"*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc"*"WR", 
    "BR"*"GL"*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc", 
    "dc\[Dagger]"^2*"ec"*"GL"*"GR"*"H\[Dagger]"*"Q", 
    "dc\[Dagger]"^2*"ec"*"GL"*"H\[Dagger]"*"Q"*"WR", 
    "BR"*"dc\[Dagger]"^2*"ec"*"GL"*"H\[Dagger]"*"Q", 
    "dc\[Dagger]"*"ec"*"GL"*"GR"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "dc\[Dagger]"*"ec"*"GL"*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WR", 
    "BR"*"dc\[Dagger]"*"ec"*"GL"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "dc"^2*"ec\[Dagger]"*"GL"*"H"*"Q\[Dagger]"*"WR", 
    "BR"*"dc"^2*"ec\[Dagger]"*"GL"*"H"*"Q\[Dagger]", 
    "dc"*"GL"*"H"*"L"*"Q\[Dagger]"^2*"WR", "BR"*"dc"*"GL"*"H"*"L"*
     "Q\[Dagger]"^2, "dc"*"ec\[Dagger]"*"GL"*"H"*"L"*"uc\[Dagger]"*"WR", 
    "BR"*"dc"*"ec\[Dagger]"*"GL"*"H"*"L"*"uc\[Dagger]", 
    "GL"*"H"*"L"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WR", 
    "BR"*"GL"*"H"*"L"^2*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2*"WL"*"WR", 
    "BR"*"dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2*"WL", 
    "H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc"*"WL"*"WR", 
    "BR"*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc"*"WL", 
    "dc\[Dagger]"^2*"ec"*"H\[Dagger]"*"Q"*"WL"*"WR", 
    "BR"*"dc\[Dagger]"^2*"ec"*"H\[Dagger]"*"Q"*"WL", 
    "dc\[Dagger]"*"ec"*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WL"*"WR", 
    "BR"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WL", 
    "BR"*"dc"^2*"ec\[Dagger]"*"H"*"Q\[Dagger]"*"WL", 
    "BR"*"dc"*"H"*"L"*"Q\[Dagger]"^2*"WL", "BR"*"dc"*"ec\[Dagger]"*"H"*"L"*
     "uc\[Dagger]"*"WL", "BR"*"H"*"L"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"BR"*"dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "BL"*"BR"*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc", 
    "BL"*"BR"*"dc\[Dagger]"^2*"ec"*"H\[Dagger]"*"Q", 
    "BL"*"BR"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L\[Dagger]"*"uc"}, 
  FL*FR^2*\[Phi]^2*\[Psi]^2 -> {"GL"*"GR"^2*"H"^2*"L"^2, 
    "GL"*"GR"*"H"^2*"L"^2*"WR", "BR"*"GL"*"GR"*"H"^2*"L"^2, 
    "GR"^2*"H"^2*"L"^2*"WL", "H"^2*"L"^2*"WL"*"WR"^2, 
    "BR"*"H"^2*"L"^2*"WL"*"WR", "BR"^2*"H"^2*"L"^2*"WL", 
    "BL"*"GR"^2*"H"^2*"L"^2, "BL"*"H"^2*"L"^2*"WR"^2, 
    "BL"*"BR"*"H"^2*"L"^2*"WR", "BL"*"BR"^2*"H"^2*"L"^2}, 
  FL^2*FR^2*\[Phi]^3 -> {}, D*\[Phi]*\[Psi]^3*OverBar[\[Psi]]^3 -> 
   {"D"*"dc\[Dagger]"^3*"H"*"Q"^3, "D"*"dc\[Dagger]"*"H\[Dagger]"*
     "L\[Dagger]"*"Q"^3*"Q\[Dagger]", "D"*"dc\[Dagger]"^2*"H\[Dagger]"*"Q"^3*
     "uc\[Dagger]", "D"*"ec\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"^2*"Q"^3, 
    "D"*"dc\[Dagger]"^2*"H"*"L\[Dagger]"*"Q"^2*"uc", 
    "D"*"H\[Dagger]"*"L\[Dagger]"^2*"Q"^2*"Q\[Dagger]"*"uc", 
    "D"*"dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"^2*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "D"*"dc\[Dagger]"*"H\[Dagger]"*"L"*"L\[Dagger]"^2*"Q"^2, 
    "D"*"dc\[Dagger]"^2*"ec"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "D"*"dc\[Dagger]"*"H"*"L\[Dagger]"^2*"Q"*"uc"^2, 
    "D"*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc"^2*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*"uc", 
    "D"*"H\[Dagger]"*"L"*"L\[Dagger]"^3*"Q"*"uc", "D"*"dc\[Dagger]"^3*"ec"*
     "H"*"Q"*"uc", "D"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L\[Dagger]"*"Q"*
     "Q\[Dagger]"*"uc", "D"*"dc\[Dagger]"^2*"ec"*"H\[Dagger]"*"Q"*"uc"*
     "uc\[Dagger]", "D"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"^2*"Q"*
     "uc", "D"*"dc"^2*"ec\[Dagger]"^2*"H"*"Q"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"^3*"ec"*"H\[Dagger]"*"Q", 
    "D"*"ec\[Dagger]"*"H"*"L"^2*"Q"*"uc\[Dagger]"^2, 
    "D"*"dc\[Dagger]"^2*"ec"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "D"*"dc\[Dagger]"^2*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"Q", 
    "D"*"H"*"L\[Dagger]"^3*"uc"^3, "D"*"dc"*"H\[Dagger]"*"L\[Dagger]"^3*
     "uc"^2, "D"*"dc\[Dagger]"^2*"ec"*"H"*"L\[Dagger]"*"uc"^2, 
    "D"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"^2*"ec"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "D"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"*"L\[Dagger]"^2*"uc", 
    "D"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "D"*"dc"^3*"ec\[Dagger]"^2*"H"*"L\[Dagger]"}, 
  D*FR*\[Phi]^2*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"*"GR"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"^3, "D"*"H\[Dagger]"^2*
     "L\[Dagger]"*"Q"^3*"WR", "BR"*"D"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"^3, 
    "D"*"dc\[Dagger]"*"ec"*"GR"*"H\[Dagger]"^2*"Q"^2, 
    "D"*"dc\[Dagger]"*"ec"*"H\[Dagger]"^2*"Q"^2*"WR", 
    "BR"*"D"*"dc\[Dagger]"*"ec"*"H\[Dagger]"^2*"Q"^2, 
    "D"*"ec"*"GR"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"*"uc", 
    "D"*"ec"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"*"uc"*"WR", 
    "BR"*"D"*"ec"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"*"uc", 
    "D"*"dc"*"ec\[Dagger]"*"GR"*"H"^2*"L"*"Q", "D"*"dc"*"ec\[Dagger]"*"H"^2*
     "L"*"Q"*"WR", "BR"*"D"*"dc"*"ec\[Dagger]"*"H"^2*"L"*"Q", 
    "D"*"GR"*"H"^2*"L"^2*"Q"*"Q\[Dagger]", "D"*"H"^2*"L"^2*"Q"*"Q\[Dagger]"*
     "WR", "BR"*"D"*"H"^2*"L"^2*"Q"*"Q\[Dagger]", "D"*"dc"^2*"ec\[Dagger]"*
     "GR"*"H"^2*"uc", "D"*"dc"^2*"ec\[Dagger]"*"H"^2*"uc"*"WR", 
    "BR"*"D"*"dc"^2*"ec\[Dagger]"*"H"^2*"uc", "D"*"dc"*"GR"*"H"^2*"L"*
     "Q\[Dagger]"*"uc", "D"*"dc"*"H"^2*"L"*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"D"*"dc"*"H"^2*"L"*"Q\[Dagger]"*"uc", "D"*"GR"*"H"^2*"L"^2*"uc"*
     "uc\[Dagger]", "D"*"H"^2*"L"^2*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"H"^2*"L"^2*"uc"*"uc\[Dagger]", "D"*"dc\[Dagger]"*"ec"^2*"GR"*
     "H\[Dagger]"^2*"uc", "D"*"dc\[Dagger]"*"ec"^2*"H\[Dagger]"^2*"uc"*"WR", 
    "BR"*"D"*"dc\[Dagger]"*"ec"^2*"H\[Dagger]"^2*"uc", 
    "D"*"dc"^3*"ec\[Dagger]"*"GR"*"H"*"H\[Dagger]", 
    "D"*"dc"^3*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WR", 
    "BR"*"D"*"dc"^3*"ec\[Dagger]"*"H"*"H\[Dagger]", 
    "D"*"dc"^2*"GR"*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]", 
    "D"*"dc"^2*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]"*"WR", 
    "BR"*"D"*"dc"^2*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GR"*"H"^2*"L"^2, "D"*"dc"*"dc\[Dagger]"*"H"^2*
     "L"^2*"WR", "BR"*"D"*"dc"*"dc\[Dagger]"*"H"^2*"L"^2, 
    "D"*"dc"*"GR"*"H"*"H\[Dagger]"*"L"^2*"uc\[Dagger]", 
    "D"*"dc"*"H"*"H\[Dagger]"*"L"^2*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"dc"*"H"*"H\[Dagger]"*"L"^2*"uc\[Dagger]", 
    "D"*"H"^2*"L"^3*"L\[Dagger]"*"WR", "BR"*"D"*"H"^2*"L"^3*"L\[Dagger]", 
    "D"*"ec"*"ec\[Dagger]"*"H"^2*"L"^2*"WR", "BR"*"D"*"ec"*"ec\[Dagger]"*
     "H"^2*"L"^2}, D*FL*FR*\[Phi]^3*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"ec\[Dagger]"*"GL"*"GR"*"H"^3*"L", "D"*"ec\[Dagger]"*"H"^3*"L"*"WL"*
     "WR", "BR"*"D"*"ec\[Dagger]"*"H"^3*"L"*"WL", 
    "BR"*"D"*"ec"*"H\[Dagger]"^3*"L\[Dagger]"*"WL", 
    "BL"*"BR"*"D"*"ec\[Dagger]"*"H"^3*"L"}, 
  D^2*\[Phi]^3*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"D"^2*"dc\[Dagger]"*"H"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"^2, 
    "D"^2*"H\[Dagger]"^3*"L\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "D"^2*"H"*"H\[Dagger]"^2*"L\[Dagger]"^2*"Q"*"uc", 
    "D"^2*"dc"*"ec\[Dagger]"^2*"H"^3*"Q", "D"^2*"dc"*"H\[Dagger]"^3*
     "L\[Dagger]"^2*"Q", "D"^2*"ec\[Dagger]"*"H"^3*"L"*"Q"*"Q\[Dagger]", 
    "D"^2*"dc\[Dagger]"^2*"ec"*"H"*"H\[Dagger]"^2*"Q", 
    "D"^2*"dc\[Dagger]"*"ec"*"H\[Dagger]"^3*"Q"*"uc\[Dagger]", 
    "D"^2*"ec\[Dagger]"*"H"^3*"L"*"uc"*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"^2*"L\[Dagger]"*"uc", 
    "D"^2*"dc"*"dc\[Dagger]"*"ec\[Dagger]"*"H"^3*"L", 
    "D"^2*"ec\[Dagger]"*"H"^3*"L"^2*"L\[Dagger]", "D"^2*"ec"*"ec\[Dagger]"^2*
     "H"^3*"L"}, D^2*FR*\[Phi]^4*\[Psi]^2 -> 
   {"D"^2*"H"^3*"H\[Dagger]"*"L"^2*"WR", "BR"*"D"^2*"H"^3*"H\[Dagger]"*"L"^2, 
    "D"^2*"ec"^2*"H\[Dagger]"^4*"WR", "BR"*"D"^2*"ec"^2*"H\[Dagger]"^4}, 
  D^2*FL*FR*\[Phi]^5 -> {}, D^3*\[Phi]^5*\[Psi]*OverBar[\[Psi]] -> 
   {"D"^3*"ec\[Dagger]"*"H"^4*"H\[Dagger]"*"L"}, D^4*\[Phi]^7 -> {}, 
  \[Phi]^2*\[Psi]^6 -> {"H\[Dagger]"^2*"Q"^6, "ec"*"H\[Dagger]"^2*"Q"^4*"uc", 
    "H"^2*"L"^3*"Q"^3, "ec"^2*"H\[Dagger]"^2*"Q"^2*"uc"^2, 
    "dc"*"H"^2*"L"^2*"Q"^2*"uc", "dc"^2*"H"*"H\[Dagger]"*"L"^2*"Q"^2, 
    "dc"^2*"H"^2*"L"*"Q"*"uc"^2, "dc"^3*"H"*"H\[Dagger]"*"L"*"Q"*"uc", 
    "ec"*"H"^2*"L"^3*"Q"*"uc", "dc"^4*"H\[Dagger]"^2*"L"*"Q", 
    "dc"*"ec"*"H"*"H\[Dagger]"*"L"^3*"Q", "dc"^3*"H"^2*"uc"^3, 
    "ec"^3*"H\[Dagger]"^2*"uc"^3, "dc"^4*"H"*"H\[Dagger]"*"uc"^2, 
    "dc"*"ec"*"H"^2*"L"^2*"uc"^2, "dc"^5*"H\[Dagger]"^2*"uc", 
    "dc"^2*"ec"*"H"*"H\[Dagger]"*"L"^2*"uc", "dc"^3*"ec"*"H\[Dagger]"^2*
     "L"^2, "ec"^2*"H"*"H\[Dagger]"*"L"^4}, FL*\[Phi]^3*\[Psi]^4 -> 
   {"ec"*"GL"*"H\[Dagger]"^3*"Q"^3, "GL"*"H"^3*"L"^2*"Q"*"uc", 
    "ec"^2*"GL"*"H\[Dagger]"^3*"Q"*"uc", "dc"*"GL"*"H"^2*"H\[Dagger]"*"L"^2*
     "Q", "dc"*"GL"*"H"^3*"L"*"uc"^2, "dc"^2*"GL"*"H"^2*"H\[Dagger]"*"L"*
     "uc", "dc"^3*"GL"*"H"*"H\[Dagger]"^2*"L", "ec"*"H\[Dagger]"^3*"Q"^3*
     "WL", "H"^3*"L"^2*"Q"*"uc"*"WL", "ec"^2*"H\[Dagger]"^3*"Q"*"uc"*"WL", 
    "dc"*"H"^2*"H\[Dagger]"*"L"^2*"Q"*"WL", "dc"*"H"^3*"L"*"uc"^2*"WL", 
    "dc"^2*"H"^2*"H\[Dagger]"*"L"*"uc"*"WL", "dc"^3*"H"*"H\[Dagger]"^2*"L"*
     "WL", "ec"*"H"^2*"H\[Dagger]"*"L"^3*"WL", "BL"*"ec"*"H\[Dagger]"^3*
     "Q"^3, "BL"*"H"^3*"L"^2*"Q"*"uc", "BL"*"ec"^2*"H\[Dagger]"^3*"Q"*"uc", 
    "BL"*"dc"*"H"^2*"H\[Dagger]"*"L"^2*"Q", "BL"*"dc"*"H"^3*"L"*"uc"^2, 
    "BL"*"dc"^2*"H"^2*"H\[Dagger]"*"L"*"uc", "BL"*"dc"^3*"H"*"H\[Dagger]"^2*
     "L", "BL"*"ec"*"H"^2*"H\[Dagger]"*"L"^3}, FL^2*\[Phi]^4*\[Psi]^2 -> 
   {"GL"^2*"H"^3*"H\[Dagger]"*"L"^2, "ec"^2*"GL"^2*"H\[Dagger]"^4, 
    "H"^3*"H\[Dagger]"*"L"^2*"WL"^2, "ec"^2*"H\[Dagger]"^4*"WL"^2, 
    "BL"*"H"^3*"H\[Dagger]"*"L"^2*"WL", "BL"*"ec"^2*"H\[Dagger]"^4*"WL", 
    "BL"^2*"H"^3*"H\[Dagger]"*"L"^2, "BL"^2*"ec"^2*"H\[Dagger]"^4}, 
  FL^3*\[Phi]^5 -> {}, \[Phi]^2*\[Psi]^4*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"^2*"H"*"H\[Dagger]"*"Q"^4, "H\[Dagger]"^2*"L\[Dagger]"*"Q"^4*
     "Q\[Dagger]", "dc\[Dagger]"*"H\[Dagger]"^2*"Q"^4*"uc\[Dagger]", 
    "dc\[Dagger]"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q"^3*"uc", 
    "H\[Dagger]"^2*"L\[Dagger]"*"Q"^3*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"^3, 
    "H\[Dagger]"^2*"L"*"L\[Dagger]"^2*"Q"^3, "dc\[Dagger]"*"ec"*
     "H\[Dagger]"^2*"Q"^3*"Q\[Dagger]", "ec"*"ec\[Dagger]"*"H\[Dagger]"^2*
     "L\[Dagger]"*"Q"^3, "H"*"H\[Dagger]"*"L\[Dagger]"^2*"Q"^2*"uc"^2, 
    "dc"*"H\[Dagger]"^2*"L\[Dagger]"^2*"Q"^2*"uc", 
    "dc\[Dagger]"^2*"ec"*"H"*"H\[Dagger]"*"Q"^2*"uc", 
    "ec"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc", 
    "dc\[Dagger]"*"ec"*"H\[Dagger]"^2*"Q"^2*"uc"*"uc\[Dagger]", 
    "dc"^2*"ec\[Dagger]"^2*"H"^2*"Q"^2, "dc"*"ec\[Dagger]"*"H"^2*"L"*"Q"^2*
     "Q\[Dagger]", "dc"*"dc\[Dagger]"^2*"ec"*"H\[Dagger]"^2*"Q"^2, 
    "H"^2*"L"^2*"Q"^2*"Q\[Dagger]"^2, "ec\[Dagger]"*"H"^2*"L"^2*"Q"^2*
     "uc\[Dagger]", "dc\[Dagger]"*"ec"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"Q"^2, 
    "dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"^2*"Q"^2, 
    "dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q"*"uc"^2, 
    "ec"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]", 
    "dc"^2*"ec\[Dagger]"*"H"^2*"Q"*"Q\[Dagger]"*"uc", 
    "dc"*"H"^2*"L"*"Q"*"Q\[Dagger]"^2*"uc", "dc"*"ec\[Dagger]"*"H"^2*"L"*"Q"*
     "uc"*"uc\[Dagger]", "dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"^2*"L\[Dagger]"*
     "Q"*"uc", "H"^2*"L"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "ec"*"H\[Dagger]"^2*"L"*"L\[Dagger]"^2*"Q"*"uc", 
    "dc\[Dagger]"*"ec"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc", 
    "ec"^2*"ec\[Dagger]"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"*"uc", 
    "dc"^3*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "dc"^2*"dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"L"*"Q", 
    "dc"^2*"H"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"^2, 
    "dc"^2*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"*"Q"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"H"^2*"L"^2*"Q"*"Q\[Dagger]", 
    "dc"*"ec\[Dagger]"*"H"^2*"L"^2*"L\[Dagger]"*"Q", 
    "dc"*"H"*"H\[Dagger]"*"L"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc"*"ec"*"ec\[Dagger]"^2*"H"^2*"L"*"Q", "H"^2*"L"^3*"L\[Dagger]"*"Q"*
     "Q\[Dagger]", "dc\[Dagger]"*"H"^2*"L"^3*"Q"*"uc\[Dagger]", 
    "H"*"H\[Dagger]"*"L"^3*"Q"*"uc\[Dagger]"^2, "ec"*"ec\[Dagger]"*"H"^2*
     "L"^2*"Q"*"Q\[Dagger]", "dc\[Dagger]"^2*"ec"^2*"H\[Dagger]"^2*"L"*"Q", 
    "ec"*"H"*"H\[Dagger]"*"L\[Dagger]"^2*"uc"^3, "dc"^2*"H"^2*"Q\[Dagger]"^2*
     "uc"^2, "dc"^2*"ec\[Dagger]"*"H"^2*"uc"^2*"uc\[Dagger]", 
    "dc"*"H"^2*"L"*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "dc"*"ec"*"H\[Dagger]"^2*"L\[Dagger]"^2*"uc"^2, 
    "H"^2*"L"^2*"uc"^2*"uc\[Dagger]"^2, "dc\[Dagger]"^2*"ec"^2*"H"*
     "H\[Dagger]"*"uc"^2, "ec"^2*"H\[Dagger]"^2*"L\[Dagger]"*"Q\[Dagger]"*
     "uc"^2, "dc\[Dagger]"*"ec"^2*"H\[Dagger]"^2*"uc"^2*"uc\[Dagger]", 
    "dc"^3*"dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"uc", 
    "dc"^3*"H"*"H\[Dagger]"*"Q\[Dagger]"^2*"uc", "dc"^3*"ec\[Dagger]"*"H"*
     "H\[Dagger]"*"uc"*"uc\[Dagger]", "dc"^2*"dc\[Dagger]"*"H"^2*"L"*
     "Q\[Dagger]"*"uc", "dc"^2*"ec\[Dagger]"*"H"^2*"L"*"L\[Dagger]"*"uc", 
    "dc"^2*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"^2*"ec"*"ec\[Dagger]"^2*"H"^2*"uc", "dc"*"H"^2*"L"^2*"L\[Dagger]"*
     "Q\[Dagger]"*"uc", "dc"*"dc\[Dagger]"*"H"^2*"L"^2*"uc"*"uc\[Dagger]", 
    "dc"*"H"*"H\[Dagger]"*"L"^2*"uc"*"uc\[Dagger]"^2, 
    "dc"*"ec"*"ec\[Dagger]"*"H"^2*"L"*"Q\[Dagger]"*"uc", 
    "dc"*"dc\[Dagger]"^2*"ec"^2*"H\[Dagger]"^2*"uc", 
    "H"^2*"L"^3*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "ec"*"H"^2*"L"^2*"Q\[Dagger]"^2*"uc", "ec"*"ec\[Dagger]"*"H"^2*"L"^2*"uc"*
     "uc\[Dagger]", "dc\[Dagger]"*"ec"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]"*
     "uc", "dc\[Dagger]"*"ec"^3*"ec\[Dagger]"*"H\[Dagger]"^2*"uc", 
    "dc"^4*"dc\[Dagger]"*"ec\[Dagger]"*"H"*"H\[Dagger]", 
    "dc"^4*"H\[Dagger]"^2*"Q\[Dagger]"^2, "dc"^4*"ec\[Dagger]"*"H\[Dagger]"^2*
     "uc\[Dagger]", "dc"^3*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]", 
    "dc"^3*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "dc"^3*"H\[Dagger]"^2*"L"*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc"^3*"ec"*"ec\[Dagger]"^2*"H"*"H\[Dagger]", "dc"^2*"dc\[Dagger]"^2*
     "H"^2*"L"^2, "dc"^2*"H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"Q\[Dagger]", 
    "dc"^2*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"^2*"uc\[Dagger]", 
    "dc"^2*"H\[Dagger]"^2*"L"^2*"uc\[Dagger]"^2, "dc"^2*"ec"*"ec\[Dagger]"*
     "H"*"H\[Dagger]"*"L"*"Q\[Dagger]", "dc"*"dc\[Dagger]"*"H"^2*"L"^3*
     "L\[Dagger]", "dc"*"H"*"H\[Dagger]"*"L"^3*"L\[Dagger]"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*"L"^2, 
    "dc"*"ec"*"H"*"H\[Dagger]"*"L"^2*"Q\[Dagger]"^2, 
    "dc"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"^2*"uc\[Dagger]", 
    "H"^2*"L"^4*"L\[Dagger]"^2, "dc\[Dagger]"*"ec"*"H"^2*"L"^3*"Q\[Dagger]", 
    "ec"*"ec\[Dagger]"*"H"^2*"L"^3*"L\[Dagger]", "ec"*"H"*"H\[Dagger]"*"L"^3*
     "Q\[Dagger]"*"uc\[Dagger]", "ec"^2*"ec\[Dagger]"^2*"H"^2*"L"^2}, 
  FL*\[Phi]^3*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"^2, 
    "GL"*"H\[Dagger]"^3*"L\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "GL"*"H"*"H\[Dagger]"^2*"L\[Dagger]"^2*"Q"*"uc", 
    "dc"*"ec\[Dagger]"^2*"GL"*"H"^3*"Q", "dc"*"GL"*"H\[Dagger]"^3*
     "L\[Dagger]"^2*"Q", "ec\[Dagger]"*"GL"*"H"^3*"L"*"Q"*"Q\[Dagger]", 
    "dc\[Dagger]"^2*"ec"*"GL"*"H"*"H\[Dagger]"^2*"Q", 
    "ec"*"GL"*"H\[Dagger]"^3*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "dc\[Dagger]"*"ec"*"GL"*"H\[Dagger]"^3*"Q"*"uc\[Dagger]", 
    "dc"*"ec\[Dagger]"*"GL"*"H"^3*"Q\[Dagger]"*"uc", 
    "GL"*"H"^3*"L"*"Q\[Dagger]"^2*"uc", "ec\[Dagger]"*"GL"*"H"^3*"L"*"uc"*
     "uc\[Dagger]", "dc\[Dagger]"*"ec"*"GL"*"H"*"H\[Dagger]"^2*"L\[Dagger]"*
     "uc", "ec"*"GL"*"H\[Dagger]"^3*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"^2*"ec\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"*"Q\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec\[Dagger]"*"GL"*"H"^3*"L", 
    "dc"*"GL"*"H"^2*"H\[Dagger]"*"L"*"Q\[Dagger]"^2, 
    "dc"*"ec\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"*"L"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"*"GL"*"H\[Dagger]"^3*"L\[Dagger]", 
    "dc\[Dagger]"*"GL"*"H"^3*"L"^2*"Q\[Dagger]", "GL"*"H"^2*"H\[Dagger]"*
     "L"^2*"Q\[Dagger]"*"uc\[Dagger]", "dc\[Dagger]"*"ec"^2*"GL"*
     "H\[Dagger]"^3*"Q\[Dagger]", "dc\[Dagger]"*"H"*"H\[Dagger]"^2*
     "L\[Dagger]"*"Q"^2*"WL", "H\[Dagger]"^3*"L\[Dagger]"*"Q"^2*"uc\[Dagger]"*
     "WL", "H"*"H\[Dagger]"^2*"L\[Dagger]"^2*"Q"*"uc"*"WL", 
    "dc"*"ec\[Dagger]"^2*"H"^3*"Q"*"WL", "dc"*"H\[Dagger]"^3*"L\[Dagger]"^2*
     "Q"*"WL", "ec\[Dagger]"*"H"^3*"L"*"Q"*"Q\[Dagger]"*"WL", 
    "dc\[Dagger]"^2*"ec"*"H"*"H\[Dagger]"^2*"Q"*"WL", 
    "ec"*"H\[Dagger]"^3*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "dc\[Dagger]"*"ec"*"H\[Dagger]"^3*"Q"*"uc\[Dagger]"*"WL", 
    "dc"*"ec\[Dagger]"*"H"^3*"Q\[Dagger]"*"uc"*"WL", 
    "H"^3*"L"*"Q\[Dagger]"^2*"uc"*"WL", "ec\[Dagger]"*"H"^3*"L"*"uc"*
     "uc\[Dagger]"*"WL", "dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"^2*"L\[Dagger]"*
     "uc"*"WL", "ec"*"H\[Dagger]"^3*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "dc"^2*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"ec\[Dagger]"*"H"^3*"L"*"WL", 
    "dc"*"H"^2*"H\[Dagger]"*"L"*"Q\[Dagger]"^2*"WL", 
    "dc"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"L"*"uc\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"^3*"L\[Dagger]"*"WL", 
    "dc\[Dagger]"*"H"^3*"L"^2*"Q\[Dagger]"*"WL", "ec\[Dagger]"*"H"^3*"L"^2*
     "L\[Dagger]"*"WL", "H"^2*"H\[Dagger]"*"L"^2*"Q\[Dagger]"*"uc\[Dagger]"*
     "WL", "ec"*"ec\[Dagger]"^2*"H"^3*"L"*"WL", "ec"*"H\[Dagger]"^3*"L"*
     "L\[Dagger]"^2*"WL", "dc\[Dagger]"*"ec"^2*"H\[Dagger]"^3*"Q\[Dagger]"*
     "WL", "ec"^2*"ec\[Dagger]"*"H\[Dagger]"^3*"L\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"*"H"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"^2, 
    "BL"*"H\[Dagger]"^3*"L\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "BL"*"H"*"H\[Dagger]"^2*"L\[Dagger]"^2*"Q"*"uc", 
    "BL"*"dc"*"ec\[Dagger]"^2*"H"^3*"Q", "BL"*"dc"*"H\[Dagger]"^3*
     "L\[Dagger]"^2*"Q", "BL"*"ec\[Dagger]"*"H"^3*"L"*"Q"*"Q\[Dagger]", 
    "BL"*"dc\[Dagger]"^2*"ec"*"H"*"H\[Dagger]"^2*"Q", 
    "BL"*"ec"*"H\[Dagger]"^3*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"dc\[Dagger]"*"ec"*"H\[Dagger]"^3*"Q"*"uc\[Dagger]", 
    "BL"*"dc"*"ec\[Dagger]"*"H"^3*"Q\[Dagger]"*"uc", 
    "BL"*"H"^3*"L"*"Q\[Dagger]"^2*"uc", "BL"*"ec\[Dagger]"*"H"^3*"L"*"uc"*
     "uc\[Dagger]", "BL"*"dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"^2*"L\[Dagger]"*
     "uc", "BL"*"ec"*"H\[Dagger]"^3*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"dc"^2*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"ec\[Dagger]"*"H"^3*"L", 
    "BL"*"dc"*"H"^2*"H\[Dagger]"*"L"*"Q\[Dagger]"^2, 
    "BL"*"dc"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"L"*"uc\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"^3*"L\[Dagger]", 
    "BL"*"dc\[Dagger]"*"H"^3*"L"^2*"Q\[Dagger]", "BL"*"ec\[Dagger]"*"H"^3*
     "L"^2*"L\[Dagger]", "BL"*"H"^2*"H\[Dagger]"*"L"^2*"Q\[Dagger]"*
     "uc\[Dagger]", "BL"*"ec"*"ec\[Dagger]"^2*"H"^3*"L", 
    "BL"*"ec"*"H\[Dagger]"^3*"L"*"L\[Dagger]"^2, "BL"*"dc\[Dagger]"*"ec"^2*
     "H\[Dagger]"^3*"Q\[Dagger]", "BL"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"^3*
     "L\[Dagger]"}, FL^2*\[Phi]^4*OverBar[\[Psi]]^2 -> 
   {"ec\[Dagger]"^2*"GL"^2*"H"^4, "GL"^2*"H"*"H\[Dagger]"^3*"L\[Dagger]"^2, 
    "ec\[Dagger]"^2*"H"^4*"WL"^2, "H"*"H\[Dagger]"^3*"L\[Dagger]"^2*"WL"^2, 
    "BL"*"ec\[Dagger]"^2*"H"^4*"WL", "BL"*"H"*"H\[Dagger]"^3*"L\[Dagger]"^2*
     "WL", "BL"^2*"ec\[Dagger]"^2*"H"^4, "BL"^2*"H"*"H\[Dagger]"^3*
     "L\[Dagger]"^2}, D*\[Phi]^4*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"*"H"*"H\[Dagger]"^3*"L\[Dagger]"*"Q"^3, "D"*"dc\[Dagger]"*"ec"*"H"*
     "H\[Dagger]"^3*"Q"^2, "D"*"ec"*"H\[Dagger]"^4*"Q"^2*"uc\[Dagger]", 
    "D"*"ec\[Dagger]"*"H"^4*"L"*"Q"*"uc", "D"*"ec"*"H"*"H\[Dagger]"^3*
     "L\[Dagger]"*"Q"*"uc", "D"*"dc"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"*"L"*
     "Q", "D"*"dc"*"ec"*"H\[Dagger]"^4*"L\[Dagger]"*"Q", 
    "D"*"H"^3*"H\[Dagger]"*"L"^2*"Q"*"Q\[Dagger]", 
    "D"*"ec"^2*"H\[Dagger]"^4*"Q"*"Q\[Dagger]", "D"*"dc"*"ec\[Dagger]"*"H"^4*
     "uc"^2, "D"*"H"^4*"L"*"Q\[Dagger]"*"uc"^2, "D"*"dc"^2*"ec\[Dagger]"*
     "H"^3*"H\[Dagger]"*"uc", "D"*"dc"*"H"^3*"H\[Dagger]"*"L"*"Q\[Dagger]"*
     "uc", "D"*"dc\[Dagger]"*"H"^4*"L"^2*"uc", "D"*"H"^3*"H\[Dagger]"*"L"^2*
     "uc"*"uc\[Dagger]", "D"*"dc\[Dagger]"*"ec"^2*"H"*"H\[Dagger]"^3*"uc", 
    "D"*"ec"^2*"H\[Dagger]"^4*"uc"*"uc\[Dagger]", "D"*"dc"^3*"ec\[Dagger]"*
     "H"^2*"H\[Dagger]"^2, "D"*"dc"^2*"H"^2*"H\[Dagger]"^2*"L"*"Q\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"*"L"^2, 
    "D"*"dc"*"H"^2*"H\[Dagger]"^2*"L"^2*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"ec"^2*"H\[Dagger]"^4, "D"*"H"^3*"H\[Dagger]"*
     "L"^3*"L\[Dagger]", "D"*"ec"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"*"L"^2, 
    "D"*"ec"^2*"H\[Dagger]"^4*"L"*"L\[Dagger]", "D"*"ec"^3*"ec\[Dagger]"*
     "H\[Dagger]"^4}, D*FL*\[Phi]^5*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"ec\[Dagger]"*"H"^4*"H\[Dagger]"*"L"*"WL", 
    "D"*"ec"*"H"*"H\[Dagger]"^4*"L\[Dagger]"*"WL", 
    "BL"*"D"*"ec\[Dagger]"*"H"^4*"H\[Dagger]"*"L", 
    "BL"*"D"*"ec"*"H"*"H\[Dagger]"^4*"L\[Dagger]"}, 
  D^2*\[Phi]^6*\[Psi]^2 -> {"D"^2*"H"^4*"H\[Dagger]"^2*"L"^2, 
    "D"^2*"ec"^2*"H"*"H\[Dagger]"^5}, D^2*FL*\[Phi]^7 -> {}, 
  \[Phi]^5*\[Psi]^4 -> {"ec"*"H"*"H\[Dagger]"^4*"Q"^3, 
    "H"^4*"H\[Dagger]"*"L"^2*"Q"*"uc", "ec"^2*"H"*"H\[Dagger]"^4*"Q"*"uc", 
    "dc"*"H"^3*"H\[Dagger]"^2*"L"^2*"Q", "dc"*"ec"^2*"H\[Dagger]"^5*"Q", 
    "H"^5*"L"*"uc"^3, "dc"*"H"^4*"H\[Dagger]"*"L"*"uc"^2, 
    "dc"^2*"H"^3*"H\[Dagger]"^2*"L"*"uc", "dc"^3*"H"^2*"H\[Dagger]"^3*"L", 
    "ec"*"H"^3*"H\[Dagger]"^2*"L"^3, "ec"^3*"H\[Dagger]"^5*"L"}, 
  FL*\[Phi]^6*\[Psi]^2 -> {"H"^4*"H\[Dagger]"^2*"L"^2*"WL", 
    "ec"^2*"H"*"H\[Dagger]"^5*"WL", "BL"*"H"^4*"H\[Dagger]"^2*"L"^2, 
    "BL"*"ec"^2*"H"*"H\[Dagger]"^5}, FL^2*\[Phi]^7 -> {}, 
  \[Phi]^5*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"*"H"^2*"H\[Dagger]"^3*"L\[Dagger]"*"Q"^2, 
    "H"*"H\[Dagger]"^4*"L\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "ec\[Dagger]"^2*"H"^5*"Q"*"uc", "H"^2*"H\[Dagger]"^3*"L\[Dagger]"^2*"Q"*
     "uc", "dc"*"ec\[Dagger]"^2*"H"^4*"H\[Dagger]"*"Q", 
    "dc"*"H"*"H\[Dagger]"^4*"L\[Dagger]"^2*"Q", "ec\[Dagger]"*"H"^4*
     "H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", "dc\[Dagger]"^2*"ec"*"H"^2*
     "H\[Dagger]"^3*"Q", "dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"^4*"Q"*
     "uc\[Dagger]", "ec"*"H\[Dagger]"^5*"Q"*"uc\[Dagger]"^2, 
    "dc\[Dagger]"*"ec\[Dagger]"*"H"^5*"L"*"uc", "ec\[Dagger]"*"H"^4*
     "H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", "dc\[Dagger]"*"ec"*"H"^2*
     "H\[Dagger]"^3*"L\[Dagger]"*"uc", "dc"*"dc\[Dagger]"*"ec\[Dagger]"*"H"^4*
     "H\[Dagger]"*"L", "ec\[Dagger]"*"H"^4*"H\[Dagger]"*"L"^2*"L\[Dagger]", 
    "ec"*"ec\[Dagger]"^2*"H"^4*"H\[Dagger]"*"L"}, 
  D*\[Phi]^7*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"ec\[Dagger]"*"H"^5*"H\[Dagger]"^2*"L"}, D^2*\[Phi]^9 -> {}, 
  \[Phi]^8*\[Psi]^2 -> {"H"^5*"H\[Dagger]"^3*"L"^2, 
    "ec"^2*"H"^2*"H\[Dagger]"^6}, \[Phi]^11 -> {}|>, 
 <|D^4*FL^4 -> {"D"^4*"GL"^4, "BL"*"D"^4*"GL"^3, "D"^4*"GL"^2*"WL"^2, 
    "BL"^2*"D"^4*"GL"^2, "D"^4*"WL"^4, "BL"*"D"^4*"WL"^3, 
    "BL"^2*"D"^4*"WL"^2, "BL"^4*"D"^4}, D^4*FL^3*FR -> 
   {"D"^4*"GL"^3*"GR", "BR"*"D"^4*"GL"^3, "D"^4*"GL"^2*"WL"*"WR", 
    "BL"*"D"^4*"GL"^2*"GR", "BL"*"BR"*"D"^4*"GL"^2, "D"^4*"GL"*"GR"*"WL"^2, 
    "BL"^2*"D"^4*"GL"*"GR", "D"^4*"WL"^3*"WR", "BR"*"D"^4*"WL"^3, 
    "BL"*"D"^4*"WL"^2*"WR", "BL"*"BR"*"D"^4*"WL"^2, "BL"^2*"D"^4*"WL"*"WR", 
    "BL"^3*"BR"*"D"^4}, D^5*FL^2*\[Psi]*OverBar[\[Psi]] -> 
   {"D"^5*"GL"^2*"Q"*"Q\[Dagger]", "D"^5*"GL"^2*"uc"*"uc\[Dagger]", 
    "D"^5*"dc"*"dc\[Dagger]"*"GL"^2, "D"^5*"GL"^2*"L"*"L\[Dagger]", 
    "D"^5*"ec"*"ec\[Dagger]"*"GL"^2, "D"^5*"GL"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"D"^5*"GL"*"Q"*"Q\[Dagger]", "BL"*"D"^5*"GL"*"uc"*"uc\[Dagger]", 
    "BL"*"D"^5*"dc"*"dc\[Dagger]"*"GL", "D"^5*"Q"*"Q\[Dagger]"*"WL"^2, 
    "D"^5*"uc"*"uc\[Dagger]"*"WL"^2, "D"^5*"dc"*"dc\[Dagger]"*"WL"^2, 
    "D"^5*"L"*"L\[Dagger]"*"WL"^2, "D"^5*"ec"*"ec\[Dagger]"*"WL"^2, 
    "BL"*"D"^5*"Q"*"Q\[Dagger]"*"WL", "BL"*"D"^5*"L"*"L\[Dagger]"*"WL", 
    "BL"^2*"D"^5*"Q"*"Q\[Dagger]", "BL"^2*"D"^5*"uc"*"uc\[Dagger]", 
    "BL"^2*"D"^5*"dc"*"dc\[Dagger]", "BL"^2*"D"^5*"L"*"L\[Dagger]", 
    "BL"^2*"D"^5*"ec"*"ec\[Dagger]"}, D^6*\[Psi]^4 -> 
   {"D"^6*"L"*"Q"^3, "D"^6*"dc"*"Q"^2*"uc", "D"^6*"ec"*"L"*"Q"*"uc", 
    "D"^6*"dc"*"ec"*"uc"^2}, D^6*FL*\[Phi]*\[Psi]^2 -> 
   {"D"^6*"GL"*"H"*"Q"*"uc", "D"^6*"dc"*"GL"*"H\[Dagger]"*"Q", 
    "D"^6*"H"*"Q"*"uc"*"WL", "D"^6*"dc"*"H\[Dagger]"*"Q"*"WL", 
    "D"^6*"ec"*"H\[Dagger]"*"L"*"WL", "BL"*"D"^6*"H"*"Q"*"uc", 
    "BL"*"D"^6*"dc"*"H\[Dagger]"*"Q", "BL"*"D"^6*"ec"*"H\[Dagger]"*"L"}, 
  D^6*FL^2*\[Phi]^2 -> {"D"^6*"GL"^2*"H"*"H\[Dagger]", 
    "D"^6*"H"*"H\[Dagger]"*"WL"^2, "BL"*"D"^6*"H"*"H\[Dagger]"*"WL", 
    "BL"^2*"D"^6*"H"*"H\[Dagger]"}, D^4*FL^2*FR^2 -> 
   {"D"^4*"GL"^2*"GR"^2, "BR"*"D"^4*"GL"^2*"GR", "D"^4*"GL"^2*"WR"^2, 
    "BR"^2*"D"^4*"GL"^2, "D"^4*"GL"*"GR"*"WL"*"WR", 
    "BL"*"BR"*"D"^4*"GL"*"GR", "D"^4*"WL"^2*"WR"^2, "BR"*"D"^4*"WL"^2*"WR", 
    "BR"^2*"D"^4*"WL"^2, "BL"*"BR"*"D"^4*"WL"*"WR", "BL"^2*"BR"^2*"D"^4}, 
  D^5*FL*FR*\[Psi]*OverBar[\[Psi]] -> {"D"^5*"GL"*"GR"*"Q"*"Q\[Dagger]", 
    "D"^5*"GL"*"Q"*"Q\[Dagger]"*"WR", "BR"*"D"^5*"GL"*"Q"*"Q\[Dagger]", 
    "D"^5*"GL"*"GR"*"uc"*"uc\[Dagger]", "BR"*"D"^5*"GL"*"uc"*"uc\[Dagger]", 
    "D"^5*"dc"*"dc\[Dagger]"*"GL"*"GR", "BR"*"D"^5*"dc"*"dc\[Dagger]"*"GL", 
    "D"^5*"GL"*"GR"*"L"*"L\[Dagger]", "D"^5*"ec"*"ec\[Dagger]"*"GL"*"GR", 
    "D"^5*"Q"*"Q\[Dagger]"*"WL"*"WR", "BR"*"D"^5*"Q"*"Q\[Dagger]"*"WL", 
    "D"^5*"uc"*"uc\[Dagger]"*"WL"*"WR", "D"^5*"dc"*"dc\[Dagger]"*"WL"*"WR", 
    "D"^5*"L"*"L\[Dagger]"*"WL"*"WR", "BR"*"D"^5*"L"*"L\[Dagger]"*"WL", 
    "D"^5*"ec"*"ec\[Dagger]"*"WL"*"WR", "BL"*"BR"*"D"^5*"Q"*"Q\[Dagger]", 
    "BL"*"BR"*"D"^5*"uc"*"uc\[Dagger]", "BL"*"BR"*"D"^5*"dc"*"dc\[Dagger]", 
    "BL"*"BR"*"D"^5*"L"*"L\[Dagger]", "BL"*"BR"*"D"^5*"ec"*"ec\[Dagger]"}, 
  D^6*\[Psi]^2*OverBar[\[Psi]]^2 -> {"D"^6*"Q"^2*"Q\[Dagger]"^2, 
    "D"^6*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]", "D"^6*"Q"*"Q\[Dagger]"*"uc"*
     "uc\[Dagger]", "D"^6*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"^6*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q", "D"^6*"L"*"L\[Dagger]"*"Q"*
     "Q\[Dagger]", "D"^6*"dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]", 
    "D"^6*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]", "D"^6*"uc"^2*"uc\[Dagger]"^2, 
    "D"^6*"dc"*"dc\[Dagger]"*"uc"*"uc\[Dagger]", "D"^6*"L"*"L\[Dagger]"*"uc"*
     "uc\[Dagger]", "D"^6*"ec"*"ec\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^6*"dc"^2*"dc\[Dagger]"^2, "D"^6*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]", 
    "D"^6*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]", "D"^6*"L"^2*"L\[Dagger]"^2, 
    "D"^6*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]", "D"^6*"ec"^2*"ec\[Dagger]"^2}, 
  D^6*FR*\[Phi]*\[Psi]^2 -> {"D"^6*"GR"*"H"*"Q"*"uc", 
    "D"^6*"H"*"Q"*"uc"*"WR", "BR"*"D"^6*"H"*"Q"*"uc", 
    "D"^6*"dc"*"GR"*"H\[Dagger]"*"Q", "D"^6*"dc"*"H\[Dagger]"*"Q"*"WR", 
    "BR"*"D"^6*"dc"*"H\[Dagger]"*"Q", "D"^6*"ec"*"H\[Dagger]"*"L"*"WR", 
    "BR"*"D"^6*"ec"*"H\[Dagger]"*"L"}, D^6*FL*FR*\[Phi]^2 -> 
   {"D"^6*"GL"*"GR"*"H"*"H\[Dagger]", "D"^6*"H"*"H\[Dagger]"*"WL"*"WR", 
    "BR"*"D"^6*"H"*"H\[Dagger]"*"WL", "BL"*"BR"*"D"^6*"H"*"H\[Dagger]"}, 
  D^7*\[Phi]^2*\[Psi]*OverBar[\[Psi]] -> 
   {"D"^7*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", "D"^7*"dc\[Dagger]"*"H"^2*"uc", 
    "D"^7*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", "D"^7*"dc"*"dc\[Dagger]"*"H"*
     "H\[Dagger]", "D"^7*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "D"^7*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"}, 
  D^8*\[Phi]^4 -> {"D"^8*"H"^2*"H\[Dagger]"^2}, 
  D^2*FL^5 -> {"D"^2*"GL"^5, "BL"*"D"^2*"GL"^4, "D"^2*"GL"^3*"WL"^2, 
    "BL"^2*"D"^2*"GL"^3, "D"^2*"GL"^2*"WL"^3, "BL"*"D"^2*"GL"^2*"WL"^2, 
    "BL"^3*"D"^2*"GL"^2, "D"^2*"WL"^5, "BL"*"D"^2*"WL"^4, 
    "BL"^2*"D"^2*"WL"^3, "BL"^3*"D"^2*"WL"^2, "BL"^5*"D"^2}, 
  D^2*FL^4*FR -> {"D"^2*"GL"^4*"GR", "BR"*"D"^2*"GL"^4, 
    "D"^2*"GL"^3*"WL"*"WR", "BL"*"D"^2*"GL"^3*"GR", "BL"*"BR"*"D"^2*"GL"^3, 
    "D"^2*"GL"^2*"GR"*"WL"^2, "D"^2*"GL"^2*"WL"^2*"WR", 
    "BR"*"D"^2*"GL"^2*"WL"^2, "BL"*"D"^2*"GL"^2*"WL"*"WR", 
    "BL"^2*"D"^2*"GL"^2*"GR", "BL"^2*"BR"*"D"^2*"GL"^2, 
    "D"^2*"GL"*"GR"*"WL"^3, "BL"*"D"^2*"GL"*"GR"*"WL"^2, 
    "BL"^3*"D"^2*"GL"*"GR", "D"^2*"WL"^4*"WR", "BR"*"D"^2*"WL"^4, 
    "BL"*"D"^2*"WL"^3*"WR", "BL"*"BR"*"D"^2*"WL"^3, "BL"^2*"D"^2*"WL"^2*"WR", 
    "BL"^2*"BR"*"D"^2*"WL"^2, "BL"^3*"D"^2*"WL"*"WR", "BL"^4*"BR"*"D"^2}, 
  D^3*FL^3*\[Psi]*OverBar[\[Psi]] -> {"D"^3*"GL"^3*"Q"*"Q\[Dagger]", 
    "D"^3*"GL"^3*"uc"*"uc\[Dagger]", "D"^3*"dc"*"dc\[Dagger]"*"GL"^3, 
    "D"^3*"GL"^3*"L"*"L\[Dagger]", "D"^3*"ec"*"ec\[Dagger]"*"GL"^3, 
    "D"^3*"GL"^2*"Q"*"Q\[Dagger]"*"WL", "D"^3*"GL"^2*"L"*"L\[Dagger]"*"WL", 
    "BL"*"D"^3*"GL"^2*"Q"*"Q\[Dagger]", "BL"*"D"^3*"GL"^2*"uc"*"uc\[Dagger]", 
    "BL"*"D"^3*"dc"*"dc\[Dagger]"*"GL"^2, "BL"*"D"^3*"GL"^2*"L"*"L\[Dagger]", 
    "BL"*"D"^3*"ec"*"ec\[Dagger]"*"GL"^2, "D"^3*"GL"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "D"^3*"GL"*"uc"*"uc\[Dagger]"*"WL"^2, "D"^3*"dc"*"dc\[Dagger]"*"GL"*
     "WL"^2, "BL"*"D"^3*"GL"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"^2*"D"^3*"GL"*"Q"*"Q\[Dagger]", "BL"^2*"D"^3*"GL"*"uc"*"uc\[Dagger]", 
    "BL"^2*"D"^3*"dc"*"dc\[Dagger]"*"GL", "D"^3*"Q"*"Q\[Dagger]"*"WL"^3, 
    "D"^3*"uc"*"uc\[Dagger]"*"WL"^3, "D"^3*"dc"*"dc\[Dagger]"*"WL"^3, 
    "D"^3*"L"*"L\[Dagger]"*"WL"^3, "D"^3*"ec"*"ec\[Dagger]"*"WL"^3, 
    "BL"*"D"^3*"Q"*"Q\[Dagger]"*"WL"^2, "BL"*"D"^3*"uc"*"uc\[Dagger]"*"WL"^2, 
    "BL"*"D"^3*"dc"*"dc\[Dagger]"*"WL"^2, "BL"*"D"^3*"L"*"L\[Dagger]"*"WL"^2, 
    "BL"*"D"^3*"ec"*"ec\[Dagger]"*"WL"^2, "BL"^2*"D"^3*"Q"*"Q\[Dagger]"*"WL", 
    "BL"^2*"D"^3*"L"*"L\[Dagger]"*"WL", "BL"^3*"D"^3*"Q"*"Q\[Dagger]", 
    "BL"^3*"D"^3*"uc"*"uc\[Dagger]", "BL"^3*"D"^3*"dc"*"dc\[Dagger]", 
    "BL"^3*"D"^3*"L"*"L\[Dagger]", "BL"^3*"D"^3*"ec"*"ec\[Dagger]"}, 
  D^4*FL*\[Psi]^4 -> {"D"^4*"GL"*"L"*"Q"^3, "D"^4*"dc"*"GL"*"Q"^2*"uc", 
    "D"^4*"ec"*"GL"*"L"*"Q"*"uc", "D"^4*"dc"*"ec"*"GL"*"uc"^2, 
    "D"^4*"L"*"Q"^3*"WL", "D"^4*"dc"*"Q"^2*"uc"*"WL", 
    "D"^4*"ec"*"L"*"Q"*"uc"*"WL", "BL"*"D"^4*"L"*"Q"^3, 
    "BL"*"D"^4*"dc"*"Q"^2*"uc", "BL"*"D"^4*"ec"*"L"*"Q"*"uc", 
    "BL"*"D"^4*"dc"*"ec"*"uc"^2}, D^4*FL^2*\[Phi]*\[Psi]^2 -> 
   {"D"^4*"GL"^2*"H"*"Q"*"uc", "D"^4*"dc"*"GL"^2*"H\[Dagger]"*"Q", 
    "D"^4*"ec"*"GL"^2*"H\[Dagger]"*"L", "D"^4*"GL"*"H"*"Q"*"uc"*"WL", 
    "D"^4*"dc"*"GL"*"H\[Dagger]"*"Q"*"WL", "BL"*"D"^4*"GL"*"H"*"Q"*"uc", 
    "BL"*"D"^4*"dc"*"GL"*"H\[Dagger]"*"Q", "D"^4*"H"*"Q"*"uc"*"WL"^2, 
    "D"^4*"dc"*"H\[Dagger]"*"Q"*"WL"^2, "D"^4*"ec"*"H\[Dagger]"*"L"*"WL"^2, 
    "BL"*"D"^4*"H"*"Q"*"uc"*"WL", "BL"*"D"^4*"dc"*"H\[Dagger]"*"Q"*"WL", 
    "BL"*"D"^4*"ec"*"H\[Dagger]"*"L"*"WL", "BL"^2*"D"^4*"H"*"Q"*"uc", 
    "BL"^2*"D"^4*"dc"*"H\[Dagger]"*"Q", "BL"^2*"D"^4*"ec"*"H\[Dagger]"*"L"}, 
  D^4*FL^3*\[Phi]^2 -> {"D"^4*"GL"^3*"H"*"H\[Dagger]", 
    "D"^4*"GL"^2*"H"*"H\[Dagger]"*"WL", "BL"*"D"^4*"GL"^2*"H"*"H\[Dagger]", 
    "D"^4*"H"*"H\[Dagger]"*"WL"^3, "BL"*"D"^4*"H"*"H\[Dagger]"*"WL"^2, 
    "BL"^2*"D"^4*"H"*"H\[Dagger]"*"WL", "BL"^3*"D"^4*"H"*"H\[Dagger]"}, 
  D^2*FL^3*FR^2 -> {"D"^2*"GL"^3*"GR"^2, "BR"*"D"^2*"GL"^3*"GR", 
    "D"^2*"GL"^3*"WR"^2, "BR"^2*"D"^2*"GL"^3, "D"^2*"GL"^2*"GR"*"WL"*"WR", 
    "D"^2*"GL"^2*"WL"*"WR"^2, "BR"*"D"^2*"GL"^2*"WL"*"WR", 
    "BL"*"D"^2*"GL"^2*"GR"^2, "BL"*"BR"*"D"^2*"GL"^2*"GR", 
    "BL"*"D"^2*"GL"^2*"WR"^2, "BL"*"BR"^2*"D"^2*"GL"^2, 
    "D"^2*"GL"*"GR"^2*"WL"^2, "D"^2*"GL"*"GR"*"WL"^2*"WR", 
    "BR"*"D"^2*"GL"*"GR"*"WL"^2, "BL"*"D"^2*"GL"*"GR"*"WL"*"WR", 
    "BL"^2*"D"^2*"GL"*"GR"^2, "BL"^2*"BR"*"D"^2*"GL"*"GR", 
    "D"^2*"GR"^2*"WL"^3, "D"^2*"WL"^3*"WR"^2, "BR"*"D"^2*"WL"^3*"WR", 
    "BR"^2*"D"^2*"WL"^3, "BL"*"D"^2*"GR"^2*"WL"^2, "BL"*"D"^2*"WL"^2*"WR"^2, 
    "BL"*"BR"*"D"^2*"WL"^2*"WR", "BL"*"BR"^2*"D"^2*"WL"^2, 
    "BL"^2*"D"^2*"WL"*"WR"^2, "BL"^2*"BR"*"D"^2*"WL"*"WR", 
    "BL"^3*"D"^2*"GR"^2, "BL"^3*"D"^2*"WR"^2, "BL"^3*"BR"^2*"D"^2}, 
  D^3*FL^2*FR*\[Psi]*OverBar[\[Psi]] -> {"D"^3*"GL"^2*"GR"*"Q"*"Q\[Dagger]", 
    "D"^3*"GL"^2*"Q"*"Q\[Dagger]"*"WR", "BR"*"D"^3*"GL"^2*"Q"*"Q\[Dagger]", 
    "D"^3*"GL"^2*"GR"*"uc"*"uc\[Dagger]", "BR"*"D"^3*"GL"^2*"uc"*
     "uc\[Dagger]", "D"^3*"dc"*"dc\[Dagger]"*"GL"^2*"GR", 
    "BR"*"D"^3*"dc"*"dc\[Dagger]"*"GL"^2, "D"^3*"GL"^2*"GR"*"L"*"L\[Dagger]", 
    "D"^3*"GL"^2*"L"*"L\[Dagger]"*"WR", "BR"*"D"^3*"GL"^2*"L"*"L\[Dagger]", 
    "D"^3*"ec"*"ec\[Dagger]"*"GL"^2*"GR", "BR"*"D"^3*"ec"*"ec\[Dagger]"*
     "GL"^2, "D"^3*"GL"*"GR"*"Q"*"Q\[Dagger]"*"WL", 
    "D"^3*"GL"*"Q"*"Q\[Dagger]"*"WL"*"WR", "BR"*"D"^3*"GL"*"Q"*"Q\[Dagger]"*
     "WL", "D"^3*"GL"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "D"^3*"dc"*"dc\[Dagger]"*"GL"*"WL"*"WR", "D"^3*"GL"*"GR"*"L"*"L\[Dagger]"*
     "WL", "BL"*"D"^3*"GL"*"GR"*"Q"*"Q\[Dagger]", 
    "BL"*"D"^3*"GL"*"Q"*"Q\[Dagger]"*"WR", "BL"*"BR"*"D"^3*"GL"*"Q"*
     "Q\[Dagger]", "BL"*"D"^3*"GL"*"GR"*"uc"*"uc\[Dagger]", 
    "BL"*"BR"*"D"^3*"GL"*"uc"*"uc\[Dagger]", "BL"*"D"^3*"dc"*"dc\[Dagger]"*
     "GL"*"GR", "BL"*"BR"*"D"^3*"dc"*"dc\[Dagger]"*"GL", 
    "BL"*"D"^3*"GL"*"GR"*"L"*"L\[Dagger]", "BL"*"D"^3*"ec"*"ec\[Dagger]"*"GL"*
     "GR", "D"^3*"GR"*"Q"*"Q\[Dagger]"*"WL"^2, "D"^3*"Q"*"Q\[Dagger]"*"WL"^2*
     "WR", "BR"*"D"^3*"Q"*"Q\[Dagger]"*"WL"^2, "D"^3*"GR"*"uc"*"uc\[Dagger]"*
     "WL"^2, "D"^3*"uc"*"uc\[Dagger]"*"WL"^2*"WR", 
    "BR"*"D"^3*"uc"*"uc\[Dagger]"*"WL"^2, "D"^3*"dc"*"dc\[Dagger]"*"GR"*
     "WL"^2, "D"^3*"dc"*"dc\[Dagger]"*"WL"^2*"WR", 
    "BR"*"D"^3*"dc"*"dc\[Dagger]"*"WL"^2, "D"^3*"L"*"L\[Dagger]"*"WL"^2*"WR", 
    "BR"*"D"^3*"L"*"L\[Dagger]"*"WL"^2, "D"^3*"ec"*"ec\[Dagger]"*"WL"^2*"WR", 
    "BR"*"D"^3*"ec"*"ec\[Dagger]"*"WL"^2, "BL"*"D"^3*"GR"*"Q"*"Q\[Dagger]"*
     "WL", "BL"*"D"^3*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"D"^3*"Q"*"Q\[Dagger]"*"WL", "BL"*"D"^3*"uc"*"uc\[Dagger]"*"WL"*
     "WR", "BL"*"D"^3*"dc"*"dc\[Dagger]"*"WL"*"WR", 
    "BL"*"D"^3*"L"*"L\[Dagger]"*"WL"*"WR", "BL"*"BR"*"D"^3*"L"*"L\[Dagger]"*
     "WL", "BL"*"D"^3*"ec"*"ec\[Dagger]"*"WL"*"WR", 
    "BL"^2*"D"^3*"GR"*"Q"*"Q\[Dagger]", "BL"^2*"D"^3*"Q"*"Q\[Dagger]"*"WR", 
    "BL"^2*"BR"*"D"^3*"Q"*"Q\[Dagger]", "BL"^2*"D"^3*"GR"*"uc"*"uc\[Dagger]", 
    "BL"^2*"BR"*"D"^3*"uc"*"uc\[Dagger]", "BL"^2*"D"^3*"dc"*"dc\[Dagger]"*
     "GR", "BL"^2*"BR"*"D"^3*"dc"*"dc\[Dagger]", 
    "BL"^2*"D"^3*"L"*"L\[Dagger]"*"WR", "BL"^2*"BR"*"D"^3*"L"*"L\[Dagger]", 
    "BL"^2*"BR"*"D"^3*"ec"*"ec\[Dagger]"}, D^4*FR*\[Psi]^4 -> 
   {"D"^4*"GR"*"L"*"Q"^3, "D"^4*"L"*"Q"^3*"WR", "BR"*"D"^4*"L"*"Q"^3, 
    "D"^4*"dc"*"GR"*"Q"^2*"uc", "D"^4*"dc"*"Q"^2*"uc"*"WR", 
    "BR"*"D"^4*"dc"*"Q"^2*"uc", "D"^4*"ec"*"GR"*"L"*"Q"*"uc", 
    "D"^4*"ec"*"L"*"Q"*"uc"*"WR", "BR"*"D"^4*"ec"*"L"*"Q"*"uc", 
    "D"^4*"dc"*"ec"*"GR"*"uc"^2, "BR"*"D"^4*"dc"*"ec"*"uc"^2}, 
  D^4*FL*\[Psi]^2*OverBar[\[Psi]]^2 -> {"D"^4*"GL"*"Q"^2*"Q\[Dagger]"^2, 
    "D"^4*"ec\[Dagger]"*"GL"*"Q"^2*"uc\[Dagger]", "D"^4*"GL"*"Q"*"Q\[Dagger]"*
     "uc"*"uc\[Dagger]", "D"^4*"dc"*"dc\[Dagger]"*"GL"*"Q"*"Q\[Dagger]", 
    "D"^4*"dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q", 
    "D"^4*"GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", "D"^4*"dc\[Dagger]"*"GL"*
     "L"*"Q"*"uc\[Dagger]", "D"^4*"ec"*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]", 
    "D"^4*"GL"*"uc"^2*"uc\[Dagger]"^2, "D"^4*"dc"*"GL"*"L\[Dagger]"*
     "Q\[Dagger]"*"uc", "D"^4*"dc"*"dc\[Dagger]"*"GL"*"uc"*"uc\[Dagger]", 
    "D"^4*"GL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^4*"ec"*"GL"*"Q\[Dagger]"^2*"uc", "D"^4*"ec"*"ec\[Dagger]"*"GL"*"uc"*
     "uc\[Dagger]", "D"^4*"dc"^2*"dc\[Dagger]"^2*"GL", 
    "D"^4*"dc"*"dc\[Dagger]"*"GL"*"L"*"L\[Dagger]", 
    "D"^4*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL", 
    "D"^4*"dc\[Dagger]"*"ec"*"GL"*"L"*"Q\[Dagger]", 
    "D"^4*"Q"^2*"Q\[Dagger]"^2*"WL", "D"^4*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]"*
     "WL", "D"^4*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"^4*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"^4*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"WL", 
    "D"^4*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", "D"^4*"dc\[Dagger]"*"L"*"Q"*
     "uc\[Dagger]"*"WL", "D"^4*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"^4*"dc"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "D"^4*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"^4*"ec"*"Q\[Dagger]"^2*"uc"*"WL", "D"^4*"dc"*"dc\[Dagger]"*"L"*
     "L\[Dagger]"*"WL", "D"^4*"L"^2*"L\[Dagger]"^2*"WL", 
    "D"^4*"dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]"*"WL", 
    "D"^4*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "BL"*"D"^4*"Q"^2*"Q\[Dagger]"^2, "BL"*"D"^4*"ec\[Dagger]"*"Q"^2*
     "uc\[Dagger]", "BL"*"D"^4*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"^4*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"D"^4*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q", 
    "BL"*"D"^4*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", "BL"*"D"^4*"dc\[Dagger]"*
     "L"*"Q"*"uc\[Dagger]", "BL"*"D"^4*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"D"^4*"uc"^2*"uc\[Dagger]"^2, "BL"*"D"^4*"dc"*"L\[Dagger]"*
     "Q\[Dagger]"*"uc", "BL"*"D"^4*"dc"*"dc\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"^4*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"^4*"ec"*"Q\[Dagger]"^2*"uc", "BL"*"D"^4*"ec"*"ec\[Dagger]"*"uc"*
     "uc\[Dagger]", "BL"*"D"^4*"dc"^2*"dc\[Dagger]"^2, 
    "BL"*"D"^4*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"*"D"^4*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]", 
    "BL"*"D"^4*"L"^2*"L\[Dagger]"^2, "BL"*"D"^4*"dc\[Dagger]"*"ec"*"L"*
     "Q\[Dagger]", "BL"*"D"^4*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"*"D"^4*"ec"^2*"ec\[Dagger]"^2}, D^4*FL*FR*\[Phi]*\[Psi]^2 -> 
   {"D"^4*"GL"*"GR"*"H"*"Q"*"uc", "D"^4*"GL"*"H"*"Q"*"uc"*"WR", 
    "BR"*"D"^4*"GL"*"H"*"Q"*"uc", "D"^4*"dc"*"GL"*"GR"*"H\[Dagger]"*"Q", 
    "D"^4*"dc"*"GL"*"H\[Dagger]"*"Q"*"WR", "BR"*"D"^4*"dc"*"GL"*"H\[Dagger]"*
     "Q", "D"^4*"ec"*"GL"*"GR"*"H\[Dagger]"*"L", "D"^4*"GR"*"H"*"Q"*"uc"*
     "WL", "D"^4*"H"*"Q"*"uc"*"WL"*"WR", "BR"*"D"^4*"H"*"Q"*"uc"*"WL", 
    "D"^4*"dc"*"GR"*"H\[Dagger]"*"Q"*"WL", "D"^4*"dc"*"H\[Dagger]"*"Q"*"WL"*
     "WR", "BR"*"D"^4*"dc"*"H\[Dagger]"*"Q"*"WL", "D"^4*"ec"*"H\[Dagger]"*"L"*
     "WL"*"WR", "BR"*"D"^4*"ec"*"H\[Dagger]"*"L"*"WL", 
    "BL"*"D"^4*"GR"*"H"*"Q"*"uc", "BL"*"D"^4*"H"*"Q"*"uc"*"WR", 
    "BL"*"BR"*"D"^4*"H"*"Q"*"uc", "BL"*"D"^4*"dc"*"GR"*"H\[Dagger]"*"Q", 
    "BL"*"D"^4*"dc"*"H\[Dagger]"*"Q"*"WR", "BL"*"BR"*"D"^4*"dc"*"H\[Dagger]"*
     "Q", "BL"*"D"^4*"ec"*"H\[Dagger]"*"L"*"WR", "BL"*"BR"*"D"^4*"ec"*
     "H\[Dagger]"*"L"}, D^4*FL^2*\[Phi]*OverBar[\[Psi]]^2 -> 
   {"D"^4*"dc\[Dagger]"*"GL"^2*"H"*"Q\[Dagger]", "D"^4*"ec\[Dagger]"*"GL"^2*
     "H"*"L\[Dagger]", "D"^4*"GL"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"^4*"dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]"*"WL", 
    "D"^4*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"D"^4*"dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]", 
    "BL"*"D"^4*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"^4*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL"^2, "D"^4*"ec\[Dagger]"*"H"*
     "L\[Dagger]"*"WL"^2, "D"^4*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*
     "WL"^2, "BL"*"D"^4*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL", 
    "BL"*"D"^4*"ec\[Dagger]"*"H"*"L\[Dagger]"*"WL", 
    "BL"*"D"^4*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"^2*"D"^4*"dc\[Dagger]"*"H"*"Q\[Dagger]", "BL"^2*"D"^4*"ec\[Dagger]"*
     "H"*"L\[Dagger]", "BL"^2*"D"^4*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"}, 
  D^4*FL^2*FR*\[Phi]^2 -> {"D"^4*"GL"^2*"GR"*"H"*"H\[Dagger]", 
    "D"^4*"GL"^2*"H"*"H\[Dagger]"*"WR", "BR"*"D"^4*"GL"^2*"H"*"H\[Dagger]", 
    "D"^4*"GL"*"GR"*"H"*"H\[Dagger]"*"WL", "BL"*"D"^4*"GL"*"GR"*"H"*
     "H\[Dagger]", "D"^4*"H"*"H\[Dagger]"*"WL"^2*"WR", 
    "BR"*"D"^4*"H"*"H\[Dagger]"*"WL"^2, "BL"*"D"^4*"H"*"H\[Dagger]"*"WL"*
     "WR", "BL"*"BR"*"D"^4*"H"*"H\[Dagger]"*"WL", 
    "BL"^2*"D"^4*"H"*"H\[Dagger]"*"WR", "BL"^2*"BR"*"D"^4*"H"*"H\[Dagger]"}, 
  D^5*\[Phi]*\[Psi]^3*OverBar[\[Psi]] -> {"D"^5*"ec\[Dagger]"*"H"*"Q"^3, 
    "D"^5*"H"*"Q"^2*"Q\[Dagger]"*"uc", "D"^5*"dc"*"H\[Dagger]"*"Q"^2*
     "Q\[Dagger]", "D"^5*"dc\[Dagger]"*"H"*"L"*"Q"^2, 
    "D"^5*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]", "D"^5*"H"*"Q"*"uc"^2*
     "uc\[Dagger]", "D"^5*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc", 
    "D"^5*"dc"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "D"^5*"H"*"L"*"L\[Dagger]"*"Q"*"uc", "D"^5*"ec"*"ec\[Dagger]"*"H"*"Q"*
     "uc", "D"^5*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q", 
    "D"^5*"dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "D"^5*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q", 
    "D"^5*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", "D"^5*"dc"*"H"*"L\[Dagger]"*
     "uc"^2, "D"^5*"ec"*"H"*"Q\[Dagger]"*"uc"^2, "D"^5*"dc"^2*"H\[Dagger]"*
     "L\[Dagger]"*"uc", "D"^5*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "D"^5*"dc\[Dagger]"*"ec"*"H"*"L"*"uc", "D"^5*"ec"*"H\[Dagger]"*"L"*"uc"*
     "uc\[Dagger]", "D"^5*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L", 
    "D"^5*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]", "D"^5*"ec"^2*"ec\[Dagger]"*
     "H\[Dagger]"*"L"}, D^5*FL*\[Phi]^2*\[Psi]*OverBar[\[Psi]] -> 
   {"D"^5*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", "D"^5*"dc\[Dagger]"*"GL"*
     "H"^2*"uc", "D"^5*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^5*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]", 
    "D"^5*"dc"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]", "D"^5*"H"*"H\[Dagger]"*"Q"*
     "Q\[Dagger]"*"WL", "D"^5*"dc\[Dagger]"*"H"^2*"uc"*"WL", 
    "D"^5*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"^5*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"WL", 
    "D"^5*"dc"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", "D"^5*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"WL", "D"^5*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL", 
    "BL"*"D"^5*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", "BL"*"D"^5*"dc\[Dagger]"*
     "H"^2*"uc", "BL"*"D"^5*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"^5*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]", 
    "BL"*"D"^5*"dc"*"H\[Dagger]"^2*"uc\[Dagger]", "BL"*"D"^5*"H"*"H\[Dagger]"*
     "L"*"L\[Dagger]", "BL"*"D"^5*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"}, 
  D^6*\[Phi]^3*\[Psi]^2 -> {"D"^6*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "D"^6*"dc"*"H"*"H\[Dagger]"^2*"Q", "D"^6*"ec"*"H"*"H\[Dagger]"^2*"L"}, 
  D^6*FL*\[Phi]^4 -> {"D"^6*"H"^2*"H\[Dagger]"^2*"WL", 
    "BL"*"D"^6*"H"^2*"H\[Dagger]"^2}, 
  FL^6 -> {"GL"^6, "BL"*"GL"^5, "GL"^4*"WL"^2, "BL"^2*"GL"^4, "GL"^3*"WL"^3, 
    "BL"*"GL"^3*"WL"^2, "BL"^3*"GL"^3, "GL"^2*"WL"^4, "BL"*"GL"^2*"WL"^3, 
    "BL"^2*"GL"^2*"WL"^2, "BL"^4*"GL"^2, "WL"^6, "BL"*"WL"^5, "BL"^2*"WL"^4, 
    "BL"^3*"WL"^3, "BL"^4*"WL"^2, "BL"^6}, D*FL^4*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"GL"^4*"Q"*"Q\[Dagger]", "D"*"GL"^4*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"^4, "D"*"GL"^4*"L"*"L\[Dagger]", 
    "D"*"ec"*"ec\[Dagger]"*"GL"^4, "D"*"GL"^3*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"GL"^3*"L"*"L\[Dagger]"*"WL", "BL"*"D"*"GL"^3*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"GL"^3*"uc"*"uc\[Dagger]", "BL"*"D"*"dc"*"dc\[Dagger]"*"GL"^3, 
    "BL"*"D"*"GL"^3*"L"*"L\[Dagger]", "BL"*"D"*"ec"*"ec\[Dagger]"*"GL"^3, 
    "D"*"GL"^2*"Q"*"Q\[Dagger]"*"WL"^2, "D"*"GL"^2*"uc"*"uc\[Dagger]"*"WL"^2, 
    "D"*"dc"*"dc\[Dagger]"*"GL"^2*"WL"^2, "D"*"GL"^2*"L"*"L\[Dagger]"*"WL"^2, 
    "D"*"ec"*"ec\[Dagger]"*"GL"^2*"WL"^2, "BL"*"D"*"GL"^2*"Q"*"Q\[Dagger]"*
     "WL", "BL"*"D"*"GL"^2*"L"*"L\[Dagger]"*"WL", 
    "BL"^2*"D"*"GL"^2*"Q"*"Q\[Dagger]", "BL"^2*"D"*"GL"^2*"uc"*"uc\[Dagger]", 
    "BL"^2*"D"*"dc"*"dc\[Dagger]"*"GL"^2, "BL"^2*"D"*"GL"^2*"L"*"L\[Dagger]", 
    "BL"^2*"D"*"ec"*"ec\[Dagger]"*"GL"^2, "D"*"GL"*"Q"*"Q\[Dagger]"*"WL"^3, 
    "D"*"GL"*"uc"*"uc\[Dagger]"*"WL"^3, "D"*"dc"*"dc\[Dagger]"*"GL"*"WL"^3, 
    "BL"*"D"*"GL"*"Q"*"Q\[Dagger]"*"WL"^2, "BL"*"D"*"GL"*"uc"*"uc\[Dagger]"*
     "WL"^2, "BL"*"D"*"dc"*"dc\[Dagger]"*"GL"*"WL"^2, 
    "BL"^2*"D"*"GL"*"Q"*"Q\[Dagger]"*"WL", "BL"^3*"D"*"GL"*"Q"*"Q\[Dagger]", 
    "BL"^3*"D"*"GL"*"uc"*"uc\[Dagger]", "BL"^3*"D"*"dc"*"dc\[Dagger]"*"GL", 
    "D"*"Q"*"Q\[Dagger]"*"WL"^4, "D"*"uc"*"uc\[Dagger]"*"WL"^4, 
    "D"*"dc"*"dc\[Dagger]"*"WL"^4, "D"*"L"*"L\[Dagger]"*"WL"^4, 
    "D"*"ec"*"ec\[Dagger]"*"WL"^4, "BL"*"D"*"Q"*"Q\[Dagger]"*"WL"^3, 
    "BL"*"D"*"uc"*"uc\[Dagger]"*"WL"^3, "BL"*"D"*"dc"*"dc\[Dagger]"*"WL"^3, 
    "BL"*"D"*"L"*"L\[Dagger]"*"WL"^3, "BL"*"D"*"ec"*"ec\[Dagger]"*"WL"^3, 
    "BL"^2*"D"*"Q"*"Q\[Dagger]"*"WL"^2, "BL"^2*"D"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "BL"^2*"D"*"dc"*"dc\[Dagger]"*"WL"^2, "BL"^2*"D"*"L"*"L\[Dagger]"*"WL"^2, 
    "BL"^2*"D"*"ec"*"ec\[Dagger]"*"WL"^2, "BL"^3*"D"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"^3*"D"*"L"*"L\[Dagger]"*"WL", "BL"^4*"D"*"Q"*"Q\[Dagger]", 
    "BL"^4*"D"*"uc"*"uc\[Dagger]", "BL"^4*"D"*"dc"*"dc\[Dagger]", 
    "BL"^4*"D"*"L"*"L\[Dagger]", "BL"^4*"D"*"ec"*"ec\[Dagger]"}, 
  D^2*FL^2*\[Psi]^4 -> {"D"^2*"GL"^2*"L"*"Q"^3, "D"^2*"dc"*"GL"^2*"Q"^2*"uc", 
    "D"^2*"ec"*"GL"^2*"L"*"Q"*"uc", "D"^2*"dc"*"ec"*"GL"^2*"uc"^2, 
    "D"^2*"GL"*"L"*"Q"^3*"WL", "D"^2*"dc"*"GL"*"Q"^2*"uc"*"WL", 
    "D"^2*"ec"*"GL"*"L"*"Q"*"uc"*"WL", "BL"*"D"^2*"GL"*"L"*"Q"^3, 
    "BL"*"D"^2*"dc"*"GL"*"Q"^2*"uc", "BL"*"D"^2*"ec"*"GL"*"L"*"Q"*"uc", 
    "BL"*"D"^2*"dc"*"ec"*"GL"*"uc"^2, "D"^2*"L"*"Q"^3*"WL"^2, 
    "D"^2*"dc"*"Q"^2*"uc"*"WL"^2, "D"^2*"ec"*"L"*"Q"*"uc"*"WL"^2, 
    "D"^2*"dc"*"ec"*"uc"^2*"WL"^2, "BL"*"D"^2*"L"*"Q"^3*"WL", 
    "BL"*"D"^2*"dc"*"Q"^2*"uc"*"WL", "BL"*"D"^2*"ec"*"L"*"Q"*"uc"*"WL", 
    "BL"^2*"D"^2*"L"*"Q"^3, "BL"^2*"D"^2*"dc"*"Q"^2*"uc", 
    "BL"^2*"D"^2*"ec"*"L"*"Q"*"uc", "BL"^2*"D"^2*"dc"*"ec"*"uc"^2}, 
  D^2*FL^3*\[Phi]*\[Psi]^2 -> {"D"^2*"GL"^3*"H"*"Q"*"uc", 
    "D"^2*"dc"*"GL"^3*"H\[Dagger]"*"Q", "D"^2*"ec"*"GL"^3*"H\[Dagger]"*"L", 
    "D"^2*"GL"^2*"H"*"Q"*"uc"*"WL", "D"^2*"dc"*"GL"^2*"H\[Dagger]"*"Q"*"WL", 
    "D"^2*"ec"*"GL"^2*"H\[Dagger]"*"L"*"WL", "BL"*"D"^2*"GL"^2*"H"*"Q"*"uc", 
    "BL"*"D"^2*"dc"*"GL"^2*"H\[Dagger]"*"Q", "BL"*"D"^2*"ec"*"GL"^2*
     "H\[Dagger]"*"L", "D"^2*"GL"*"H"*"Q"*"uc"*"WL"^2, 
    "D"^2*"dc"*"GL"*"H\[Dagger]"*"Q"*"WL"^2, "BL"*"D"^2*"GL"*"H"*"Q"*"uc"*
     "WL", "BL"*"D"^2*"dc"*"GL"*"H\[Dagger]"*"Q"*"WL", 
    "BL"^2*"D"^2*"GL"*"H"*"Q"*"uc", "BL"^2*"D"^2*"dc"*"GL"*"H\[Dagger]"*"Q", 
    "D"^2*"H"*"Q"*"uc"*"WL"^3, "D"^2*"dc"*"H\[Dagger]"*"Q"*"WL"^3, 
    "D"^2*"ec"*"H\[Dagger]"*"L"*"WL"^3, "BL"*"D"^2*"H"*"Q"*"uc"*"WL"^2, 
    "BL"*"D"^2*"dc"*"H\[Dagger]"*"Q"*"WL"^2, "BL"*"D"^2*"ec"*"H\[Dagger]"*"L"*
     "WL"^2, "BL"^2*"D"^2*"H"*"Q"*"uc"*"WL", "BL"^2*"D"^2*"dc"*"H\[Dagger]"*
     "Q"*"WL", "BL"^2*"D"^2*"ec"*"H\[Dagger]"*"L"*"WL", 
    "BL"^3*"D"^2*"H"*"Q"*"uc", "BL"^3*"D"^2*"dc"*"H\[Dagger]"*"Q", 
    "BL"^3*"D"^2*"ec"*"H\[Dagger]"*"L"}, D^2*FL^4*\[Phi]^2 -> 
   {"D"^2*"GL"^4*"H"*"H\[Dagger]", "D"^2*"GL"^3*"H"*"H\[Dagger]"*"WL", 
    "BL"*"D"^2*"GL"^3*"H"*"H\[Dagger]", "D"^2*"GL"^2*"H"*"H\[Dagger]"*"WL"^2, 
    "BL"*"D"^2*"GL"^2*"H"*"H\[Dagger]"*"WL", "BL"^2*"D"^2*"GL"^2*"H"*
     "H\[Dagger]", "D"^2*"H"*"H\[Dagger]"*"WL"^4, "BL"*"D"^2*"H"*"H\[Dagger]"*
     "WL"^3, "BL"^2*"D"^2*"H"*"H\[Dagger]"*"WL"^2, 
    "BL"^3*"D"^2*"H"*"H\[Dagger]"*"WL", "BL"^4*"D"^2*"H"*"H\[Dagger]"}, 
  FL^4*FR^2 -> {"GL"^4*"GR"^2, "BR"*"GL"^4*"GR", "GL"^4*"WR"^2, 
    "BR"^2*"GL"^4, "GL"^3*"GR"*"WL"*"WR", "GL"^3*"WL"*"WR"^2, 
    "BR"*"GL"^3*"WL"*"WR", "BL"*"GL"^3*"GR"^2, "BL"*"BR"*"GL"^3*"GR", 
    "BL"*"GL"^3*"WR"^2, "BL"*"BR"^2*"GL"^3, "GL"^2*"GR"^2*"WL"^2, 
    "GL"^2*"GR"*"WL"^2*"WR", "BR"*"GL"^2*"GR"*"WL"^2, "GL"^2*"WL"^2*"WR"^2, 
    "BR"*"GL"^2*"WL"^2*"WR", "BR"^2*"GL"^2*"WL"^2, 
    "BL"*"GL"^2*"GR"*"WL"*"WR", "BL"*"GL"^2*"WL"*"WR"^2, 
    "BL"*"BR"*"GL"^2*"WL"*"WR", "BL"^2*"GL"^2*"GR"^2, 
    "BL"^2*"BR"*"GL"^2*"GR", "BL"^2*"GL"^2*"WR"^2, "BL"^2*"BR"^2*"GL"^2, 
    "GL"*"GR"^2*"WL"^3, "GL"*"GR"*"WL"^3*"WR", "BR"*"GL"*"GR"*"WL"^3, 
    "BL"*"GL"*"GR"^2*"WL"^2, "BL"*"GL"*"GR"*"WL"^2*"WR", 
    "BL"*"BR"*"GL"*"GR"*"WL"^2, "BL"^2*"GL"*"GR"*"WL"*"WR", 
    "BL"^3*"GL"*"GR"^2, "BL"^3*"BR"*"GL"*"GR", "GR"^2*"WL"^4, "WL"^4*"WR"^2, 
    "BR"*"WL"^4*"WR", "BR"^2*"WL"^4, "BL"*"GR"^2*"WL"^3, "BL"*"WL"^3*"WR"^2, 
    "BL"*"BR"*"WL"^3*"WR", "BL"*"BR"^2*"WL"^3, "BL"^2*"GR"^2*"WL"^2, 
    "BL"^2*"WL"^2*"WR"^2, "BL"^2*"BR"*"WL"^2*"WR", "BL"^2*"BR"^2*"WL"^2, 
    "BL"^3*"WL"*"WR"^2, "BL"^3*"BR"*"WL"*"WR", "BL"^4*"GR"^2, "BL"^4*"WR"^2, 
    "BL"^4*"BR"^2}, D*FL^3*FR*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"GL"^3*"GR"*"Q"*"Q\[Dagger]", "D"*"GL"^3*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"D"*"GL"^3*"Q"*"Q\[Dagger]", "D"*"GL"^3*"GR"*"uc"*"uc\[Dagger]", 
    "BR"*"D"*"GL"^3*"uc"*"uc\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"GL"^3*"GR", 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"GL"^3, "D"*"GL"^3*"GR"*"L"*"L\[Dagger]", 
    "D"*"GL"^3*"L"*"L\[Dagger]"*"WR", "BR"*"D"*"GL"^3*"L"*"L\[Dagger]", 
    "D"*"ec"*"ec\[Dagger]"*"GL"^3*"GR", "BR"*"D"*"ec"*"ec\[Dagger]"*"GL"^3, 
    "D"*"GL"^2*"GR"*"Q"*"Q\[Dagger]"*"WL", "D"*"GL"^2*"Q"*"Q\[Dagger]"*"WL"*
     "WR", "BR"*"D"*"GL"^2*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"GL"^2*"uc"*"uc\[Dagger]"*"WL"*"WR", "D"*"dc"*"dc\[Dagger]"*"GL"^2*
     "WL"*"WR", "D"*"GL"^2*"GR"*"L"*"L\[Dagger]"*"WL", 
    "D"*"GL"^2*"L"*"L\[Dagger]"*"WL"*"WR", "BR"*"D"*"GL"^2*"L"*"L\[Dagger]"*
     "WL", "D"*"ec"*"ec\[Dagger]"*"GL"^2*"WL"*"WR", 
    "BL"*"D"*"GL"^2*"GR"*"Q"*"Q\[Dagger]", "BL"*"D"*"GL"^2*"Q"*"Q\[Dagger]"*
     "WR", "BL"*"BR"*"D"*"GL"^2*"Q"*"Q\[Dagger]", "BL"*"D"*"GL"^2*"GR"*"uc"*
     "uc\[Dagger]", "BL"*"BR"*"D"*"GL"^2*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"GL"^2*"GR", "BL"*"BR"*"D"*"dc"*"dc\[Dagger]"*
     "GL"^2, "BL"*"D"*"GL"^2*"GR"*"L"*"L\[Dagger]", 
    "BL"*"D"*"GL"^2*"L"*"L\[Dagger]"*"WR", "BL"*"BR"*"D"*"GL"^2*"L"*
     "L\[Dagger]", "BL"*"D"*"ec"*"ec\[Dagger]"*"GL"^2*"GR", 
    "BL"*"BR"*"D"*"ec"*"ec\[Dagger]"*"GL"^2, "D"*"GL"*"GR"*"Q"*"Q\[Dagger]"*
     "WL"^2, "D"*"GL"*"Q"*"Q\[Dagger]"*"WL"^2*"WR", 
    "BR"*"D"*"GL"*"Q"*"Q\[Dagger]"*"WL"^2, "D"*"GL"*"GR"*"uc"*"uc\[Dagger]"*
     "WL"^2, "D"*"GL"*"uc"*"uc\[Dagger]"*"WL"^2*"WR", 
    "BR"*"D"*"GL"*"uc"*"uc\[Dagger]"*"WL"^2, "D"*"dc"*"dc\[Dagger]"*"GL"*"GR"*
     "WL"^2, "D"*"dc"*"dc\[Dagger]"*"GL"*"WL"^2*"WR", 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"GL"*"WL"^2, "D"*"GL"*"GR"*"L"*"L\[Dagger]"*
     "WL"^2, "D"*"ec"*"ec\[Dagger]"*"GL"*"GR"*"WL"^2, 
    "BL"*"D"*"GL"*"GR"*"Q"*"Q\[Dagger]"*"WL", "BL"*"D"*"GL"*"Q"*"Q\[Dagger]"*
     "WL"*"WR", "BL"*"BR"*"D"*"GL"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"D"*"GL"*"uc"*"uc\[Dagger]"*"WL"*"WR", "BL"*"D"*"dc"*"dc\[Dagger]"*
     "GL"*"WL"*"WR", "BL"*"D"*"GL"*"GR"*"L"*"L\[Dagger]"*"WL", 
    "BL"^2*"D"*"GL"*"GR"*"Q"*"Q\[Dagger]", "BL"^2*"D"*"GL"*"Q"*"Q\[Dagger]"*
     "WR", "BL"^2*"BR"*"D"*"GL"*"Q"*"Q\[Dagger]", "BL"^2*"D"*"GL"*"GR"*"uc"*
     "uc\[Dagger]", "BL"^2*"BR"*"D"*"GL"*"uc"*"uc\[Dagger]", 
    "BL"^2*"D"*"dc"*"dc\[Dagger]"*"GL"*"GR", "BL"^2*"BR"*"D"*"dc"*
     "dc\[Dagger]"*"GL", "BL"^2*"D"*"GL"*"GR"*"L"*"L\[Dagger]", 
    "BL"^2*"D"*"ec"*"ec\[Dagger]"*"GL"*"GR", "D"*"GR"*"Q"*"Q\[Dagger]"*
     "WL"^3, "D"*"Q"*"Q\[Dagger]"*"WL"^3*"WR", "BR"*"D"*"Q"*"Q\[Dagger]"*
     "WL"^3, "D"*"GR"*"uc"*"uc\[Dagger]"*"WL"^3, "D"*"uc"*"uc\[Dagger]"*
     "WL"^3*"WR", "BR"*"D"*"uc"*"uc\[Dagger]"*"WL"^3, 
    "D"*"dc"*"dc\[Dagger]"*"GR"*"WL"^3, "D"*"dc"*"dc\[Dagger]"*"WL"^3*"WR", 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"WL"^3, "D"*"L"*"L\[Dagger]"*"WL"^3*"WR", 
    "BR"*"D"*"L"*"L\[Dagger]"*"WL"^3, "D"*"ec"*"ec\[Dagger]"*"WL"^3*"WR", 
    "BR"*"D"*"ec"*"ec\[Dagger]"*"WL"^3, "BL"*"D"*"GR"*"Q"*"Q\[Dagger]"*
     "WL"^2, "BL"*"D"*"Q"*"Q\[Dagger]"*"WL"^2*"WR", 
    "BL"*"BR"*"D"*"Q"*"Q\[Dagger]"*"WL"^2, "BL"*"D"*"GR"*"uc"*"uc\[Dagger]"*
     "WL"^2, "BL"*"D"*"uc"*"uc\[Dagger]"*"WL"^2*"WR", 
    "BL"*"BR"*"D"*"uc"*"uc\[Dagger]"*"WL"^2, "BL"*"D"*"dc"*"dc\[Dagger]"*"GR"*
     "WL"^2, "BL"*"D"*"dc"*"dc\[Dagger]"*"WL"^2*"WR", 
    "BL"*"BR"*"D"*"dc"*"dc\[Dagger]"*"WL"^2, "BL"*"D"*"L"*"L\[Dagger]"*"WL"^2*
     "WR", "BL"*"BR"*"D"*"L"*"L\[Dagger]"*"WL"^2, "BL"*"D"*"ec"*"ec\[Dagger]"*
     "WL"^2*"WR", "BL"*"BR"*"D"*"ec"*"ec\[Dagger]"*"WL"^2, 
    "BL"^2*"D"*"GR"*"Q"*"Q\[Dagger]"*"WL", "BL"^2*"D"*"Q"*"Q\[Dagger]"*"WL"*
     "WR", "BL"^2*"BR"*"D"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"^2*"D"*"uc"*"uc\[Dagger]"*"WL"*"WR", "BL"^2*"D"*"dc"*"dc\[Dagger]"*
     "WL"*"WR", "BL"^2*"D"*"L"*"L\[Dagger]"*"WL"*"WR", 
    "BL"^2*"BR"*"D"*"L"*"L\[Dagger]"*"WL", "BL"^2*"D"*"ec"*"ec\[Dagger]"*"WL"*
     "WR", "BL"^3*"D"*"GR"*"Q"*"Q\[Dagger]", "BL"^3*"D"*"Q"*"Q\[Dagger]"*
     "WR", "BL"^3*"BR"*"D"*"Q"*"Q\[Dagger]", "BL"^3*"D"*"GR"*"uc"*
     "uc\[Dagger]", "BL"^3*"BR"*"D"*"uc"*"uc\[Dagger]", 
    "BL"^3*"D"*"dc"*"dc\[Dagger]"*"GR", "BL"^3*"BR"*"D"*"dc"*"dc\[Dagger]", 
    "BL"^3*"D"*"L"*"L\[Dagger]"*"WR", "BL"^3*"BR"*"D"*"L"*"L\[Dagger]", 
    "BL"^3*"BR"*"D"*"ec"*"ec\[Dagger]"}, D^2*FL*FR*\[Psi]^4 -> 
   {"D"^2*"GL"*"GR"*"L"*"Q"^3, "D"^2*"GL"*"L"*"Q"^3*"WR", 
    "BR"*"D"^2*"GL"*"L"*"Q"^3, "D"^2*"dc"*"GL"*"GR"*"Q"^2*"uc", 
    "D"^2*"dc"*"GL"*"Q"^2*"uc"*"WR", "BR"*"D"^2*"dc"*"GL"*"Q"^2*"uc", 
    "D"^2*"ec"*"GL"*"GR"*"L"*"Q"*"uc", "D"^2*"ec"*"GL"*"L"*"Q"*"uc"*"WR", 
    "BR"*"D"^2*"ec"*"GL"*"L"*"Q"*"uc", "D"^2*"dc"*"ec"*"GL"*"GR"*"uc"^2, 
    "BR"*"D"^2*"dc"*"ec"*"GL"*"uc"^2, "D"^2*"GR"*"L"*"Q"^3*"WL", 
    "D"^2*"L"*"Q"^3*"WL"*"WR", "BR"*"D"^2*"L"*"Q"^3*"WL", 
    "D"^2*"dc"*"GR"*"Q"^2*"uc"*"WL", "D"^2*"dc"*"Q"^2*"uc"*"WL"*"WR", 
    "BR"*"D"^2*"dc"*"Q"^2*"uc"*"WL", "D"^2*"ec"*"GR"*"L"*"Q"*"uc"*"WL", 
    "D"^2*"ec"*"L"*"Q"*"uc"*"WL"*"WR", "BR"*"D"^2*"ec"*"L"*"Q"*"uc"*"WL", 
    "D"^2*"dc"*"ec"*"uc"^2*"WL"*"WR", "BL"*"D"^2*"GR"*"L"*"Q"^3, 
    "BL"*"D"^2*"L"*"Q"^3*"WR", "BL"*"BR"*"D"^2*"L"*"Q"^3, 
    "BL"*"D"^2*"dc"*"GR"*"Q"^2*"uc", "BL"*"D"^2*"dc"*"Q"^2*"uc"*"WR", 
    "BL"*"BR"*"D"^2*"dc"*"Q"^2*"uc", "BL"*"D"^2*"ec"*"GR"*"L"*"Q"*"uc", 
    "BL"*"D"^2*"ec"*"L"*"Q"*"uc"*"WR", "BL"*"BR"*"D"^2*"ec"*"L"*"Q"*"uc", 
    "BL"*"D"^2*"dc"*"ec"*"GR"*"uc"^2, "BL"*"BR"*"D"^2*"dc"*"ec"*"uc"^2}, 
  D^2*FL^2*\[Psi]^2*OverBar[\[Psi]]^2 -> {"D"^2*"GL"^2*"Q"^2*"Q\[Dagger]"^2, 
    "D"^2*"ec\[Dagger]"*"GL"^2*"Q"^2*"uc\[Dagger]", 
    "D"^2*"GL"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"dc"*"dc\[Dagger]"*"GL"^2*"Q"*"Q\[Dagger]", 
    "D"^2*"dc"*"ec\[Dagger]"*"GL"^2*"L\[Dagger]"*"Q", 
    "D"^2*"GL"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"GL"^2*"L"*"Q"*"uc\[Dagger]", 
    "D"^2*"ec"*"ec\[Dagger]"*"GL"^2*"Q"*"Q\[Dagger]", 
    "D"^2*"GL"^2*"uc"^2*"uc\[Dagger]"^2, "D"^2*"dc"*"GL"^2*"L\[Dagger]"*
     "Q\[Dagger]"*"uc", "D"^2*"dc"*"dc\[Dagger]"*"GL"^2*"uc"*"uc\[Dagger]", 
    "D"^2*"GL"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"ec"*"GL"^2*"Q\[Dagger]"^2*"uc", "D"^2*"ec"*"ec\[Dagger]"*"GL"^2*
     "uc"*"uc\[Dagger]", "D"^2*"dc"^2*"dc\[Dagger]"^2*"GL"^2, 
    "D"^2*"dc"*"dc\[Dagger]"*"GL"^2*"L"*"L\[Dagger]", 
    "D"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"^2, 
    "D"^2*"GL"^2*"L"^2*"L\[Dagger]"^2, "D"^2*"dc\[Dagger]"*"ec"*"GL"^2*"L"*
     "Q\[Dagger]", "D"^2*"ec"*"ec\[Dagger]"*"GL"^2*"L"*"L\[Dagger]", 
    "D"^2*"ec"^2*"ec\[Dagger]"^2*"GL"^2, "D"^2*"GL"*"Q"^2*"Q\[Dagger]"^2*
     "WL", "D"^2*"ec\[Dagger]"*"GL"*"Q"^2*"uc\[Dagger]"*"WL", 
    "D"^2*"GL"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"^2*"dc"*"dc\[Dagger]"*"GL"*"Q"*"Q\[Dagger]"*"WL", 
    "D"^2*"dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q"*"WL", 
    "D"^2*"GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"^2*"dc\[Dagger]"*"GL"*"L"*"Q"*"uc\[Dagger]"*"WL", 
    "D"^2*"ec"*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]"*"WL", 
    "D"^2*"dc"*"GL"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "D"^2*"GL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"^2*"ec"*"GL"*"Q\[Dagger]"^2*"uc"*"WL", "D"^2*"dc"*"dc\[Dagger]"*"GL"*
     "L"*"L\[Dagger]"*"WL", "D"^2*"dc\[Dagger]"*"ec"*"GL"*"L"*"Q\[Dagger]"*
     "WL", "BL"*"D"^2*"GL"*"Q"^2*"Q\[Dagger]"^2, "BL"*"D"^2*"ec\[Dagger]"*
     "GL"*"Q"^2*"uc\[Dagger]", "BL"*"D"^2*"GL"*"Q"*"Q\[Dagger]"*"uc"*
     "uc\[Dagger]", "BL"*"D"^2*"dc"*"dc\[Dagger]"*"GL"*"Q"*"Q\[Dagger]", 
    "BL"*"D"^2*"dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q", 
    "BL"*"D"^2*"GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"D"^2*"dc\[Dagger]"*"GL"*"L"*"Q"*"uc\[Dagger]", 
    "BL"*"D"^2*"ec"*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]", 
    "BL"*"D"^2*"GL"*"uc"^2*"uc\[Dagger]"^2, "BL"*"D"^2*"dc"*"GL"*"L\[Dagger]"*
     "Q\[Dagger]"*"uc", "BL"*"D"^2*"dc"*"dc\[Dagger]"*"GL"*"uc"*
     "uc\[Dagger]", "BL"*"D"^2*"GL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"^2*"ec"*"GL"*"Q\[Dagger]"^2*"uc", "BL"*"D"^2*"ec"*"ec\[Dagger]"*
     "GL"*"uc"*"uc\[Dagger]", "BL"*"D"^2*"dc"^2*"dc\[Dagger]"^2*"GL", 
    "BL"*"D"^2*"dc"*"dc\[Dagger]"*"GL"*"L"*"L\[Dagger]", 
    "BL"*"D"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL", 
    "BL"*"D"^2*"dc\[Dagger]"*"ec"*"GL"*"L"*"Q\[Dagger]", 
    "D"^2*"Q"^2*"Q\[Dagger]"^2*"WL"^2, "D"^2*"ec\[Dagger]"*"Q"^2*
     "uc\[Dagger]"*"WL"^2, "D"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "D"^2*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "D"^2*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"WL"^2, 
    "D"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "D"^2*"dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*"WL"^2, 
    "D"^2*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "D"^2*"uc"^2*"uc\[Dagger]"^2*"WL"^2, "D"^2*"dc"*"L\[Dagger]"*"Q\[Dagger]"*
     "uc"*"WL"^2, "D"^2*"dc"*"dc\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "D"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "D"^2*"ec"*"Q\[Dagger]"^2*"uc"*"WL"^2, "D"^2*"ec"*"ec\[Dagger]"*"uc"*
     "uc\[Dagger]"*"WL"^2, "D"^2*"dc"^2*"dc\[Dagger]"^2*"WL"^2, 
    "D"^2*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*"WL"^2, 
    "D"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"WL"^2, 
    "D"^2*"L"^2*"L\[Dagger]"^2*"WL"^2, "D"^2*"dc\[Dagger]"*"ec"*"L"*
     "Q\[Dagger]"*"WL"^2, "D"^2*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"WL"^2, 
    "D"^2*"ec"^2*"ec\[Dagger]"^2*"WL"^2, "BL"*"D"^2*"Q"^2*"Q\[Dagger]"^2*
     "WL", "BL"*"D"^2*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL", 
    "BL"*"D"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"D"^2*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"D"^2*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"WL", 
    "BL"*"D"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"D"^2*"dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*"WL", 
    "BL"*"D"^2*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"D"^2*"dc"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "BL"*"D"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"D"^2*"ec"*"Q\[Dagger]"^2*"uc"*"WL", "BL"*"D"^2*"dc"*"dc\[Dagger]"*
     "L"*"L\[Dagger]"*"WL", "BL"*"D"^2*"L"^2*"L\[Dagger]"^2*"WL", 
    "BL"*"D"^2*"dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]"*"WL", 
    "BL"*"D"^2*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "BL"^2*"D"^2*"Q"^2*"Q\[Dagger]"^2, "BL"^2*"D"^2*"ec\[Dagger]"*"Q"^2*
     "uc\[Dagger]", "BL"^2*"D"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"D"^2*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"^2*"D"^2*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q", 
    "BL"^2*"D"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"^2*"D"^2*"dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]", 
    "BL"^2*"D"^2*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"^2*"D"^2*"uc"^2*"uc\[Dagger]"^2, "BL"^2*"D"^2*"dc"*"L\[Dagger]"*
     "Q\[Dagger]"*"uc", "BL"^2*"D"^2*"dc"*"dc\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"D"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"D"^2*"ec"*"Q\[Dagger]"^2*"uc", "BL"^2*"D"^2*"ec"*"ec\[Dagger]"*
     "uc"*"uc\[Dagger]", "BL"^2*"D"^2*"dc"^2*"dc\[Dagger]"^2, 
    "BL"^2*"D"^2*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"^2*"D"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]", 
    "BL"^2*"D"^2*"L"^2*"L\[Dagger]"^2, "BL"^2*"D"^2*"dc\[Dagger]"*"ec"*"L"*
     "Q\[Dagger]", "BL"^2*"D"^2*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"^2*"D"^2*"ec"^2*"ec\[Dagger]"^2}, D^2*FL^2*FR*\[Phi]*\[Psi]^2 -> 
   {"D"^2*"GL"^2*"GR"*"H"*"Q"*"uc", "D"^2*"GL"^2*"H"*"Q"*"uc"*"WR", 
    "BR"*"D"^2*"GL"^2*"H"*"Q"*"uc", "D"^2*"dc"*"GL"^2*"GR"*"H\[Dagger]"*"Q", 
    "D"^2*"dc"*"GL"^2*"H\[Dagger]"*"Q"*"WR", "BR"*"D"^2*"dc"*"GL"^2*
     "H\[Dagger]"*"Q", "D"^2*"ec"*"GL"^2*"GR"*"H\[Dagger]"*"L", 
    "D"^2*"ec"*"GL"^2*"H\[Dagger]"*"L"*"WR", "BR"*"D"^2*"ec"*"GL"^2*
     "H\[Dagger]"*"L", "D"^2*"GL"*"GR"*"H"*"Q"*"uc"*"WL", 
    "D"^2*"GL"*"H"*"Q"*"uc"*"WL"*"WR", "BR"*"D"^2*"GL"*"H"*"Q"*"uc"*"WL", 
    "D"^2*"dc"*"GL"*"GR"*"H\[Dagger]"*"Q"*"WL", "D"^2*"dc"*"GL"*"H\[Dagger]"*
     "Q"*"WL"*"WR", "BR"*"D"^2*"dc"*"GL"*"H\[Dagger]"*"Q"*"WL", 
    "D"^2*"ec"*"GL"*"GR"*"H\[Dagger]"*"L"*"WL", "BL"*"D"^2*"GL"*"GR"*"H"*"Q"*
     "uc", "BL"*"D"^2*"GL"*"H"*"Q"*"uc"*"WR", "BL"*"BR"*"D"^2*"GL"*"H"*"Q"*
     "uc", "BL"*"D"^2*"dc"*"GL"*"GR"*"H\[Dagger]"*"Q", 
    "BL"*"D"^2*"dc"*"GL"*"H\[Dagger]"*"Q"*"WR", "BL"*"BR"*"D"^2*"dc"*"GL"*
     "H\[Dagger]"*"Q", "BL"*"D"^2*"ec"*"GL"*"GR"*"H\[Dagger]"*"L", 
    "D"^2*"GR"*"H"*"Q"*"uc"*"WL"^2, "D"^2*"H"*"Q"*"uc"*"WL"^2*"WR", 
    "BR"*"D"^2*"H"*"Q"*"uc"*"WL"^2, "D"^2*"dc"*"GR"*"H\[Dagger]"*"Q"*"WL"^2, 
    "D"^2*"dc"*"H\[Dagger]"*"Q"*"WL"^2*"WR", "BR"*"D"^2*"dc"*"H\[Dagger]"*"Q"*
     "WL"^2, "D"^2*"ec"*"H\[Dagger]"*"L"*"WL"^2*"WR", 
    "BR"*"D"^2*"ec"*"H\[Dagger]"*"L"*"WL"^2, "BL"*"D"^2*"GR"*"H"*"Q"*"uc"*
     "WL", "BL"*"D"^2*"H"*"Q"*"uc"*"WL"*"WR", "BL"*"BR"*"D"^2*"H"*"Q"*"uc"*
     "WL", "BL"*"D"^2*"dc"*"GR"*"H\[Dagger]"*"Q"*"WL", 
    "BL"*"D"^2*"dc"*"H\[Dagger]"*"Q"*"WL"*"WR", "BL"*"BR"*"D"^2*"dc"*
     "H\[Dagger]"*"Q"*"WL", "BL"*"D"^2*"ec"*"H\[Dagger]"*"L"*"WL"*"WR", 
    "BL"*"BR"*"D"^2*"ec"*"H\[Dagger]"*"L"*"WL", "BL"^2*"D"^2*"GR"*"H"*"Q"*
     "uc", "BL"^2*"D"^2*"H"*"Q"*"uc"*"WR", "BL"^2*"BR"*"D"^2*"H"*"Q"*"uc", 
    "BL"^2*"D"^2*"dc"*"GR"*"H\[Dagger]"*"Q", "BL"^2*"D"^2*"dc"*"H\[Dagger]"*
     "Q"*"WR", "BL"^2*"BR"*"D"^2*"dc"*"H\[Dagger]"*"Q", 
    "BL"^2*"D"^2*"ec"*"H\[Dagger]"*"L"*"WR", "BL"^2*"BR"*"D"^2*"ec"*
     "H\[Dagger]"*"L"}, D^2*FL^3*\[Phi]*OverBar[\[Psi]]^2 -> 
   {"D"^2*"dc\[Dagger]"*"GL"^3*"H"*"Q\[Dagger]", "D"^2*"ec\[Dagger]"*"GL"^3*
     "H"*"L\[Dagger]", "D"^2*"GL"^3*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"GL"^2*"H"*"Q\[Dagger]"*"WL", 
    "D"^2*"ec\[Dagger]"*"GL"^2*"H"*"L\[Dagger]"*"WL", 
    "D"^2*"GL"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"D"^2*"dc\[Dagger]"*"GL"^2*"H"*"Q\[Dagger]", 
    "BL"*"D"^2*"ec\[Dagger]"*"GL"^2*"H"*"L\[Dagger]", 
    "BL"*"D"^2*"GL"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]"*"WL"^2, 
    "D"^2*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, 
    "BL"*"D"^2*"dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]"*"WL", 
    "BL"*"D"^2*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"^2*"D"^2*"dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]", 
    "BL"^2*"D"^2*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL"^3, "D"^2*"ec\[Dagger]"*"H"*
     "L\[Dagger]"*"WL"^3, "D"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*
     "WL"^3, "BL"*"D"^2*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL"^2, 
    "BL"*"D"^2*"ec\[Dagger]"*"H"*"L\[Dagger]"*"WL"^2, 
    "BL"*"D"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, 
    "BL"^2*"D"^2*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL", 
    "BL"^2*"D"^2*"ec\[Dagger]"*"H"*"L\[Dagger]"*"WL", 
    "BL"^2*"D"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"^3*"D"^2*"dc\[Dagger]"*"H"*"Q\[Dagger]", "BL"^3*"D"^2*"ec\[Dagger]"*
     "H"*"L\[Dagger]", "BL"^3*"D"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"}, 
  D^2*FL^3*FR*\[Phi]^2 -> {"D"^2*"GL"^3*"GR"*"H"*"H\[Dagger]", 
    "D"^2*"GL"^3*"H"*"H\[Dagger]"*"WR", "BR"*"D"^2*"GL"^3*"H"*"H\[Dagger]", 
    "D"^2*"GL"^2*"GR"*"H"*"H\[Dagger]"*"WL", "D"^2*"GL"^2*"H"*"H\[Dagger]"*
     "WL"*"WR", "BR"*"D"^2*"GL"^2*"H"*"H\[Dagger]"*"WL", 
    "BL"*"D"^2*"GL"^2*"GR"*"H"*"H\[Dagger]", "BL"*"D"^2*"GL"^2*"H"*
     "H\[Dagger]"*"WR", "BL"*"BR"*"D"^2*"GL"^2*"H"*"H\[Dagger]", 
    "D"^2*"GL"*"GR"*"H"*"H\[Dagger]"*"WL"^2, "BL"*"D"^2*"GL"*"GR"*"H"*
     "H\[Dagger]"*"WL", "BL"^2*"D"^2*"GL"*"GR"*"H"*"H\[Dagger]", 
    "D"^2*"H"*"H\[Dagger]"*"WL"^3*"WR", "BR"*"D"^2*"H"*"H\[Dagger]"*"WL"^3, 
    "BL"*"D"^2*"H"*"H\[Dagger]"*"WL"^2*"WR", "BL"*"BR"*"D"^2*"H"*"H\[Dagger]"*
     "WL"^2, "BL"^2*"D"^2*"H"*"H\[Dagger]"*"WL"*"WR", 
    "BL"^2*"BR"*"D"^2*"H"*"H\[Dagger]"*"WL", "BL"^3*"D"^2*"H"*"H\[Dagger]"*
     "WR", "BL"^3*"BR"*"D"^2*"H"*"H\[Dagger]"}, 
  D^3*\[Psi]^5*OverBar[\[Psi]] -> {"D"^3*"dc"*"ec\[Dagger]"*"Q"^4, 
    "D"^3*"L"*"Q"^4*"Q\[Dagger]", "D"^3*"dc"*"Q"^3*"Q\[Dagger]"*"uc", 
    "D"^3*"L"*"Q"^3*"uc"*"uc\[Dagger]", "D"^3*"dc"*"dc\[Dagger]"*"L"*"Q"^3, 
    "D"^3*"L"^2*"L\[Dagger]"*"Q"^3, "D"^3*"ec"*"ec\[Dagger]"*"L"*"Q"^3, 
    "D"^3*"dc"*"Q"^2*"uc"^2*"uc\[Dagger]", "D"^3*"dc"^2*"dc\[Dagger]"*"Q"^2*
     "uc", "D"^3*"dc"*"L"*"L\[Dagger]"*"Q"^2*"uc", 
    "D"^3*"dc"*"ec"*"ec\[Dagger]"*"Q"^2*"uc", "D"^3*"ec"*"L"*"Q"^2*
     "Q\[Dagger]"*"uc", "D"^3*"dc\[Dagger]"*"ec"*"L"^2*"Q"^2, 
    "D"^3*"dc"^2*"L\[Dagger]"*"Q"*"uc"^2, "D"^3*"dc"*"ec"*"Q"*"Q\[Dagger]"*
     "uc"^2, "D"^3*"ec"*"L"*"Q"*"uc"^2*"uc\[Dagger]", 
    "D"^3*"dc"*"dc\[Dagger]"*"ec"*"L"*"Q"*"uc", "D"^3*"ec"*"L"^2*"L\[Dagger]"*
     "Q"*"uc", "D"^3*"ec"^2*"ec\[Dagger]"*"L"*"Q"*"uc", 
    "D"^3*"dc"*"ec"*"uc"^3*"uc\[Dagger]", "D"^3*"dc"^2*"dc\[Dagger]"*"ec"*
     "uc"^2, "D"^3*"dc"*"ec"*"L"*"L\[Dagger]"*"uc"^2, 
    "D"^3*"dc"*"ec"^2*"ec\[Dagger]"*"uc"^2, "D"^3*"ec"^2*"L"*"Q\[Dagger]"*
     "uc"^2, "D"^3*"dc\[Dagger]"*"ec"^2*"L"^2*"uc"}, 
  D^3*FL*\[Phi]*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"^3*"ec\[Dagger]"*"GL"*"H"*"Q"^3, "D"^3*"GL"*"H"*"Q"^2*"Q\[Dagger]"*
     "uc", "D"^3*"dc"*"GL"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "D"^3*"dc\[Dagger]"*"GL"*"H"*"L"*"Q"^2, "D"^3*"GL"*"H\[Dagger]"*"L"*"Q"^2*
     "uc\[Dagger]", "D"^3*"GL"*"H"*"Q"*"uc"^2*"uc\[Dagger]", 
    "D"^3*"dc"*"dc\[Dagger]"*"GL"*"H"*"Q"*"uc", "D"^3*"dc"*"GL"*"H\[Dagger]"*
     "Q"*"uc"*"uc\[Dagger]", "D"^3*"GL"*"H"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "D"^3*"ec"*"ec\[Dagger]"*"GL"*"H"*"Q"*"uc", "D"^3*"dc"^2*"dc\[Dagger]"*
     "GL"*"H\[Dagger]"*"Q", "D"^3*"dc"*"GL"*"H\[Dagger]"*"L"*"L\[Dagger]"*
     "Q", "D"^3*"dc"*"ec"*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"Q", 
    "D"^3*"ec"*"GL"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "D"^3*"dc"*"GL"*"H"*"L\[Dagger]"*"uc"^2, "D"^3*"ec"*"GL"*"H"*"Q\[Dagger]"*
     "uc"^2, "D"^3*"dc"^2*"GL"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "D"^3*"dc"*"ec"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "D"^3*"dc\[Dagger]"*"ec"*"GL"*"H"*"L"*"uc", "D"^3*"ec"*"GL"*"H\[Dagger]"*
     "L"*"uc"*"uc\[Dagger]", "D"^3*"dc"*"dc\[Dagger]"*"ec"*"GL"*"H\[Dagger]"*
     "L", "D"^3*"ec\[Dagger]"*"H"*"Q"^3*"WL", "D"^3*"H"*"Q"^2*"Q\[Dagger]"*
     "uc"*"WL", "D"^3*"dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"WL", 
    "D"^3*"dc\[Dagger]"*"H"*"L"*"Q"^2*"WL", "D"^3*"H\[Dagger]"*"L"*"Q"^2*
     "uc\[Dagger]"*"WL", "D"^3*"H"*"Q"*"uc"^2*"uc\[Dagger]"*"WL", 
    "D"^3*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc"*"WL", "D"^3*"dc"*"H\[Dagger]"*"Q"*
     "uc"*"uc\[Dagger]"*"WL", "D"^3*"H"*"L"*"L\[Dagger]"*"Q"*"uc"*"WL", 
    "D"^3*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc"*"WL", "D"^3*"dc"^2*"dc\[Dagger]"*
     "H\[Dagger]"*"Q"*"WL", "D"^3*"dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*
     "WL", "D"^3*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"*"WL", 
    "D"^3*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"WL", 
    "D"^3*"dc"*"H"*"L\[Dagger]"*"uc"^2*"WL", "D"^3*"ec"*"H"*"Q\[Dagger]"*
     "uc"^2*"WL", "D"^3*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WL", 
    "D"^3*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "D"^3*"dc\[Dagger]"*"ec"*"H"*"L"*"uc"*"WL", "D"^3*"ec"*"H\[Dagger]"*"L"*
     "uc"*"uc\[Dagger]"*"WL", "D"^3*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"*
     "WL", "D"^3*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"WL", 
    "D"^3*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"WL", 
    "BL"*"D"^3*"ec\[Dagger]"*"H"*"Q"^3, "BL"*"D"^3*"H"*"Q"^2*"Q\[Dagger]"*
     "uc", "BL"*"D"^3*"dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "BL"*"D"^3*"dc\[Dagger]"*"H"*"L"*"Q"^2, "BL"*"D"^3*"H\[Dagger]"*"L"*"Q"^2*
     "uc\[Dagger]", "BL"*"D"^3*"H"*"Q"*"uc"^2*"uc\[Dagger]", 
    "BL"*"D"^3*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc", "BL"*"D"^3*"dc"*"H\[Dagger]"*
     "Q"*"uc"*"uc\[Dagger]", "BL"*"D"^3*"H"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "BL"*"D"^3*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc", "BL"*"D"^3*"dc"^2*
     "dc\[Dagger]"*"H\[Dagger]"*"Q", "BL"*"D"^3*"dc"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q", "BL"*"D"^3*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q", 
    "BL"*"D"^3*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "BL"*"D"^3*"dc"*"H"*"L\[Dagger]"*"uc"^2, "BL"*"D"^3*"ec"*"H"*"Q\[Dagger]"*
     "uc"^2, "BL"*"D"^3*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "BL"*"D"^3*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "BL"*"D"^3*"dc\[Dagger]"*"ec"*"H"*"L"*"uc", "BL"*"D"^3*"ec"*"H\[Dagger]"*
     "L"*"uc"*"uc\[Dagger]", "BL"*"D"^3*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*
     "L", "BL"*"D"^3*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]", 
    "BL"*"D"^3*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"}, 
  D^3*FL^2*\[Phi]^2*\[Psi]*OverBar[\[Psi]] -> 
   {"D"^3*"GL"^2*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"^3*"dc\[Dagger]"*"GL"^2*"H"^2*"uc", "D"^3*"GL"^2*"H"*"H\[Dagger]"*"uc"*
     "uc\[Dagger]", "D"^3*"dc"*"dc\[Dagger]"*"GL"^2*"H"*"H\[Dagger]", 
    "D"^3*"dc"*"GL"^2*"H\[Dagger]"^2*"uc\[Dagger]", 
    "D"^3*"GL"^2*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "D"^3*"ec"*"ec\[Dagger]"*"GL"^2*"H"*"H\[Dagger]", 
    "D"^3*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"^3*"dc\[Dagger]"*"GL"*"H"^2*"uc"*"WL", "D"^3*"GL"*"H"*"H\[Dagger]"*
     "uc"*"uc\[Dagger]"*"WL", "D"^3*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*
     "WL", "D"^3*"dc"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "BL"*"D"^3*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"D"^3*"dc\[Dagger]"*"GL"*"H"^2*"uc", "BL"*"D"^3*"GL"*"H"*
     "H\[Dagger]"*"uc"*"uc\[Dagger]", "BL"*"D"^3*"dc"*"dc\[Dagger]"*"GL"*"H"*
     "H\[Dagger]", "BL"*"D"^3*"dc"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "D"^3*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "D"^3*"dc\[Dagger]"*"H"^2*"uc"*"WL"^2, "D"^3*"H"*"H\[Dagger]"*"uc"*
     "uc\[Dagger]"*"WL"^2, "D"^3*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"WL"^2, 
    "D"^3*"dc"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL"^2, 
    "D"^3*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL"^2, 
    "D"^3*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL"^2, 
    "BL"*"D"^3*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"D"^3*"dc\[Dagger]"*"H"^2*"uc"*"WL", "BL"*"D"^3*"H"*"H\[Dagger]"*
     "uc"*"uc\[Dagger]"*"WL", "BL"*"D"^3*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*
     "WL", "BL"*"D"^3*"dc"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "BL"*"D"^3*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "BL"*"D"^3*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL", 
    "BL"^2*"D"^3*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"^2*"D"^3*"dc\[Dagger]"*"H"^2*"uc", "BL"^2*"D"^3*"H"*"H\[Dagger]"*"uc"*
     "uc\[Dagger]", "BL"^2*"D"^3*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]", 
    "BL"^2*"D"^3*"dc"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "BL"^2*"D"^3*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"^2*"D"^3*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"}, 
  D^4*\[Phi]^2*\[Psi]^4 -> {"D"^4*"H"*"H\[Dagger]"*"L"*"Q"^3, 
    "D"^4*"H"^2*"Q"^2*"uc"^2, "D"^4*"dc"*"H"*"H\[Dagger]"*"Q"^2*"uc", 
    "D"^4*"dc"^2*"H\[Dagger]"^2*"Q"^2, "D"^4*"ec"*"H"*"H\[Dagger]"*"L"*"Q"*
     "uc", "D"^4*"dc"*"ec"*"H\[Dagger]"^2*"L"*"Q", "D"^4*"ec"*"H"^2*"uc"^3, 
    "D"^4*"dc"*"ec"*"H"*"H\[Dagger]"*"uc"^2, "D"^4*"dc"^2*"ec"*"H\[Dagger]"^2*
     "uc", "D"^4*"ec"^2*"H\[Dagger]"^2*"L"^2}, D^4*FL*\[Phi]^3*\[Psi]^2 -> 
   {"D"^4*"GL"*"H"^2*"H\[Dagger]"*"Q"*"uc", "D"^4*"dc"*"GL"*"H"*
     "H\[Dagger]"^2*"Q", "D"^4*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WL", 
    "D"^4*"dc"*"H"*"H\[Dagger]"^2*"Q"*"WL", "D"^4*"ec"*"H"*"H\[Dagger]"^2*"L"*
     "WL", "BL"*"D"^4*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "BL"*"D"^4*"dc"*"H"*"H\[Dagger]"^2*"Q", "BL"*"D"^4*"ec"*"H"*
     "H\[Dagger]"^2*"L"}, D^4*FL^2*\[Phi]^4 -> 
   {"D"^4*"GL"^2*"H"^2*"H\[Dagger]"^2, "D"^4*"H"^2*"H\[Dagger]"^2*"WL"^2, 
    "BL"*"D"^4*"H"^2*"H\[Dagger]"^2*"WL", "BL"^2*"D"^4*"H"^2*"H\[Dagger]"^2}, 
  FL^3*FR^3 -> {"GL"^3*"GR"^3, "BR"*"GL"^3*"GR"^2, "GL"^3*"GR"*"WR"^2, 
    "BR"^2*"GL"^3*"GR", "GL"^3*"WR"^3, "BR"*"GL"^3*"WR"^2, "BR"^3*"GL"^3, 
    "GL"^2*"GR"^2*"WL"*"WR", "GL"^2*"GR"*"WL"*"WR"^2, 
    "BR"*"GL"^2*"GR"*"WL"*"WR", "GL"^2*"WL"*"WR"^3, "BR"*"GL"^2*"WL"*"WR"^2, 
    "BR"^2*"GL"^2*"WL"*"WR", "BL"*"BR"*"GL"^2*"GR"^2, 
    "BL"*"GL"^2*"GR"*"WR"^2, "BL"*"BR"^2*"GL"^2*"GR", "BL"*"GL"^2*"WR"^3, 
    "BL"*"BR"*"GL"^2*"WR"^2, "BL"*"BR"^3*"GL"^2, "GL"*"GR"*"WL"^2*"WR"^2, 
    "BR"*"GL"*"GR"*"WL"^2*"WR", "BR"^2*"GL"*"GR"*"WL"^2, 
    "BL"*"BR"*"GL"*"GR"*"WL"*"WR", "BL"^2*"BR"^2*"GL"*"GR", "WL"^3*"WR"^3, 
    "BR"*"WL"^3*"WR"^2, "BR"^2*"WL"^3*"WR", "BR"^3*"WL"^3, 
    "BL"*"BR"*"WL"^2*"WR"^2, "BL"*"BR"^2*"WL"^2*"WR", "BL"*"BR"^3*"WL"^2, 
    "BL"^2*"BR"^2*"WL"*"WR", "BL"^3*"BR"^3}, 
  D*FL^2*FR^2*\[Psi]*OverBar[\[Psi]] -> {"D"*"GL"^2*"GR"^2*"Q"*"Q\[Dagger]", 
    "D"*"GL"^2*"GR"*"Q"*"Q\[Dagger]"*"WR", "BR"*"D"*"GL"^2*"GR"*"Q"*
     "Q\[Dagger]", "D"*"GL"^2*"Q"*"Q\[Dagger]"*"WR"^2, 
    "BR"*"D"*"GL"^2*"Q"*"Q\[Dagger]"*"WR", "BR"^2*"D"*"GL"^2*"Q"*
     "Q\[Dagger]", "D"*"GL"^2*"GR"^2*"uc"*"uc\[Dagger]", 
    "BR"*"D"*"GL"^2*"GR"*"uc"*"uc\[Dagger]", "D"*"GL"^2*"uc"*"uc\[Dagger]"*
     "WR"^2, "BR"^2*"D"*"GL"^2*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"^2*"GR"^2, "BR"*"D"*"dc"*"dc\[Dagger]"*"GL"^2*
     "GR", "D"*"dc"*"dc\[Dagger]"*"GL"^2*"WR"^2, 
    "BR"^2*"D"*"dc"*"dc\[Dagger]"*"GL"^2, "D"*"GL"^2*"GR"^2*"L"*"L\[Dagger]", 
    "D"*"GL"^2*"GR"*"L"*"L\[Dagger]"*"WR", "BR"*"D"*"GL"^2*"GR"*"L"*
     "L\[Dagger]", "D"*"GL"^2*"L"*"L\[Dagger]"*"WR"^2, 
    "BR"*"D"*"GL"^2*"L"*"L\[Dagger]"*"WR", "BR"^2*"D"*"GL"^2*"L"*
     "L\[Dagger]", "D"*"ec"*"ec\[Dagger]"*"GL"^2*"GR"^2, 
    "BR"*"D"*"ec"*"ec\[Dagger]"*"GL"^2*"GR", "D"*"ec"*"ec\[Dagger]"*"GL"^2*
     "WR"^2, "BR"^2*"D"*"ec"*"ec\[Dagger]"*"GL"^2, 
    "D"*"GL"*"GR"*"Q"*"Q\[Dagger]"*"WL"*"WR", "BR"*"D"*"GL"*"GR"*"Q"*
     "Q\[Dagger]"*"WL", "D"*"GL"*"Q"*"Q\[Dagger]"*"WL"*"WR"^2, 
    "BR"*"D"*"GL"*"Q"*"Q\[Dagger]"*"WL"*"WR", "BR"^2*"D"*"GL"*"Q"*
     "Q\[Dagger]"*"WL", "D"*"GL"*"GR"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "D"*"GL"*"uc"*"uc\[Dagger]"*"WL"*"WR"^2, "BR"*"D"*"GL"*"uc"*"uc\[Dagger]"*
     "WL"*"WR", "D"*"dc"*"dc\[Dagger]"*"GL"*"GR"*"WL"*"WR", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"WL"*"WR"^2, "BR"*"D"*"dc"*"dc\[Dagger]"*"GL"*
     "WL"*"WR", "D"*"GL"*"GR"*"L"*"L\[Dagger]"*"WL"*"WR", 
    "BR"*"D"*"GL"*"GR"*"L"*"L\[Dagger]"*"WL", "D"*"ec"*"ec\[Dagger]"*"GL"*
     "GR"*"WL"*"WR", "BL"*"BR"*"D"*"GL"*"GR"*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"GL"*"Q"*"Q\[Dagger]"*"WR"^2, "BL"*"BR"*"D"*"GL"*"Q"*
     "Q\[Dagger]"*"WR", "BL"*"BR"^2*"D"*"GL"*"Q"*"Q\[Dagger]", 
    "BL"*"BR"*"D"*"GL"*"GR"*"uc"*"uc\[Dagger]", "BL"*"D"*"GL"*"uc"*
     "uc\[Dagger]"*"WR"^2, "BL"*"BR"^2*"D"*"GL"*"uc"*"uc\[Dagger]", 
    "BL"*"BR"*"D"*"dc"*"dc\[Dagger]"*"GL"*"GR", "BL"*"D"*"dc"*"dc\[Dagger]"*
     "GL"*"WR"^2, "BL"*"BR"^2*"D"*"dc"*"dc\[Dagger]"*"GL", 
    "BL"*"BR"*"D"*"GL"*"GR"*"L"*"L\[Dagger]", "BL"*"BR"*"D"*"ec"*
     "ec\[Dagger]"*"GL"*"GR", "D"*"Q"*"Q\[Dagger]"*"WL"^2*"WR"^2, 
    "BR"*"D"*"Q"*"Q\[Dagger]"*"WL"^2*"WR", "BR"^2*"D"*"Q"*"Q\[Dagger]"*
     "WL"^2, "D"*"uc"*"uc\[Dagger]"*"WL"^2*"WR"^2, 
    "BR"*"D"*"uc"*"uc\[Dagger]"*"WL"^2*"WR", "BR"^2*"D"*"uc"*"uc\[Dagger]"*
     "WL"^2, "D"*"dc"*"dc\[Dagger]"*"WL"^2*"WR"^2, 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"WL"^2*"WR", "BR"^2*"D"*"dc"*"dc\[Dagger]"*
     "WL"^2, "D"*"L"*"L\[Dagger]"*"WL"^2*"WR"^2, "BR"*"D"*"L"*"L\[Dagger]"*
     "WL"^2*"WR", "BR"^2*"D"*"L"*"L\[Dagger]"*"WL"^2, 
    "D"*"ec"*"ec\[Dagger]"*"WL"^2*"WR"^2, "BR"*"D"*"ec"*"ec\[Dagger]"*"WL"^2*
     "WR", "BR"^2*"D"*"ec"*"ec\[Dagger]"*"WL"^2, 
    "BL"*"BR"*"D"*"Q"*"Q\[Dagger]"*"WL"*"WR", "BL"*"BR"^2*"D"*"Q"*
     "Q\[Dagger]"*"WL", "BL"*"BR"*"D"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"D"*"dc"*"dc\[Dagger]"*"WL"*"WR", "BL"*"BR"*"D"*"L"*
     "L\[Dagger]"*"WL"*"WR", "BL"*"BR"^2*"D"*"L"*"L\[Dagger]"*"WL", 
    "BL"*"BR"*"D"*"ec"*"ec\[Dagger]"*"WL"*"WR", "BL"^2*"BR"^2*"D"*"Q"*
     "Q\[Dagger]", "BL"^2*"BR"^2*"D"*"uc"*"uc\[Dagger]", 
    "BL"^2*"BR"^2*"D"*"dc"*"dc\[Dagger]", "BL"^2*"BR"^2*"D"*"L"*"L\[Dagger]", 
    "BL"^2*"BR"^2*"D"*"ec"*"ec\[Dagger]"}, D^2*FR^2*\[Psi]^4 -> 
   {"D"^2*"GR"^2*"L"*"Q"^3, "D"^2*"GR"*"L"*"Q"^3*"WR", 
    "BR"*"D"^2*"GR"*"L"*"Q"^3, "D"^2*"L"*"Q"^3*"WR"^2, 
    "BR"*"D"^2*"L"*"Q"^3*"WR", "BR"^2*"D"^2*"L"*"Q"^3, 
    "D"^2*"dc"*"GR"^2*"Q"^2*"uc", "D"^2*"dc"*"GR"*"Q"^2*"uc"*"WR", 
    "BR"*"D"^2*"dc"*"GR"*"Q"^2*"uc", "D"^2*"dc"*"Q"^2*"uc"*"WR"^2, 
    "BR"*"D"^2*"dc"*"Q"^2*"uc"*"WR", "BR"^2*"D"^2*"dc"*"Q"^2*"uc", 
    "D"^2*"ec"*"GR"^2*"L"*"Q"*"uc", "D"^2*"ec"*"GR"*"L"*"Q"*"uc"*"WR", 
    "BR"*"D"^2*"ec"*"GR"*"L"*"Q"*"uc", "D"^2*"ec"*"L"*"Q"*"uc"*"WR"^2, 
    "BR"*"D"^2*"ec"*"L"*"Q"*"uc"*"WR", "BR"^2*"D"^2*"ec"*"L"*"Q"*"uc", 
    "D"^2*"dc"*"ec"*"GR"^2*"uc"^2, "BR"*"D"^2*"dc"*"ec"*"GR"*"uc"^2, 
    "D"^2*"dc"*"ec"*"uc"^2*"WR"^2, "BR"^2*"D"^2*"dc"*"ec"*"uc"^2}, 
  D^2*FL*FR*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"D"^2*"GL"*"GR"*"Q"^2*"Q\[Dagger]"^2, "D"^2*"GL"*"Q"^2*"Q\[Dagger]"^2*
     "WR", "BR"*"D"^2*"GL"*"Q"^2*"Q\[Dagger]"^2, "D"^2*"ec\[Dagger]"*"GL"*
     "GR"*"Q"^2*"uc\[Dagger]", "D"^2*"ec\[Dagger]"*"GL"*"Q"^2*"uc\[Dagger]"*
     "WR", "BR"*"D"^2*"ec\[Dagger]"*"GL"*"Q"^2*"uc\[Dagger]", 
    "D"^2*"GL"*"GR"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"GL"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"D"^2*"GL"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"dc"*"dc\[Dagger]"*"GL"*"GR"*"Q"*"Q\[Dagger]", 
    "D"^2*"dc"*"dc\[Dagger]"*"GL"*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"D"^2*"dc"*"dc\[Dagger]"*"GL"*"Q"*"Q\[Dagger]", 
    "D"^2*"dc"*"ec\[Dagger]"*"GL"*"GR"*"L\[Dagger]"*"Q", 
    "D"^2*"dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q"*"WR", 
    "BR"*"D"^2*"dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q", 
    "D"^2*"GL"*"GR"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"^2*"GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"D"^2*"GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"GL"*"GR"*"L"*"Q"*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"GL"*"L"*"Q"*"uc\[Dagger]"*"WR", 
    "BR"*"D"^2*"dc\[Dagger]"*"GL"*"L"*"Q"*"uc\[Dagger]", 
    "D"^2*"ec"*"ec\[Dagger]"*"GL"*"GR"*"Q"*"Q\[Dagger]", 
    "D"^2*"ec"*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"D"^2*"ec"*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]", 
    "D"^2*"GL"*"GR"*"uc"^2*"uc\[Dagger]"^2, "BR"*"D"^2*"GL"*"uc"^2*
     "uc\[Dagger]"^2, "D"^2*"dc"*"GL"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"D"^2*"dc"*"GL"*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "D"^2*"dc"*"dc\[Dagger]"*"GL"*"GR"*"uc"*"uc\[Dagger]", 
    "BR"*"D"^2*"dc"*"dc\[Dagger]"*"GL"*"uc"*"uc\[Dagger]", 
    "D"^2*"GL"*"GR"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"GL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"D"^2*"GL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"ec"*"GL"*"Q\[Dagger]"^2*"uc"*"WR", "BR"*"D"^2*"ec"*"GL"*
     "Q\[Dagger]"^2*"uc", "D"^2*"ec"*"ec\[Dagger]"*"GL"*"GR"*"uc"*
     "uc\[Dagger]", "BR"*"D"^2*"ec"*"ec\[Dagger]"*"GL"*"uc"*"uc\[Dagger]", 
    "D"^2*"dc"^2*"dc\[Dagger]"^2*"GL"*"GR", "BR"*"D"^2*"dc"^2*"dc\[Dagger]"^2*
     "GL", "D"^2*"dc"*"dc\[Dagger]"*"GL"*"GR"*"L"*"L\[Dagger]", 
    "D"^2*"dc"*"dc\[Dagger]"*"GL"*"L"*"L\[Dagger]"*"WR", 
    "BR"*"D"^2*"dc"*"dc\[Dagger]"*"GL"*"L"*"L\[Dagger]", 
    "D"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"GR", 
    "BR"*"D"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL", 
    "D"^2*"GL"*"GR"*"L"^2*"L\[Dagger]"^2, "D"^2*"dc\[Dagger]"*"ec"*"GL"*"L"*
     "Q\[Dagger]"*"WR", "BR"*"D"^2*"dc\[Dagger]"*"ec"*"GL"*"L"*"Q\[Dagger]", 
    "D"^2*"ec"*"ec\[Dagger]"*"GL"*"GR"*"L"*"L\[Dagger]", 
    "D"^2*"ec"^2*"ec\[Dagger]"^2*"GL"*"GR", "D"^2*"Q"^2*"Q\[Dagger]"^2*"WL"*
     "WR", "BR"*"D"^2*"Q"^2*"Q\[Dagger]"^2*"WL", "D"^2*"ec\[Dagger]"*"Q"^2*
     "uc\[Dagger]"*"WL"*"WR", "BR"*"D"^2*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]"*
     "WL", "D"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"D"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"^2*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BR"*"D"^2*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"^2*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"WL"*"WR", 
    "BR"*"D"^2*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"WL", 
    "D"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BR"*"D"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"^2*"dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"D"^2*"dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*"WL", 
    "D"^2*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BR"*"D"^2*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"^2*"uc"^2*"uc\[Dagger]"^2*"WL"*"WR", "BR"*"D"^2*"dc"*"L\[Dagger]"*
     "Q\[Dagger]"*"uc"*"WL", "D"^2*"dc"*"dc\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*
     "WR", "D"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"D"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BR"*"D"^2*"ec"*"Q\[Dagger]"^2*"uc"*"WL", "D"^2*"ec"*"ec\[Dagger]"*"uc"*
     "uc\[Dagger]"*"WL"*"WR", "D"^2*"dc"^2*"dc\[Dagger]"^2*"WL"*"WR", 
    "D"^2*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*"WL"*"WR", 
    "BR"*"D"^2*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "D"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"WL"*"WR", 
    "D"^2*"L"^2*"L\[Dagger]"^2*"WL"*"WR", "BR"*"D"^2*"L"^2*"L\[Dagger]"^2*
     "WL", "BR"*"D"^2*"dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]"*"WL", 
    "D"^2*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"WL"*"WR", 
    "BR"*"D"^2*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "D"^2*"ec"^2*"ec\[Dagger]"^2*"WL"*"WR", "BL"*"BR"*"D"^2*"Q"^2*
     "Q\[Dagger]"^2, "BL"*"BR"*"D"^2*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "BL"*"BR"*"D"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"BR"*"D"^2*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"BR"*"D"^2*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q", 
    "BL"*"BR"*"D"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"BR"*"D"^2*"dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]", 
    "BL"*"BR"*"D"^2*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"BR"*"D"^2*"uc"^2*"uc\[Dagger]"^2, "BL"*"BR"*"D"^2*"dc"*
     "dc\[Dagger]"*"uc"*"uc\[Dagger]", "BL"*"BR"*"D"^2*"L"*"L\[Dagger]"*"uc"*
     "uc\[Dagger]", "BL"*"BR"*"D"^2*"ec"*"ec\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"BR"*"D"^2*"dc"^2*"dc\[Dagger]"^2, "BL"*"BR"*"D"^2*"dc"*
     "dc\[Dagger]"*"L"*"L\[Dagger]", "BL"*"BR"*"D"^2*"dc"*"dc\[Dagger]"*"ec"*
     "ec\[Dagger]", "BL"*"BR"*"D"^2*"L"^2*"L\[Dagger]"^2, 
    "BL"*"BR"*"D"^2*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"*"BR"*"D"^2*"ec"^2*"ec\[Dagger]"^2}, D^2*FL*FR^2*\[Phi]*\[Psi]^2 -> 
   {"D"^2*"GL"*"GR"^2*"H"*"Q"*"uc", "D"^2*"GL"*"GR"*"H"*"Q"*"uc"*"WR", 
    "BR"*"D"^2*"GL"*"GR"*"H"*"Q"*"uc", "D"^2*"GL"*"H"*"Q"*"uc"*"WR"^2, 
    "BR"*"D"^2*"GL"*"H"*"Q"*"uc"*"WR", "BR"^2*"D"^2*"GL"*"H"*"Q"*"uc", 
    "D"^2*"dc"*"GL"*"GR"^2*"H\[Dagger]"*"Q", "D"^2*"dc"*"GL"*"GR"*
     "H\[Dagger]"*"Q"*"WR", "BR"*"D"^2*"dc"*"GL"*"GR"*"H\[Dagger]"*"Q", 
    "D"^2*"dc"*"GL"*"H\[Dagger]"*"Q"*"WR"^2, "BR"*"D"^2*"dc"*"GL"*
     "H\[Dagger]"*"Q"*"WR", "BR"^2*"D"^2*"dc"*"GL"*"H\[Dagger]"*"Q", 
    "D"^2*"ec"*"GL"*"GR"^2*"H\[Dagger]"*"L", "D"^2*"ec"*"GL"*"GR"*
     "H\[Dagger]"*"L"*"WR", "BR"*"D"^2*"ec"*"GL"*"GR"*"H\[Dagger]"*"L", 
    "D"^2*"GR"^2*"H"*"Q"*"uc"*"WL", "D"^2*"GR"*"H"*"Q"*"uc"*"WL"*"WR", 
    "BR"*"D"^2*"GR"*"H"*"Q"*"uc"*"WL", "D"^2*"H"*"Q"*"uc"*"WL"*"WR"^2, 
    "BR"*"D"^2*"H"*"Q"*"uc"*"WL"*"WR", "BR"^2*"D"^2*"H"*"Q"*"uc"*"WL", 
    "D"^2*"dc"*"GR"^2*"H\[Dagger]"*"Q"*"WL", "D"^2*"dc"*"GR"*"H\[Dagger]"*"Q"*
     "WL"*"WR", "BR"*"D"^2*"dc"*"GR"*"H\[Dagger]"*"Q"*"WL", 
    "D"^2*"dc"*"H\[Dagger]"*"Q"*"WL"*"WR"^2, "BR"*"D"^2*"dc"*"H\[Dagger]"*"Q"*
     "WL"*"WR", "BR"^2*"D"^2*"dc"*"H\[Dagger]"*"Q"*"WL", 
    "D"^2*"ec"*"GR"^2*"H\[Dagger]"*"L"*"WL", "D"^2*"ec"*"H\[Dagger]"*"L"*"WL"*
     "WR"^2, "BR"*"D"^2*"ec"*"H\[Dagger]"*"L"*"WL"*"WR", 
    "BR"^2*"D"^2*"ec"*"H\[Dagger]"*"L"*"WL", "BL"*"D"^2*"GR"^2*"H"*"Q"*"uc", 
    "BL"*"D"^2*"GR"*"H"*"Q"*"uc"*"WR", "BL"*"BR"*"D"^2*"GR"*"H"*"Q"*"uc", 
    "BL"*"D"^2*"H"*"Q"*"uc"*"WR"^2, "BL"*"BR"*"D"^2*"H"*"Q"*"uc"*"WR", 
    "BL"*"BR"^2*"D"^2*"H"*"Q"*"uc", "BL"*"D"^2*"dc"*"GR"^2*"H\[Dagger]"*"Q", 
    "BL"*"D"^2*"dc"*"GR"*"H\[Dagger]"*"Q"*"WR", "BL"*"BR"*"D"^2*"dc"*"GR"*
     "H\[Dagger]"*"Q", "BL"*"D"^2*"dc"*"H\[Dagger]"*"Q"*"WR"^2, 
    "BL"*"BR"*"D"^2*"dc"*"H\[Dagger]"*"Q"*"WR", "BL"*"BR"^2*"D"^2*"dc"*
     "H\[Dagger]"*"Q", "BL"*"D"^2*"ec"*"GR"^2*"H\[Dagger]"*"L", 
    "BL"*"D"^2*"ec"*"H\[Dagger]"*"L"*"WR"^2, "BL"*"BR"*"D"^2*"ec"*
     "H\[Dagger]"*"L"*"WR", "BL"*"BR"^2*"D"^2*"ec"*"H\[Dagger]"*"L"}, 
  D^2*FL^2*FR^2*\[Phi]^2 -> {"D"^2*"GL"^2*"GR"^2*"H"*"H\[Dagger]", 
    "D"^2*"GL"^2*"GR"*"H"*"H\[Dagger]"*"WR", "BR"*"D"^2*"GL"^2*"GR"*"H"*
     "H\[Dagger]", "D"^2*"GL"^2*"H"*"H\[Dagger]"*"WR"^2, 
    "BR"*"D"^2*"GL"^2*"H"*"H\[Dagger]"*"WR", "BR"^2*"D"^2*"GL"^2*"H"*
     "H\[Dagger]", "D"^2*"GL"*"GR"*"H"*"H\[Dagger]"*"WL"*"WR", 
    "BR"*"D"^2*"GL"*"GR"*"H"*"H\[Dagger]"*"WL", "BL"*"BR"*"D"^2*"GL"*"GR"*"H"*
     "H\[Dagger]", "D"^2*"H"*"H\[Dagger]"*"WL"^2*"WR"^2, 
    "BR"*"D"^2*"H"*"H\[Dagger]"*"WL"^2*"WR", "BR"^2*"D"^2*"H"*"H\[Dagger]"*
     "WL"^2, "BL"*"BR"*"D"^2*"H"*"H\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"^2*"D"^2*"H"*"H\[Dagger]"*"WL", "BL"^2*"BR"^2*"D"^2*"H"*
     "H\[Dagger]"}, D^3*\[Psi]^3*OverBar[\[Psi]]^3 -> 
   {"D"^3*"Q"^3*"Q\[Dagger]"^3, "D"^3*"ec\[Dagger]"*"Q"^3*"Q\[Dagger]"*
     "uc\[Dagger]", "D"^3*"Q"^2*"Q\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"^3*"ec\[Dagger]"*"Q"^2*"uc"*"uc\[Dagger]"^2, 
    "D"^3*"dc"*"dc\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, 
    "D"^3*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "D"^3*"dc"*"dc\[Dagger]"*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "D"^3*"L"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, "D"^3*"dc\[Dagger]"*"L"*
     "Q"^2*"Q\[Dagger]"*"uc\[Dagger]", "D"^3*"ec\[Dagger]"*"L"*"L\[Dagger]"*
     "Q"^2*"uc\[Dagger]", "D"^3*"ec"*"ec\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, 
    "D"^3*"ec"*"ec\[Dagger]"^2*"Q"^2*"uc\[Dagger]", 
    "D"^3*"Q"*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "D"^3*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^3*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "D"^3*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^3*"dc\[Dagger]"*"L"*"Q"*"uc"*"uc\[Dagger]"^2, 
    "D"^3*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^3*"dc"^2*"dc\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "D"^3*"dc"^2*"dc\[Dagger]"*"ec\[Dagger]"*"L\[Dagger]"*"Q", 
    "D"^3*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"^3*"dc"*"dc\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]", 
    "D"^3*"dc"*"ec\[Dagger]"*"L"*"L\[Dagger]"^2*"Q", 
    "D"^3*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"^3*"dc"*"ec"*"ec\[Dagger]"^2*"L\[Dagger]"*"Q", 
    "D"^3*"L"^2*"L\[Dagger]"^2*"Q"*"Q\[Dagger]", "D"^3*"dc\[Dagger]"*"L"^2*
     "L\[Dagger]"*"Q"*"uc\[Dagger]", "D"^3*"ec"*"ec\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"*"Q\[Dagger]", "D"^3*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*
     "L"*"Q"*"uc\[Dagger]", "D"^3*"ec"^2*"ec\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "D"^3*"uc"^3*"uc\[Dagger]"^3, "D"^3*"dc"*"dc\[Dagger]"*"uc"^2*
     "uc\[Dagger]"^2, "D"^3*"L"*"L\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "D"^3*"ec"*"ec\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "D"^3*"dc"^2*"dc\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"^3*"dc"^2*"ec\[Dagger]"*"L\[Dagger]"^2*"uc", 
    "D"^3*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^3*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^3*"L"^2*"L\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"^3*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^3*"ec"^2*"ec\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"^3*"dc"^3*"dc\[Dagger]"^3, "D"^3*"dc"^2*"dc\[Dagger]"^2*"L"*
     "L\[Dagger]", "D"^3*"dc"^2*"dc\[Dagger]"^2*"ec"*"ec\[Dagger]", 
    "D"^3*"dc"*"dc\[Dagger]"*"L"^2*"L\[Dagger]"^2, 
    "D"^3*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]", 
    "D"^3*"dc"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"^2, 
    "D"^3*"L"^3*"L\[Dagger]"^3, "D"^3*"ec"*"ec\[Dagger]"*"L"^2*
     "L\[Dagger]"^2, "D"^3*"ec"^2*"ec\[Dagger]"^2*"L"*"L\[Dagger]", 
    "D"^3*"ec"^3*"ec\[Dagger]"^3}, D^3*FR*\[Phi]*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"^3*"ec\[Dagger]"*"GR"*"H"*"Q"^3, "D"^3*"ec\[Dagger]"*"H"*"Q"^3*"WR", 
    "BR"*"D"^3*"ec\[Dagger]"*"H"*"Q"^3, "D"^3*"GR"*"H"*"Q"^2*"Q\[Dagger]"*
     "uc", "D"^3*"H"*"Q"^2*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"D"^3*"H"*"Q"^2*"Q\[Dagger]"*"uc", "D"^3*"dc"*"GR"*"H\[Dagger]"*
     "Q"^2*"Q\[Dagger]", "D"^3*"dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"WR", 
    "BR"*"D"^3*"dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "D"^3*"dc\[Dagger]"*"GR"*"H"*"L"*"Q"^2, "D"^3*"dc\[Dagger]"*"H"*"L"*"Q"^2*
     "WR", "BR"*"D"^3*"dc\[Dagger]"*"H"*"L"*"Q"^2, 
    "D"^3*"GR"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]", 
    "D"^3*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]"*"WR", 
    "BR"*"D"^3*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]", 
    "D"^3*"GR"*"H"*"Q"*"uc"^2*"uc\[Dagger]", "D"^3*"H"*"Q"*"uc"^2*
     "uc\[Dagger]"*"WR", "BR"*"D"^3*"H"*"Q"*"uc"^2*"uc\[Dagger]", 
    "D"^3*"dc"*"dc\[Dagger]"*"GR"*"H"*"Q"*"uc", "D"^3*"dc"*"dc\[Dagger]"*"H"*
     "Q"*"uc"*"WR", "BR"*"D"^3*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc", 
    "D"^3*"dc"*"GR"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "D"^3*"dc"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"D"^3*"dc"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "D"^3*"GR"*"H"*"L"*"L\[Dagger]"*"Q"*"uc", "D"^3*"H"*"L"*"L\[Dagger]"*"Q"*
     "uc"*"WR", "BR"*"D"^3*"H"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "D"^3*"ec"*"ec\[Dagger]"*"GR"*"H"*"Q"*"uc", "D"^3*"ec"*"ec\[Dagger]"*"H"*
     "Q"*"uc"*"WR", "BR"*"D"^3*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc", 
    "D"^3*"dc"^2*"dc\[Dagger]"*"GR"*"H\[Dagger]"*"Q", 
    "D"^3*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q"*"WR", 
    "BR"*"D"^3*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q", 
    "D"^3*"dc"*"GR"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "D"^3*"dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"WR", 
    "BR"*"D"^3*"dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "D"^3*"dc"*"ec"*"ec\[Dagger]"*"GR"*"H\[Dagger]"*"Q", 
    "D"^3*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"*"WR", 
    "BR"*"D"^3*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q", 
    "D"^3*"ec"*"GR"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "D"^3*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"D"^3*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "D"^3*"dc"*"GR"*"H"*"L\[Dagger]"*"uc"^2, "D"^3*"dc"*"H"*"L\[Dagger]"*
     "uc"^2*"WR", "BR"*"D"^3*"dc"*"H"*"L\[Dagger]"*"uc"^2, 
    "D"^3*"ec"*"GR"*"H"*"Q\[Dagger]"*"uc"^2, "D"^3*"ec"*"H"*"Q\[Dagger]"*
     "uc"^2*"WR", "BR"*"D"^3*"ec"*"H"*"Q\[Dagger]"*"uc"^2, 
    "D"^3*"dc"^2*"GR"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "D"^3*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WR", 
    "BR"*"D"^3*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "D"^3*"dc"*"ec"*"GR"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "D"^3*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"D"^3*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "D"^3*"dc\[Dagger]"*"ec"*"GR"*"H"*"L"*"uc", "D"^3*"dc\[Dagger]"*"ec"*"H"*
     "L"*"uc"*"WR", "BR"*"D"^3*"dc\[Dagger]"*"ec"*"H"*"L"*"uc", 
    "D"^3*"ec"*"GR"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", 
    "D"^3*"ec"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"D"^3*"ec"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", 
    "D"^3*"dc"*"dc\[Dagger]"*"ec"*"GR"*"H\[Dagger]"*"L", 
    "D"^3*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"*"WR", 
    "BR"*"D"^3*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L", 
    "D"^3*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"WR", 
    "BR"*"D"^3*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]", 
    "D"^3*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"WR", 
    "BR"*"D"^3*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"}, 
  D^3*FL*FR*\[Phi]^2*\[Psi]*OverBar[\[Psi]] -> 
   {"D"^3*"GL"*"GR"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"^3*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"D"^3*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"^3*"dc\[Dagger]"*"GL"*"GR"*"H"^2*"uc", "D"^3*"dc\[Dagger]"*"GL"*"H"^2*
     "uc"*"WR", "BR"*"D"^3*"dc\[Dagger]"*"GL"*"H"^2*"uc", 
    "D"^3*"GL"*"GR"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^3*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"D"^3*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^3*"dc"*"dc\[Dagger]"*"GL"*"GR"*"H"*"H\[Dagger]", 
    "D"^3*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"WR", 
    "BR"*"D"^3*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]", 
    "D"^3*"dc"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]"*"WR", 
    "BR"*"D"^3*"dc"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "D"^3*"GL"*"GR"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "D"^3*"ec"*"ec\[Dagger]"*"GL"*"GR"*"H"*"H\[Dagger]", 
    "D"^3*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BR"*"D"^3*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"^3*"dc\[Dagger]"*"H"^2*"uc"*"WL"*"WR", "BR"*"D"^3*"dc\[Dagger]"*"H"^2*
     "uc"*"WL", "D"^3*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"D"^3*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"^3*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"WL"*"WR", 
    "BR"*"D"^3*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"WL", 
    "BR"*"D"^3*"dc"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "D"^3*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL"*"WR", 
    "BR"*"D"^3*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "D"^3*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL"*"WR", 
    "BR"*"D"^3*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL", 
    "BL"*"BR"*"D"^3*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"BR"*"D"^3*"dc\[Dagger]"*"H"^2*"uc", "BL"*"BR"*"D"^3*"H"*
     "H\[Dagger]"*"uc"*"uc\[Dagger]", "BL"*"BR"*"D"^3*"dc"*"dc\[Dagger]"*"H"*
     "H\[Dagger]", "BL"*"BR"*"D"^3*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"*"BR"*"D"^3*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"}, 
  D^4*\[Phi]^2*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"D"^4*"dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"Q"^2, 
    "D"^4*"H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, "D"^4*"ec\[Dagger]"*"H"*
     "H\[Dagger]"*"Q"^2*"uc\[Dagger]", "D"^4*"dc\[Dagger]"*"H"^2*"Q"*
     "Q\[Dagger]"*"uc", "D"^4*"ec\[Dagger]"*"H"^2*"L\[Dagger]"*"Q"*"uc", 
    "D"^4*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^4*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"^4*"dc"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q", 
    "D"^4*"dc\[Dagger]"^2*"H"^2*"L"*"Q", "D"^4*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"*"Q\[Dagger]", "D"^4*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*
     "Q"*"uc\[Dagger]", "D"^4*"H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"^2, 
    "D"^4*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"^4*"dc\[Dagger]"*"H"^2*"uc"^2*"uc\[Dagger]", 
    "D"^4*"H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "D"^4*"dc"*"dc\[Dagger]"^2*"H"^2*"uc", "D"^4*"dc"*"dc\[Dagger]"*"H"*
     "H\[Dagger]"*"uc"*"uc\[Dagger]", "D"^4*"dc\[Dagger]"*"H"^2*"L"*
     "L\[Dagger]"*"uc", "D"^4*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*
     "uc\[Dagger]", "D"^4*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*"uc", 
    "D"^4*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^4*"dc"^2*"dc\[Dagger]"^2*"H"*"H\[Dagger]", 
    "D"^4*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "D"^4*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]", 
    "D"^4*"H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2, "D"^4*"ec"*"ec\[Dagger]"*"H"*
     "H\[Dagger]"*"L"*"L\[Dagger]", "D"^4*"ec"^2*"ec\[Dagger]"^2*"H"*
     "H\[Dagger]"}, D^4*FR*\[Phi]^3*\[Psi]^2 -> 
   {"D"^4*"GR"*"H"^2*"H\[Dagger]"*"Q"*"uc", "D"^4*"H"^2*"H\[Dagger]"*"Q"*"uc"*
     "WR", "BR"*"D"^4*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "D"^4*"dc"*"GR"*"H"*"H\[Dagger]"^2*"Q", "D"^4*"dc"*"H"*"H\[Dagger]"^2*"Q"*
     "WR", "BR"*"D"^4*"dc"*"H"*"H\[Dagger]"^2*"Q", 
    "D"^4*"ec"*"H"*"H\[Dagger]"^2*"L"*"WR", "BR"*"D"^4*"ec"*"H"*
     "H\[Dagger]"^2*"L"}, D^4*FL*FR*\[Phi]^4 -> 
   {"D"^4*"GL"*"GR"*"H"^2*"H\[Dagger]"^2, "D"^4*"H"^2*"H\[Dagger]"^2*"WL"*
     "WR", "BR"*"D"^4*"H"^2*"H\[Dagger]"^2*"WL", "BL"*"BR"*"D"^4*"H"^2*
     "H\[Dagger]"^2}, D^5*\[Phi]^4*\[Psi]*OverBar[\[Psi]] -> 
   {"D"^5*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", "D"^5*"dc\[Dagger]"*"H"^3*
     "H\[Dagger]"*"uc", "D"^5*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"^5*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2, 
    "D"^5*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]", "D"^5*"ec"*"ec\[Dagger]"*
     "H"^2*"H\[Dagger]"^2}, D^6*\[Phi]^6 -> {"D"^6*"H"^3*"H\[Dagger]"^3}, 
  FL^3*\[Psi]^4 -> {"GL"^3*"L"*"Q"^3, "dc"*"GL"^3*"Q"^2*"uc", 
    "ec"*"GL"^3*"L"*"Q"*"uc", "dc"*"ec"*"GL"^3*"uc"^2, "GL"^2*"L"*"Q"^3*"WL", 
    "dc"*"GL"^2*"Q"^2*"uc"*"WL", "ec"*"GL"^2*"L"*"Q"*"uc"*"WL", 
    "BL"*"GL"^2*"L"*"Q"^3, "BL"*"dc"*"GL"^2*"Q"^2*"uc", 
    "BL"*"ec"*"GL"^2*"L"*"Q"*"uc", "BL"*"dc"*"ec"*"GL"^2*"uc"^2, 
    "GL"*"L"*"Q"^3*"WL"^2, "dc"*"GL"*"Q"^2*"uc"*"WL"^2, 
    "ec"*"GL"*"L"*"Q"*"uc"*"WL"^2, "dc"*"ec"*"GL"*"uc"^2*"WL"^2, 
    "BL"*"GL"*"L"*"Q"^3*"WL", "BL"*"dc"*"GL"*"Q"^2*"uc"*"WL", 
    "BL"*"ec"*"GL"*"L"*"Q"*"uc"*"WL", "BL"^2*"GL"*"L"*"Q"^3, 
    "BL"^2*"dc"*"GL"*"Q"^2*"uc", "BL"^2*"ec"*"GL"*"L"*"Q"*"uc", 
    "BL"^2*"dc"*"ec"*"GL"*"uc"^2, "L"*"Q"^3*"WL"^3, "dc"*"Q"^2*"uc"*"WL"^3, 
    "ec"*"L"*"Q"*"uc"*"WL"^3, "dc"*"ec"*"uc"^2*"WL"^3, "BL"*"L"*"Q"^3*"WL"^2, 
    "BL"*"dc"*"Q"^2*"uc"*"WL"^2, "BL"*"ec"*"L"*"Q"*"uc"*"WL"^2, 
    "BL"*"dc"*"ec"*"uc"^2*"WL"^2, "BL"^2*"L"*"Q"^3*"WL", 
    "BL"^2*"dc"*"Q"^2*"uc"*"WL", "BL"^2*"ec"*"L"*"Q"*"uc"*"WL", 
    "BL"^3*"L"*"Q"^3, "BL"^3*"dc"*"Q"^2*"uc", "BL"^3*"ec"*"L"*"Q"*"uc", 
    "BL"^3*"dc"*"ec"*"uc"^2}, FL^4*\[Phi]*\[Psi]^2 -> 
   {"GL"^4*"H"*"Q"*"uc", "dc"*"GL"^4*"H\[Dagger]"*"Q", 
    "ec"*"GL"^4*"H\[Dagger]"*"L", "GL"^3*"H"*"Q"*"uc"*"WL", 
    "dc"*"GL"^3*"H\[Dagger]"*"Q"*"WL", "ec"*"GL"^3*"H\[Dagger]"*"L"*"WL", 
    "BL"*"GL"^3*"H"*"Q"*"uc", "BL"*"dc"*"GL"^3*"H\[Dagger]"*"Q", 
    "BL"*"ec"*"GL"^3*"H\[Dagger]"*"L", "GL"^2*"H"*"Q"*"uc"*"WL"^2, 
    "dc"*"GL"^2*"H\[Dagger]"*"Q"*"WL"^2, "ec"*"GL"^2*"H\[Dagger]"*"L"*"WL"^2, 
    "BL"*"GL"^2*"H"*"Q"*"uc"*"WL", "BL"*"dc"*"GL"^2*"H\[Dagger]"*"Q"*"WL", 
    "BL"*"ec"*"GL"^2*"H\[Dagger]"*"L"*"WL", "BL"^2*"GL"^2*"H"*"Q"*"uc", 
    "BL"^2*"dc"*"GL"^2*"H\[Dagger]"*"Q", "BL"^2*"ec"*"GL"^2*"H\[Dagger]"*"L", 
    "GL"*"H"*"Q"*"uc"*"WL"^3, "dc"*"GL"*"H\[Dagger]"*"Q"*"WL"^3, 
    "BL"*"GL"*"H"*"Q"*"uc"*"WL"^2, "BL"*"dc"*"GL"*"H\[Dagger]"*"Q"*"WL"^2, 
    "BL"^2*"GL"*"H"*"Q"*"uc"*"WL", "BL"^2*"dc"*"GL"*"H\[Dagger]"*"Q"*"WL", 
    "BL"^3*"GL"*"H"*"Q"*"uc", "BL"^3*"dc"*"GL"*"H\[Dagger]"*"Q", 
    "H"*"Q"*"uc"*"WL"^4, "dc"*"H\[Dagger]"*"Q"*"WL"^4, 
    "ec"*"H\[Dagger]"*"L"*"WL"^4, "BL"*"H"*"Q"*"uc"*"WL"^3, 
    "BL"*"dc"*"H\[Dagger]"*"Q"*"WL"^3, "BL"*"ec"*"H\[Dagger]"*"L"*"WL"^3, 
    "BL"^2*"H"*"Q"*"uc"*"WL"^2, "BL"^2*"dc"*"H\[Dagger]"*"Q"*"WL"^2, 
    "BL"^2*"ec"*"H\[Dagger]"*"L"*"WL"^2, "BL"^3*"H"*"Q"*"uc"*"WL", 
    "BL"^3*"dc"*"H\[Dagger]"*"Q"*"WL", "BL"^3*"ec"*"H\[Dagger]"*"L"*"WL", 
    "BL"^4*"H"*"Q"*"uc", "BL"^4*"dc"*"H\[Dagger]"*"Q", 
    "BL"^4*"ec"*"H\[Dagger]"*"L"}, FL^5*\[Phi]^2 -> 
   {"GL"^5*"H"*"H\[Dagger]", "GL"^4*"H"*"H\[Dagger]"*"WL", 
    "BL"*"GL"^4*"H"*"H\[Dagger]", "GL"^3*"H"*"H\[Dagger]"*"WL"^2, 
    "BL"*"GL"^3*"H"*"H\[Dagger]"*"WL", "BL"^2*"GL"^3*"H"*"H\[Dagger]", 
    "GL"^2*"H"*"H\[Dagger]"*"WL"^3, "BL"*"GL"^2*"H"*"H\[Dagger]"*"WL"^2, 
    "BL"^2*"GL"^2*"H"*"H\[Dagger]"*"WL", "BL"^3*"GL"^2*"H"*"H\[Dagger]", 
    "H"*"H\[Dagger]"*"WL"^5, "BL"*"H"*"H\[Dagger]"*"WL"^4, 
    "BL"^2*"H"*"H\[Dagger]"*"WL"^3, "BL"^3*"H"*"H\[Dagger]"*"WL"^2, 
    "BL"^4*"H"*"H\[Dagger]"*"WL", "BL"^5*"H"*"H\[Dagger]"}, 
  FL^3*\[Psi]^2*OverBar[\[Psi]]^2 -> {"GL"^3*"Q"^2*"Q\[Dagger]"^2, 
    "ec\[Dagger]"*"GL"^3*"Q"^2*"uc\[Dagger]", "GL"^3*"Q"*"Q\[Dagger]"*"uc"*
     "uc\[Dagger]", "dc"*"dc\[Dagger]"*"GL"^3*"Q"*"Q\[Dagger]", 
    "dc"*"ec\[Dagger]"*"GL"^3*"L\[Dagger]"*"Q", "GL"^3*"L"*"L\[Dagger]"*"Q"*
     "Q\[Dagger]", "dc\[Dagger]"*"GL"^3*"L"*"Q"*"uc\[Dagger]", 
    "ec"*"ec\[Dagger]"*"GL"^3*"Q"*"Q\[Dagger]", 
    "GL"^3*"uc"^2*"uc\[Dagger]"^2, "dc"*"GL"^3*"L\[Dagger]"*"Q\[Dagger]"*
     "uc", "dc"*"dc\[Dagger]"*"GL"^3*"uc"*"uc\[Dagger]", 
    "GL"^3*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", "ec"*"GL"^3*"Q\[Dagger]"^2*
     "uc", "ec"*"ec\[Dagger]"*"GL"^3*"uc"*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2*"GL"^3, "dc"*"dc\[Dagger]"*"GL"^3*"L"*
     "L\[Dagger]", "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"^3, 
    "GL"^3*"L"^2*"L\[Dagger]"^2, "dc\[Dagger]"*"ec"*"GL"^3*"L"*"Q\[Dagger]", 
    "ec"*"ec\[Dagger]"*"GL"^3*"L"*"L\[Dagger]", "ec"^2*"ec\[Dagger]"^2*
     "GL"^3, "GL"^2*"Q"^2*"Q\[Dagger]"^2*"WL", "ec\[Dagger]"*"GL"^2*"Q"^2*
     "uc\[Dagger]"*"WL", "GL"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"GL"^2*"Q"*"Q\[Dagger]"*"WL", 
    "dc"*"ec\[Dagger]"*"GL"^2*"L\[Dagger]"*"Q"*"WL", 
    "GL"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "dc\[Dagger]"*"GL"^2*"L"*"Q"*"uc\[Dagger]"*"WL", 
    "ec"*"ec\[Dagger]"*"GL"^2*"Q"*"Q\[Dagger]"*"WL", 
    "dc"*"GL"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "GL"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "ec"*"GL"^2*"Q\[Dagger]"^2*"uc"*"WL", "dc"*"dc\[Dagger]"*"GL"^2*"L"*
     "L\[Dagger]"*"WL", "GL"^2*"L"^2*"L\[Dagger]"^2*"WL", 
    "dc\[Dagger]"*"ec"*"GL"^2*"L"*"Q\[Dagger]"*"WL", 
    "ec"*"ec\[Dagger]"*"GL"^2*"L"*"L\[Dagger]"*"WL", 
    "BL"*"GL"^2*"Q"^2*"Q\[Dagger]"^2, "BL"*"ec\[Dagger]"*"GL"^2*"Q"^2*
     "uc\[Dagger]", "BL"*"GL"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"GL"^2*"Q"*"Q\[Dagger]", 
    "BL"*"dc"*"ec\[Dagger]"*"GL"^2*"L\[Dagger]"*"Q", 
    "BL"*"GL"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"dc\[Dagger]"*"GL"^2*"L"*"Q"*"uc\[Dagger]", 
    "BL"*"ec"*"ec\[Dagger]"*"GL"^2*"Q"*"Q\[Dagger]", 
    "BL"*"GL"^2*"uc"^2*"uc\[Dagger]"^2, "BL"*"dc"*"GL"^2*"L\[Dagger]"*
     "Q\[Dagger]"*"uc", "BL"*"dc"*"dc\[Dagger]"*"GL"^2*"uc"*"uc\[Dagger]", 
    "BL"*"GL"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"ec"*"GL"^2*"Q\[Dagger]"^2*"uc", "BL"*"ec"*"ec\[Dagger]"*"GL"^2*"uc"*
     "uc\[Dagger]", "BL"*"dc"^2*"dc\[Dagger]"^2*"GL"^2, 
    "BL"*"dc"*"dc\[Dagger]"*"GL"^2*"L"*"L\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"^2, 
    "BL"*"GL"^2*"L"^2*"L\[Dagger]"^2, "BL"*"dc\[Dagger]"*"ec"*"GL"^2*"L"*
     "Q\[Dagger]", "BL"*"ec"*"ec\[Dagger]"*"GL"^2*"L"*"L\[Dagger]", 
    "BL"*"ec"^2*"ec\[Dagger]"^2*"GL"^2, "GL"*"Q"^2*"Q\[Dagger]"^2*"WL"^2, 
    "ec\[Dagger]"*"GL"*"Q"^2*"uc\[Dagger]"*"WL"^2, 
    "GL"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "dc"*"dc\[Dagger]"*"GL"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q"*"WL"^2, 
    "GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "dc\[Dagger]"*"GL"*"L"*"Q"*"uc\[Dagger]"*"WL"^2, 
    "ec"*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "GL"*"uc"^2*"uc\[Dagger]"^2*"WL"^2, "dc"*"GL"*"L\[Dagger]"*"Q\[Dagger]"*
     "uc"*"WL"^2, "dc"*"dc\[Dagger]"*"GL"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "GL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "ec"*"GL"*"Q\[Dagger]"^2*"uc"*"WL"^2, "ec"*"ec\[Dagger]"*"GL"*"uc"*
     "uc\[Dagger]"*"WL"^2, "dc"^2*"dc\[Dagger]"^2*"GL"*"WL"^2, 
    "dc"*"dc\[Dagger]"*"GL"*"L"*"L\[Dagger]"*"WL"^2, 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"WL"^2, 
    "dc\[Dagger]"*"ec"*"GL"*"L"*"Q\[Dagger]"*"WL"^2, 
    "BL"*"GL"*"Q"^2*"Q\[Dagger]"^2*"WL", "BL"*"ec\[Dagger]"*"GL"*"Q"^2*
     "uc\[Dagger]"*"WL", "BL"*"GL"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"dc"*"dc\[Dagger]"*"GL"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q"*"WL", 
    "BL"*"GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"*"GL"*"L"*"Q"*"uc\[Dagger]"*"WL", 
    "BL"*"ec"*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"dc"*"GL"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "BL"*"GL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"ec"*"GL"*"Q\[Dagger]"^2*"uc"*"WL", "BL"*"dc"*"dc\[Dagger]"*"GL"*"L"*
     "L\[Dagger]"*"WL", "BL"*"dc\[Dagger]"*"ec"*"GL"*"L"*"Q\[Dagger]"*"WL", 
    "BL"^2*"GL"*"Q"^2*"Q\[Dagger]"^2, "BL"^2*"ec\[Dagger]"*"GL"*"Q"^2*
     "uc\[Dagger]", "BL"^2*"GL"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"dc"*"dc\[Dagger]"*"GL"*"Q"*"Q\[Dagger]", 
    "BL"^2*"dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q", 
    "BL"^2*"GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"^2*"dc\[Dagger]"*"GL"*"L"*"Q"*"uc\[Dagger]", 
    "BL"^2*"ec"*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]", 
    "BL"^2*"GL"*"uc"^2*"uc\[Dagger]"^2, "BL"^2*"dc"*"GL"*"L\[Dagger]"*
     "Q\[Dagger]"*"uc", "BL"^2*"dc"*"dc\[Dagger]"*"GL"*"uc"*"uc\[Dagger]", 
    "BL"^2*"GL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"ec"*"GL"*"Q\[Dagger]"^2*"uc", "BL"^2*"ec"*"ec\[Dagger]"*"GL"*"uc"*
     "uc\[Dagger]", "BL"^2*"dc"^2*"dc\[Dagger]"^2*"GL", 
    "BL"^2*"dc"*"dc\[Dagger]"*"GL"*"L"*"L\[Dagger]", 
    "BL"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL", 
    "BL"^2*"dc\[Dagger]"*"ec"*"GL"*"L"*"Q\[Dagger]", 
    "Q"^2*"Q\[Dagger]"^2*"WL"^3, "ec\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL"^3, 
    "Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^3, "dc"*"dc\[Dagger]"*"Q"*
     "Q\[Dagger]"*"WL"^3, "dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"WL"^3, 
    "L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^3, "dc\[Dagger]"*"L"*"Q"*
     "uc\[Dagger]"*"WL"^3, "ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^3, 
    "uc"^2*"uc\[Dagger]"^2*"WL"^3, "dc"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*
     "WL"^3, "dc"*"dc\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^3, 
    "L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^3, "ec"*"Q\[Dagger]"^2*"uc"*
     "WL"^3, "ec"*"ec\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^3, 
    "dc"^2*"dc\[Dagger]"^2*"WL"^3, "dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*
     "WL"^3, "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"WL"^3, 
    "L"^2*"L\[Dagger]"^2*"WL"^3, "dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]"*"WL"^3, 
    "ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"WL"^3, "ec"^2*"ec\[Dagger]"^2*
     "WL"^3, "BL"*"Q"^2*"Q\[Dagger]"^2*"WL"^2, "BL"*"ec\[Dagger]"*"Q"^2*
     "uc\[Dagger]"*"WL"^2, "BL"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "BL"*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "BL"*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"WL"^2, 
    "BL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "BL"*"dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*"WL"^2, 
    "BL"*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "BL"*"uc"^2*"uc\[Dagger]"^2*"WL"^2, "BL"*"dc"*"L\[Dagger]"*"Q\[Dagger]"*
     "uc"*"WL"^2, "BL"*"dc"*"dc\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "BL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "BL"*"ec"*"Q\[Dagger]"^2*"uc"*"WL"^2, "BL"*"ec"*"ec\[Dagger]"*"uc"*
     "uc\[Dagger]"*"WL"^2, "BL"*"dc"^2*"dc\[Dagger]"^2*"WL"^2, 
    "BL"*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*"WL"^2, 
    "BL"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"WL"^2, 
    "BL"*"L"^2*"L\[Dagger]"^2*"WL"^2, "BL"*"dc\[Dagger]"*"ec"*"L"*
     "Q\[Dagger]"*"WL"^2, "BL"*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"WL"^2, 
    "BL"*"ec"^2*"ec\[Dagger]"^2*"WL"^2, "BL"^2*"Q"^2*"Q\[Dagger]"^2*"WL", 
    "BL"^2*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL", 
    "BL"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"^2*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"^2*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"WL", 
    "BL"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"^2*"dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*"WL", 
    "BL"^2*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"^2*"dc"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "BL"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"^2*"ec"*"Q\[Dagger]"^2*"uc"*"WL", "BL"^2*"dc"*"dc\[Dagger]"*"L"*
     "L\[Dagger]"*"WL", "BL"^2*"L"^2*"L\[Dagger]"^2*"WL", 
    "BL"^2*"dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]"*"WL", 
    "BL"^2*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "BL"^3*"Q"^2*"Q\[Dagger]"^2, "BL"^3*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "BL"^3*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", "BL"^3*"dc"*"dc\[Dagger]"*"Q"*
     "Q\[Dagger]", "BL"^3*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q", 
    "BL"^3*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", "BL"^3*"dc\[Dagger]"*"L"*"Q"*
     "uc\[Dagger]", "BL"^3*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"^3*"uc"^2*"uc\[Dagger]"^2, "BL"^3*"dc"*"L\[Dagger]"*"Q\[Dagger]"*
     "uc", "BL"^3*"dc"*"dc\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^3*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", "BL"^3*"ec"*"Q\[Dagger]"^2*
     "uc", "BL"^3*"ec"*"ec\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^3*"dc"^2*"dc\[Dagger]"^2, "BL"^3*"dc"*"dc\[Dagger]"*"L"*
     "L\[Dagger]", "BL"^3*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]", 
    "BL"^3*"L"^2*"L\[Dagger]"^2, "BL"^3*"dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]", 
    "BL"^3*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"^3*"ec"^2*"ec\[Dagger]"^2}, FL^4*\[Phi]*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"*"GL"^4*"H"*"Q\[Dagger]", "ec\[Dagger]"*"GL"^4*"H"*
     "L\[Dagger]", "GL"^4*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"GL"^3*"H"*"Q\[Dagger]"*"WL", "ec\[Dagger]"*"GL"^3*"H"*
     "L\[Dagger]"*"WL", "GL"^3*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"*"GL"^3*"H"*"Q\[Dagger]", "BL"*"ec\[Dagger]"*"GL"^3*"H"*
     "L\[Dagger]", "BL"*"GL"^3*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"GL"^2*"H"*"Q\[Dagger]"*"WL"^2, "ec\[Dagger]"*"GL"^2*"H"*
     "L\[Dagger]"*"WL"^2, "GL"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*
     "WL"^2, "BL"*"dc\[Dagger]"*"GL"^2*"H"*"Q\[Dagger]"*"WL", 
    "BL"*"ec\[Dagger]"*"GL"^2*"H"*"L\[Dagger]"*"WL", 
    "BL"*"GL"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"^2*"dc\[Dagger]"*"GL"^2*"H"*"Q\[Dagger]", "BL"^2*"ec\[Dagger]"*"GL"^2*
     "H"*"L\[Dagger]", "BL"^2*"GL"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]"*"WL"^3, "GL"*"H\[Dagger]"*
     "Q\[Dagger]"*"uc\[Dagger]"*"WL"^3, "BL"*"dc\[Dagger]"*"GL"*"H"*
     "Q\[Dagger]"*"WL"^2, "BL"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*
     "WL"^2, "BL"^2*"dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]"*"WL", 
    "BL"^2*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"^3*"dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]", "BL"^3*"GL"*"H\[Dagger]"*
     "Q\[Dagger]"*"uc\[Dagger]", "dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL"^4, 
    "ec\[Dagger]"*"H"*"L\[Dagger]"*"WL"^4, "H\[Dagger]"*"Q\[Dagger]"*
     "uc\[Dagger]"*"WL"^4, "BL"*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL"^3, 
    "BL"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"WL"^3, "BL"*"H\[Dagger]"*
     "Q\[Dagger]"*"uc\[Dagger]"*"WL"^3, "BL"^2*"dc\[Dagger]"*"H"*"Q\[Dagger]"*
     "WL"^2, "BL"^2*"ec\[Dagger]"*"H"*"L\[Dagger]"*"WL"^2, 
    "BL"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, 
    "BL"^3*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL", "BL"^3*"ec\[Dagger]"*"H"*
     "L\[Dagger]"*"WL", "BL"^3*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"^4*"dc\[Dagger]"*"H"*"Q\[Dagger]", "BL"^4*"ec\[Dagger]"*"H"*
     "L\[Dagger]", "BL"^4*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"}, 
  D*FL*\[Psi]^5*OverBar[\[Psi]] -> {"D"*"dc"*"ec\[Dagger]"*"GL"*"Q"^4, 
    "D"*"GL"*"L"*"Q"^4*"Q\[Dagger]", "D"*"dc"*"GL"*"Q"^3*"Q\[Dagger]"*"uc", 
    "D"*"GL"*"L"*"Q"^3*"uc"*"uc\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"GL"*"L"*
     "Q"^3, "D"*"GL"*"L"^2*"L\[Dagger]"*"Q"^3, "D"*"ec"*"ec\[Dagger]"*"GL"*
     "L"*"Q"^3, "D"*"dc"*"GL"*"Q"^2*"uc"^2*"uc\[Dagger]", 
    "D"*"dc"^2*"dc\[Dagger]"*"GL"*"Q"^2*"uc", "D"*"dc"*"GL"*"L"*"L\[Dagger]"*
     "Q"^2*"uc", "D"*"dc"*"ec"*"ec\[Dagger]"*"GL"*"Q"^2*"uc", 
    "D"*"ec"*"GL"*"L"*"Q"^2*"Q\[Dagger]"*"uc", "D"*"dc\[Dagger]"*"ec"*"GL"*
     "L"^2*"Q"^2, "D"*"dc"^2*"GL"*"L\[Dagger]"*"Q"*"uc"^2, 
    "D"*"dc"*"ec"*"GL"*"Q"*"Q\[Dagger]"*"uc"^2, "D"*"ec"*"GL"*"L"*"Q"*"uc"^2*
     "uc\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"ec"*"GL"*"L"*"Q"*"uc", 
    "D"*"ec"*"GL"*"L"^2*"L\[Dagger]"*"Q"*"uc", "D"*"ec"^2*"ec\[Dagger]"*"GL"*
     "L"*"Q"*"uc", "D"*"dc"*"ec"*"GL"*"uc"^3*"uc\[Dagger]", 
    "D"*"dc"^2*"dc\[Dagger]"*"ec"*"GL"*"uc"^2, "D"*"dc"*"ec"*"GL"*"L"*
     "L\[Dagger]"*"uc"^2, "D"*"dc"*"ec"^2*"ec\[Dagger]"*"GL"*"uc"^2, 
    "D"*"ec"^2*"GL"*"L"*"Q\[Dagger]"*"uc"^2, "D"*"dc\[Dagger]"*"ec"^2*"GL"*
     "L"^2*"uc", "D"*"dc"*"ec\[Dagger]"*"Q"^4*"WL", 
    "D"*"L"*"Q"^4*"Q\[Dagger]"*"WL", "D"*"dc"*"Q"^3*"Q\[Dagger]"*"uc"*"WL", 
    "D"*"L"*"Q"^3*"uc"*"uc\[Dagger]"*"WL", "D"*"dc"*"dc\[Dagger]"*"L"*"Q"^3*
     "WL", "D"*"L"^2*"L\[Dagger]"*"Q"^3*"WL", "D"*"ec"*"ec\[Dagger]"*"L"*
     "Q"^3*"WL", "D"*"dc"*"Q"^2*"uc"^2*"uc\[Dagger]"*"WL", 
    "D"*"dc"^2*"dc\[Dagger]"*"Q"^2*"uc"*"WL", "D"*"dc"*"L"*"L\[Dagger]"*"Q"^2*
     "uc"*"WL", "D"*"dc"*"ec"*"ec\[Dagger]"*"Q"^2*"uc"*"WL", 
    "D"*"ec"*"L"*"Q"^2*"Q\[Dagger]"*"uc"*"WL", "D"*"dc\[Dagger]"*"ec"*"L"^2*
     "Q"^2*"WL", "D"*"dc"^2*"L\[Dagger]"*"Q"*"uc"^2*"WL", 
    "D"*"dc"*"ec"*"Q"*"Q\[Dagger]"*"uc"^2*"WL", "D"*"ec"*"L"*"Q"*"uc"^2*
     "uc\[Dagger]"*"WL", "D"*"dc"*"dc\[Dagger]"*"ec"*"L"*"Q"*"uc"*"WL", 
    "D"*"ec"*"L"^2*"L\[Dagger]"*"Q"*"uc"*"WL", "D"*"ec"^2*"ec\[Dagger]"*"L"*
     "Q"*"uc"*"WL", "D"*"dc"*"ec"*"L"*"L\[Dagger]"*"uc"^2*"WL", 
    "D"*"ec"^2*"L"*"Q\[Dagger]"*"uc"^2*"WL", "D"*"dc\[Dagger]"*"ec"^2*"L"^2*
     "uc"*"WL", "BL"*"D"*"dc"*"ec\[Dagger]"*"Q"^4, 
    "BL"*"D"*"L"*"Q"^4*"Q\[Dagger]", "BL"*"D"*"dc"*"Q"^3*"Q\[Dagger]"*"uc", 
    "BL"*"D"*"L"*"Q"^3*"uc"*"uc\[Dagger]", "BL"*"D"*"dc"*"dc\[Dagger]"*"L"*
     "Q"^3, "BL"*"D"*"L"^2*"L\[Dagger]"*"Q"^3, "BL"*"D"*"ec"*"ec\[Dagger]"*
     "L"*"Q"^3, "BL"*"D"*"dc"*"Q"^2*"uc"^2*"uc\[Dagger]", 
    "BL"*"D"*"dc"^2*"dc\[Dagger]"*"Q"^2*"uc", "BL"*"D"*"dc"*"L"*"L\[Dagger]"*
     "Q"^2*"uc", "BL"*"D"*"dc"*"ec"*"ec\[Dagger]"*"Q"^2*"uc", 
    "BL"*"D"*"ec"*"L"*"Q"^2*"Q\[Dagger]"*"uc", "BL"*"D"*"dc\[Dagger]"*"ec"*
     "L"^2*"Q"^2, "BL"*"D"*"dc"^2*"L\[Dagger]"*"Q"*"uc"^2, 
    "BL"*"D"*"dc"*"ec"*"Q"*"Q\[Dagger]"*"uc"^2, "BL"*"D"*"ec"*"L"*"Q"*"uc"^2*
     "uc\[Dagger]", "BL"*"D"*"dc"*"dc\[Dagger]"*"ec"*"L"*"Q"*"uc", 
    "BL"*"D"*"ec"*"L"^2*"L\[Dagger]"*"Q"*"uc", "BL"*"D"*"ec"^2*"ec\[Dagger]"*
     "L"*"Q"*"uc", "BL"*"D"*"dc"*"ec"*"uc"^3*"uc\[Dagger]", 
    "BL"*"D"*"dc"^2*"dc\[Dagger]"*"ec"*"uc"^2, "BL"*"D"*"dc"*"ec"*"L"*
     "L\[Dagger]"*"uc"^2, "BL"*"D"*"dc"*"ec"^2*"ec\[Dagger]"*"uc"^2, 
    "BL"*"D"*"ec"^2*"L"*"Q\[Dagger]"*"uc"^2, "BL"*"D"*"dc\[Dagger]"*"ec"^2*
     "L"^2*"uc"}, D*FL^2*\[Phi]*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"*"ec\[Dagger]"*"GL"^2*"H"*"Q"^3, "D"*"GL"^2*"H"*"Q"^2*"Q\[Dagger]"*
     "uc", "D"*"dc"*"GL"^2*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"*"GL"^2*"H"*"L"*"Q"^2, "D"*"GL"^2*"H\[Dagger]"*"L"*"Q"^2*
     "uc\[Dagger]", "D"*"GL"^2*"H"*"Q"*"uc"^2*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"^2*"H"*"Q"*"uc", "D"*"dc"*"GL"^2*"H\[Dagger]"*
     "Q"*"uc"*"uc\[Dagger]", "D"*"GL"^2*"H"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "D"*"ec"*"ec\[Dagger]"*"GL"^2*"H"*"Q"*"uc", "D"*"dc"^2*"dc\[Dagger]"*
     "GL"^2*"H\[Dagger]"*"Q", "D"*"dc"*"GL"^2*"H\[Dagger]"*"L"*"L\[Dagger]"*
     "Q", "D"*"dc"*"ec"*"ec\[Dagger]"*"GL"^2*"H\[Dagger]"*"Q", 
    "D"*"ec"*"GL"^2*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "D"*"dc"*"GL"^2*"H"*"L\[Dagger]"*"uc"^2, "D"*"ec"*"GL"^2*"H"*"Q\[Dagger]"*
     "uc"^2, "D"*"dc"^2*"GL"^2*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "D"*"dc"*"ec"*"GL"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "D"*"dc\[Dagger]"*"ec"*"GL"^2*"H"*"L"*"uc", "D"*"ec"*"GL"^2*"H\[Dagger]"*
     "L"*"uc"*"uc\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"ec"*"GL"^2*"H\[Dagger]"*
     "L", "D"*"ec"*"GL"^2*"H\[Dagger]"*"L"^2*"L\[Dagger]", 
    "D"*"ec"^2*"ec\[Dagger]"*"GL"^2*"H\[Dagger]"*"L", 
    "D"*"ec\[Dagger]"*"GL"*"H"*"Q"^3*"WL", "D"*"GL"*"H"*"Q"^2*"Q\[Dagger]"*
     "uc"*"WL", "D"*"dc"*"GL"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"GL"*"H"*"L"*"Q"^2*"WL", "D"*"GL"*"H\[Dagger]"*"L"*
     "Q"^2*"uc\[Dagger]"*"WL", "D"*"GL"*"H"*"Q"*"uc"^2*"uc\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"H"*"Q"*"uc"*"WL", 
    "D"*"dc"*"GL"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"GL"*"H"*"L"*"L\[Dagger]"*"Q"*"uc"*"WL", "D"*"ec"*"ec\[Dagger]"*"GL"*
     "H"*"Q"*"uc"*"WL", "D"*"dc"^2*"dc\[Dagger]"*"GL"*"H\[Dagger]"*"Q"*"WL", 
    "D"*"dc"*"GL"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"WL", 
    "D"*"dc"*"ec"*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"Q"*"WL", 
    "D"*"ec"*"GL"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"dc"*"GL"*"H"*"L\[Dagger]"*"uc"^2*"WL", "D"*"ec"*"GL"*"H"*
     "Q\[Dagger]"*"uc"^2*"WL", "D"*"dc"^2*"GL"*"H\[Dagger]"*"L\[Dagger]"*"uc"*
     "WL", "D"*"dc"*"ec"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "D"*"dc\[Dagger]"*"ec"*"GL"*"H"*"L"*"uc"*"WL", 
    "D"*"ec"*"GL"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"GL"*"H\[Dagger]"*"L"*"WL", 
    "BL"*"D"*"ec\[Dagger]"*"GL"*"H"*"Q"^3, "BL"*"D"*"GL"*"H"*"Q"^2*
     "Q\[Dagger]"*"uc", "BL"*"D"*"dc"*"GL"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"*"GL"*"H"*"L"*"Q"^2, "BL"*"D"*"GL"*"H\[Dagger]"*"L"*
     "Q"^2*"uc\[Dagger]", "BL"*"D"*"GL"*"H"*"Q"*"uc"^2*"uc\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"GL"*"H"*"Q"*"uc", 
    "BL"*"D"*"dc"*"GL"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"GL"*"H"*"L"*"L\[Dagger]"*"Q"*"uc", "BL"*"D"*"ec"*"ec\[Dagger]"*
     "GL"*"H"*"Q"*"uc", "BL"*"D"*"dc"^2*"dc\[Dagger]"*"GL"*"H\[Dagger]"*"Q", 
    "BL"*"D"*"dc"*"GL"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "BL"*"D"*"dc"*"ec"*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"Q", 
    "BL"*"D"*"ec"*"GL"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"dc"*"GL"*"H"*"L\[Dagger]"*"uc"^2, "BL"*"D"*"ec"*"GL"*"H"*
     "Q\[Dagger]"*"uc"^2, "BL"*"D"*"dc"^2*"GL"*"H\[Dagger]"*"L\[Dagger]"*
     "uc", "BL"*"D"*"dc"*"ec"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "BL"*"D"*"dc\[Dagger]"*"ec"*"GL"*"H"*"L"*"uc", 
    "BL"*"D"*"ec"*"GL"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"ec"*"GL"*"H\[Dagger]"*"L", 
    "D"*"ec\[Dagger]"*"H"*"Q"^3*"WL"^2, "D"*"H"*"Q"^2*"Q\[Dagger]"*"uc"*
     "WL"^2, "D"*"dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"WL"^2, 
    "D"*"dc\[Dagger]"*"H"*"L"*"Q"^2*"WL"^2, "D"*"H\[Dagger]"*"L"*"Q"^2*
     "uc\[Dagger]"*"WL"^2, "D"*"H"*"Q"*"uc"^2*"uc\[Dagger]"*"WL"^2, 
    "D"*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc"*"WL"^2, "D"*"dc"*"H\[Dagger]"*"Q"*
     "uc"*"uc\[Dagger]"*"WL"^2, "D"*"H"*"L"*"L\[Dagger]"*"Q"*"uc"*"WL"^2, 
    "D"*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc"*"WL"^2, "D"*"dc"^2*"dc\[Dagger]"*
     "H\[Dagger]"*"Q"*"WL"^2, "D"*"dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*
     "WL"^2, "D"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"*"WL"^2, 
    "D"*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "D"*"dc"*"H"*"L\[Dagger]"*"uc"^2*"WL"^2, "D"*"ec"*"H"*"Q\[Dagger]"*"uc"^2*
     "WL"^2, "D"*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WL"^2, 
    "D"*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"WL"^2, 
    "D"*"dc\[Dagger]"*"ec"*"H"*"L"*"uc"*"WL"^2, "D"*"ec"*"H\[Dagger]"*"L"*
     "uc"*"uc\[Dagger]"*"WL"^2, "D"*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"*
     "WL"^2, "D"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"WL"^2, 
    "D"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"WL"^2, 
    "BL"*"D"*"ec\[Dagger]"*"H"*"Q"^3*"WL", "BL"*"D"*"H"*"Q"^2*"Q\[Dagger]"*
     "uc"*"WL", "BL"*"D"*"dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"WL", 
    "BL"*"D"*"dc\[Dagger]"*"H"*"L"*"Q"^2*"WL", "BL"*"D"*"H\[Dagger]"*"L"*
     "Q"^2*"uc\[Dagger]"*"WL", "BL"*"D"*"H"*"Q"*"uc"^2*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc"*"WL", 
    "BL"*"D"*"dc"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"H"*"L"*"L\[Dagger]"*"Q"*"uc"*"WL", "BL"*"D"*"ec"*"ec\[Dagger]"*
     "H"*"Q"*"uc"*"WL", "BL"*"D"*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q"*"WL", 
    "BL"*"D"*"dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"WL", 
    "BL"*"D"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"*"WL", 
    "BL"*"D"*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"D"*"dc"*"H"*"L\[Dagger]"*"uc"^2*"WL", "BL"*"D"*"ec"*"H"*
     "Q\[Dagger]"*"uc"^2*"WL", "BL"*"D"*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"*
     "WL", "BL"*"D"*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "BL"*"D"*"dc\[Dagger]"*"ec"*"H"*"L"*"uc"*"WL", 
    "BL"*"D"*"ec"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"*"WL", 
    "BL"*"D"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"WL", 
    "BL"*"D"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"WL", 
    "BL"^2*"D"*"ec\[Dagger]"*"H"*"Q"^3, "BL"^2*"D"*"H"*"Q"^2*"Q\[Dagger]"*
     "uc", "BL"^2*"D"*"dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "BL"^2*"D"*"dc\[Dagger]"*"H"*"L"*"Q"^2, "BL"^2*"D"*"H\[Dagger]"*"L"*"Q"^2*
     "uc\[Dagger]", "BL"^2*"D"*"H"*"Q"*"uc"^2*"uc\[Dagger]", 
    "BL"^2*"D"*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc", "BL"^2*"D"*"dc"*"H\[Dagger]"*
     "Q"*"uc"*"uc\[Dagger]", "BL"^2*"D"*"H"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "BL"^2*"D"*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc", "BL"^2*"D"*"dc"^2*
     "dc\[Dagger]"*"H\[Dagger]"*"Q", "BL"^2*"D"*"dc"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q", "BL"^2*"D"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q", 
    "BL"^2*"D"*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "BL"^2*"D"*"dc"*"H"*"L\[Dagger]"*"uc"^2, "BL"^2*"D"*"ec"*"H"*"Q\[Dagger]"*
     "uc"^2, "BL"^2*"D"*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "BL"^2*"D"*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "BL"^2*"D"*"dc\[Dagger]"*"ec"*"H"*"L"*"uc", "BL"^2*"D"*"ec"*"H\[Dagger]"*
     "L"*"uc"*"uc\[Dagger]", "BL"^2*"D"*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*
     "L", "BL"^2*"D"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]", 
    "BL"^2*"D"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"}, 
  D*FL^3*\[Phi]^2*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"GL"^3*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", "D"*"dc\[Dagger]"*"GL"^3*
     "H"^2*"uc", "D"*"GL"^3*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"^3*"H"*"H\[Dagger]", 
    "D"*"dc"*"GL"^3*"H\[Dagger]"^2*"uc\[Dagger]", "D"*"GL"^3*"H"*"H\[Dagger]"*
     "L"*"L\[Dagger]", "D"*"ec"*"ec\[Dagger]"*"GL"^3*"H"*"H\[Dagger]", 
    "D"*"GL"^2*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"GL"^2*"H"^2*"uc"*"WL", "D"*"GL"^2*"H"*"H\[Dagger]"*
     "uc"*"uc\[Dagger]"*"WL", "D"*"dc"*"dc\[Dagger]"*"GL"^2*"H"*"H\[Dagger]"*
     "WL", "D"*"dc"*"GL"^2*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "D"*"GL"^2*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "D"*"ec"*"ec\[Dagger]"*"GL"^2*"H"*"H\[Dagger]"*"WL", 
    "BL"*"D"*"GL"^2*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"*"GL"^2*"H"^2*"uc", "BL"*"D"*"GL"^2*"H"*
     "H\[Dagger]"*"uc"*"uc\[Dagger]", "BL"*"D"*"dc"*"dc\[Dagger]"*"GL"^2*"H"*
     "H\[Dagger]", "BL"*"D"*"dc"*"GL"^2*"H\[Dagger]"^2*"uc\[Dagger]", 
    "BL"*"D"*"GL"^2*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"GL"^2*"H"*"H\[Dagger]", 
    "D"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "D"*"dc\[Dagger]"*"GL"*"H"^2*"uc"*"WL"^2, "D"*"GL"*"H"*"H\[Dagger]"*"uc"*
     "uc\[Dagger]"*"WL"^2, "D"*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*
     "WL"^2, "D"*"dc"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL"^2, 
    "BL"*"D"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"D"*"dc\[Dagger]"*"GL"*"H"^2*"uc"*"WL", 
    "BL"*"D"*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"WL", 
    "BL"*"D"*"dc"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "BL"^2*"D"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"^2*"D"*"dc\[Dagger]"*"GL"*"H"^2*"uc", "BL"^2*"D"*"GL"*"H"*
     "H\[Dagger]"*"uc"*"uc\[Dagger]", "BL"^2*"D"*"dc"*"dc\[Dagger]"*"GL"*"H"*
     "H\[Dagger]", "BL"^2*"D"*"dc"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "D"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^3, "D"*"dc\[Dagger]"*"H"^2*
     "uc"*"WL"^3, "D"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^3, 
    "D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"WL"^3, 
    "D"*"dc"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL"^3, "D"*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"WL"^3, "D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL"^3, 
    "BL"*"D"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "BL"*"D"*"dc\[Dagger]"*"H"^2*"uc"*"WL"^2, "BL"*"D"*"H"*"H\[Dagger]"*"uc"*
     "uc\[Dagger]"*"WL"^2, "BL"*"D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*
     "WL"^2, "BL"*"D"*"dc"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL"^2, 
    "BL"*"D"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL"^2, 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL"^2, 
    "BL"^2*"D"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"^2*"D"*"dc\[Dagger]"*"H"^2*"uc"*"WL", "BL"^2*"D"*"H"*"H\[Dagger]"*
     "uc"*"uc\[Dagger]"*"WL", "BL"^2*"D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*
     "WL", "BL"^2*"D"*"dc"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "BL"^2*"D"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "BL"^2*"D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL", 
    "BL"^3*"D"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", "BL"^3*"D"*"dc\[Dagger]"*
     "H"^2*"uc", "BL"^3*"D"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^3*"D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]", 
    "BL"^3*"D"*"dc"*"H\[Dagger]"^2*"uc\[Dagger]", "BL"^3*"D"*"H"*"H\[Dagger]"*
     "L"*"L\[Dagger]", "BL"^3*"D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"}, 
  D^2*\[Phi]*\[Psi]^6 -> {"D"^2*"H"*"L"*"Q"^4*"uc", 
    "D"^2*"dc"*"H\[Dagger]"*"L"*"Q"^4, "D"^2*"dc"*"H"*"Q"^3*"uc"^2, 
    "D"^2*"dc"^2*"H\[Dagger]"*"Q"^3*"uc", "D"^2*"ec"*"H\[Dagger]"*"L"^2*
     "Q"^3, "D"^2*"ec"*"H"*"L"*"Q"^2*"uc"^2, "D"^2*"dc"*"ec"*"H\[Dagger]"*"L"*
     "Q"^2*"uc", "D"^2*"dc"*"ec"*"H"*"Q"*"uc"^3, 
    "D"^2*"dc"^2*"ec"*"H\[Dagger]"*"Q"*"uc"^2, "D"^2*"ec"^2*"H\[Dagger]"*
     "L"^2*"Q"*"uc", "D"^2*"ec"^2*"H"*"L"*"uc"^3, 
    "D"^2*"dc"*"ec"^2*"H\[Dagger]"*"L"*"uc"^2, "D"^2*"dc"^3*"H"*"L"^3}, 
  D^2*FL*\[Phi]^2*\[Psi]^4 -> {"D"^2*"GL"*"H"*"H\[Dagger]"*"L"*"Q"^3, 
    "D"^2*"GL"*"H"^2*"Q"^2*"uc"^2, "D"^2*"dc"*"GL"*"H"*"H\[Dagger]"*"Q"^2*
     "uc", "D"^2*"dc"^2*"GL"*"H\[Dagger]"^2*"Q"^2, 
    "D"^2*"ec"*"GL"*"H"*"H\[Dagger]"*"L"*"Q"*"uc", 
    "D"^2*"dc"*"ec"*"GL"*"H\[Dagger]"^2*"L"*"Q", "D"^2*"ec"*"GL"*"H"^2*
     "uc"^3, "D"^2*"dc"*"ec"*"GL"*"H"*"H\[Dagger]"*"uc"^2, 
    "D"^2*"dc"^2*"ec"*"GL"*"H\[Dagger]"^2*"uc", "D"^2*"H"*"H\[Dagger]"*"L"*
     "Q"^3*"WL", "D"^2*"H"^2*"Q"^2*"uc"^2*"WL", "D"^2*"dc"*"H"*"H\[Dagger]"*
     "Q"^2*"uc"*"WL", "D"^2*"dc"^2*"H\[Dagger]"^2*"Q"^2*"WL", 
    "D"^2*"ec"*"H"*"H\[Dagger]"*"L"*"Q"*"uc"*"WL", 
    "D"^2*"dc"*"ec"*"H\[Dagger]"^2*"L"*"Q"*"WL", "D"^2*"ec"*"H"^2*"uc"^3*
     "WL", "D"^2*"dc"*"ec"*"H"*"H\[Dagger]"*"uc"^2*"WL", 
    "D"^2*"dc"^2*"ec"*"H\[Dagger]"^2*"uc"*"WL", "D"^2*"ec"^2*"H\[Dagger]"^2*
     "L"^2*"WL", "BL"*"D"^2*"H"*"H\[Dagger]"*"L"*"Q"^3, 
    "BL"*"D"^2*"H"^2*"Q"^2*"uc"^2, "BL"*"D"^2*"dc"*"H"*"H\[Dagger]"*"Q"^2*
     "uc", "BL"*"D"^2*"dc"^2*"H\[Dagger]"^2*"Q"^2, 
    "BL"*"D"^2*"ec"*"H"*"H\[Dagger]"*"L"*"Q"*"uc", 
    "BL"*"D"^2*"dc"*"ec"*"H\[Dagger]"^2*"L"*"Q", "BL"*"D"^2*"ec"*"H"^2*
     "uc"^3, "BL"*"D"^2*"dc"*"ec"*"H"*"H\[Dagger]"*"uc"^2, 
    "BL"*"D"^2*"dc"^2*"ec"*"H\[Dagger]"^2*"uc", "BL"*"D"^2*"ec"^2*
     "H\[Dagger]"^2*"L"^2}, D^2*FL^2*\[Phi]^3*\[Psi]^2 -> 
   {"D"^2*"GL"^2*"H"^2*"H\[Dagger]"*"Q"*"uc", "D"^2*"dc"*"GL"^2*"H"*
     "H\[Dagger]"^2*"Q", "D"^2*"ec"*"GL"^2*"H"*"H\[Dagger]"^2*"L", 
    "D"^2*"GL"*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WL", "D"^2*"dc"*"GL"*"H"*
     "H\[Dagger]"^2*"Q"*"WL", "BL"*"D"^2*"GL"*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "BL"*"D"^2*"dc"*"GL"*"H"*"H\[Dagger]"^2*"Q", "D"^2*"H"^2*"H\[Dagger]"*"Q"*
     "uc"*"WL"^2, "D"^2*"dc"*"H"*"H\[Dagger]"^2*"Q"*"WL"^2, 
    "D"^2*"ec"*"H"*"H\[Dagger]"^2*"L"*"WL"^2, "BL"*"D"^2*"H"^2*"H\[Dagger]"*
     "Q"*"uc"*"WL", "BL"*"D"^2*"dc"*"H"*"H\[Dagger]"^2*"Q"*"WL", 
    "BL"*"D"^2*"ec"*"H"*"H\[Dagger]"^2*"L"*"WL", 
    "BL"^2*"D"^2*"H"^2*"H\[Dagger]"*"Q"*"uc", "BL"^2*"D"^2*"dc"*"H"*
     "H\[Dagger]"^2*"Q", "BL"^2*"D"^2*"ec"*"H"*"H\[Dagger]"^2*"L"}, 
  D^2*FL^3*\[Phi]^4 -> {"D"^2*"GL"^3*"H"^2*"H\[Dagger]"^2, 
    "D"^2*"GL"^2*"H"^2*"H\[Dagger]"^2*"WL", "BL"*"D"^2*"GL"^2*"H"^2*
     "H\[Dagger]"^2, "D"^2*"H"^2*"H\[Dagger]"^2*"WL"^3, 
    "BL"*"D"^2*"H"^2*"H\[Dagger]"^2*"WL"^2, "BL"^2*"D"^2*"H"^2*"H\[Dagger]"^2*
     "WL", "BL"^3*"D"^2*"H"^2*"H\[Dagger]"^2}, 
  FL*FR^2*\[Psi]^4 -> {"GL"*"GR"^2*"L"*"Q"^3, "GL"*"GR"*"L"*"Q"^3*"WR", 
    "BR"*"GL"*"GR"*"L"*"Q"^3, "GL"*"L"*"Q"^3*"WR"^2, 
    "BR"*"GL"*"L"*"Q"^3*"WR", "BR"^2*"GL"*"L"*"Q"^3, 
    "dc"*"GL"*"GR"^2*"Q"^2*"uc", "dc"*"GL"*"GR"*"Q"^2*"uc"*"WR", 
    "BR"*"dc"*"GL"*"GR"*"Q"^2*"uc", "dc"*"GL"*"Q"^2*"uc"*"WR"^2, 
    "BR"*"dc"*"GL"*"Q"^2*"uc"*"WR", "BR"^2*"dc"*"GL"*"Q"^2*"uc", 
    "ec"*"GL"*"GR"^2*"L"*"Q"*"uc", "ec"*"GL"*"GR"*"L"*"Q"*"uc"*"WR", 
    "BR"*"ec"*"GL"*"GR"*"L"*"Q"*"uc", "ec"*"GL"*"L"*"Q"*"uc"*"WR"^2, 
    "BR"*"ec"*"GL"*"L"*"Q"*"uc"*"WR", "BR"^2*"ec"*"GL"*"L"*"Q"*"uc", 
    "dc"*"ec"*"GL"*"GR"^2*"uc"^2, "BR"*"dc"*"ec"*"GL"*"GR"*"uc"^2, 
    "dc"*"ec"*"GL"*"uc"^2*"WR"^2, "BR"^2*"dc"*"ec"*"GL"*"uc"^2, 
    "GR"^2*"L"*"Q"^3*"WL", "GR"*"L"*"Q"^3*"WL"*"WR", 
    "BR"*"GR"*"L"*"Q"^3*"WL", "L"*"Q"^3*"WL"*"WR"^2, 
    "BR"*"L"*"Q"^3*"WL"*"WR", "BR"^2*"L"*"Q"^3*"WL", 
    "dc"*"GR"^2*"Q"^2*"uc"*"WL", "dc"*"GR"*"Q"^2*"uc"*"WL"*"WR", 
    "BR"*"dc"*"GR"*"Q"^2*"uc"*"WL", "dc"*"Q"^2*"uc"*"WL"*"WR"^2, 
    "BR"*"dc"*"Q"^2*"uc"*"WL"*"WR", "BR"^2*"dc"*"Q"^2*"uc"*"WL", 
    "ec"*"GR"^2*"L"*"Q"*"uc"*"WL", "ec"*"GR"*"L"*"Q"*"uc"*"WL"*"WR", 
    "BR"*"ec"*"GR"*"L"*"Q"*"uc"*"WL", "ec"*"L"*"Q"*"uc"*"WL"*"WR"^2, 
    "BR"*"ec"*"L"*"Q"*"uc"*"WL"*"WR", "BR"^2*"ec"*"L"*"Q"*"uc"*"WL", 
    "dc"*"ec"*"GR"*"uc"^2*"WL"*"WR", "dc"*"ec"*"uc"^2*"WL"*"WR"^2, 
    "BR"*"dc"*"ec"*"uc"^2*"WL"*"WR", "BL"*"GR"^2*"L"*"Q"^3, 
    "BL"*"GR"*"L"*"Q"^3*"WR", "BL"*"BR"*"GR"*"L"*"Q"^3, 
    "BL"*"L"*"Q"^3*"WR"^2, "BL"*"BR"*"L"*"Q"^3*"WR", "BL"*"BR"^2*"L"*"Q"^3, 
    "BL"*"dc"*"GR"^2*"Q"^2*"uc", "BL"*"dc"*"GR"*"Q"^2*"uc"*"WR", 
    "BL"*"BR"*"dc"*"GR"*"Q"^2*"uc", "BL"*"dc"*"Q"^2*"uc"*"WR"^2, 
    "BL"*"BR"*"dc"*"Q"^2*"uc"*"WR", "BL"*"BR"^2*"dc"*"Q"^2*"uc", 
    "BL"*"ec"*"GR"^2*"L"*"Q"*"uc", "BL"*"ec"*"GR"*"L"*"Q"*"uc"*"WR", 
    "BL"*"BR"*"ec"*"GR"*"L"*"Q"*"uc", "BL"*"ec"*"L"*"Q"*"uc"*"WR"^2, 
    "BL"*"BR"*"ec"*"L"*"Q"*"uc"*"WR", "BL"*"BR"^2*"ec"*"L"*"Q"*"uc", 
    "BL"*"dc"*"ec"*"GR"^2*"uc"^2, "BL"*"BR"*"dc"*"ec"*"GR"*"uc"^2, 
    "BL"*"dc"*"ec"*"uc"^2*"WR"^2, "BL"*"BR"^2*"dc"*"ec"*"uc"^2}, 
  FL^2*FR*\[Psi]^2*OverBar[\[Psi]]^2 -> {"GL"^2*"GR"*"Q"^2*"Q\[Dagger]"^2, 
    "GL"^2*"Q"^2*"Q\[Dagger]"^2*"WR", "BR"*"GL"^2*"Q"^2*"Q\[Dagger]"^2, 
    "ec\[Dagger]"*"GL"^2*"GR"*"Q"^2*"uc\[Dagger]", 
    "ec\[Dagger]"*"GL"^2*"Q"^2*"uc\[Dagger]"*"WR", 
    "BR"*"ec\[Dagger]"*"GL"^2*"Q"^2*"uc\[Dagger]", 
    "GL"^2*"GR"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "GL"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"GL"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"GL"^2*"GR"*"Q"*"Q\[Dagger]", 
    "dc"*"dc\[Dagger]"*"GL"^2*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"GL"^2*"Q"*"Q\[Dagger]", 
    "dc"*"ec\[Dagger]"*"GL"^2*"GR"*"L\[Dagger]"*"Q", 
    "dc"*"ec\[Dagger]"*"GL"^2*"L\[Dagger]"*"Q"*"WR", 
    "BR"*"dc"*"ec\[Dagger]"*"GL"^2*"L\[Dagger]"*"Q", 
    "GL"^2*"GR"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "GL"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"GL"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "dc\[Dagger]"*"GL"^2*"GR"*"L"*"Q"*"uc\[Dagger]", 
    "dc\[Dagger]"*"GL"^2*"L"*"Q"*"uc\[Dagger]"*"WR", 
    "BR"*"dc\[Dagger]"*"GL"^2*"L"*"Q"*"uc\[Dagger]", 
    "ec"*"ec\[Dagger]"*"GL"^2*"GR"*"Q"*"Q\[Dagger]", 
    "ec"*"ec\[Dagger]"*"GL"^2*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"ec"*"ec\[Dagger]"*"GL"^2*"Q"*"Q\[Dagger]", 
    "GL"^2*"GR"*"uc"^2*"uc\[Dagger]"^2, "BR"*"GL"^2*"uc"^2*"uc\[Dagger]"^2, 
    "dc"*"GL"^2*"GR"*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "dc"*"GL"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"dc"*"GL"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "dc"*"dc\[Dagger]"*"GL"^2*"GR"*"uc"*"uc\[Dagger]", 
    "BR"*"dc"*"dc\[Dagger]"*"GL"^2*"uc"*"uc\[Dagger]", 
    "GL"^2*"GR"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "GL"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"GL"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "ec"*"GL"^2*"GR"*"Q\[Dagger]"^2*"uc", "ec"*"GL"^2*"Q\[Dagger]"^2*"uc"*
     "WR", "BR"*"ec"*"GL"^2*"Q\[Dagger]"^2*"uc", "ec"*"ec\[Dagger]"*"GL"^2*
     "GR"*"uc"*"uc\[Dagger]", "BR"*"ec"*"ec\[Dagger]"*"GL"^2*"uc"*
     "uc\[Dagger]", "dc"^2*"dc\[Dagger]"^2*"GL"^2*"GR", 
    "BR"*"dc"^2*"dc\[Dagger]"^2*"GL"^2, "dc"*"dc\[Dagger]"*"GL"^2*"GR"*"L"*
     "L\[Dagger]", "dc"*"dc\[Dagger]"*"GL"^2*"L"*"L\[Dagger]"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"GL"^2*"L"*"L\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"^2*"GR", 
    "BR"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"^2, 
    "GL"^2*"GR"*"L"^2*"L\[Dagger]"^2, "GL"^2*"L"^2*"L\[Dagger]"^2*"WR", 
    "BR"*"GL"^2*"L"^2*"L\[Dagger]"^2, "dc\[Dagger]"*"ec"*"GL"^2*"GR"*"L"*
     "Q\[Dagger]", "dc\[Dagger]"*"ec"*"GL"^2*"L"*"Q\[Dagger]"*"WR", 
    "BR"*"dc\[Dagger]"*"ec"*"GL"^2*"L"*"Q\[Dagger]", 
    "ec"*"ec\[Dagger]"*"GL"^2*"GR"*"L"*"L\[Dagger]", 
    "ec"*"ec\[Dagger]"*"GL"^2*"L"*"L\[Dagger]"*"WR", 
    "BR"*"ec"*"ec\[Dagger]"*"GL"^2*"L"*"L\[Dagger]", 
    "ec"^2*"ec\[Dagger]"^2*"GL"^2*"GR", "BR"*"ec"^2*"ec\[Dagger]"^2*"GL"^2, 
    "GL"*"GR"*"Q"^2*"Q\[Dagger]"^2*"WL", "GL"*"Q"^2*"Q\[Dagger]"^2*"WL"*"WR", 
    "BR"*"GL"*"Q"^2*"Q\[Dagger]"^2*"WL", "ec\[Dagger]"*"GL"*"GR"*"Q"^2*
     "uc\[Dagger]"*"WL", "ec\[Dagger]"*"GL"*"Q"^2*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"ec\[Dagger]"*"GL"*"Q"^2*"uc\[Dagger]"*"WL", 
    "GL"*"GR"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "GL"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"GL"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"GL"*"GR"*"Q"*"Q\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"GL"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"GL"*"Q"*"Q\[Dagger]"*"WL", 
    "dc"*"ec\[Dagger]"*"GL"*"GR"*"L\[Dagger]"*"Q"*"WL", 
    "dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q"*"WL"*"WR", 
    "BR"*"dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q"*"WL", 
    "GL"*"GR"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BR"*"GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "dc\[Dagger]"*"GL"*"GR"*"L"*"Q"*"uc\[Dagger]"*"WL", 
    "dc\[Dagger]"*"GL"*"L"*"Q"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"dc\[Dagger]"*"GL"*"L"*"Q"*"uc\[Dagger]"*"WL", 
    "ec"*"ec\[Dagger]"*"GL"*"GR"*"Q"*"Q\[Dagger]"*"WL", 
    "ec"*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BR"*"ec"*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]"*"WL", 
    "GL"*"uc"^2*"uc\[Dagger]"^2*"WL"*"WR", "dc"*"GL"*"GR"*"L\[Dagger]"*
     "Q\[Dagger]"*"uc"*"WL", "dc"*"GL"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL"*
     "WR", "BR"*"dc"*"GL"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "dc"*"dc\[Dagger]"*"GL"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "GL"*"GR"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "GL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"GL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "ec"*"GL"*"GR"*"Q\[Dagger]"^2*"uc"*"WL", "ec"*"GL"*"Q\[Dagger]"^2*"uc"*
     "WL"*"WR", "BR"*"ec"*"GL"*"Q\[Dagger]"^2*"uc"*"WL", 
    "ec"*"ec\[Dagger]"*"GL"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "dc"^2*"dc\[Dagger]"^2*"GL"*"WL"*"WR", "dc"*"dc\[Dagger]"*"GL"*"GR"*"L"*
     "L\[Dagger]"*"WL", "dc"*"dc\[Dagger]"*"GL"*"L"*"L\[Dagger]"*"WL"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"GL"*"L"*"L\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"WL"*"WR", 
    "GL"*"GR"*"L"^2*"L\[Dagger]"^2*"WL", "dc\[Dagger]"*"ec"*"GL"*"GR"*"L"*
     "Q\[Dagger]"*"WL", "dc\[Dagger]"*"ec"*"GL"*"L"*"Q\[Dagger]"*"WL"*"WR", 
    "BR"*"dc\[Dagger]"*"ec"*"GL"*"L"*"Q\[Dagger]"*"WL", 
    "ec"*"ec\[Dagger]"*"GL"*"GR"*"L"*"L\[Dagger]"*"WL", 
    "BL"*"GL"*"GR"*"Q"^2*"Q\[Dagger]"^2, "BL"*"GL"*"Q"^2*"Q\[Dagger]"^2*"WR", 
    "BL"*"BR"*"GL"*"Q"^2*"Q\[Dagger]"^2, "BL"*"ec\[Dagger]"*"GL"*"GR"*"Q"^2*
     "uc\[Dagger]", "BL"*"ec\[Dagger]"*"GL"*"Q"^2*"uc\[Dagger]"*"WR", 
    "BL"*"BR"*"ec\[Dagger]"*"GL"*"Q"^2*"uc\[Dagger]", 
    "BL"*"GL"*"GR"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"GL"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BL"*"BR"*"GL"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"GL"*"GR"*"Q"*"Q\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"GL"*"Q"*"Q\[Dagger]"*"WR", 
    "BL"*"BR"*"dc"*"dc\[Dagger]"*"GL"*"Q"*"Q\[Dagger]", 
    "BL"*"dc"*"ec\[Dagger]"*"GL"*"GR"*"L\[Dagger]"*"Q", 
    "BL"*"dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q"*"WR", 
    "BL"*"BR"*"dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q", 
    "BL"*"GL"*"GR"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WR", 
    "BL"*"BR"*"GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"dc\[Dagger]"*"GL"*"GR"*"L"*"Q"*"uc\[Dagger]", 
    "BL"*"dc\[Dagger]"*"GL"*"L"*"Q"*"uc\[Dagger]"*"WR", 
    "BL"*"BR"*"dc\[Dagger]"*"GL"*"L"*"Q"*"uc\[Dagger]", 
    "BL"*"ec"*"ec\[Dagger]"*"GL"*"GR"*"Q"*"Q\[Dagger]", 
    "BL"*"ec"*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]"*"WR", 
    "BL"*"BR"*"ec"*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]", 
    "BL"*"GL"*"GR"*"uc"^2*"uc\[Dagger]"^2, "BL"*"BR"*"GL"*"uc"^2*
     "uc\[Dagger]"^2, "BL"*"dc"*"GL"*"GR"*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "BL"*"dc"*"GL"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WR", 
    "BL"*"BR"*"dc"*"GL"*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "BL"*"dc"*"dc\[Dagger]"*"GL"*"GR"*"uc"*"uc\[Dagger]", 
    "BL"*"BR"*"dc"*"dc\[Dagger]"*"GL"*"uc"*"uc\[Dagger]", 
    "BL"*"GL"*"GR"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"GL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BL"*"BR"*"GL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"ec"*"GL"*"GR"*"Q\[Dagger]"^2*"uc", "BL"*"ec"*"GL"*"Q\[Dagger]"^2*
     "uc"*"WR", "BL"*"BR"*"ec"*"GL"*"Q\[Dagger]"^2*"uc", 
    "BL"*"ec"*"ec\[Dagger]"*"GL"*"GR"*"uc"*"uc\[Dagger]", 
    "BL"*"BR"*"ec"*"ec\[Dagger]"*"GL"*"uc"*"uc\[Dagger]", 
    "BL"*"dc"^2*"dc\[Dagger]"^2*"GL"*"GR", "BL"*"BR"*"dc"^2*"dc\[Dagger]"^2*
     "GL", "BL"*"dc"*"dc\[Dagger]"*"GL"*"GR"*"L"*"L\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"GL"*"L"*"L\[Dagger]"*"WR", 
    "BL"*"BR"*"dc"*"dc\[Dagger]"*"GL"*"L"*"L\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"GR", 
    "BL"*"BR"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL", 
    "BL"*"GL"*"GR"*"L"^2*"L\[Dagger]"^2, "BL"*"dc\[Dagger]"*"ec"*"GL"*"GR"*
     "L"*"Q\[Dagger]", "BL"*"dc\[Dagger]"*"ec"*"GL"*"L"*"Q\[Dagger]"*"WR", 
    "BL"*"BR"*"dc\[Dagger]"*"ec"*"GL"*"L"*"Q\[Dagger]", 
    "BL"*"ec"*"ec\[Dagger]"*"GL"*"GR"*"L"*"L\[Dagger]", 
    "BL"*"ec"^2*"ec\[Dagger]"^2*"GL"*"GR", "GR"*"Q"^2*"Q\[Dagger]"^2*"WL"^2, 
    "Q"^2*"Q\[Dagger]"^2*"WL"^2*"WR", "BR"*"Q"^2*"Q\[Dagger]"^2*"WL"^2, 
    "ec\[Dagger]"*"GR"*"Q"^2*"uc\[Dagger]"*"WL"^2, 
    "ec\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL"^2*"WR", 
    "BR"*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL"^2, 
    "GR"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2*"WR", 
    "BR"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "dc"*"dc\[Dagger]"*"GR"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "dc"*"ec\[Dagger]"*"GR"*"L\[Dagger]"*"Q"*"WL"^2, 
    "dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"WL"^2*"WR", 
    "BR"*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"WL"^2, 
    "GR"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2*"WR", 
    "BR"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "dc\[Dagger]"*"GR"*"L"*"Q"*"uc\[Dagger]"*"WL"^2, 
    "dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*"WL"^2*"WR", 
    "BR"*"dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*"WL"^2, 
    "ec"*"ec\[Dagger]"*"GR"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2*"WR", 
    "BR"*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "GR"*"uc"^2*"uc\[Dagger]"^2*"WL"^2, "uc"^2*"uc\[Dagger]"^2*"WL"^2*"WR", 
    "BR"*"uc"^2*"uc\[Dagger]"^2*"WL"^2, "dc"*"GR"*"L\[Dagger]"*"Q\[Dagger]"*
     "uc"*"WL"^2, "dc"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL"^2*"WR", 
    "BR"*"dc"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL"^2, 
    "dc"*"dc\[Dagger]"*"GR"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "dc"*"dc\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "GR"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2*"WR", 
    "BR"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "ec"*"GR"*"Q\[Dagger]"^2*"uc"*"WL"^2, "ec"*"Q\[Dagger]"^2*"uc"*"WL"^2*
     "WR", "BR"*"ec"*"Q\[Dagger]"^2*"uc"*"WL"^2, "ec"*"ec\[Dagger]"*"GR"*"uc"*
     "uc\[Dagger]"*"WL"^2, "ec"*"ec\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2*"WR", 
    "BR"*"ec"*"ec\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "dc"^2*"dc\[Dagger]"^2*"GR"*"WL"^2, "dc"^2*"dc\[Dagger]"^2*"WL"^2*"WR", 
    "BR"*"dc"^2*"dc\[Dagger]"^2*"WL"^2, "dc"*"dc\[Dagger]"*"GR"*"L"*
     "L\[Dagger]"*"WL"^2, "dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*"WL"^2*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*"WL"^2, 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GR"*"WL"^2, 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"WL"^2*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"WL"^2, 
    "L"^2*"L\[Dagger]"^2*"WL"^2*"WR", "BR"*"L"^2*"L\[Dagger]"^2*"WL"^2, 
    "dc\[Dagger]"*"ec"*"GR"*"L"*"Q\[Dagger]"*"WL"^2, 
    "dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]"*"WL"^2*"WR", 
    "BR"*"dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]"*"WL"^2, 
    "ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"WL"^2*"WR", 
    "BR"*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"WL"^2, 
    "ec"^2*"ec\[Dagger]"^2*"WL"^2*"WR", "BR"*"ec"^2*"ec\[Dagger]"^2*"WL"^2, 
    "BL"*"GR"*"Q"^2*"Q\[Dagger]"^2*"WL", "BL"*"Q"^2*"Q\[Dagger]"^2*"WL"*"WR", 
    "BL"*"BR"*"Q"^2*"Q\[Dagger]"^2*"WL", "BL"*"ec\[Dagger]"*"GR"*"Q"^2*
     "uc\[Dagger]"*"WL", "BL"*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL", 
    "BL"*"GR"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"dc"*"dc\[Dagger]"*"GR"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"dc"*"ec\[Dagger]"*"GR"*"L\[Dagger]"*"Q"*"WL", 
    "BL"*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"WL"*"WR", 
    "BL"*"BR"*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"WL", 
    "BL"*"GR"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"*"GR"*"L"*"Q"*"uc\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*"WL", 
    "BL"*"ec"*"ec\[Dagger]"*"GR"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"uc"^2*"uc\[Dagger]"^2*"WL"*"WR", "BL"*"dc"*"GR"*"L\[Dagger]"*
     "Q\[Dagger]"*"uc"*"WL", "BL"*"dc"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL"*
     "WR", "BL"*"BR"*"dc"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "BL"*"dc"*"dc\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BL"*"GR"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"ec"*"GR"*"Q\[Dagger]"^2*"uc"*"WL", "BL"*"ec"*"Q\[Dagger]"^2*"uc"*
     "WL"*"WR", "BL"*"BR"*"ec"*"Q\[Dagger]"^2*"uc"*"WL", 
    "BL"*"ec"*"ec\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BL"*"dc"^2*"dc\[Dagger]"^2*"WL"*"WR", "BL"*"dc"*"dc\[Dagger]"*"GR"*"L"*
     "L\[Dagger]"*"WL", "BL"*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "BL"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"WL"*"WR", 
    "BL"*"L"^2*"L\[Dagger]"^2*"WL"*"WR", "BL"*"BR"*"L"^2*"L\[Dagger]"^2*"WL", 
    "BL"*"dc\[Dagger]"*"ec"*"GR"*"L"*"Q\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]"*"WL", 
    "BL"*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "BL"*"ec"^2*"ec\[Dagger]"^2*"WL"*"WR", "BL"^2*"GR"*"Q"^2*"Q\[Dagger]"^2, 
    "BL"^2*"Q"^2*"Q\[Dagger]"^2*"WR", "BL"^2*"BR"*"Q"^2*"Q\[Dagger]"^2, 
    "BL"^2*"ec\[Dagger]"*"GR"*"Q"^2*"uc\[Dagger]", 
    "BL"^2*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WR", 
    "BL"^2*"BR"*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "BL"^2*"GR"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BL"^2*"BR"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"dc"*"dc\[Dagger]"*"GR"*"Q"*"Q\[Dagger]", 
    "BL"^2*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"WR", 
    "BL"^2*"BR"*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"^2*"dc"*"ec\[Dagger]"*"GR"*"L\[Dagger]"*"Q", 
    "BL"^2*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"WR", 
    "BL"^2*"BR"*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q", 
    "BL"^2*"GR"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WR", 
    "BL"^2*"BR"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"^2*"dc\[Dagger]"*"GR"*"L"*"Q"*"uc\[Dagger]", 
    "BL"^2*"dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*"WR", 
    "BL"^2*"BR"*"dc\[Dagger]"*"L"*"Q"*"uc\[Dagger]", 
    "BL"^2*"ec"*"ec\[Dagger]"*"GR"*"Q"*"Q\[Dagger]", 
    "BL"^2*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WR", 
    "BL"^2*"BR"*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"^2*"GR"*"uc"^2*"uc\[Dagger]"^2, "BL"^2*"BR"*"uc"^2*"uc\[Dagger]"^2, 
    "BL"^2*"dc"*"GR"*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "BL"^2*"dc"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WR", 
    "BL"^2*"BR"*"dc"*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "BL"^2*"dc"*"dc\[Dagger]"*"GR"*"uc"*"uc\[Dagger]", 
    "BL"^2*"BR"*"dc"*"dc\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"GR"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BL"^2*"BR"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"ec"*"GR"*"Q\[Dagger]"^2*"uc", "BL"^2*"ec"*"Q\[Dagger]"^2*"uc"*
     "WR", "BL"^2*"BR"*"ec"*"Q\[Dagger]"^2*"uc", "BL"^2*"ec"*"ec\[Dagger]"*
     "GR"*"uc"*"uc\[Dagger]", "BL"^2*"BR"*"ec"*"ec\[Dagger]"*"uc"*
     "uc\[Dagger]", "BL"^2*"dc"^2*"dc\[Dagger]"^2*"GR", 
    "BL"^2*"BR"*"dc"^2*"dc\[Dagger]"^2, "BL"^2*"dc"*"dc\[Dagger]"*"GR"*"L"*
     "L\[Dagger]", "BL"^2*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*"WR", 
    "BL"^2*"BR"*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GR", 
    "BL"^2*"BR"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]", 
    "BL"^2*"L"^2*"L\[Dagger]"^2*"WR", "BL"^2*"BR"*"L"^2*"L\[Dagger]"^2, 
    "BL"^2*"dc\[Dagger]"*"ec"*"GR"*"L"*"Q\[Dagger]", 
    "BL"^2*"dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]"*"WR", 
    "BL"^2*"BR"*"dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]", 
    "BL"^2*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"WR", 
    "BL"^2*"BR"*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"^2*"BR"*"ec"^2*"ec\[Dagger]"^2}, FL^2*FR^2*\[Phi]*\[Psi]^2 -> 
   {"GL"^2*"GR"^2*"H"*"Q"*"uc", "GL"^2*"GR"*"H"*"Q"*"uc"*"WR", 
    "BR"*"GL"^2*"GR"*"H"*"Q"*"uc", "GL"^2*"H"*"Q"*"uc"*"WR"^2, 
    "BR"*"GL"^2*"H"*"Q"*"uc"*"WR", "BR"^2*"GL"^2*"H"*"Q"*"uc", 
    "dc"*"GL"^2*"GR"^2*"H\[Dagger]"*"Q", "dc"*"GL"^2*"GR"*"H\[Dagger]"*"Q"*
     "WR", "BR"*"dc"*"GL"^2*"GR"*"H\[Dagger]"*"Q", 
    "dc"*"GL"^2*"H\[Dagger]"*"Q"*"WR"^2, "BR"*"dc"*"GL"^2*"H\[Dagger]"*"Q"*
     "WR", "BR"^2*"dc"*"GL"^2*"H\[Dagger]"*"Q", "ec"*"GL"^2*"GR"^2*
     "H\[Dagger]"*"L", "ec"*"GL"^2*"GR"*"H\[Dagger]"*"L"*"WR", 
    "BR"*"ec"*"GL"^2*"GR"*"H\[Dagger]"*"L", "ec"*"GL"^2*"H\[Dagger]"*"L"*
     "WR"^2, "BR"*"ec"*"GL"^2*"H\[Dagger]"*"L"*"WR", 
    "BR"^2*"ec"*"GL"^2*"H\[Dagger]"*"L", "GL"*"GR"^2*"H"*"Q"*"uc"*"WL", 
    "GL"*"GR"*"H"*"Q"*"uc"*"WL"*"WR", "BR"*"GL"*"GR"*"H"*"Q"*"uc"*"WL", 
    "GL"*"H"*"Q"*"uc"*"WL"*"WR"^2, "BR"*"GL"*"H"*"Q"*"uc"*"WL"*"WR", 
    "BR"^2*"GL"*"H"*"Q"*"uc"*"WL", "dc"*"GL"*"GR"^2*"H\[Dagger]"*"Q"*"WL", 
    "dc"*"GL"*"GR"*"H\[Dagger]"*"Q"*"WL"*"WR", "BR"*"dc"*"GL"*"GR"*
     "H\[Dagger]"*"Q"*"WL", "dc"*"GL"*"H\[Dagger]"*"Q"*"WL"*"WR"^2, 
    "BR"*"dc"*"GL"*"H\[Dagger]"*"Q"*"WL"*"WR", "BR"^2*"dc"*"GL"*"H\[Dagger]"*
     "Q"*"WL", "ec"*"GL"*"GR"^2*"H\[Dagger]"*"L"*"WL", 
    "ec"*"GL"*"GR"*"H\[Dagger]"*"L"*"WL"*"WR", "BR"*"ec"*"GL"*"GR"*
     "H\[Dagger]"*"L"*"WL", "BL"*"GL"*"GR"^2*"H"*"Q"*"uc", 
    "BL"*"GL"*"GR"*"H"*"Q"*"uc"*"WR", "BL"*"BR"*"GL"*"GR"*"H"*"Q"*"uc", 
    "BL"*"GL"*"H"*"Q"*"uc"*"WR"^2, "BL"*"BR"*"GL"*"H"*"Q"*"uc"*"WR", 
    "BL"*"BR"^2*"GL"*"H"*"Q"*"uc", "BL"*"dc"*"GL"*"GR"^2*"H\[Dagger]"*"Q", 
    "BL"*"dc"*"GL"*"GR"*"H\[Dagger]"*"Q"*"WR", "BL"*"BR"*"dc"*"GL"*"GR"*
     "H\[Dagger]"*"Q", "BL"*"dc"*"GL"*"H\[Dagger]"*"Q"*"WR"^2, 
    "BL"*"BR"*"dc"*"GL"*"H\[Dagger]"*"Q"*"WR", "BL"*"BR"^2*"dc"*"GL"*
     "H\[Dagger]"*"Q", "BL"*"ec"*"GL"*"GR"^2*"H\[Dagger]"*"L", 
    "BL"*"ec"*"GL"*"GR"*"H\[Dagger]"*"L"*"WR", "BL"*"BR"*"ec"*"GL"*"GR"*
     "H\[Dagger]"*"L", "GR"^2*"H"*"Q"*"uc"*"WL"^2, 
    "GR"*"H"*"Q"*"uc"*"WL"^2*"WR", "BR"*"GR"*"H"*"Q"*"uc"*"WL"^2, 
    "H"*"Q"*"uc"*"WL"^2*"WR"^2, "BR"*"H"*"Q"*"uc"*"WL"^2*"WR", 
    "BR"^2*"H"*"Q"*"uc"*"WL"^2, "dc"*"GR"^2*"H\[Dagger]"*"Q"*"WL"^2, 
    "dc"*"GR"*"H\[Dagger]"*"Q"*"WL"^2*"WR", "BR"*"dc"*"GR"*"H\[Dagger]"*"Q"*
     "WL"^2, "dc"*"H\[Dagger]"*"Q"*"WL"^2*"WR"^2, "BR"*"dc"*"H\[Dagger]"*"Q"*
     "WL"^2*"WR", "BR"^2*"dc"*"H\[Dagger]"*"Q"*"WL"^2, 
    "ec"*"GR"^2*"H\[Dagger]"*"L"*"WL"^2, "ec"*"H\[Dagger]"*"L"*"WL"^2*"WR"^2, 
    "BR"*"ec"*"H\[Dagger]"*"L"*"WL"^2*"WR", "BR"^2*"ec"*"H\[Dagger]"*"L"*
     "WL"^2, "BL"*"GR"^2*"H"*"Q"*"uc"*"WL", "BL"*"GR"*"H"*"Q"*"uc"*"WL"*"WR", 
    "BL"*"BR"*"GR"*"H"*"Q"*"uc"*"WL", "BL"*"H"*"Q"*"uc"*"WL"*"WR"^2, 
    "BL"*"BR"*"H"*"Q"*"uc"*"WL"*"WR", "BL"*"BR"^2*"H"*"Q"*"uc"*"WL", 
    "BL"*"dc"*"GR"^2*"H\[Dagger]"*"Q"*"WL", "BL"*"dc"*"GR"*"H\[Dagger]"*"Q"*
     "WL"*"WR", "BL"*"BR"*"dc"*"GR"*"H\[Dagger]"*"Q"*"WL", 
    "BL"*"dc"*"H\[Dagger]"*"Q"*"WL"*"WR"^2, "BL"*"BR"*"dc"*"H\[Dagger]"*"Q"*
     "WL"*"WR", "BL"*"BR"^2*"dc"*"H\[Dagger]"*"Q"*"WL", 
    "BL"*"ec"*"GR"^2*"H\[Dagger]"*"L"*"WL", "BL"*"ec"*"H\[Dagger]"*"L"*"WL"*
     "WR"^2, "BL"*"BR"*"ec"*"H\[Dagger]"*"L"*"WL"*"WR", 
    "BL"*"BR"^2*"ec"*"H\[Dagger]"*"L"*"WL", "BL"^2*"GR"^2*"H"*"Q"*"uc", 
    "BL"^2*"GR"*"H"*"Q"*"uc"*"WR", "BL"^2*"BR"*"GR"*"H"*"Q"*"uc", 
    "BL"^2*"H"*"Q"*"uc"*"WR"^2, "BL"^2*"BR"*"H"*"Q"*"uc"*"WR", 
    "BL"^2*"BR"^2*"H"*"Q"*"uc", "BL"^2*"dc"*"GR"^2*"H\[Dagger]"*"Q", 
    "BL"^2*"dc"*"GR"*"H\[Dagger]"*"Q"*"WR", "BL"^2*"BR"*"dc"*"GR"*
     "H\[Dagger]"*"Q", "BL"^2*"dc"*"H\[Dagger]"*"Q"*"WR"^2, 
    "BL"^2*"BR"*"dc"*"H\[Dagger]"*"Q"*"WR", "BL"^2*"BR"^2*"dc"*"H\[Dagger]"*
     "Q", "BL"^2*"ec"*"GR"^2*"H\[Dagger]"*"L", "BL"^2*"ec"*"H\[Dagger]"*"L"*
     "WR"^2, "BL"^2*"BR"*"ec"*"H\[Dagger]"*"L"*"WR", 
    "BL"^2*"BR"^2*"ec"*"H\[Dagger]"*"L"}, FL^3*OverBar[\[Psi]]^4 -> 
   {"GL"^3*"L\[Dagger]"*"Q\[Dagger]"^3, "dc\[Dagger]"*"GL"^3*"Q\[Dagger]"^2*
     "uc\[Dagger]", "ec\[Dagger]"*"GL"^3*"L\[Dagger]"*"Q\[Dagger]"*
     "uc\[Dagger]", "dc\[Dagger]"*"ec\[Dagger]"*"GL"^3*"uc\[Dagger]"^2, 
    "GL"^2*"L\[Dagger]"*"Q\[Dagger]"^3*"WL", "dc\[Dagger]"*"GL"^2*
     "Q\[Dagger]"^2*"uc\[Dagger]"*"WL", "ec\[Dagger]"*"GL"^2*"L\[Dagger]"*
     "Q\[Dagger]"*"uc\[Dagger]"*"WL", "BL"*"GL"^2*"L\[Dagger]"*
     "Q\[Dagger]"^3, "BL"*"dc\[Dagger]"*"GL"^2*"Q\[Dagger]"^2*"uc\[Dagger]", 
    "BL"*"ec\[Dagger]"*"GL"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "BL"*"dc\[Dagger]"*"ec\[Dagger]"*"GL"^2*"uc\[Dagger]"^2, 
    "GL"*"L\[Dagger]"*"Q\[Dagger]"^3*"WL"^2, "dc\[Dagger]"*"GL"*
     "Q\[Dagger]"^2*"uc\[Dagger]"*"WL"^2, "ec\[Dagger]"*"GL"*"L\[Dagger]"*
     "Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, "dc\[Dagger]"*"ec\[Dagger]"*"GL"*
     "uc\[Dagger]"^2*"WL"^2, "BL"*"GL"*"L\[Dagger]"*"Q\[Dagger]"^3*"WL", 
    "BL"*"dc\[Dagger]"*"GL"*"Q\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "BL"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"^2*"GL"*"L\[Dagger]"*"Q\[Dagger]"^3, "BL"^2*"dc\[Dagger]"*"GL"*
     "Q\[Dagger]"^2*"uc\[Dagger]", "BL"^2*"ec\[Dagger]"*"GL"*"L\[Dagger]"*
     "Q\[Dagger]"*"uc\[Dagger]", "BL"^2*"dc\[Dagger]"*"ec\[Dagger]"*"GL"*
     "uc\[Dagger]"^2, "L\[Dagger]"*"Q\[Dagger]"^3*"WL"^3, 
    "dc\[Dagger]"*"Q\[Dagger]"^2*"uc\[Dagger]"*"WL"^3, 
    "ec\[Dagger]"*"L\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^3, 
    "dc\[Dagger]"*"ec\[Dagger]"*"uc\[Dagger]"^2*"WL"^3, 
    "BL"*"L\[Dagger]"*"Q\[Dagger]"^3*"WL"^2, "BL"*"dc\[Dagger]"*
     "Q\[Dagger]"^2*"uc\[Dagger]"*"WL"^2, "BL"*"ec\[Dagger]"*"L\[Dagger]"*
     "Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, "BL"*"dc\[Dagger]"*"ec\[Dagger]"*
     "uc\[Dagger]"^2*"WL"^2, "BL"^2*"L\[Dagger]"*"Q\[Dagger]"^3*"WL", 
    "BL"^2*"dc\[Dagger]"*"Q\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "BL"^2*"ec\[Dagger]"*"L\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"^3*"L\[Dagger]"*"Q\[Dagger]"^3, "BL"^3*"dc\[Dagger]"*"Q\[Dagger]"^2*
     "uc\[Dagger]", "BL"^3*"ec\[Dagger]"*"L\[Dagger]"*"Q\[Dagger]"*
     "uc\[Dagger]", "BL"^3*"dc\[Dagger]"*"ec\[Dagger]"*"uc\[Dagger]"^2}, 
  FL^3*FR*\[Phi]*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"*"GL"^3*"GR"*"H"*"Q\[Dagger]", "dc\[Dagger]"*"GL"^3*"H"*
     "Q\[Dagger]"*"WR", "BR"*"dc\[Dagger]"*"GL"^3*"H"*"Q\[Dagger]", 
    "ec\[Dagger]"*"GL"^3*"GR"*"H"*"L\[Dagger]", "ec\[Dagger]"*"GL"^3*"H"*
     "L\[Dagger]"*"WR", "BR"*"ec\[Dagger]"*"GL"^3*"H"*"L\[Dagger]", 
    "GL"^3*"GR"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "GL"^3*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WR", 
    "BR"*"GL"^3*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"GL"^2*"GR"*"H"*"Q\[Dagger]"*"WL", 
    "dc\[Dagger]"*"GL"^2*"H"*"Q\[Dagger]"*"WL"*"WR", 
    "BR"*"dc\[Dagger]"*"GL"^2*"H"*"Q\[Dagger]"*"WL", 
    "ec\[Dagger]"*"GL"^2*"GR"*"H"*"L\[Dagger]"*"WL", 
    "ec\[Dagger]"*"GL"^2*"H"*"L\[Dagger]"*"WL"*"WR", 
    "BR"*"ec\[Dagger]"*"GL"^2*"H"*"L\[Dagger]"*"WL", 
    "GL"^2*"GR"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "GL"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"GL"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"*"GL"^2*"GR"*"H"*"Q\[Dagger]", 
    "BL"*"dc\[Dagger]"*"GL"^2*"H"*"Q\[Dagger]"*"WR", 
    "BL"*"BR"*"dc\[Dagger]"*"GL"^2*"H"*"Q\[Dagger]", 
    "BL"*"ec\[Dagger]"*"GL"^2*"GR"*"H"*"L\[Dagger]", 
    "BL"*"ec\[Dagger]"*"GL"^2*"H"*"L\[Dagger]"*"WR", 
    "BL"*"BR"*"ec\[Dagger]"*"GL"^2*"H"*"L\[Dagger]", 
    "BL"*"GL"^2*"GR"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "BL"*"GL"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WR", 
    "BL"*"BR"*"GL"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"GL"*"GR"*"H"*"Q\[Dagger]"*"WL"^2, 
    "dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]"*"WL"^2*"WR", 
    "BR"*"dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]"*"WL"^2, 
    "ec\[Dagger]"*"GL"*"GR"*"H"*"L\[Dagger]"*"WL"^2, 
    "GL"*"GR"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, 
    "GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^2*"WR", 
    "BR"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, 
    "BL"*"dc\[Dagger]"*"GL"*"GR"*"H"*"Q\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]"*"WL", 
    "BL"*"ec\[Dagger]"*"GL"*"GR"*"H"*"L\[Dagger]"*"WL", 
    "BL"*"GL"*"GR"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"^2*"dc\[Dagger]"*"GL"*"GR"*"H"*"Q\[Dagger]", 
    "BL"^2*"dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]"*"WR", 
    "BL"^2*"BR"*"dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]", 
    "BL"^2*"ec\[Dagger]"*"GL"*"GR"*"H"*"L\[Dagger]", 
    "BL"^2*"GL"*"GR"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "BL"^2*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WR", 
    "BL"^2*"BR"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"GR"*"H"*"Q\[Dagger]"*"WL"^3, "dc\[Dagger]"*"H"*
     "Q\[Dagger]"*"WL"^3*"WR", "BR"*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL"^3, 
    "ec\[Dagger]"*"H"*"L\[Dagger]"*"WL"^3*"WR", "BR"*"ec\[Dagger]"*"H"*
     "L\[Dagger]"*"WL"^3, "GR"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*
     "WL"^3, "H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^3*"WR", 
    "BR"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^3, 
    "BL"*"dc\[Dagger]"*"GR"*"H"*"Q\[Dagger]"*"WL"^2, 
    "BL"*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL"^2*"WR", 
    "BL"*"BR"*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL"^2, 
    "BL"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"WL"^2*"WR", 
    "BL"*"BR"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"WL"^2, 
    "BL"*"GR"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, 
    "BL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^2*"WR", 
    "BL"*"BR"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, 
    "BL"^2*"dc\[Dagger]"*"GR"*"H"*"Q\[Dagger]"*"WL", 
    "BL"^2*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL"*"WR", 
    "BL"^2*"BR"*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"WL", 
    "BL"^2*"ec\[Dagger]"*"H"*"L\[Dagger]"*"WL"*"WR", 
    "BL"^2*"BR"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"WL", 
    "BL"^2*"GR"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"*"WR", 
    "BL"^2*"BR"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"^3*"dc\[Dagger]"*"GR"*"H"*"Q\[Dagger]", "BL"^3*"dc\[Dagger]"*"H"*
     "Q\[Dagger]"*"WR", "BL"^3*"BR"*"dc\[Dagger]"*"H"*"Q\[Dagger]", 
    "BL"^3*"ec\[Dagger]"*"H"*"L\[Dagger]"*"WR", "BL"^3*"BR"*"ec\[Dagger]"*"H"*
     "L\[Dagger]", "BL"^3*"GR"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "BL"^3*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WR", 
    "BL"^3*"BR"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"}, 
  FL^3*FR^2*\[Phi]^2 -> {"GL"^3*"GR"^2*"H"*"H\[Dagger]", 
    "GL"^3*"GR"*"H"*"H\[Dagger]"*"WR", "BR"*"GL"^3*"GR"*"H"*"H\[Dagger]", 
    "GL"^3*"H"*"H\[Dagger]"*"WR"^2, "BR"*"GL"^3*"H"*"H\[Dagger]"*"WR", 
    "BR"^2*"GL"^3*"H"*"H\[Dagger]", "GL"^2*"GR"^2*"H"*"H\[Dagger]"*"WL", 
    "GL"^2*"GR"*"H"*"H\[Dagger]"*"WL"*"WR", "BR"*"GL"^2*"GR"*"H"*"H\[Dagger]"*
     "WL", "GL"^2*"H"*"H\[Dagger]"*"WL"*"WR"^2, "BR"*"GL"^2*"H"*"H\[Dagger]"*
     "WL"*"WR", "BR"^2*"GL"^2*"H"*"H\[Dagger]"*"WL", 
    "BL"*"GL"^2*"GR"^2*"H"*"H\[Dagger]", "BL"*"GL"^2*"GR"*"H"*"H\[Dagger]"*
     "WR", "BL"*"BR"*"GL"^2*"GR"*"H"*"H\[Dagger]", 
    "BL"*"GL"^2*"H"*"H\[Dagger]"*"WR"^2, "BL"*"BR"*"GL"^2*"H"*"H\[Dagger]"*
     "WR", "BL"*"BR"^2*"GL"^2*"H"*"H\[Dagger]", "GL"*"GR"^2*"H"*"H\[Dagger]"*
     "WL"^2, "GL"*"GR"*"H"*"H\[Dagger]"*"WL"^2*"WR", 
    "BR"*"GL"*"GR"*"H"*"H\[Dagger]"*"WL"^2, "BL"*"GL"*"GR"^2*"H"*"H\[Dagger]"*
     "WL", "BL"*"GL"*"GR"*"H"*"H\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"GL"*"GR"*"H"*"H\[Dagger]"*"WL", "BL"^2*"GL"*"GR"^2*"H"*
     "H\[Dagger]", "BL"^2*"GL"*"GR"*"H"*"H\[Dagger]"*"WR", 
    "BL"^2*"BR"*"GL"*"GR"*"H"*"H\[Dagger]", "GR"^2*"H"*"H\[Dagger]"*"WL"^3, 
    "H"*"H\[Dagger]"*"WL"^3*"WR"^2, "BR"*"H"*"H\[Dagger]"*"WL"^3*"WR", 
    "BR"^2*"H"*"H\[Dagger]"*"WL"^3, "BL"*"GR"^2*"H"*"H\[Dagger]"*"WL"^2, 
    "BL"*"H"*"H\[Dagger]"*"WL"^2*"WR"^2, "BL"*"BR"*"H"*"H\[Dagger]"*"WL"^2*
     "WR", "BL"*"BR"^2*"H"*"H\[Dagger]"*"WL"^2, "BL"^2*"GR"^2*"H"*
     "H\[Dagger]"*"WL", "BL"^2*"H"*"H\[Dagger]"*"WL"*"WR"^2, 
    "BL"^2*"BR"*"H"*"H\[Dagger]"*"WL"*"WR", "BL"^2*"BR"^2*"H"*"H\[Dagger]"*
     "WL", "BL"^3*"GR"^2*"H"*"H\[Dagger]", "BL"^3*"H"*"H\[Dagger]"*"WR"^2, 
    "BL"^3*"BR"*"H"*"H\[Dagger]"*"WR", "BL"^3*"BR"^2*"H"*"H\[Dagger]"}, 
  D*FR*\[Psi]^5*OverBar[\[Psi]] -> {"D"*"dc"*"ec\[Dagger]"*"GR"*"Q"^4, 
    "D"*"dc"*"ec\[Dagger]"*"Q"^4*"WR", "BR"*"D"*"dc"*"ec\[Dagger]"*"Q"^4, 
    "D"*"GR"*"L"*"Q"^4*"Q\[Dagger]", "D"*"L"*"Q"^4*"Q\[Dagger]"*"WR", 
    "BR"*"D"*"L"*"Q"^4*"Q\[Dagger]", "D"*"dc"*"GR"*"Q"^3*"Q\[Dagger]"*"uc", 
    "D"*"dc"*"Q"^3*"Q\[Dagger]"*"uc"*"WR", "BR"*"D"*"dc"*"Q"^3*"Q\[Dagger]"*
     "uc", "D"*"GR"*"L"*"Q"^3*"uc"*"uc\[Dagger]", 
    "D"*"L"*"Q"^3*"uc"*"uc\[Dagger]"*"WR", "BR"*"D"*"L"*"Q"^3*"uc"*
     "uc\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"GR"*"L"*"Q"^3, 
    "D"*"dc"*"dc\[Dagger]"*"L"*"Q"^3*"WR", "BR"*"D"*"dc"*"dc\[Dagger]"*"L"*
     "Q"^3, "D"*"GR"*"L"^2*"L\[Dagger]"*"Q"^3, "D"*"L"^2*"L\[Dagger]"*"Q"^3*
     "WR", "BR"*"D"*"L"^2*"L\[Dagger]"*"Q"^3, "D"*"ec"*"ec\[Dagger]"*"GR"*"L"*
     "Q"^3, "D"*"ec"*"ec\[Dagger]"*"L"*"Q"^3*"WR", 
    "BR"*"D"*"ec"*"ec\[Dagger]"*"L"*"Q"^3, "D"*"dc"*"GR"*"Q"^2*"uc"^2*
     "uc\[Dagger]", "D"*"dc"*"Q"^2*"uc"^2*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"dc"*"Q"^2*"uc"^2*"uc\[Dagger]", "D"*"dc"^2*"dc\[Dagger]"*"GR"*
     "Q"^2*"uc", "D"*"dc"^2*"dc\[Dagger]"*"Q"^2*"uc"*"WR", 
    "BR"*"D"*"dc"^2*"dc\[Dagger]"*"Q"^2*"uc", "D"*"dc"*"GR"*"L"*"L\[Dagger]"*
     "Q"^2*"uc", "D"*"dc"*"L"*"L\[Dagger]"*"Q"^2*"uc"*"WR", 
    "BR"*"D"*"dc"*"L"*"L\[Dagger]"*"Q"^2*"uc", "D"*"dc"*"ec"*"ec\[Dagger]"*
     "GR"*"Q"^2*"uc", "D"*"dc"*"ec"*"ec\[Dagger]"*"Q"^2*"uc"*"WR", 
    "BR"*"D"*"dc"*"ec"*"ec\[Dagger]"*"Q"^2*"uc", "D"*"ec"*"GR"*"L"*"Q"^2*
     "Q\[Dagger]"*"uc", "D"*"ec"*"L"*"Q"^2*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"D"*"ec"*"L"*"Q"^2*"Q\[Dagger]"*"uc", "D"*"dc\[Dagger]"*"ec"*"GR"*
     "L"^2*"Q"^2, "D"*"dc\[Dagger]"*"ec"*"L"^2*"Q"^2*"WR", 
    "BR"*"D"*"dc\[Dagger]"*"ec"*"L"^2*"Q"^2, "D"*"dc"^2*"GR"*"L\[Dagger]"*"Q"*
     "uc"^2, "D"*"dc"^2*"L\[Dagger]"*"Q"*"uc"^2*"WR", 
    "BR"*"D"*"dc"^2*"L\[Dagger]"*"Q"*"uc"^2, "D"*"dc"*"ec"*"GR"*"Q"*
     "Q\[Dagger]"*"uc"^2, "D"*"dc"*"ec"*"Q"*"Q\[Dagger]"*"uc"^2*"WR", 
    "BR"*"D"*"dc"*"ec"*"Q"*"Q\[Dagger]"*"uc"^2, "D"*"ec"*"GR"*"L"*"Q"*"uc"^2*
     "uc\[Dagger]", "D"*"ec"*"L"*"Q"*"uc"^2*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"ec"*"L"*"Q"*"uc"^2*"uc\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"ec"*
     "GR"*"L"*"Q"*"uc", "D"*"dc"*"dc\[Dagger]"*"ec"*"L"*"Q"*"uc"*"WR", 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"ec"*"L"*"Q"*"uc", 
    "D"*"ec"*"GR"*"L"^2*"L\[Dagger]"*"Q"*"uc", "D"*"ec"*"L"^2*"L\[Dagger]"*
     "Q"*"uc"*"WR", "BR"*"D"*"ec"*"L"^2*"L\[Dagger]"*"Q"*"uc", 
    "D"*"ec"^2*"ec\[Dagger]"*"GR"*"L"*"Q"*"uc", "D"*"ec"^2*"ec\[Dagger]"*"L"*
     "Q"*"uc"*"WR", "BR"*"D"*"ec"^2*"ec\[Dagger]"*"L"*"Q"*"uc", 
    "D"*"dc"*"ec"*"GR"*"uc"^3*"uc\[Dagger]", "BR"*"D"*"dc"*"ec"*"uc"^3*
     "uc\[Dagger]", "D"*"dc"^2*"dc\[Dagger]"*"ec"*"GR"*"uc"^2, 
    "BR"*"D"*"dc"^2*"dc\[Dagger]"*"ec"*"uc"^2, "D"*"dc"*"ec"*"GR"*"L"*
     "L\[Dagger]"*"uc"^2, "D"*"dc"*"ec"*"L"*"L\[Dagger]"*"uc"^2*"WR", 
    "BR"*"D"*"dc"*"ec"*"L"*"L\[Dagger]"*"uc"^2, "D"*"dc"*"ec"^2*"ec\[Dagger]"*
     "GR"*"uc"^2, "BR"*"D"*"dc"*"ec"^2*"ec\[Dagger]"*"uc"^2, 
    "D"*"ec"^2*"GR"*"L"*"Q\[Dagger]"*"uc"^2, "D"*"ec"^2*"L"*"Q\[Dagger]"*
     "uc"^2*"WR", "BR"*"D"*"ec"^2*"L"*"Q\[Dagger]"*"uc"^2, 
    "D"*"dc\[Dagger]"*"ec"^2*"GR"*"L"^2*"uc", "D"*"dc\[Dagger]"*"ec"^2*"L"^2*
     "uc"*"WR", "BR"*"D"*"dc\[Dagger]"*"ec"^2*"L"^2*"uc"}, 
  D*FL*\[Psi]^3*OverBar[\[Psi]]^3 -> {"D"*"GL"*"Q"^3*"Q\[Dagger]"^3, 
    "D"*"ec\[Dagger]"*"GL"*"Q"^3*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"*"GL"*"Q"^2*"Q\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"*"ec\[Dagger]"*"GL"*"Q"^2*"uc"*"uc\[Dagger]"^2, 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"Q"^2*"Q\[Dagger]"^2, 
    "D"*"dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"ec\[Dagger]"*"GL"*"Q"^2*"uc\[Dagger]", 
    "D"*"GL"*"L"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, 
    "D"*"dc\[Dagger]"*"GL"*"L"*"Q"^2*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"*"ec\[Dagger]"*"GL"*"L"*"L\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "D"*"ec"*"ec\[Dagger]"*"GL"*"Q"^2*"Q\[Dagger]"^2, 
    "D"*"ec"*"ec\[Dagger]"^2*"GL"*"Q"^2*"uc\[Dagger]", 
    "D"*"GL"*"Q"*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "D"*"dc"*"GL"*"L\[Dagger]"*"Q"*"Q\[Dagger]"^2*"uc", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "D"*"GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"*"dc\[Dagger]"*"GL"*"L"*"Q"*"uc"*"uc\[Dagger]"^2, 
    "D"*"ec"*"GL"*"Q"*"Q\[Dagger]"^3*"uc", "D"*"ec"*"ec\[Dagger]"*"GL"*"Q"*
     "Q\[Dagger]"*"uc"*"uc\[Dagger]", "D"*"dc"^2*"dc\[Dagger]"^2*"GL"*"Q"*
     "Q\[Dagger]", "D"*"dc"^2*"dc\[Dagger]"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*
     "Q", "D"*"dc"*"dc\[Dagger]"*"GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"^2*"GL"*"L"*"Q"*"uc\[Dagger]", 
    "D"*"dc"*"ec\[Dagger]"*"GL"*"L"*"L\[Dagger]"^2*"Q", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"Q"*"Q\[Dagger]", 
    "D"*"dc"*"ec"*"ec\[Dagger]"^2*"GL"*"L\[Dagger]"*"Q", 
    "D"*"GL"*"L"^2*"L\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"*"GL"*"L"^2*"L\[Dagger]"*"Q"*"uc\[Dagger]", 
    "D"*"dc\[Dagger]"*"ec"*"GL"*"L"*"Q"*"Q\[Dagger]"^2, 
    "D"*"ec"*"ec\[Dagger]"*"GL"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"L"*"Q"*"uc\[Dagger]", 
    "D"*"ec"^2*"ec\[Dagger]"^2*"GL"*"Q"*"Q\[Dagger]", 
    "D"*"GL"*"uc"^3*"uc\[Dagger]"^3, "D"*"dc"*"GL"*"L\[Dagger]"*"Q\[Dagger]"*
     "uc"^2*"uc\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"GL"*"uc"^2*
     "uc\[Dagger]"^2, "D"*"GL"*"L"*"L\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "D"*"ec"*"GL"*"Q\[Dagger]"^2*"uc"^2*"uc\[Dagger]", 
    "D"*"ec"*"ec\[Dagger]"*"GL"*"uc"^2*"uc\[Dagger]"^2, 
    "D"*"dc"^2*"dc\[Dagger]"*"GL"*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "D"*"dc"^2*"dc\[Dagger]"^2*"GL"*"uc"*"uc\[Dagger]", 
    "D"*"dc"^2*"ec\[Dagger]"*"GL"*"L\[Dagger]"^2*"uc", 
    "D"*"dc"*"GL"*"L"*"L\[Dagger]"^2*"Q\[Dagger]"*"uc", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"GL"*"Q\[Dagger]"^2*"uc", 
    "D"*"dc"*"ec"*"ec\[Dagger]"*"GL"*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"uc"*"uc\[Dagger]", 
    "D"*"GL"*"L"^2*"L\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"*"ec"*"GL"*"L"*"L\[Dagger]"*"Q\[Dagger]"^2*"uc", 
    "D"*"dc\[Dagger]"*"ec"*"GL"*"L"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"*"ec"*"ec\[Dagger]"*"GL"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"*"ec"^2*"ec\[Dagger]"*"GL"*"Q\[Dagger]"^2*"uc", 
    "D"*"ec"^2*"ec\[Dagger]"^2*"GL"*"uc"*"uc\[Dagger]", 
    "D"*"dc"^3*"dc\[Dagger]"^3*"GL", "D"*"dc"^2*"dc\[Dagger]"^2*"GL"*"L"*
     "L\[Dagger]", "D"*"dc"^2*"dc\[Dagger]"^2*"ec"*"ec\[Dagger]"*"GL", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"L"^2*"L\[Dagger]"^2, 
    "D"*"dc"*"dc\[Dagger]"^2*"ec"*"GL"*"L"*"Q\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"L"*"L\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"^2*"GL", 
    "D"*"dc\[Dagger]"*"ec"*"GL"*"L"^2*"L\[Dagger]"*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"^2*"ec"*"GL"*"L"^2*"uc\[Dagger]", 
    "D"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"GL"*"L"*"Q\[Dagger]", 
    "D"*"Q"^3*"Q\[Dagger]"^3*"WL", "D"*"ec\[Dagger]"*"Q"^3*"Q\[Dagger]"*
     "uc\[Dagger]"*"WL", "D"*"Q"^2*"Q\[Dagger]"^2*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"ec\[Dagger]"*"Q"^2*"uc"*"uc\[Dagger]"^2*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"Q"^2*"Q\[Dagger]"^2*"WL", 
    "D"*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL", 
    "D"*"L"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"^2*"WL", 
    "D"*"dc\[Dagger]"*"L"*"Q"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "D"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL", 
    "D"*"ec"*"ec\[Dagger]"*"Q"^2*"Q\[Dagger]"^2*"WL", 
    "D"*"ec"*"ec\[Dagger]"^2*"Q"^2*"uc\[Dagger]"*"WL", 
    "D"*"Q"*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]"^2*"WL", 
    "D"*"dc"*"L\[Dagger]"*"Q"*"Q\[Dagger]"^2*"uc"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"L"*"Q"*"uc"*"uc\[Dagger]"^2*"WL", 
    "D"*"ec"*"Q"*"Q\[Dagger]"^3*"uc"*"WL", "D"*"ec"*"ec\[Dagger]"*"Q"*
     "Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", "D"*"dc"^2*"dc\[Dagger]"^2*"Q"*
     "Q\[Dagger]"*"WL", "D"*"dc"^2*"dc\[Dagger]"*"ec\[Dagger]"*"L\[Dagger]"*
     "Q"*"WL", "D"*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"*"WL", 
    "D"*"dc"*"ec\[Dagger]"*"L"*"L\[Dagger]"^2*"Q"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"dc"*"ec"*"ec\[Dagger]"^2*"L\[Dagger]"*"Q"*"WL", 
    "D"*"L"^2*"L\[Dagger]"^2*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"*"uc\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"ec"*"L"*"Q"*"Q\[Dagger]"^2*"WL", 
    "D"*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*"WL", 
    "D"*"ec"^2*"ec\[Dagger]"^2*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"dc"*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]"*"WL", 
    "D"*"L"*"L\[Dagger]"*"uc"^2*"uc\[Dagger]"^2*"WL", 
    "D"*"ec"*"Q\[Dagger]"^2*"uc"^2*"uc\[Dagger]"*"WL", 
    "D"*"dc"^2*"dc\[Dagger]"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "D"*"dc"^2*"ec\[Dagger]"*"L\[Dagger]"^2*"uc"*"WL", 
    "D"*"dc"*"L"*"L\[Dagger]"^2*"Q\[Dagger]"*"uc"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"Q\[Dagger]"^2*"uc"*"WL", 
    "D"*"dc"*"ec"*"ec\[Dagger]"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "D"*"L"^2*"L\[Dagger]"^2*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"ec"*"L"*"L\[Dagger]"*"Q\[Dagger]"^2*"uc"*"WL", 
    "D"*"dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"ec"^2*"ec\[Dagger]"*"Q\[Dagger]"^2*"uc"*"WL", 
    "D"*"dc"^2*"dc\[Dagger]"^2*"L"*"L\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"L"^2*"L\[Dagger]"^2*"WL", 
    "D"*"dc"*"dc\[Dagger]"^2*"ec"*"L"*"Q\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "D"*"L"^3*"L\[Dagger]"^3*"WL", "D"*"dc\[Dagger]"*"ec"*"L"^2*"L\[Dagger]"*
     "Q\[Dagger]"*"WL", "D"*"dc\[Dagger]"^2*"ec"*"L"^2*"uc\[Dagger]"*"WL", 
    "D"*"ec"*"ec\[Dagger]"*"L"^2*"L\[Dagger]"^2*"WL", 
    "D"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"L"*"Q\[Dagger]"*"WL", 
    "D"*"ec"^2*"ec\[Dagger]"^2*"L"*"L\[Dagger]"*"WL", 
    "BL"*"D"*"Q"^3*"Q\[Dagger]"^3, "BL"*"D"*"ec\[Dagger]"*"Q"^3*"Q\[Dagger]"*
     "uc\[Dagger]", "BL"*"D"*"Q"^2*"Q\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"ec\[Dagger]"*"Q"^2*"uc"*"uc\[Dagger]"^2, 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, 
    "BL"*"D"*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "BL"*"D"*"L"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, 
    "BL"*"D"*"dc\[Dagger]"*"L"*"Q"^2*"Q\[Dagger]"*"uc\[Dagger]", 
    "BL"*"D"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, 
    "BL"*"D"*"ec"*"ec\[Dagger]"^2*"Q"^2*"uc\[Dagger]", 
    "BL"*"D"*"Q"*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "BL"*"D"*"dc"*"L\[Dagger]"*"Q"*"Q\[Dagger]"^2*"uc", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"*"L"*"Q"*"uc"*"uc\[Dagger]"^2, 
    "BL"*"D"*"ec"*"Q"*"Q\[Dagger]"^3*"uc", "BL"*"D"*"ec"*"ec\[Dagger]"*"Q"*
     "Q\[Dagger]"*"uc"*"uc\[Dagger]", "BL"*"D"*"dc"^2*"dc\[Dagger]"^2*"Q"*
     "Q\[Dagger]", "BL"*"D"*"dc"^2*"dc\[Dagger]"*"ec\[Dagger]"*"L\[Dagger]"*
     "Q", "BL"*"D"*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]", 
    "BL"*"D"*"dc"*"ec\[Dagger]"*"L"*"L\[Dagger]"^2*"Q", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"dc"*"ec"*"ec\[Dagger]"^2*"L\[Dagger]"*"Q", 
    "BL"*"D"*"L"^2*"L\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"*"uc\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"*"ec"*"L"*"Q"*"Q\[Dagger]"^2, 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"L"*"Q"*"uc\[Dagger]", 
    "BL"*"D"*"ec"^2*"ec\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"uc"^3*"uc\[Dagger]"^3, "BL"*"D"*"dc"*"L\[Dagger]"*"Q\[Dagger]"*
     "uc"^2*"uc\[Dagger]", "BL"*"D"*"dc"*"dc\[Dagger]"*"uc"^2*
     "uc\[Dagger]"^2, "BL"*"D"*"L"*"L\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "BL"*"D"*"ec"*"Q\[Dagger]"^2*"uc"^2*"uc\[Dagger]", 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "BL"*"D"*"dc"^2*"dc\[Dagger]"*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "BL"*"D"*"dc"^2*"dc\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"dc"^2*"ec\[Dagger]"*"L\[Dagger]"^2*"uc", 
    "BL"*"D"*"dc"*"L"*"L\[Dagger]"^2*"Q\[Dagger]"*"uc", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"ec"*"Q\[Dagger]"^2*"uc", 
    "BL"*"D"*"dc"*"ec"*"ec\[Dagger]"*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"L"^2*"L\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"ec"*"L"*"L\[Dagger]"*"Q\[Dagger]"^2*"uc", 
    "BL"*"D"*"dc\[Dagger]"*"ec"*"L"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"ec"^2*"ec\[Dagger]"*"Q\[Dagger]"^2*"uc", 
    "BL"*"D"*"ec"^2*"ec\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"dc"^3*"dc\[Dagger]"^3, "BL"*"D"*"dc"^2*"dc\[Dagger]"^2*"L"*
     "L\[Dagger]", "BL"*"D"*"dc"^2*"dc\[Dagger]"^2*"ec"*"ec\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"L"^2*"L\[Dagger]"^2, 
    "BL"*"D"*"dc"*"dc\[Dagger]"^2*"ec"*"L"*"Q\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"^2, 
    "BL"*"D"*"L"^3*"L\[Dagger]"^3, "BL"*"D"*"dc\[Dagger]"*"ec"*"L"^2*
     "L\[Dagger]"*"Q\[Dagger]", "BL"*"D"*"dc\[Dagger]"^2*"ec"*"L"^2*
     "uc\[Dagger]", "BL"*"D"*"ec"*"ec\[Dagger]"*"L"^2*"L\[Dagger]"^2, 
    "BL"*"D"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"L"*"Q\[Dagger]", 
    "BL"*"D"*"ec"^2*"ec\[Dagger]"^2*"L"*"L\[Dagger]", 
    "BL"*"D"*"ec"^3*"ec\[Dagger]"^3}, 
  D*FL*FR*\[Phi]*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"*"ec\[Dagger]"*"GL"*"GR"*"H"*"Q"^3, "D"*"ec\[Dagger]"*"GL"*"H"*"Q"^3*
     "WR", "BR"*"D"*"ec\[Dagger]"*"GL"*"H"*"Q"^3, "D"*"GL"*"GR"*"H"*"Q"^2*
     "Q\[Dagger]"*"uc", "D"*"GL"*"H"*"Q"^2*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"D"*"GL"*"H"*"Q"^2*"Q\[Dagger]"*"uc", "D"*"dc"*"GL"*"GR"*
     "H\[Dagger]"*"Q"^2*"Q\[Dagger]", "D"*"dc"*"GL"*"H\[Dagger]"*"Q"^2*
     "Q\[Dagger]"*"WR", "BR"*"D"*"dc"*"GL"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"*"GL"*"GR"*"H"*"L"*"Q"^2, "D"*"dc\[Dagger]"*"GL"*"H"*"L"*
     "Q"^2*"WR", "BR"*"D"*"dc\[Dagger]"*"GL"*"H"*"L"*"Q"^2, 
    "D"*"GL"*"GR"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]", 
    "D"*"GL"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"GL"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]", 
    "D"*"GL"*"GR"*"H"*"Q"*"uc"^2*"uc\[Dagger]", "D"*"GL"*"H"*"Q"*"uc"^2*
     "uc\[Dagger]"*"WR", "BR"*"D"*"GL"*"H"*"Q"*"uc"^2*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"GR"*"H"*"Q"*"uc", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"H"*"Q"*"uc"*"WR", 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"GL"*"H"*"Q"*"uc", 
    "D"*"dc"*"GL"*"GR"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"GL"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"dc"*"GL"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "D"*"GL"*"GR"*"H"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "D"*"GL"*"H"*"L"*"L\[Dagger]"*"Q"*"uc"*"WR", "BR"*"D"*"GL"*"H"*"L"*
     "L\[Dagger]"*"Q"*"uc", "D"*"ec"*"ec\[Dagger]"*"GL"*"GR"*"H"*"Q"*"uc", 
    "D"*"ec"*"ec\[Dagger]"*"GL"*"H"*"Q"*"uc"*"WR", 
    "BR"*"D"*"ec"*"ec\[Dagger]"*"GL"*"H"*"Q"*"uc", 
    "D"*"dc"^2*"dc\[Dagger]"*"GL"*"GR"*"H\[Dagger]"*"Q", 
    "D"*"dc"^2*"dc\[Dagger]"*"GL"*"H\[Dagger]"*"Q"*"WR", 
    "BR"*"D"*"dc"^2*"dc\[Dagger]"*"GL"*"H\[Dagger]"*"Q", 
    "D"*"dc"*"GL"*"GR"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "D"*"dc"*"GL"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"WR", 
    "BR"*"D"*"dc"*"GL"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "D"*"dc"*"ec"*"ec\[Dagger]"*"GL"*"GR"*"H\[Dagger]"*"Q", 
    "D"*"dc"*"ec"*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"Q"*"WR", 
    "BR"*"D"*"dc"*"ec"*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"Q", 
    "D"*"ec"*"GL"*"GR"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "D"*"ec"*"GL"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"D"*"ec"*"GL"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "D"*"dc"*"GL"*"GR"*"H"*"L\[Dagger]"*"uc"^2, "D"*"dc"*"GL"*"H"*
     "L\[Dagger]"*"uc"^2*"WR", "BR"*"D"*"dc"*"GL"*"H"*"L\[Dagger]"*"uc"^2, 
    "D"*"ec"*"GL"*"GR"*"H"*"Q\[Dagger]"*"uc"^2, "D"*"ec"*"GL"*"H"*
     "Q\[Dagger]"*"uc"^2*"WR", "BR"*"D"*"ec"*"GL"*"H"*"Q\[Dagger]"*"uc"^2, 
    "D"*"dc"^2*"GL"*"GR"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "D"*"dc"^2*"GL"*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WR", 
    "BR"*"D"*"dc"^2*"GL"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "D"*"dc"*"ec"*"GL"*"GR"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "D"*"dc"*"ec"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"D"*"dc"*"ec"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "D"*"dc\[Dagger]"*"ec"*"GL"*"GR"*"H"*"L"*"uc", 
    "D"*"dc\[Dagger]"*"ec"*"GL"*"H"*"L"*"uc"*"WR", 
    "BR"*"D"*"dc\[Dagger]"*"ec"*"GL"*"H"*"L"*"uc", 
    "D"*"ec"*"GL"*"GR"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", 
    "D"*"ec"*"GL"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"ec"*"GL"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"GL"*"GR"*"H\[Dagger]"*"L", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"GL"*"H\[Dagger]"*"L"*"WR", 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"ec"*"GL"*"H\[Dagger]"*"L", 
    "D"*"ec"*"GL"*"GR"*"H\[Dagger]"*"L"^2*"L\[Dagger]", 
    "D"*"ec"^2*"ec\[Dagger]"*"GL"*"GR"*"H\[Dagger]"*"L", 
    "D"*"ec\[Dagger]"*"GR"*"H"*"Q"^3*"WL", "D"*"ec\[Dagger]"*"H"*"Q"^3*"WL"*
     "WR", "BR"*"D"*"ec\[Dagger]"*"H"*"Q"^3*"WL", 
    "D"*"GR"*"H"*"Q"^2*"Q\[Dagger]"*"uc"*"WL", "D"*"H"*"Q"^2*"Q\[Dagger]"*
     "uc"*"WL"*"WR", "BR"*"D"*"H"*"Q"^2*"Q\[Dagger]"*"uc"*"WL", 
    "D"*"dc"*"GR"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"WL", 
    "D"*"dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"WL"*"WR", 
    "BR"*"D"*"dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"GR"*"H"*"L"*"Q"^2*"WL", "D"*"dc\[Dagger]"*"H"*"L"*
     "Q"^2*"WL"*"WR", "BR"*"D"*"dc\[Dagger]"*"H"*"L"*"Q"^2*"WL", 
    "D"*"GR"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]"*"WL", 
    "D"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"D"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]"*"WL", 
    "D"*"GR"*"H"*"Q"*"uc"^2*"uc\[Dagger]"*"WL", "D"*"H"*"Q"*"uc"^2*
     "uc\[Dagger]"*"WL"*"WR", "BR"*"D"*"H"*"Q"*"uc"^2*"uc\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"GR"*"H"*"Q"*"uc"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc"*"WL"*"WR", 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc"*"WL", 
    "D"*"dc"*"GR"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"dc"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"D"*"dc"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"GR"*"H"*"L"*"L\[Dagger]"*"Q"*"uc"*"WL", "D"*"H"*"L"*"L\[Dagger]"*"Q"*
     "uc"*"WL"*"WR", "BR"*"D"*"H"*"L"*"L\[Dagger]"*"Q"*"uc"*"WL", 
    "D"*"ec"*"ec\[Dagger]"*"GR"*"H"*"Q"*"uc"*"WL", 
    "D"*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc"*"WL"*"WR", 
    "BR"*"D"*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc"*"WL", 
    "D"*"dc"^2*"dc\[Dagger]"*"GR"*"H\[Dagger]"*"Q"*"WL", 
    "D"*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q"*"WL"*"WR", 
    "BR"*"D"*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q"*"WL", 
    "D"*"dc"*"GR"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"WL", 
    "D"*"dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"WL"*"WR", 
    "BR"*"D"*"dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"WL", 
    "D"*"dc"*"ec"*"ec\[Dagger]"*"GR"*"H\[Dagger]"*"Q"*"WL", 
    "D"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"*"WL"*"WR", 
    "BR"*"D"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"*"WL", 
    "D"*"ec"*"GR"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BR"*"D"*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"dc"*"GR"*"H"*"L\[Dagger]"*"uc"^2*"WL", "D"*"dc"*"H"*"L\[Dagger]"*
     "uc"^2*"WL"*"WR", "BR"*"D"*"dc"*"H"*"L\[Dagger]"*"uc"^2*"WL", 
    "D"*"ec"*"GR"*"H"*"Q\[Dagger]"*"uc"^2*"WL", "D"*"ec"*"H"*"Q\[Dagger]"*
     "uc"^2*"WL"*"WR", "BR"*"D"*"ec"*"H"*"Q\[Dagger]"*"uc"^2*"WL", 
    "D"*"dc"^2*"GR"*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WL", 
    "D"*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WL"*"WR", 
    "BR"*"D"*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WL", 
    "D"*"dc"*"ec"*"GR"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "D"*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"WL"*"WR", 
    "BR"*"D"*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "D"*"dc\[Dagger]"*"ec"*"GR"*"H"*"L"*"uc"*"WL", 
    "D"*"dc\[Dagger]"*"ec"*"H"*"L"*"uc"*"WL"*"WR", 
    "BR"*"D"*"dc\[Dagger]"*"ec"*"H"*"L"*"uc"*"WL", 
    "D"*"ec"*"GR"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"ec"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"D"*"ec"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"GR"*"H\[Dagger]"*"L"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"*"WL"*"WR", 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"*"WL", 
    "D"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"WL"*"WR", 
    "BR"*"D"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"WL", 
    "D"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"WL"*"WR", 
    "BR"*"D"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"WL", 
    "BL"*"D"*"ec\[Dagger]"*"GR"*"H"*"Q"^3, "BL"*"D"*"ec\[Dagger]"*"H"*"Q"^3*
     "WR", "BL"*"BR"*"D"*"ec\[Dagger]"*"H"*"Q"^3, "BL"*"D"*"GR"*"H"*"Q"^2*
     "Q\[Dagger]"*"uc", "BL"*"D"*"H"*"Q"^2*"Q\[Dagger]"*"uc"*"WR", 
    "BL"*"BR"*"D"*"H"*"Q"^2*"Q\[Dagger]"*"uc", "BL"*"D"*"dc"*"GR"*
     "H\[Dagger]"*"Q"^2*"Q\[Dagger]", "BL"*"D"*"dc"*"H\[Dagger]"*"Q"^2*
     "Q\[Dagger]"*"WR", "BL"*"BR"*"D"*"dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"*"GR"*"H"*"L"*"Q"^2, "BL"*"D"*"dc\[Dagger]"*"H"*"L"*
     "Q"^2*"WR", "BL"*"BR"*"D"*"dc\[Dagger]"*"H"*"L"*"Q"^2, 
    "BL"*"D"*"GR"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]", 
    "BL"*"D"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]"*"WR", 
    "BL"*"BR"*"D"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]", 
    "BL"*"D"*"GR"*"H"*"Q"*"uc"^2*"uc\[Dagger]", "BL"*"D"*"H"*"Q"*"uc"^2*
     "uc\[Dagger]"*"WR", "BL"*"BR"*"D"*"H"*"Q"*"uc"^2*"uc\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"GR"*"H"*"Q"*"uc", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc"*"WR", 
    "BL"*"BR"*"D"*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc", 
    "BL"*"D"*"dc"*"GR"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"dc"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]"*"WR", 
    "BL"*"BR"*"D"*"dc"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"GR"*"H"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "BL"*"D"*"H"*"L"*"L\[Dagger]"*"Q"*"uc"*"WR", "BL"*"BR"*"D"*"H"*"L"*
     "L\[Dagger]"*"Q"*"uc", "BL"*"D"*"ec"*"ec\[Dagger]"*"GR"*"H"*"Q"*"uc", 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc"*"WR", 
    "BL"*"BR"*"D"*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc", 
    "BL"*"D"*"dc"^2*"dc\[Dagger]"*"GR"*"H\[Dagger]"*"Q", 
    "BL"*"D"*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q"*"WR", 
    "BL"*"BR"*"D"*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q", 
    "BL"*"D"*"dc"*"GR"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "BL"*"D"*"dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"WR", 
    "BL"*"BR"*"D"*"dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "BL"*"D"*"dc"*"ec"*"ec\[Dagger]"*"GR"*"H\[Dagger]"*"Q", 
    "BL"*"D"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"*"WR", 
    "BL"*"BR"*"D"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q", 
    "BL"*"D"*"ec"*"GR"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"WR", 
    "BL"*"BR"*"D"*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"dc"*"GR"*"H"*"L\[Dagger]"*"uc"^2, "BL"*"D"*"dc"*"H"*
     "L\[Dagger]"*"uc"^2*"WR", "BL"*"BR"*"D"*"dc"*"H"*"L\[Dagger]"*"uc"^2, 
    "BL"*"D"*"ec"*"GR"*"H"*"Q\[Dagger]"*"uc"^2, "BL"*"D"*"ec"*"H"*
     "Q\[Dagger]"*"uc"^2*"WR", "BL"*"BR"*"D"*"ec"*"H"*"Q\[Dagger]"*"uc"^2, 
    "BL"*"D"*"dc"^2*"GR"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "BL"*"D"*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WR", 
    "BL"*"BR"*"D"*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "BL"*"D"*"dc"*"ec"*"GR"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "BL"*"D"*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"WR", 
    "BL"*"BR"*"D"*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "BL"*"D"*"dc\[Dagger]"*"ec"*"GR"*"H"*"L"*"uc", 
    "BL"*"D"*"dc\[Dagger]"*"ec"*"H"*"L"*"uc"*"WR", 
    "BL"*"BR"*"D"*"dc\[Dagger]"*"ec"*"H"*"L"*"uc", 
    "BL"*"D"*"ec"*"GR"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"ec"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]"*"WR", 
    "BL"*"BR"*"D"*"ec"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"ec"*"GR"*"H\[Dagger]"*"L", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"*"WR", 
    "BL"*"BR"*"D"*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L", 
    "BL"*"D"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"WR", 
    "BL"*"BR"*"D"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]", 
    "BL"*"D"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"WR", 
    "BL"*"BR"*"D"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"}, 
  D*FL^2*\[Phi]*\[Psi]*OverBar[\[Psi]]^3 -> 
   {"D"*"dc\[Dagger]"*"GL"^2*"H"*"Q"*"Q\[Dagger]"^2, 
    "D"*"ec\[Dagger]"*"GL"^2*"H"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"*"ec\[Dagger]"*"GL"^2*"H"*"Q"*"uc\[Dagger]", 
    "D"*"GL"^2*"H\[Dagger]"*"Q"*"Q\[Dagger]"^2*"uc\[Dagger]", 
    "D"*"ec\[Dagger]"*"GL"^2*"H\[Dagger]"*"Q"*"uc\[Dagger]"^2, 
    "D"*"GL"^2*"H"*"L\[Dagger]"*"Q\[Dagger]"^2*"uc", 
    "D"*"dc\[Dagger]"*"GL"^2*"H"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"*"ec\[Dagger]"*"GL"^2*"H"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"*"GL"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"^2, 
    "D"*"dc"*"dc\[Dagger]"^2*"GL"^2*"H"*"Q\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"ec\[Dagger]"*"GL"^2*"H"*"L\[Dagger]", 
    "D"*"dc"*"GL"^2*"H\[Dagger]"*"L\[Dagger]"*"Q\[Dagger]"^2, 
    "D"*"dc"*"dc\[Dagger]"*"GL"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"*"dc"*"ec\[Dagger]"*"GL"^2*"H\[Dagger]"*"L\[Dagger]"*"uc\[Dagger]", 
    "D"*"dc\[Dagger]"*"GL"^2*"H"*"L"*"L\[Dagger]"*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"^2*"GL"^2*"H"*"L"*"uc\[Dagger]", 
    "D"*"ec\[Dagger]"*"GL"^2*"H"*"L"*"L\[Dagger]"^2, 
    "D"*"GL"^2*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"*"dc\[Dagger]"*"GL"^2*"H\[Dagger]"*"L"*"uc\[Dagger]"^2, 
    "D"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"^2*"H"*"Q\[Dagger]", 
    "D"*"ec"*"ec\[Dagger]"^2*"GL"^2*"H"*"L\[Dagger]", 
    "D"*"ec"*"GL"^2*"H\[Dagger]"*"Q\[Dagger]"^3, "D"*"ec"*"ec\[Dagger]"*
     "GL"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"*"dc\[Dagger]"*"GL"*"H"*"Q"*"Q\[Dagger]"^2*"WL", 
    "D"*"ec\[Dagger]"*"GL"*"H"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"ec\[Dagger]"*"GL"*"H"*"Q"*"uc\[Dagger]"*"WL", 
    "D"*"GL"*"H\[Dagger]"*"Q"*"Q\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "D"*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"Q"*"uc\[Dagger]"^2*"WL", 
    "D"*"GL"*"H"*"L\[Dagger]"*"Q\[Dagger]"^2*"uc"*"WL", 
    "D"*"dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"ec\[Dagger]"*"GL"*"H"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"^2*"WL", 
    "D"*"dc"*"dc\[Dagger]"^2*"GL"*"H"*"Q\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"ec\[Dagger]"*"GL"*"H"*"L\[Dagger]"*"WL", 
    "D"*"dc"*"GL"*"H\[Dagger]"*"L\[Dagger]"*"Q\[Dagger]"^2*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "D"*"dc"*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"L\[Dagger]"*"uc\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"GL"*"H"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"^2*"GL"*"H"*"L"*"uc\[Dagger]"*"WL", 
    "D"*"GL"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"GL"*"H\[Dagger]"*"L"*"uc\[Dagger]"^2*"WL", 
    "D"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"H"*"Q\[Dagger]"*"WL", 
    "D"*"ec"*"GL"*"H\[Dagger]"*"Q\[Dagger]"^3*"WL", 
    "D"*"ec"*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"dc\[Dagger]"*"GL"*"H"*"Q"*"Q\[Dagger]"^2, 
    "BL"*"D"*"ec\[Dagger]"*"GL"*"H"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"*"ec\[Dagger]"*"GL"*"H"*"Q"*"uc\[Dagger]", 
    "BL"*"D"*"GL"*"H\[Dagger]"*"Q"*"Q\[Dagger]"^2*"uc\[Dagger]", 
    "BL"*"D"*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"Q"*"uc\[Dagger]"^2, 
    "BL"*"D"*"GL"*"H"*"L\[Dagger]"*"Q\[Dagger]"^2*"uc", 
    "BL"*"D"*"dc\[Dagger]"*"GL"*"H"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"ec\[Dagger]"*"GL"*"H"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"^2, 
    "BL"*"D"*"dc"*"dc\[Dagger]"^2*"GL"*"H"*"Q\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"ec\[Dagger]"*"GL"*"H"*"L\[Dagger]", 
    "BL"*"D"*"dc"*"GL"*"H\[Dagger]"*"L\[Dagger]"*"Q\[Dagger]"^2, 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "BL"*"D"*"dc"*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"L\[Dagger]"*"uc\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"*"GL"*"H"*"L"*"L\[Dagger]"*"Q\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"^2*"GL"*"H"*"L"*"uc\[Dagger]", 
    "BL"*"D"*"GL"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"*"GL"*"H\[Dagger]"*"L"*"uc\[Dagger]"^2, 
    "BL"*"D"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"H"*"Q\[Dagger]", 
    "BL"*"D"*"ec"*"GL"*"H\[Dagger]"*"Q\[Dagger]"^3, 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"*"dc\[Dagger]"*"H"*"Q"*"Q\[Dagger]"^2*"WL"^2, 
    "D"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "D"*"dc\[Dagger]"*"ec\[Dagger]"*"H"*"Q"*"uc\[Dagger]"*"WL"^2, 
    "D"*"H\[Dagger]"*"Q"*"Q\[Dagger]"^2*"uc\[Dagger]"*"WL"^2, 
    "D"*"ec\[Dagger]"*"H\[Dagger]"*"Q"*"uc\[Dagger]"^2*"WL"^2, 
    "D"*"H"*"L\[Dagger]"*"Q\[Dagger]"^2*"uc"*"WL"^2, 
    "D"*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "D"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "D"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"^2*"WL"^2, 
    "D"*"dc"*"dc\[Dagger]"^2*"H"*"Q\[Dagger]"*"WL"^2, 
    "D"*"dc"*"dc\[Dagger]"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"WL"^2, 
    "D"*"dc"*"H\[Dagger]"*"L\[Dagger]"*"Q\[Dagger]"^2*"WL"^2, 
    "D"*"dc"*"dc\[Dagger]"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, 
    "D"*"dc"*"ec\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"uc\[Dagger]"*"WL"^2, 
    "D"*"dc\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"WL"^2, 
    "D"*"dc\[Dagger]"^2*"H"*"L"*"uc\[Dagger]"*"WL"^2, 
    "D"*"ec\[Dagger]"*"H"*"L"*"L\[Dagger]"^2*"WL"^2, 
    "D"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, 
    "D"*"dc\[Dagger]"*"H\[Dagger]"*"L"*"uc\[Dagger]"^2*"WL"^2, 
    "D"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"Q\[Dagger]"*"WL"^2, 
    "D"*"ec"*"ec\[Dagger]"^2*"H"*"L\[Dagger]"*"WL"^2, 
    "D"*"ec"*"H\[Dagger]"*"Q\[Dagger]"^3*"WL"^2, "D"*"ec"*"ec\[Dagger]"*
     "H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, 
    "BL"*"D"*"dc\[Dagger]"*"H"*"Q"*"Q\[Dagger]"^2*"WL", 
    "BL"*"D"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"D"*"dc\[Dagger]"*"ec\[Dagger]"*"H"*"Q"*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"H\[Dagger]"*"Q"*"Q\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"ec\[Dagger]"*"H\[Dagger]"*"Q"*"uc\[Dagger]"^2*"WL", 
    "BL"*"D"*"H"*"L\[Dagger]"*"Q\[Dagger]"^2*"uc"*"WL", 
    "BL"*"D"*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"^2*"WL", 
    "BL"*"D"*"dc"*"dc\[Dagger]"^2*"H"*"Q\[Dagger]"*"WL", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"WL", 
    "BL"*"D"*"dc"*"H\[Dagger]"*"L\[Dagger]"*"Q\[Dagger]"^2*"WL", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"dc"*"ec\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"dc\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"WL", 
    "BL"*"D"*"dc\[Dagger]"^2*"H"*"L"*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"ec\[Dagger]"*"H"*"L"*"L\[Dagger]"^2*"WL", 
    "BL"*"D"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"dc\[Dagger]"*"H\[Dagger]"*"L"*"uc\[Dagger]"^2*"WL", 
    "BL"*"D"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"Q\[Dagger]"*"WL", 
    "BL"*"D"*"ec"*"ec\[Dagger]"^2*"H"*"L\[Dagger]"*"WL", 
    "BL"*"D"*"ec"*"H\[Dagger]"*"Q\[Dagger]"^3*"WL", 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"^2*"D"*"dc\[Dagger]"*"H"*"Q"*"Q\[Dagger]"^2, 
    "BL"^2*"D"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"^2*"D"*"dc\[Dagger]"*"ec\[Dagger]"*"H"*"Q"*"uc\[Dagger]", 
    "BL"^2*"D"*"H\[Dagger]"*"Q"*"Q\[Dagger]"^2*"uc\[Dagger]", 
    "BL"^2*"D"*"ec\[Dagger]"*"H\[Dagger]"*"Q"*"uc\[Dagger]"^2, 
    "BL"^2*"D"*"H"*"L\[Dagger]"*"Q\[Dagger]"^2*"uc", 
    "BL"^2*"D"*"dc\[Dagger]"*"H"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"D"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"D"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"^2, 
    "BL"^2*"D"*"dc"*"dc\[Dagger]"^2*"H"*"Q\[Dagger]", 
    "BL"^2*"D"*"dc"*"dc\[Dagger]"*"ec\[Dagger]"*"H"*"L\[Dagger]", 
    "BL"^2*"D"*"dc"*"H\[Dagger]"*"L\[Dagger]"*"Q\[Dagger]"^2, 
    "BL"^2*"D"*"dc"*"dc\[Dagger]"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "BL"^2*"D"*"dc"*"ec\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"uc\[Dagger]", 
    "BL"^2*"D"*"dc\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q\[Dagger]", 
    "BL"^2*"D"*"dc\[Dagger]"^2*"H"*"L"*"uc\[Dagger]", 
    "BL"^2*"D"*"ec\[Dagger]"*"H"*"L"*"L\[Dagger]"^2, 
    "BL"^2*"D"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]", 
    "BL"^2*"D"*"dc\[Dagger]"*"H\[Dagger]"*"L"*"uc\[Dagger]"^2, 
    "BL"^2*"D"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"Q\[Dagger]", 
    "BL"^2*"D"*"ec"*"ec\[Dagger]"^2*"H"*"L\[Dagger]", 
    "BL"^2*"D"*"ec"*"H\[Dagger]"*"Q\[Dagger]"^3, 
    "BL"^2*"D"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q\[Dagger]"*"uc\[Dagger]"}, 
  D*FL^2*FR*\[Phi]^2*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"GL"^2*"GR"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"*"GL"^2*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"D"*"GL"^2*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"*"GL"^2*"GR"*"H"^2*"uc", "D"*"dc\[Dagger]"*"GL"^2*"H"^2*
     "uc"*"WR", "BR"*"D"*"dc\[Dagger]"*"GL"^2*"H"^2*"uc", 
    "D"*"GL"^2*"GR"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"*"GL"^2*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"GL"^2*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"^2*"GR"*"H"*"H\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"^2*"H"*"H\[Dagger]"*"WR", 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"GL"^2*"H"*"H\[Dagger]", 
    "D"*"dc"*"GL"^2*"GR"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "D"*"dc"*"GL"^2*"H\[Dagger]"^2*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"dc"*"GL"^2*"H\[Dagger]"^2*"uc\[Dagger]", 
    "D"*"GL"^2*"GR"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "D"*"GL"^2*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WR", 
    "BR"*"D"*"GL"^2*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "D"*"ec"*"ec\[Dagger]"*"GL"^2*"GR"*"H"*"H\[Dagger]", 
    "D"*"ec"*"ec\[Dagger]"*"GL"^2*"H"*"H\[Dagger]"*"WR", 
    "BR"*"D"*"ec"*"ec\[Dagger]"*"GL"^2*"H"*"H\[Dagger]", 
    "D"*"GL"*"GR"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BR"*"D"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"GL"*"GR"*"H"^2*"uc"*"WL", "D"*"dc\[Dagger]"*"GL"*"H"^2*
     "uc"*"WL"*"WR", "BR"*"D"*"dc\[Dagger]"*"GL"*"H"^2*"uc"*"WL", 
    "D"*"GL"*"GR"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"D"*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"GR"*"H"*"H\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"WL"*"WR", 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"WL", 
    "D"*"dc"*"GL"*"GR"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "D"*"dc"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"D"*"dc"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "D"*"GL"*"GR"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "D"*"ec"*"ec\[Dagger]"*"GL"*"GR"*"H"*"H\[Dagger]"*"WL", 
    "BL"*"D"*"GL"*"GR"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WR", 
    "BL"*"BR"*"D"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"*"GL"*"GR"*"H"^2*"uc", "BL"*"D"*"dc\[Dagger]"*"GL"*
     "H"^2*"uc"*"WR", "BL"*"BR"*"D"*"dc\[Dagger]"*"GL"*"H"^2*"uc", 
    "BL"*"D"*"GL"*"GR"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BL"*"BR"*"D"*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"GL"*"GR"*"H"*"H\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"WR", 
    "BL"*"BR"*"D"*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]", 
    "BL"*"D"*"dc"*"GL"*"GR"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "BL"*"D"*"dc"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]"*"WR", 
    "BL"*"BR"*"D"*"dc"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "BL"*"D"*"GL"*"GR"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"GL"*"GR"*"H"*"H\[Dagger]", 
    "D"*"GR"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "D"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2*"WR", 
    "BR"*"D"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "D"*"dc\[Dagger]"*"GR"*"H"^2*"uc"*"WL"^2, "D"*"dc\[Dagger]"*"H"^2*"uc"*
     "WL"^2*"WR", "BR"*"D"*"dc\[Dagger]"*"H"^2*"uc"*"WL"^2, 
    "D"*"GR"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "D"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2*"WR", 
    "BR"*"D"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "D"*"dc"*"dc\[Dagger]"*"GR"*"H"*"H\[Dagger]"*"WL"^2, 
    "D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"WL"^2*"WR", 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"WL"^2, 
    "D"*"dc"*"GR"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL"^2, 
    "D"*"dc"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL"^2*"WR", 
    "BR"*"D"*"dc"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL"^2, 
    "D"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL"^2*"WR", 
    "BR"*"D"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL"^2, 
    "D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL"^2*"WR", 
    "BR"*"D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL"^2, 
    "BL"*"D"*"GR"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"D"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"D"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"D"*"dc\[Dagger]"*"GR"*"H"^2*"uc"*"WL", "BL"*"D"*"dc\[Dagger]"*"H"^2*
     "uc"*"WL"*"WR", "BL"*"BR"*"D"*"dc\[Dagger]"*"H"^2*"uc"*"WL", 
    "BL"*"D"*"GR"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"D"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"GR"*"H"*"H\[Dagger]"*"WL", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"WL", 
    "BL"*"D"*"dc"*"GR"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"dc"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"D"*"dc"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"D"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL"*"WR", 
    "BL"*"BR"*"D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL", 
    "BL"^2*"D"*"GR"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"^2*"D"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WR", 
    "BL"^2*"BR"*"D"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"^2*"D"*"dc\[Dagger]"*"GR"*"H"^2*"uc", "BL"^2*"D"*"dc\[Dagger]"*"H"^2*
     "uc"*"WR", "BL"^2*"BR"*"D"*"dc\[Dagger]"*"H"^2*"uc", 
    "BL"^2*"D"*"GR"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"D"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BL"^2*"BR"*"D"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"D"*"dc"*"dc\[Dagger]"*"GR"*"H"*"H\[Dagger]", 
    "BL"^2*"D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"WR", 
    "BL"^2*"BR"*"D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]", 
    "BL"^2*"D"*"dc"*"GR"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "BL"^2*"D"*"dc"*"H\[Dagger]"^2*"uc\[Dagger]"*"WR", 
    "BL"^2*"BR"*"D"*"dc"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "BL"^2*"D"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WR", 
    "BL"^2*"BR"*"D"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"^2*"D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WR", 
    "BL"^2*"BR"*"D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"}, 
  D^2*\[Phi]*\[Psi]^4*OverBar[\[Psi]]^2 -> 
   {"D"^2*"ec\[Dagger]"*"H"*"Q"^4*"Q\[Dagger]", 
    "D"^2*"H"*"Q"^3*"Q\[Dagger]"^2*"uc", "D"^2*"ec\[Dagger]"*"H"*"Q"^3*"uc"*
     "uc\[Dagger]", "D"^2*"dc"*"dc\[Dagger]"*"ec\[Dagger]"*"H"*"Q"^3, 
    "D"^2*"dc"*"H\[Dagger]"*"Q"^3*"Q\[Dagger]"^2, "D"^2*"dc"*"ec\[Dagger]"*
     "H\[Dagger]"*"Q"^3*"uc\[Dagger]", "D"^2*"dc\[Dagger]"*"H"*"L"*"Q"^3*
     "Q\[Dagger]", "D"^2*"ec\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q"^3, 
    "D"^2*"H\[Dagger]"*"L"*"Q"^3*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"^2*"ec"*"ec\[Dagger]"^2*"H"*"Q"^3, "D"^2*"H"*"Q"^2*"Q\[Dagger]"*"uc"^2*
     "uc\[Dagger]", "D"^2*"dc"*"dc\[Dagger]"*"H"*"Q"^2*"Q\[Dagger]"*"uc", 
    "D"^2*"dc"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"Q"^2*"uc", 
    "D"^2*"dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"H"*"L"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc", 
    "D"^2*"dc\[Dagger]"*"H"*"L"*"Q"^2*"uc"*"uc\[Dagger]", 
    "D"^2*"H\[Dagger]"*"L"*"Q"^2*"uc"*"uc\[Dagger]"^2, 
    "D"^2*"ec"*"ec\[Dagger]"*"H"*"Q"^2*"Q\[Dagger]"*"uc", 
    "D"^2*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "D"^2*"dc"^2*"ec\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "D"^2*"dc"*"dc\[Dagger]"^2*"H"*"L"*"Q"^2, "D"^2*"dc"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"^2*"Q\[Dagger]", "D"^2*"dc"*"dc\[Dagger]"*"H\[Dagger]"*
     "L"*"Q"^2*"uc\[Dagger]", "D"^2*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*
     "Q"^2*"Q\[Dagger]", "D"^2*"dc\[Dagger]"*"H"*"L"^2*"L\[Dagger]"*"Q"^2, 
    "D"^2*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"L"*"Q"^2, 
    "D"^2*"ec"*"H\[Dagger]"*"L"*"Q"^2*"Q\[Dagger]"^2, 
    "D"^2*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]", 
    "D"^2*"H"*"Q"*"uc"^3*"uc\[Dagger]"^2, "D"^2*"dc"*"H"*"L\[Dagger]"*"Q"*
     "Q\[Dagger]"*"uc"^2, "D"^2*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc"^2*
     "uc\[Dagger]", "D"^2*"dc"*"H\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]"^2, 
    "D"^2*"H"*"L"*"L\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]", 
    "D"^2*"ec"*"H"*"Q"*"Q\[Dagger]"^2*"uc"^2, "D"^2*"ec"*"ec\[Dagger]"*"H"*
     "Q"*"uc"^2*"uc\[Dagger]", "D"^2*"dc"^2*"dc\[Dagger]"^2*"H"*"Q"*"uc", 
    "D"^2*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc", 
    "D"^2*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "D"^2*"dc"*"dc\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "D"^2*"dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "D"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc", 
    "D"^2*"dc"*"ec"*"H\[Dagger]"*"Q"*"Q\[Dagger]"^2*"uc", 
    "D"^2*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "D"^2*"H"*"L"^2*"L\[Dagger]"^2*"Q"*"uc", "D"^2*"dc\[Dagger]"*"ec"*"H"*"L"*
     "Q"*"Q\[Dagger]"*"uc", "D"^2*"ec"*"ec\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q"*
     "uc", "D"^2*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"ec"^2*"ec\[Dagger]"^2*"H"*"Q"*"uc", "D"^2*"dc"^3*"dc\[Dagger]"^2*
     "H\[Dagger]"*"Q", "D"^2*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q", "D"^2*"dc"^2*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*
     "H\[Dagger]"*"Q", "D"^2*"dc"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2*"Q", 
    "D"^2*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "D"^2*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "D"^2*"dc"*"ec"^2*"ec\[Dagger]"^2*"H\[Dagger]"*"Q", 
    "D"^2*"dc\[Dagger]"^2*"ec"*"H"*"L"^2*"Q", "D"^2*"ec"*"H\[Dagger]"*"L"^2*
     "L\[Dagger]"*"Q"*"Q\[Dagger]", "D"^2*"dc\[Dagger]"*"ec"*"H\[Dagger]"*
     "L"^2*"Q"*"uc\[Dagger]", "D"^2*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"Q"*
     "Q\[Dagger]", "D"^2*"dc"*"H"*"L\[Dagger]"*"uc"^3*"uc\[Dagger]", 
    "D"^2*"ec"*"H"*"Q\[Dagger]"*"uc"^3*"uc\[Dagger]", 
    "D"^2*"dc"^2*"dc\[Dagger]"*"H"*"L\[Dagger]"*"uc"^2, 
    "D"^2*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "D"^2*"dc"*"H"*"L"*"L\[Dagger]"^2*"uc"^2, "D"^2*"dc"*"dc\[Dagger]"*"ec"*
     "H"*"Q\[Dagger]"*"uc"^2, "D"^2*"dc"*"ec"*"ec\[Dagger]"*"H"*"L\[Dagger]"*
     "uc"^2, "D"^2*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "D"^2*"ec"*"H"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2, 
    "D"^2*"dc\[Dagger]"*"ec"*"H"*"L"*"uc"^2*"uc\[Dagger]", 
    "D"^2*"ec"*"H\[Dagger]"*"L"*"uc"^2*"uc\[Dagger]"^2, 
    "D"^2*"ec"^2*"ec\[Dagger]"*"H"*"Q\[Dagger]"*"uc"^2, 
    "D"^2*"dc"^3*"dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "D"^2*"dc"^2*"H\[Dagger]"*"L"*"L\[Dagger]"^2*"uc", 
    "D"^2*"dc"^2*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "D"^2*"dc"^2*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "D"^2*"dc"*"dc\[Dagger]"^2*"ec"*"H"*"L"*"uc", 
    "D"^2*"dc"*"ec"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "D"^2*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", 
    "D"^2*"dc"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "D"^2*"dc\[Dagger]"*"ec"*"H"*"L"^2*"L\[Dagger]"*"uc", 
    "D"^2*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"H"*"L"*"uc", 
    "D"^2*"ec"^2*"H\[Dagger]"*"L"*"Q\[Dagger]"^2*"uc", 
    "D"^2*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", 
    "D"^2*"dc"^2*"dc\[Dagger]"^2*"ec"*"H\[Dagger]"*"L", 
    "D"^2*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]", 
    "D"^2*"dc"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L", 
    "D"^2*"ec"*"H\[Dagger]"*"L"^3*"L\[Dagger]"^2, "D"^2*"dc\[Dagger]"*"ec"^2*
     "H\[Dagger]"*"L"^2*"Q\[Dagger]", "D"^2*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*
     "L"^2*"L\[Dagger]", "D"^2*"ec"^3*"ec\[Dagger]"^2*"H\[Dagger]"*"L"}, 
  D^2*FR*\[Phi]^2*\[Psi]^4 -> {"D"^2*"GR"*"H"*"H\[Dagger]"*"L"*"Q"^3, 
    "D"^2*"H"*"H\[Dagger]"*"L"*"Q"^3*"WR", "BR"*"D"^2*"H"*"H\[Dagger]"*"L"*
     "Q"^3, "D"^2*"GR"*"H"^2*"Q"^2*"uc"^2, "D"^2*"H"^2*"Q"^2*"uc"^2*"WR", 
    "BR"*"D"^2*"H"^2*"Q"^2*"uc"^2, "D"^2*"dc"*"GR"*"H"*"H\[Dagger]"*"Q"^2*
     "uc", "D"^2*"dc"*"H"*"H\[Dagger]"*"Q"^2*"uc"*"WR", 
    "BR"*"D"^2*"dc"*"H"*"H\[Dagger]"*"Q"^2*"uc", 
    "D"^2*"dc"^2*"GR"*"H\[Dagger]"^2*"Q"^2, "D"^2*"dc"^2*"H\[Dagger]"^2*"Q"^2*
     "WR", "BR"*"D"^2*"dc"^2*"H\[Dagger]"^2*"Q"^2, 
    "D"^2*"ec"*"GR"*"H"*"H\[Dagger]"*"L"*"Q"*"uc", 
    "D"^2*"ec"*"H"*"H\[Dagger]"*"L"*"Q"*"uc"*"WR", 
    "BR"*"D"^2*"ec"*"H"*"H\[Dagger]"*"L"*"Q"*"uc", 
    "D"^2*"dc"*"ec"*"GR"*"H\[Dagger]"^2*"L"*"Q", 
    "D"^2*"dc"*"ec"*"H\[Dagger]"^2*"L"*"Q"*"WR", "BR"*"D"^2*"dc"*"ec"*
     "H\[Dagger]"^2*"L"*"Q", "D"^2*"ec"*"GR"*"H"^2*"uc"^3, 
    "D"^2*"ec"*"H"^2*"uc"^3*"WR", "BR"*"D"^2*"ec"*"H"^2*"uc"^3, 
    "D"^2*"dc"*"ec"*"GR"*"H"*"H\[Dagger]"*"uc"^2, 
    "D"^2*"dc"*"ec"*"H"*"H\[Dagger]"*"uc"^2*"WR", "BR"*"D"^2*"dc"*"ec"*"H"*
     "H\[Dagger]"*"uc"^2, "D"^2*"dc"^2*"ec"*"GR"*"H\[Dagger]"^2*"uc", 
    "D"^2*"dc"^2*"ec"*"H\[Dagger]"^2*"uc"*"WR", "BR"*"D"^2*"dc"^2*"ec"*
     "H\[Dagger]"^2*"uc", "D"^2*"ec"^2*"H\[Dagger]"^2*"L"^2*"WR", 
    "BR"*"D"^2*"ec"^2*"H\[Dagger]"^2*"L"^2}, 
  D^2*FL*\[Phi]^2*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"D"^2*"dc\[Dagger]"*"ec\[Dagger]"*"GL"*"H"^2*"Q"^2, 
    "D"^2*"GL"*"H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, 
    "D"^2*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"GL"*"H"^2*"Q"*"Q\[Dagger]"*"uc", 
    "D"^2*"ec\[Dagger]"*"GL"*"H"^2*"L\[Dagger]"*"Q"*"uc", 
    "D"^2*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"^2*"dc"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q", 
    "D"^2*"dc"*"GL"*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"^2*"GL"*"H"^2*"L"*"Q", "D"^2*"GL"*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"*"Q\[Dagger]", "D"^2*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*
     "L"*"Q"*"uc\[Dagger]", "D"^2*"GL"*"H\[Dagger]"^2*"L"*"Q"*
     "uc\[Dagger]"^2, "D"^2*"ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"Q"*
     "Q\[Dagger]", "D"^2*"GL"*"H"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2, 
    "D"^2*"dc\[Dagger]"*"GL"*"H"^2*"uc"^2*"uc\[Dagger]", 
    "D"^2*"GL"*"H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "D"^2*"dc"*"dc\[Dagger]"^2*"GL"*"H"^2*"uc", "D"^2*"dc"*"GL"*"H"*
     "H\[Dagger]"*"L\[Dagger]"*"Q\[Dagger]"*"uc", "D"^2*"dc"*"dc\[Dagger]"*
     "GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", "D"^2*"dc"*"GL"*"H\[Dagger]"^2*
     "uc"*"uc\[Dagger]"^2, "D"^2*"dc\[Dagger]"*"GL"*"H"^2*"L"*"L\[Dagger]"*
     "uc", "D"^2*"GL"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"H"^2*"uc", 
    "D"^2*"ec"*"GL"*"H"*"H\[Dagger]"*"Q\[Dagger]"^2*"uc", 
    "D"^2*"ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"dc"^2*"dc\[Dagger]"^2*"GL"*"H"*"H\[Dagger]", 
    "D"^2*"dc"^2*"GL"*"H\[Dagger]"^2*"L\[Dagger]"*"Q\[Dagger]", 
    "D"^2*"dc"^2*"dc\[Dagger]"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "D"^2*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "D"^2*"dc"*"GL"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc\[Dagger]", 
    "D"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]", 
    "D"^2*"dc"*"ec"*"GL"*"H\[Dagger]"^2*"Q\[Dagger]"^2, 
    "D"^2*"dc"*"ec"*"ec\[Dagger]"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"ec"*"GL"*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]", 
    "D"^2*"ec"*"GL"*"H\[Dagger]"^2*"L"*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"Q"^2*"WL", 
    "D"^2*"H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2*"WL", 
    "D"^2*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL", 
    "D"^2*"dc\[Dagger]"*"H"^2*"Q"*"Q\[Dagger]"*"uc"*"WL", 
    "D"^2*"ec\[Dagger]"*"H"^2*"L\[Dagger]"*"Q"*"uc"*"WL", 
    "D"^2*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"^2*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"^2*"dc"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q"*"WL", 
    "D"^2*"dc"*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "D"^2*"dc\[Dagger]"^2*"H"^2*"L"*"Q"*"WL", "D"^2*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", "D"^2*"dc\[Dagger]"*"H"*"H\[Dagger]"*
     "L"*"Q"*"uc\[Dagger]"*"WL", "D"^2*"H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"^2*
     "WL", "D"^2*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "D"^2*"H"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2*"WL", 
    "D"^2*"dc\[Dagger]"*"H"^2*"uc"^2*"uc\[Dagger]"*"WL", 
    "D"^2*"H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2*"WL", 
    "D"^2*"dc"*"dc\[Dagger]"^2*"H"^2*"uc"*"WL", "D"^2*"dc"*"H"*"H\[Dagger]"*
     "L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", "D"^2*"dc"*"dc\[Dagger]"*"H"*
     "H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", "D"^2*"dc"*"H\[Dagger]"^2*"uc"*
     "uc\[Dagger]"^2*"WL", "D"^2*"dc\[Dagger]"*"H"^2*"L"*"L\[Dagger]"*"uc"*
     "WL", "D"^2*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"^2*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*"uc"*"WL", 
    "D"^2*"ec"*"H"*"H\[Dagger]"*"Q\[Dagger]"^2*"uc"*"WL", 
    "D"^2*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "D"^2*"dc"^2*"dc\[Dagger]"^2*"H"*"H\[Dagger]"*"WL", 
    "D"^2*"dc"^2*"H\[Dagger]"^2*"L\[Dagger]"*"Q\[Dagger]"*"WL", 
    "D"^2*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "D"^2*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "D"^2*"dc"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc\[Dagger]"*"WL", 
    "D"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL", 
    "D"^2*"dc"*"ec"*"H\[Dagger]"^2*"Q\[Dagger]"^2*"WL", 
    "D"^2*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "D"^2*"H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2*"WL", 
    "D"^2*"dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]"*"WL", 
    "D"^2*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "D"^2*"ec"*"H\[Dagger]"^2*"L"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "D"^2*"ec"^2*"ec\[Dagger]"^2*"H"*"H\[Dagger]"*"WL", 
    "BL"*"D"^2*"dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"Q"^2, 
    "BL"*"D"^2*"H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, 
    "BL"*"D"^2*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "BL"*"D"^2*"dc\[Dagger]"*"H"^2*"Q"*"Q\[Dagger]"*"uc", 
    "BL"*"D"^2*"ec\[Dagger]"*"H"^2*"L\[Dagger]"*"Q"*"uc", 
    "BL"*"D"^2*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"^2*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"D"^2*"dc"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q", 
    "BL"*"D"^2*"dc"*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]", 
    "BL"*"D"^2*"dc\[Dagger]"^2*"H"^2*"L"*"Q", "BL"*"D"^2*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"*"Q\[Dagger]", "BL"*"D"^2*"dc\[Dagger]"*"H"*"H\[Dagger]"*
     "L"*"Q"*"uc\[Dagger]", "BL"*"D"^2*"H\[Dagger]"^2*"L"*"Q"*
     "uc\[Dagger]"^2, "BL"*"D"^2*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"*
     "Q\[Dagger]", "BL"*"D"^2*"H"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2, 
    "BL"*"D"^2*"dc\[Dagger]"*"H"^2*"uc"^2*"uc\[Dagger]", 
    "BL"*"D"^2*"H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "BL"*"D"^2*"dc"*"dc\[Dagger]"^2*"H"^2*"uc", "BL"*"D"^2*"dc"*"H"*
     "H\[Dagger]"*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "BL"*"D"^2*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"^2*"dc"*"H\[Dagger]"^2*"uc"*"uc\[Dagger]"^2, 
    "BL"*"D"^2*"dc\[Dagger]"*"H"^2*"L"*"L\[Dagger]"*"uc", 
    "BL"*"D"^2*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"^2*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*"uc", 
    "BL"*"D"^2*"ec"*"H"*"H\[Dagger]"*"Q\[Dagger]"^2*"uc", 
    "BL"*"D"^2*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"D"^2*"dc"^2*"dc\[Dagger]"^2*"H"*"H\[Dagger]", 
    "BL"*"D"^2*"dc"^2*"H\[Dagger]"^2*"L\[Dagger]"*"Q\[Dagger]", 
    "BL"*"D"^2*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "BL"*"D"^2*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"*"D"^2*"dc"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc\[Dagger]", 
    "BL"*"D"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]", 
    "BL"*"D"^2*"dc"*"ec"*"H\[Dagger]"^2*"Q\[Dagger]"^2, 
    "BL"*"D"^2*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "BL"*"D"^2*"H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2, 
    "BL"*"D"^2*"dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]", 
    "BL"*"D"^2*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"*"D"^2*"ec"*"H\[Dagger]"^2*"L"*"Q\[Dagger]"*"uc\[Dagger]", 
    "BL"*"D"^2*"ec"^2*"ec\[Dagger]"^2*"H"*"H\[Dagger]"}, 
  D^2*FL*FR*\[Phi]^3*\[Psi]^2 -> {"D"^2*"GL"*"GR"*"H"^2*"H\[Dagger]"*"Q"*
     "uc", "D"^2*"GL"*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WR", 
    "BR"*"D"^2*"GL"*"H"^2*"H\[Dagger]"*"Q"*"uc", "D"^2*"dc"*"GL"*"GR"*"H"*
     "H\[Dagger]"^2*"Q", "D"^2*"dc"*"GL"*"H"*"H\[Dagger]"^2*"Q"*"WR", 
    "BR"*"D"^2*"dc"*"GL"*"H"*"H\[Dagger]"^2*"Q", "D"^2*"ec"*"GL"*"GR"*"H"*
     "H\[Dagger]"^2*"L", "D"^2*"GR"*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WL", 
    "D"^2*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WL"*"WR", 
    "BR"*"D"^2*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WL", "D"^2*"dc"*"GR"*"H"*
     "H\[Dagger]"^2*"Q"*"WL", "D"^2*"dc"*"H"*"H\[Dagger]"^2*"Q"*"WL"*"WR", 
    "BR"*"D"^2*"dc"*"H"*"H\[Dagger]"^2*"Q"*"WL", 
    "D"^2*"ec"*"H"*"H\[Dagger]"^2*"L"*"WL"*"WR", "BR"*"D"^2*"ec"*"H"*
     "H\[Dagger]"^2*"L"*"WL", "BL"*"D"^2*"GR"*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "BL"*"D"^2*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WR", "BL"*"BR"*"D"^2*"H"^2*
     "H\[Dagger]"*"Q"*"uc", "BL"*"D"^2*"dc"*"GR"*"H"*"H\[Dagger]"^2*"Q", 
    "BL"*"D"^2*"dc"*"H"*"H\[Dagger]"^2*"Q"*"WR", "BL"*"BR"*"D"^2*"dc"*"H"*
     "H\[Dagger]"^2*"Q", "BL"*"D"^2*"ec"*"H"*"H\[Dagger]"^2*"L"*"WR", 
    "BL"*"BR"*"D"^2*"ec"*"H"*"H\[Dagger]"^2*"L"}, 
  D^2*FL^2*\[Phi]^3*OverBar[\[Psi]]^2 -> 
   {"D"^2*"dc\[Dagger]"*"GL"^2*"H"^2*"H\[Dagger]"*"Q\[Dagger]", 
    "D"^2*"ec\[Dagger]"*"GL"^2*"H"^2*"H\[Dagger]"*"L\[Dagger]", 
    "D"^2*"GL"^2*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"WL", 
    "D"^2*"GL"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"D"^2*"dc\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"*"Q\[Dagger]", 
    "BL"*"D"^2*"GL"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"WL"^2, 
    "D"^2*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"L\[Dagger]"*"WL"^2, 
    "D"^2*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, 
    "BL"*"D"^2*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"WL", 
    "BL"*"D"^2*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"L\[Dagger]"*"WL", 
    "BL"*"D"^2*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"^2*"D"^2*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"Q\[Dagger]", 
    "BL"^2*"D"^2*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"L\[Dagger]", 
    "BL"^2*"D"^2*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]"}, 
  D^2*FL^2*FR*\[Phi]^4 -> {"D"^2*"GL"^2*"GR"*"H"^2*"H\[Dagger]"^2, 
    "D"^2*"GL"^2*"H"^2*"H\[Dagger]"^2*"WR", "BR"*"D"^2*"GL"^2*"H"^2*
     "H\[Dagger]"^2, "D"^2*"GL"*"GR"*"H"^2*"H\[Dagger]"^2*"WL", 
    "BL"*"D"^2*"GL"*"GR"*"H"^2*"H\[Dagger]"^2, "D"^2*"H"^2*"H\[Dagger]"^2*
     "WL"^2*"WR", "BR"*"D"^2*"H"^2*"H\[Dagger]"^2*"WL"^2, 
    "BL"*"D"^2*"H"^2*"H\[Dagger]"^2*"WL"*"WR", "BL"*"BR"*"D"^2*"H"^2*
     "H\[Dagger]"^2*"WL", "BL"^2*"D"^2*"H"^2*"H\[Dagger]"^2*"WR", 
    "BL"^2*"BR"*"D"^2*"H"^2*"H\[Dagger]"^2}, 
  D^3*\[Phi]^3*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"^3*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"^3, "D"^3*"H"^2*"H\[Dagger]"*
     "Q"^2*"Q\[Dagger]"*"uc", "D"^3*"dc"*"H"*"H\[Dagger]"^2*"Q"^2*
     "Q\[Dagger]", "D"^3*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"L"*"Q"^2, 
    "D"^3*"H"*"H\[Dagger]"^2*"L"*"Q"^2*"uc\[Dagger]", 
    "D"^3*"dc\[Dagger]"*"H"^3*"Q"*"uc"^2, "D"^3*"H"^2*"H\[Dagger]"*"Q"*"uc"^2*
     "uc\[Dagger]", "D"^3*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "D"^3*"dc"*"H"*"H\[Dagger]"^2*"Q"*"uc"*"uc\[Dagger]", 
    "D"^3*"H"^2*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "D"^3*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "D"^3*"dc"^2*"dc\[Dagger]"*"H"*"H\[Dagger]"^2*"Q", 
    "D"^3*"dc"^2*"H\[Dagger]"^3*"Q"*"uc\[Dagger]", 
    "D"^3*"dc"*"H"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"Q", 
    "D"^3*"dc"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"Q", 
    "D"^3*"ec"*"H"*"H\[Dagger]"^2*"L"*"Q"*"Q\[Dagger]", 
    "D"^3*"H"^3*"L\[Dagger]"*"uc"^3, "D"^3*"dc"*"H"^2*"H\[Dagger]"*
     "L\[Dagger]"*"uc"^2, "D"^3*"ec"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc"^2, 
    "D"^3*"dc"^2*"H"*"H\[Dagger]"^2*"L\[Dagger]"*"uc", 
    "D"^3*"dc"*"ec"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc", 
    "D"^3*"dc\[Dagger]"*"ec"*"H"^2*"H\[Dagger]"*"L"*"uc", 
    "D"^3*"ec"*"H"*"H\[Dagger]"^2*"L"*"uc"*"uc\[Dagger]", 
    "D"^3*"dc"^3*"H\[Dagger]"^3*"L\[Dagger]", "D"^3*"dc"^2*"ec"*
     "H\[Dagger]"^3*"Q\[Dagger]", "D"^3*"dc"*"dc\[Dagger]"*"ec"*"H"*
     "H\[Dagger]"^2*"L", "D"^3*"dc"*"ec"*"H\[Dagger]"^3*"L"*"uc\[Dagger]", 
    "D"^3*"ec"*"H"*"H\[Dagger]"^2*"L"^2*"L\[Dagger]", 
    "D"^3*"ec"^2*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"L"}, 
  D^3*FL*\[Phi]^4*\[Psi]*OverBar[\[Psi]] -> 
   {"D"^3*"GL"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "D"^3*"dc\[Dagger]"*"GL"*"H"^3*"H\[Dagger]"*"uc", 
    "D"^3*"GL"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"^3*"dc"*"dc\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"^2, 
    "D"^3*"dc"*"GL"*"H"*"H\[Dagger]"^3*"uc\[Dagger]", 
    "D"^3*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"WL", 
    "D"^3*"dc\[Dagger]"*"H"^3*"H\[Dagger]"*"uc"*"WL", 
    "D"^3*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]"*"WL", 
    "D"^3*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2*"WL", 
    "D"^3*"dc"*"H"*"H\[Dagger]"^3*"uc\[Dagger]"*"WL", 
    "D"^3*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"WL", 
    "D"^3*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"WL", 
    "BL"*"D"^3*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "BL"*"D"^3*"dc\[Dagger]"*"H"^3*"H\[Dagger]"*"uc", 
    "BL"*"D"^3*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "BL"*"D"^3*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2, 
    "BL"*"D"^3*"dc"*"H"*"H\[Dagger]"^3*"uc\[Dagger]", 
    "BL"*"D"^3*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]", 
    "BL"*"D"^3*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2}, 
  D^4*\[Phi]^5*\[Psi]^2 -> {"D"^4*"H"^3*"H\[Dagger]"^2*"Q"*"uc", 
    "D"^4*"dc"*"H"^2*"H\[Dagger]"^3*"Q", "D"^4*"ec"*"H"^2*"H\[Dagger]"^3*
     "L"}, D^4*FL*\[Phi]^6 -> {"D"^4*"H"^3*"H\[Dagger]"^3*"WL", 
    "BL"*"D"^4*"H"^3*"H\[Dagger]"^3}, 
  \[Psi]^8 -> {"L"^2*"Q"^6, "dc"*"L"*"Q"^5*"uc", "dc"^2*"Q"^4*"uc"^2, 
    "ec"*"L"^2*"Q"^4*"uc", "dc"*"ec"*"L"*"Q"^3*"uc"^2, 
    "dc"^2*"ec"*"Q"^2*"uc"^3, "ec"^2*"L"^2*"Q"^2*"uc"^2, 
    "dc"*"ec"^2*"L"*"Q"*"uc"^3, "dc"^4*"L"^3*"Q", "dc"^2*"ec"^2*"uc"^4, 
    "ec"^3*"L"^2*"uc"^3, "dc"^5*"L"^2*"uc", "dc"^3*"ec"*"L"^4}, 
  FL*\[Phi]*\[Psi]^6 -> {"GL"*"H"*"L"*"Q"^4*"uc", "dc"*"GL"*"H\[Dagger]"*"L"*
     "Q"^4, "dc"*"GL"*"H"*"Q"^3*"uc"^2, "dc"^2*"GL"*"H\[Dagger]"*"Q"^3*"uc", 
    "ec"*"GL"*"H\[Dagger]"*"L"^2*"Q"^3, "ec"*"GL"*"H"*"L"*"Q"^2*"uc"^2, 
    "dc"*"ec"*"GL"*"H\[Dagger]"*"L"*"Q"^2*"uc", "dc"*"ec"*"GL"*"H"*"Q"*
     "uc"^3, "dc"^2*"ec"*"GL"*"H\[Dagger]"*"Q"*"uc"^2, 
    "ec"^2*"GL"*"H\[Dagger]"*"L"^2*"Q"*"uc", "ec"^2*"GL"*"H"*"L"*"uc"^3, 
    "dc"*"ec"^2*"GL"*"H\[Dagger]"*"L"*"uc"^2, "dc"^3*"GL"*"H"*"L"^3, 
    "H"*"L"*"Q"^4*"uc"*"WL", "dc"*"H\[Dagger]"*"L"*"Q"^4*"WL", 
    "dc"*"H"*"Q"^3*"uc"^2*"WL", "dc"^2*"H\[Dagger]"*"Q"^3*"uc"*"WL", 
    "ec"*"H\[Dagger]"*"L"^2*"Q"^3*"WL", "ec"*"H"*"L"*"Q"^2*"uc"^2*"WL", 
    "dc"*"ec"*"H\[Dagger]"*"L"*"Q"^2*"uc"*"WL", "dc"*"ec"*"H"*"Q"*"uc"^3*
     "WL", "dc"^2*"ec"*"H\[Dagger]"*"Q"*"uc"^2*"WL", 
    "ec"^2*"H\[Dagger]"*"L"^2*"Q"*"uc"*"WL", "ec"^2*"H"*"L"*"uc"^3*"WL", 
    "dc"*"ec"^2*"H\[Dagger]"*"L"*"uc"^2*"WL", "dc"^3*"H"*"L"^3*"WL", 
    "BL"*"H"*"L"*"Q"^4*"uc", "BL"*"dc"*"H\[Dagger]"*"L"*"Q"^4, 
    "BL"*"dc"*"H"*"Q"^3*"uc"^2, "BL"*"dc"^2*"H\[Dagger]"*"Q"^3*"uc", 
    "BL"*"ec"*"H\[Dagger]"*"L"^2*"Q"^3, "BL"*"ec"*"H"*"L"*"Q"^2*"uc"^2, 
    "BL"*"dc"*"ec"*"H\[Dagger]"*"L"*"Q"^2*"uc", "BL"*"dc"*"ec"*"H"*"Q"*
     "uc"^3, "BL"*"dc"^2*"ec"*"H\[Dagger]"*"Q"*"uc"^2, 
    "BL"*"ec"^2*"H\[Dagger]"*"L"^2*"Q"*"uc", "BL"*"ec"^2*"H"*"L"*"uc"^3, 
    "BL"*"dc"*"ec"^2*"H\[Dagger]"*"L"*"uc"^2, "BL"*"dc"^3*"H"*"L"^3}, 
  FL^2*\[Phi]^2*\[Psi]^4 -> {"GL"^2*"H"*"H\[Dagger]"*"L"*"Q"^3, 
    "GL"^2*"H"^2*"Q"^2*"uc"^2, "dc"*"GL"^2*"H"*"H\[Dagger]"*"Q"^2*"uc", 
    "dc"^2*"GL"^2*"H\[Dagger]"^2*"Q"^2, "ec"*"GL"^2*"H"*"H\[Dagger]"*"L"*"Q"*
     "uc", "dc"*"ec"*"GL"^2*"H\[Dagger]"^2*"L"*"Q", "ec"*"GL"^2*"H"^2*"uc"^3, 
    "dc"*"ec"*"GL"^2*"H"*"H\[Dagger]"*"uc"^2, "dc"^2*"ec"*"GL"^2*
     "H\[Dagger]"^2*"uc", "ec"^2*"GL"^2*"H\[Dagger]"^2*"L"^2, 
    "GL"*"H"*"H\[Dagger]"*"L"*"Q"^3*"WL", "GL"*"H"^2*"Q"^2*"uc"^2*"WL", 
    "dc"*"GL"*"H"*"H\[Dagger]"*"Q"^2*"uc"*"WL", "dc"^2*"GL"*"H\[Dagger]"^2*
     "Q"^2*"WL", "ec"*"GL"*"H"*"H\[Dagger]"*"L"*"Q"*"uc"*"WL", 
    "dc"*"ec"*"GL"*"H\[Dagger]"^2*"L"*"Q"*"WL", "ec"*"GL"*"H"^2*"uc"^3*"WL", 
    "dc"*"ec"*"GL"*"H"*"H\[Dagger]"*"uc"^2*"WL", 
    "dc"^2*"ec"*"GL"*"H\[Dagger]"^2*"uc"*"WL", "BL"*"GL"*"H"*"H\[Dagger]"*"L"*
     "Q"^3, "BL"*"GL"*"H"^2*"Q"^2*"uc"^2, "BL"*"dc"*"GL"*"H"*"H\[Dagger]"*
     "Q"^2*"uc", "BL"*"dc"^2*"GL"*"H\[Dagger]"^2*"Q"^2, 
    "BL"*"ec"*"GL"*"H"*"H\[Dagger]"*"L"*"Q"*"uc", 
    "BL"*"dc"*"ec"*"GL"*"H\[Dagger]"^2*"L"*"Q", "BL"*"ec"*"GL"*"H"^2*"uc"^3, 
    "BL"*"dc"*"ec"*"GL"*"H"*"H\[Dagger]"*"uc"^2, "BL"*"dc"^2*"ec"*"GL"*
     "H\[Dagger]"^2*"uc", "H"*"H\[Dagger]"*"L"*"Q"^3*"WL"^2, 
    "H"^2*"Q"^2*"uc"^2*"WL"^2, "dc"*"H"*"H\[Dagger]"*"Q"^2*"uc"*"WL"^2, 
    "dc"^2*"H\[Dagger]"^2*"Q"^2*"WL"^2, "ec"*"H"*"H\[Dagger]"*"L"*"Q"*"uc"*
     "WL"^2, "dc"*"ec"*"H\[Dagger]"^2*"L"*"Q"*"WL"^2, 
    "ec"*"H"^2*"uc"^3*"WL"^2, "dc"*"ec"*"H"*"H\[Dagger]"*"uc"^2*"WL"^2, 
    "dc"^2*"ec"*"H\[Dagger]"^2*"uc"*"WL"^2, "ec"^2*"H\[Dagger]"^2*"L"^2*
     "WL"^2, "BL"*"H"*"H\[Dagger]"*"L"*"Q"^3*"WL", 
    "BL"*"H"^2*"Q"^2*"uc"^2*"WL", "BL"*"dc"*"H"*"H\[Dagger]"*"Q"^2*"uc"*"WL", 
    "BL"*"dc"^2*"H\[Dagger]"^2*"Q"^2*"WL", "BL"*"ec"*"H"*"H\[Dagger]"*"L"*"Q"*
     "uc"*"WL", "BL"*"dc"*"ec"*"H\[Dagger]"^2*"L"*"Q"*"WL", 
    "BL"*"ec"*"H"^2*"uc"^3*"WL", "BL"*"dc"*"ec"*"H"*"H\[Dagger]"*"uc"^2*"WL", 
    "BL"*"dc"^2*"ec"*"H\[Dagger]"^2*"uc"*"WL", "BL"*"ec"^2*"H\[Dagger]"^2*
     "L"^2*"WL", "BL"^2*"H"*"H\[Dagger]"*"L"*"Q"^3, 
    "BL"^2*"H"^2*"Q"^2*"uc"^2, "BL"^2*"dc"*"H"*"H\[Dagger]"*"Q"^2*"uc", 
    "BL"^2*"dc"^2*"H\[Dagger]"^2*"Q"^2, "BL"^2*"ec"*"H"*"H\[Dagger]"*"L"*"Q"*
     "uc", "BL"^2*"dc"*"ec"*"H\[Dagger]"^2*"L"*"Q", "BL"^2*"ec"*"H"^2*"uc"^3, 
    "BL"^2*"dc"*"ec"*"H"*"H\[Dagger]"*"uc"^2, "BL"^2*"dc"^2*"ec"*
     "H\[Dagger]"^2*"uc", "BL"^2*"ec"^2*"H\[Dagger]"^2*"L"^2}, 
  FL^3*\[Phi]^3*\[Psi]^2 -> {"GL"^3*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "dc"*"GL"^3*"H"*"H\[Dagger]"^2*"Q", "ec"*"GL"^3*"H"*"H\[Dagger]"^2*"L", 
    "GL"^2*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WL", "dc"*"GL"^2*"H"*"H\[Dagger]"^2*
     "Q"*"WL", "ec"*"GL"^2*"H"*"H\[Dagger]"^2*"L"*"WL", 
    "BL"*"GL"^2*"H"^2*"H\[Dagger]"*"Q"*"uc", "BL"*"dc"*"GL"^2*"H"*
     "H\[Dagger]"^2*"Q", "BL"*"ec"*"GL"^2*"H"*"H\[Dagger]"^2*"L", 
    "GL"*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WL"^2, "dc"*"GL"*"H"*"H\[Dagger]"^2*"Q"*
     "WL"^2, "BL"*"GL"*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WL", 
    "BL"*"dc"*"GL"*"H"*"H\[Dagger]"^2*"Q"*"WL", "BL"^2*"GL"*"H"^2*
     "H\[Dagger]"*"Q"*"uc", "BL"^2*"dc"*"GL"*"H"*"H\[Dagger]"^2*"Q", 
    "H"^2*"H\[Dagger]"*"Q"*"uc"*"WL"^3, "dc"*"H"*"H\[Dagger]"^2*"Q"*"WL"^3, 
    "ec"*"H"*"H\[Dagger]"^2*"L"*"WL"^3, "BL"*"H"^2*"H\[Dagger]"*"Q"*"uc"*
     "WL"^2, "BL"*"dc"*"H"*"H\[Dagger]"^2*"Q"*"WL"^2, 
    "BL"*"ec"*"H"*"H\[Dagger]"^2*"L"*"WL"^2, "BL"^2*"H"^2*"H\[Dagger]"*"Q"*
     "uc"*"WL", "BL"^2*"dc"*"H"*"H\[Dagger]"^2*"Q"*"WL", 
    "BL"^2*"ec"*"H"*"H\[Dagger]"^2*"L"*"WL", "BL"^3*"H"^2*"H\[Dagger]"*"Q"*
     "uc", "BL"^3*"dc"*"H"*"H\[Dagger]"^2*"Q", "BL"^3*"ec"*"H"*"H\[Dagger]"^2*
     "L"}, FL^4*\[Phi]^4 -> {"GL"^4*"H"^2*"H\[Dagger]"^2, 
    "GL"^3*"H"^2*"H\[Dagger]"^2*"WL", "BL"*"GL"^3*"H"^2*"H\[Dagger]"^2, 
    "GL"^2*"H"^2*"H\[Dagger]"^2*"WL"^2, "BL"*"GL"^2*"H"^2*"H\[Dagger]"^2*
     "WL", "BL"^2*"GL"^2*"H"^2*"H\[Dagger]"^2, "H"^2*"H\[Dagger]"^2*"WL"^4, 
    "BL"*"H"^2*"H\[Dagger]"^2*"WL"^3, "BL"^2*"H"^2*"H\[Dagger]"^2*"WL"^2, 
    "BL"^3*"H"^2*"H\[Dagger]"^2*"WL", "BL"^4*"H"^2*"H\[Dagger]"^2}, 
  \[Psi]^6*OverBar[\[Psi]]^2 -> {"dc"*"ec\[Dagger]"*"Q"^5*"Q\[Dagger]", 
    "L"*"Q"^5*"Q\[Dagger]"^2, "ec\[Dagger]"*"L"*"Q"^5*"uc\[Dagger]", 
    "dc"*"Q"^4*"Q\[Dagger]"^2*"uc", "dc"*"ec\[Dagger]"*"Q"^4*"uc"*
     "uc\[Dagger]", "L"*"Q"^4*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"*"ec\[Dagger]"*"Q"^4, "dc"*"dc\[Dagger]"*"L"*"Q"^4*
     "Q\[Dagger]", "dc"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"Q"^4, 
    "dc"*"ec"*"ec\[Dagger]"^2*"Q"^4, "L"^2*"L\[Dagger]"*"Q"^4*"Q\[Dagger]", 
    "dc\[Dagger]"*"L"^2*"Q"^4*"uc\[Dagger]", "ec"*"ec\[Dagger]"*"L"*"Q"^4*
     "Q\[Dagger]", "dc"*"Q"^3*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "L"*"Q"^3*"uc"^2*"uc\[Dagger]"^2, "dc"^2*"dc\[Dagger]"*"Q"^3*"Q\[Dagger]"*
     "uc", "dc"^2*"ec\[Dagger]"*"L\[Dagger]"*"Q"^3*"uc", 
    "dc"*"L"*"L\[Dagger]"*"Q"^3*"Q\[Dagger]"*"uc", 
    "dc"*"dc\[Dagger]"*"L"*"Q"^3*"uc"*"uc\[Dagger]", 
    "dc"*"ec"*"ec\[Dagger]"*"Q"^3*"Q\[Dagger]"*"uc", 
    "L"^2*"L\[Dagger]"*"Q"^3*"uc"*"uc\[Dagger]", 
    "ec"*"L"*"Q"^3*"Q\[Dagger]"^2*"uc", "ec"*"ec\[Dagger]"*"L"*"Q"^3*"uc"*
     "uc\[Dagger]", "dc"^2*"dc\[Dagger]"^2*"L"*"Q"^3, 
    "dc"*"dc\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"^3, "dc"*"dc\[Dagger]"*"ec"*
     "ec\[Dagger]"*"L"*"Q"^3, "L"^3*"L\[Dagger]"^2*"Q"^3, 
    "dc\[Dagger]"*"ec"*"L"^2*"Q"^3*"Q\[Dagger]", "ec"*"ec\[Dagger]"*"L"^2*
     "L\[Dagger]"*"Q"^3, "ec"^2*"ec\[Dagger]"^2*"L"*"Q"^3, 
    "dc"*"Q"^2*"uc"^3*"uc\[Dagger]"^2, "dc"^2*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"*
     "uc"^2, "dc"^2*"dc\[Dagger]"*"Q"^2*"uc"^2*"uc\[Dagger]", 
    "dc"*"L"*"L\[Dagger]"*"Q"^2*"uc"^2*"uc\[Dagger]", 
    "dc"*"ec"*"Q"^2*"Q\[Dagger]"^2*"uc"^2, "dc"*"ec"*"ec\[Dagger]"*"Q"^2*
     "uc"^2*"uc\[Dagger]", "ec"*"L"*"Q"^2*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "dc"^3*"dc\[Dagger]"^2*"Q"^2*"uc", "dc"^2*"dc\[Dagger]"*"L"*"L\[Dagger]"*
     "Q"^2*"uc", "dc"^2*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"Q"^2*"uc", 
    "dc"*"L"^2*"L\[Dagger]"^2*"Q"^2*"uc", "dc"*"dc\[Dagger]"*"ec"*"L"*"Q"^2*
     "Q\[Dagger]"*"uc", "dc"*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"Q"^2*"uc", 
    "dc"*"ec"^2*"ec\[Dagger]"^2*"Q"^2*"uc", "ec"*"L"^2*"L\[Dagger]"*"Q"^2*
     "Q\[Dagger]"*"uc", "dc\[Dagger]"*"ec"*"L"^2*"Q"^2*"uc"*"uc\[Dagger]", 
    "ec"^2*"ec\[Dagger]"*"L"*"Q"^2*"Q\[Dagger]"*"uc", 
    "dc"*"dc\[Dagger]"^2*"ec"*"L"^2*"Q"^2, "dc\[Dagger]"*"ec"*"L"^3*
     "L\[Dagger]"*"Q"^2, "dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"L"^2*"Q"^2, 
    "dc"^2*"L\[Dagger]"*"Q"*"uc"^3*"uc\[Dagger]", "dc"*"ec"*"Q"*"Q\[Dagger]"*
     "uc"^3*"uc\[Dagger]", "ec"*"L"*"Q"*"uc"^3*"uc\[Dagger]"^2, 
    "dc"^3*"dc\[Dagger]"*"L\[Dagger]"*"Q"*"uc"^2, "dc"^2*"L"*"L\[Dagger]"^2*
     "Q"*"uc"^2, "dc"^2*"dc\[Dagger]"*"ec"*"Q"*"Q\[Dagger]"*"uc"^2, 
    "dc"^2*"ec"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"uc"^2, 
    "dc"*"ec"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"^2, 
    "dc"*"dc\[Dagger]"*"ec"*"L"*"Q"*"uc"^2*"uc\[Dagger]", 
    "dc"*"ec"^2*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"^2, 
    "ec"*"L"^2*"L\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]", 
    "ec"^2*"L"*"Q"*"Q\[Dagger]"^2*"uc"^2, "ec"^2*"ec\[Dagger]"*"L"*"Q"*"uc"^2*
     "uc\[Dagger]", "dc"^2*"dc\[Dagger]"^2*"ec"*"L"*"Q"*"uc", 
    "dc"*"dc\[Dagger]"*"ec"*"L"^2*"L\[Dagger]"*"Q"*"uc", 
    "dc"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"L"*"Q"*"uc", 
    "ec"*"L"^3*"L\[Dagger]"^2*"Q"*"uc", "dc\[Dagger]"*"ec"^2*"L"^2*"Q"*
     "Q\[Dagger]"*"uc", "ec"^2*"ec\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"*"uc", 
    "ec"^3*"ec\[Dagger]"^2*"L"*"Q"*"uc", "dc\[Dagger]"^2*"ec"^2*"L"^3*"Q", 
    "dc"*"ec"*"uc"^4*"uc\[Dagger]"^2, "dc"^3*"L\[Dagger]"^2*"uc"^3, 
    "dc"^2*"ec"*"L\[Dagger]"*"Q\[Dagger]"*"uc"^3, "dc"^2*"dc\[Dagger]"*"ec"*
     "uc"^3*"uc\[Dagger]", "dc"*"ec"*"L"*"L\[Dagger]"*"uc"^3*"uc\[Dagger]", 
    "dc"*"ec"^2*"Q\[Dagger]"^2*"uc"^3, "dc"*"ec"^2*"ec\[Dagger]"*"uc"^3*
     "uc\[Dagger]", "ec"^2*"L"*"Q\[Dagger]"*"uc"^3*"uc\[Dagger]", 
    "dc"^3*"dc\[Dagger]"^2*"ec"*"uc"^2, "dc"^2*"dc\[Dagger]"*"ec"*"L"*
     "L\[Dagger]"*"uc"^2, "dc"^2*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"uc"^2, 
    "dc"*"ec"*"L"^2*"L\[Dagger]"^2*"uc"^2, "dc"*"dc\[Dagger]"*"ec"^2*"L"*
     "Q\[Dagger]"*"uc"^2, "dc"*"ec"^2*"ec\[Dagger]"*"L"*"L\[Dagger]"*"uc"^2, 
    "dc"*"ec"^3*"ec\[Dagger]"^2*"uc"^2, "ec"^2*"L"^2*"L\[Dagger]"*
     "Q\[Dagger]"*"uc"^2, "dc\[Dagger]"*"ec"^2*"L"^2*"uc"^2*"uc\[Dagger]", 
    "ec"^3*"ec\[Dagger]"*"L"*"Q\[Dagger]"*"uc"^2, "dc"*"dc\[Dagger]"^2*"ec"^2*
     "L"^2*"uc", "dc\[Dagger]"*"ec"^2*"L"^3*"L\[Dagger]"*"uc", 
    "dc\[Dagger]"*"ec"^3*"ec\[Dagger]"*"L"^2*"uc", "dc"^6*"ec\[Dagger]"^2, 
    "dc"^5*"ec\[Dagger]"*"L"*"Q\[Dagger]", "dc"^4*"L"^2*"Q\[Dagger]"^2, 
    "dc"^4*"ec\[Dagger]"*"L"^2*"uc\[Dagger]", "dc"^3*"L"^3*"Q\[Dagger]"*
     "uc\[Dagger]", "dc"^2*"L"^4*"uc\[Dagger]"^2}, 
  FL*\[Phi]*\[Psi]^4*OverBar[\[Psi]]^2 -> 
   {"ec\[Dagger]"*"GL"*"H"*"Q"^4*"Q\[Dagger]", "GL"*"H"*"Q"^3*"Q\[Dagger]"^2*
     "uc", "ec\[Dagger]"*"GL"*"H"*"Q"^3*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec\[Dagger]"*"GL"*"H"*"Q"^3, 
    "dc"*"GL"*"H\[Dagger]"*"Q"^3*"Q\[Dagger]"^2, "dc"*"ec\[Dagger]"*"GL"*
     "H\[Dagger]"*"Q"^3*"uc\[Dagger]", "dc\[Dagger]"*"GL"*"H"*"L"*"Q"^3*
     "Q\[Dagger]", "ec\[Dagger]"*"GL"*"H"*"L"*"L\[Dagger]"*"Q"^3, 
    "GL"*"H\[Dagger]"*"L"*"Q"^3*"Q\[Dagger]"*"uc\[Dagger]", 
    "ec"*"ec\[Dagger]"^2*"GL"*"H"*"Q"^3, "GL"*"H"*"Q"^2*"Q\[Dagger]"*"uc"^2*
     "uc\[Dagger]", "dc"*"dc\[Dagger]"*"GL"*"H"*"Q"^2*"Q\[Dagger]"*"uc", 
    "dc"*"ec\[Dagger]"*"GL"*"H"*"L\[Dagger]"*"Q"^2*"uc", 
    "dc"*"GL"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "GL"*"H"*"L"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc", 
    "dc\[Dagger]"*"GL"*"H"*"L"*"Q"^2*"uc"*"uc\[Dagger]", 
    "GL"*"H\[Dagger]"*"L"*"Q"^2*"uc"*"uc\[Dagger]"^2, 
    "ec"*"ec\[Dagger]"*"GL"*"H"*"Q"^2*"Q\[Dagger]"*"uc", 
    "dc"^2*"dc\[Dagger]"*"GL"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "dc"^2*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "dc"*"dc\[Dagger]"^2*"GL"*"H"*"L"*"Q"^2, "dc"*"GL"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"^2*"Q\[Dagger]", "dc"*"dc\[Dagger]"*"GL"*"H\[Dagger]"*
     "L"*"Q"^2*"uc\[Dagger]", "dc"*"ec"*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"Q"^2*
     "Q\[Dagger]", "dc\[Dagger]"*"GL"*"H"*"L"^2*"L\[Dagger]"*"Q"^2, 
    "GL"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"H"*"L"*"Q"^2, 
    "ec"*"GL"*"H\[Dagger]"*"L"*"Q"^2*"Q\[Dagger]"^2, 
    "ec"*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]", 
    "GL"*"H"*"Q"*"uc"^3*"uc\[Dagger]"^2, "dc"*"GL"*"H"*"L\[Dagger]"*"Q"*
     "Q\[Dagger]"*"uc"^2, "dc"*"dc\[Dagger]"*"GL"*"H"*"Q"*"uc"^2*
     "uc\[Dagger]", "dc"*"GL"*"H\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]"^2, 
    "GL"*"H"*"L"*"L\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]", 
    "ec"*"GL"*"H"*"Q"*"Q\[Dagger]"^2*"uc"^2, "ec"*"ec\[Dagger]"*"GL"*"H"*"Q"*
     "uc"^2*"uc\[Dagger]", "dc"^2*"dc\[Dagger]"^2*"GL"*"H"*"Q"*"uc", 
    "dc"^2*"GL"*"H\[Dagger]"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc", 
    "dc"^2*"dc\[Dagger]"*"GL"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"GL"*"H"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "dc"*"GL"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"H"*"Q"*"uc", 
    "dc"*"ec"*"GL"*"H\[Dagger]"*"Q"*"Q\[Dagger]"^2*"uc", 
    "dc"*"ec"*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "GL"*"H"*"L"^2*"L\[Dagger]"^2*"Q"*"uc", "dc\[Dagger]"*"ec"*"GL"*"H"*"L"*
     "Q"*"Q\[Dagger]"*"uc", "ec"*"ec\[Dagger]"*"GL"*"H"*"L"*"L\[Dagger]"*"Q"*
     "uc", "ec"*"GL"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "ec"^2*"ec\[Dagger]"^2*"GL"*"H"*"Q"*"uc", "dc"^3*"dc\[Dagger]"^2*"GL"*
     "H\[Dagger]"*"Q", "dc"^2*"dc\[Dagger]"*"GL"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q", "dc"^2*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*
     "H\[Dagger]"*"Q", "dc"*"GL"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2*"Q", 
    "dc"*"dc\[Dagger]"*"ec"*"GL"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "dc"*"ec"*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "dc"*"ec"^2*"ec\[Dagger]"^2*"GL"*"H\[Dagger]"*"Q", 
    "dc\[Dagger]"^2*"ec"*"GL"*"H"*"L"^2*"Q", "ec"*"GL"*"H\[Dagger]"*"L"^2*
     "L\[Dagger]"*"Q"*"Q\[Dagger]", "dc\[Dagger]"*"ec"*"GL"*"H\[Dagger]"*
     "L"^2*"Q"*"uc\[Dagger]", "ec"^2*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"L"*"Q"*
     "Q\[Dagger]", "dc"*"GL"*"H"*"L\[Dagger]"*"uc"^3*"uc\[Dagger]", 
    "ec"*"GL"*"H"*"Q\[Dagger]"*"uc"^3*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"*"GL"*"H"*"L\[Dagger]"*"uc"^2, 
    "dc"^2*"GL"*"H\[Dagger]"*"L\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "dc"*"GL"*"H"*"L"*"L\[Dagger]"^2*"uc"^2, "dc"*"dc\[Dagger]"*"ec"*"GL"*"H"*
     "Q\[Dagger]"*"uc"^2, "dc"*"ec"*"ec\[Dagger]"*"GL"*"H"*"L\[Dagger]"*
     "uc"^2, "dc"*"ec"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "ec"*"GL"*"H"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2, 
    "dc\[Dagger]"*"ec"*"GL"*"H"*"L"*"uc"^2*"uc\[Dagger]", 
    "ec"*"GL"*"H\[Dagger]"*"L"*"uc"^2*"uc\[Dagger]"^2, 
    "ec"^2*"ec\[Dagger]"*"GL"*"H"*"Q\[Dagger]"*"uc"^2, 
    "dc"^3*"dc\[Dagger]"*"GL"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "dc"^2*"GL"*"H\[Dagger]"*"L"*"L\[Dagger]"^2*"uc", 
    "dc"^2*"dc\[Dagger]"*"ec"*"GL"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "dc"^2*"ec"*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "dc"*"dc\[Dagger]"^2*"ec"*"GL"*"H"*"L"*"uc", "dc"*"ec"*"GL"*"H\[Dagger]"*
     "L"*"L\[Dagger]"*"Q\[Dagger]"*"uc", "dc"*"dc\[Dagger]"*"ec"*"GL"*
     "H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", "dc"*"ec"^2*"ec\[Dagger]"*"GL"*
     "H\[Dagger]"*"Q\[Dagger]"*"uc", "dc\[Dagger]"*"ec"*"GL"*"H"*"L"^2*
     "L\[Dagger]"*"uc", "ec"*"GL"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"uc"*
     "uc\[Dagger]", "dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"GL"*"H"*"L"*"uc", 
    "ec"^2*"GL"*"H\[Dagger]"*"L"*"Q\[Dagger]"^2*"uc", 
    "ec"^2*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2*"ec"*"GL"*"H\[Dagger]"*"L", 
    "dc"*"dc\[Dagger]"*"ec"*"GL"*"H\[Dagger]"*"L"^2*"L\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"GL"*"H\[Dagger]"*"L", 
    "dc\[Dagger]"*"ec"^2*"GL"*"H\[Dagger]"*"L"^2*"Q\[Dagger]", 
    "ec\[Dagger]"*"H"*"Q"^4*"Q\[Dagger]"*"WL", "H"*"Q"^3*"Q\[Dagger]"^2*"uc"*
     "WL", "ec\[Dagger]"*"H"*"Q"^3*"uc"*"uc\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"ec\[Dagger]"*"H"*"Q"^3*"WL", 
    "dc"*"H\[Dagger]"*"Q"^3*"Q\[Dagger]"^2*"WL", 
    "dc"*"ec\[Dagger]"*"H\[Dagger]"*"Q"^3*"uc\[Dagger]"*"WL", 
    "dc\[Dagger]"*"H"*"L"*"Q"^3*"Q\[Dagger]"*"WL", 
    "ec\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q"^3*"WL", 
    "H\[Dagger]"*"L"*"Q"^3*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "ec"*"ec\[Dagger]"^2*"H"*"Q"^3*"WL", "H"*"Q"^2*"Q\[Dagger]"*"uc"^2*
     "uc\[Dagger]"*"WL", "dc"*"dc\[Dagger]"*"H"*"Q"^2*"Q\[Dagger]"*"uc"*"WL", 
    "dc"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"Q"^2*"uc"*"WL", 
    "dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "H"*"L"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc"*"WL", 
    "dc\[Dagger]"*"H"*"L"*"Q"^2*"uc"*"uc\[Dagger]"*"WL", 
    "H\[Dagger]"*"L"*"Q"^2*"uc"*"uc\[Dagger]"^2*"WL", 
    "ec"*"ec\[Dagger]"*"H"*"Q"^2*"Q\[Dagger]"*"uc"*"WL", 
    "dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"WL", 
    "dc"^2*"ec\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2*"WL", 
    "dc"*"dc\[Dagger]"^2*"H"*"L"*"Q"^2*"WL", "dc"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"^2*"Q\[Dagger]"*"WL", "dc"*"dc\[Dagger]"*"H\[Dagger]"*
     "L"*"Q"^2*"uc\[Dagger]"*"WL", "dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"^2*
     "Q\[Dagger]"*"WL", "dc\[Dagger]"*"H"*"L"^2*"L\[Dagger]"*"Q"^2*"WL", 
    "H\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL", 
    "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"L"*"Q"^2*"WL", 
    "ec"*"H\[Dagger]"*"L"*"Q"^2*"Q\[Dagger]"^2*"WL", 
    "ec"*"ec\[Dagger]"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]"*"WL", 
    "H"*"Q"*"uc"^3*"uc\[Dagger]"^2*"WL", "dc"*"H"*"L\[Dagger]"*"Q"*
     "Q\[Dagger]"*"uc"^2*"WL", "dc"*"dc\[Dagger]"*"H"*"Q"*"uc"^2*
     "uc\[Dagger]"*"WL", "dc"*"H\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]"^2*"WL", 
    "H"*"L"*"L\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]"*"WL", 
    "ec"*"H"*"Q"*"Q\[Dagger]"^2*"uc"^2*"WL", "ec"*"ec\[Dagger]"*"H"*"Q"*
     "uc"^2*"uc\[Dagger]"*"WL", "dc"^2*"dc\[Dagger]"^2*"H"*"Q"*"uc"*"WL", 
    "dc"^2*"H\[Dagger]"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"WL", 
    "dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q"*"uc"*"WL", 
    "dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"uc"*"uc\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc"*"WL", 
    "dc"*"ec"*"H\[Dagger]"*"Q"*"Q\[Dagger]"^2*"uc"*"WL", 
    "dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]"*"WL", 
    "H"*"L"^2*"L\[Dagger]"^2*"Q"*"uc"*"WL", "dc\[Dagger]"*"ec"*"H"*"L"*"Q"*
     "Q\[Dagger]"*"uc"*"WL", "ec"*"ec\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q"*"uc"*
     "WL", "ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "ec"^2*"ec\[Dagger]"^2*"H"*"Q"*"uc"*"WL", "dc"^3*"dc\[Dagger]"^2*
     "H\[Dagger]"*"Q"*"WL", "dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"*"WL", "dc"^2*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*
     "H\[Dagger]"*"Q"*"WL", "dc"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2*"Q"*"WL", 
    "dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"WL", 
    "dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"WL", 
    "dc"*"ec"^2*"ec\[Dagger]"^2*"H\[Dagger]"*"Q"*"WL", 
    "dc\[Dagger]"^2*"ec"*"H"*"L"^2*"Q"*"WL", "ec"*"H\[Dagger]"*"L"^2*
     "L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", "dc\[Dagger]"*"ec"*"H\[Dagger]"*
     "L"^2*"Q"*"uc\[Dagger]"*"WL", "ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"Q"*
     "Q\[Dagger]"*"WL", "dc"*"H"*"L\[Dagger]"*"uc"^3*"uc\[Dagger]"*"WL", 
    "ec"*"H"*"Q\[Dagger]"*"uc"^3*"uc\[Dagger]"*"WL", 
    "dc"^2*"dc\[Dagger]"*"H"*"L\[Dagger]"*"uc"^2*"WL", 
    "dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"^2*"uc\[Dagger]"*"WL", 
    "dc"*"H"*"L"*"L\[Dagger]"^2*"uc"^2*"WL", "dc"*"dc\[Dagger]"*"ec"*"H"*
     "Q\[Dagger]"*"uc"^2*"WL", "dc"*"ec"*"ec\[Dagger]"*"H"*"L\[Dagger]"*
     "uc"^2*"WL", "dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]"*
     "WL", "ec"*"H"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2*"WL", 
    "dc\[Dagger]"*"ec"*"H"*"L"*"uc"^2*"uc\[Dagger]"*"WL", 
    "ec"*"H\[Dagger]"*"L"*"uc"^2*"uc\[Dagger]"^2*"WL", 
    "ec"^2*"ec\[Dagger]"*"H"*"Q\[Dagger]"*"uc"^2*"WL", 
    "dc"^3*"dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WL", 
    "dc"^2*"H\[Dagger]"*"L"*"L\[Dagger]"^2*"uc"*"WL", 
    "dc"^2*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "dc"^2*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WL", 
    "dc"*"dc\[Dagger]"^2*"ec"*"H"*"L"*"uc"*"WL", "dc"*"ec"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", "dc"*"dc\[Dagger]"*"ec"*
     "H\[Dagger]"*"L"*"uc"*"uc\[Dagger]"*"WL", "dc"*"ec"^2*"ec\[Dagger]"*
     "H\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", "dc\[Dagger]"*"ec"*"H"*"L"^2*
     "L\[Dagger]"*"uc"*"WL", "ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"uc"*
     "uc\[Dagger]"*"WL", "dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"H"*"L"*"uc"*
     "WL", "ec"^2*"H\[Dagger]"*"L"*"Q\[Dagger]"^2*"uc"*"WL", 
    "ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]"*"WL", 
    "dc"^2*"dc\[Dagger]"^2*"ec"*"H\[Dagger]"*"L"*"WL", 
    "dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"WL", 
    "ec"*"H\[Dagger]"*"L"^3*"L\[Dagger]"^2*"WL", "dc\[Dagger]"*"ec"^2*
     "H\[Dagger]"*"L"^2*"Q\[Dagger]"*"WL", "ec"^2*"ec\[Dagger]"*"H\[Dagger]"*
     "L"^2*"L\[Dagger]"*"WL", "ec"^3*"ec\[Dagger]"^2*"H\[Dagger]"*"L"*"WL", 
    "BL"*"ec\[Dagger]"*"H"*"Q"^4*"Q\[Dagger]", "BL"*"H"*"Q"^3*"Q\[Dagger]"^2*
     "uc", "BL"*"ec\[Dagger]"*"H"*"Q"^3*"uc"*"uc\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"ec\[Dagger]"*"H"*"Q"^3, 
    "BL"*"dc"*"H\[Dagger]"*"Q"^3*"Q\[Dagger]"^2, "BL"*"dc"*"ec\[Dagger]"*
     "H\[Dagger]"*"Q"^3*"uc\[Dagger]", "BL"*"dc\[Dagger]"*"H"*"L"*"Q"^3*
     "Q\[Dagger]", "BL"*"ec\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q"^3, 
    "BL"*"H\[Dagger]"*"L"*"Q"^3*"Q\[Dagger]"*"uc\[Dagger]", 
    "BL"*"ec"*"ec\[Dagger]"^2*"H"*"Q"^3, "BL"*"H"*"Q"^2*"Q\[Dagger]"*"uc"^2*
     "uc\[Dagger]", "BL"*"dc"*"dc\[Dagger]"*"H"*"Q"^2*"Q\[Dagger]"*"uc", 
    "BL"*"dc"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"Q"^2*"uc", 
    "BL"*"dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"H"*"L"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc", 
    "BL"*"dc\[Dagger]"*"H"*"L"*"Q"^2*"uc"*"uc\[Dagger]", 
    "BL"*"H\[Dagger]"*"L"*"Q"^2*"uc"*"uc\[Dagger]"^2, 
    "BL"*"ec"*"ec\[Dagger]"*"H"*"Q"^2*"Q\[Dagger]"*"uc", 
    "BL"*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "BL"*"dc"^2*"ec\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "BL"*"dc"*"dc\[Dagger]"^2*"H"*"L"*"Q"^2, "BL"*"dc"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"^2*"Q\[Dagger]", "BL"*"dc"*"dc\[Dagger]"*"H\[Dagger]"*
     "L"*"Q"^2*"uc\[Dagger]", "BL"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"^2*
     "Q\[Dagger]", "BL"*"dc\[Dagger]"*"H"*"L"^2*"L\[Dagger]"*"Q"^2, 
    "BL"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "BL"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"L"*"Q"^2, 
    "BL"*"ec"*"H\[Dagger]"*"L"*"Q"^2*"Q\[Dagger]"^2, 
    "BL"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]", 
    "BL"*"H"*"Q"*"uc"^3*"uc\[Dagger]"^2, "BL"*"dc"*"H"*"L\[Dagger]"*"Q"*
     "Q\[Dagger]"*"uc"^2, "BL"*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc"^2*
     "uc\[Dagger]", "BL"*"dc"*"H\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]"^2, 
    "BL"*"H"*"L"*"L\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]", 
    "BL"*"ec"*"H"*"Q"*"Q\[Dagger]"^2*"uc"^2, "BL"*"ec"*"ec\[Dagger]"*"H"*"Q"*
     "uc"^2*"uc\[Dagger]", "BL"*"dc"^2*"dc\[Dagger]"^2*"H"*"Q"*"uc", 
    "BL"*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc", 
    "BL"*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "BL"*"dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc", 
    "BL"*"dc"*"ec"*"H\[Dagger]"*"Q"*"Q\[Dagger]"^2*"uc", 
    "BL"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "BL"*"H"*"L"^2*"L\[Dagger]"^2*"Q"*"uc", "BL"*"dc\[Dagger]"*"ec"*"H"*"L"*
     "Q"*"Q\[Dagger]"*"uc", "BL"*"ec"*"ec\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q"*
     "uc", "BL"*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"ec"^2*"ec\[Dagger]"^2*"H"*"Q"*"uc", "BL"*"dc"^3*"dc\[Dagger]"^2*
     "H\[Dagger]"*"Q", "BL"*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q", "BL"*"dc"^2*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*
     "H\[Dagger]"*"Q", "BL"*"dc"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2*"Q", 
    "BL"*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "BL"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "BL"*"dc"*"ec"^2*"ec\[Dagger]"^2*"H\[Dagger]"*"Q", 
    "BL"*"dc\[Dagger]"^2*"ec"*"H"*"L"^2*"Q", "BL"*"ec"*"H\[Dagger]"*"L"^2*
     "L\[Dagger]"*"Q"*"Q\[Dagger]", "BL"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*
     "L"^2*"Q"*"uc\[Dagger]", "BL"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"Q"*
     "Q\[Dagger]", "BL"*"dc"*"H"*"L\[Dagger]"*"uc"^3*"uc\[Dagger]", 
    "BL"*"ec"*"H"*"Q\[Dagger]"*"uc"^3*"uc\[Dagger]", 
    "BL"*"dc"^2*"dc\[Dagger]"*"H"*"L\[Dagger]"*"uc"^2, 
    "BL"*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "BL"*"dc"*"H"*"L"*"L\[Dagger]"^2*"uc"^2, "BL"*"dc"*"dc\[Dagger]"*"ec"*"H"*
     "Q\[Dagger]"*"uc"^2, "BL"*"dc"*"ec"*"ec\[Dagger]"*"H"*"L\[Dagger]"*
     "uc"^2, "BL"*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "BL"*"ec"*"H"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2, 
    "BL"*"dc\[Dagger]"*"ec"*"H"*"L"*"uc"^2*"uc\[Dagger]", 
    "BL"*"ec"*"H\[Dagger]"*"L"*"uc"^2*"uc\[Dagger]"^2, 
    "BL"*"ec"^2*"ec\[Dagger]"*"H"*"Q\[Dagger]"*"uc"^2, 
    "BL"*"dc"^3*"dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "BL"*"dc"^2*"H\[Dagger]"*"L"*"L\[Dagger]"^2*"uc", 
    "BL"*"dc"^2*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "BL"*"dc"^2*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "BL"*"dc"*"dc\[Dagger]"^2*"ec"*"H"*"L"*"uc", "BL"*"dc"*"ec"*"H\[Dagger]"*
     "L"*"L\[Dagger]"*"Q\[Dagger]"*"uc", "BL"*"dc"*"dc\[Dagger]"*"ec"*
     "H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", "BL"*"dc"*"ec"^2*"ec\[Dagger]"*
     "H\[Dagger]"*"Q\[Dagger]"*"uc", "BL"*"dc\[Dagger]"*"ec"*"H"*"L"^2*
     "L\[Dagger]"*"uc", "BL"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"uc"*
     "uc\[Dagger]", "BL"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"H"*"L"*"uc", 
    "BL"*"ec"^2*"H\[Dagger]"*"L"*"Q\[Dagger]"^2*"uc", 
    "BL"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", 
    "BL"*"dc"^2*"dc\[Dagger]"^2*"ec"*"H\[Dagger]"*"L", 
    "BL"*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L", 
    "BL"*"ec"*"H\[Dagger]"*"L"^3*"L\[Dagger]"^2, "BL"*"dc\[Dagger]"*"ec"^2*
     "H\[Dagger]"*"L"^2*"Q\[Dagger]", "BL"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*
     "L"^2*"L\[Dagger]", "BL"*"ec"^3*"ec\[Dagger]"^2*"H\[Dagger]"*"L"}, 
  FL^2*\[Phi]^2*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"*"ec\[Dagger]"*"GL"^2*"H"^2*"Q"^2, 
    "GL"^2*"H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, "ec\[Dagger]"*"GL"^2*"H"*
     "H\[Dagger]"*"Q"^2*"uc\[Dagger]", "dc\[Dagger]"*"GL"^2*"H"^2*"Q"*
     "Q\[Dagger]"*"uc", "ec\[Dagger]"*"GL"^2*"H"^2*"L\[Dagger]"*"Q"*"uc", 
    "GL"^2*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"GL"^2*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "dc"*"ec\[Dagger]"*"GL"^2*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q", 
    "dc"*"GL"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"^2*"GL"^2*"H"^2*"L"*"Q", "GL"^2*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"*"Q\[Dagger]", "dc\[Dagger]"*"GL"^2*"H"*"H\[Dagger]"*"L"*
     "Q"*"uc\[Dagger]", "GL"^2*"H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"^2, 
    "ec"*"ec\[Dagger]"*"GL"^2*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "GL"^2*"H"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2, 
    "dc\[Dagger]"*"GL"^2*"H"^2*"uc"^2*"uc\[Dagger]", 
    "GL"^2*"H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "dc"*"dc\[Dagger]"^2*"GL"^2*"H"^2*"uc", "dc"*"GL"^2*"H"*"H\[Dagger]"*
     "L\[Dagger]"*"Q\[Dagger]"*"uc", "dc"*"dc\[Dagger]"*"GL"^2*"H"*
     "H\[Dagger]"*"uc"*"uc\[Dagger]", "dc"*"GL"^2*"H\[Dagger]"^2*"uc"*
     "uc\[Dagger]"^2, "dc\[Dagger]"*"GL"^2*"H"^2*"L"*"L\[Dagger]"*"uc", 
    "GL"^2*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"^2*"H"^2*"uc", 
    "ec"*"GL"^2*"H"*"H\[Dagger]"*"Q\[Dagger]"^2*"uc", 
    "ec"*"ec\[Dagger]"*"GL"^2*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2*"GL"^2*"H"*"H\[Dagger]", 
    "dc"^2*"GL"^2*"H\[Dagger]"^2*"L\[Dagger]"*"Q\[Dagger]", 
    "dc"^2*"dc\[Dagger]"*"GL"^2*"H\[Dagger]"^2*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"GL"^2*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "dc"*"GL"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"^2*"H"*"H\[Dagger]", 
    "dc"*"ec"*"GL"^2*"H\[Dagger]"^2*"Q\[Dagger]"^2, 
    "dc"*"ec"*"ec\[Dagger]"*"GL"^2*"H\[Dagger]"^2*"uc\[Dagger]", 
    "GL"^2*"H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2, "dc\[Dagger]"*"ec"*"GL"^2*
     "H"*"H\[Dagger]"*"L"*"Q\[Dagger]", "ec"*"ec\[Dagger]"*"GL"^2*"H"*
     "H\[Dagger]"*"L"*"L\[Dagger]", "ec"*"GL"^2*"H\[Dagger]"^2*"L"*
     "Q\[Dagger]"*"uc\[Dagger]", "ec"^2*"ec\[Dagger]"^2*"GL"^2*"H"*
     "H\[Dagger]", "dc\[Dagger]"*"ec\[Dagger]"*"GL"*"H"^2*"Q"^2*"WL", 
    "GL"*"H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2*"WL", 
    "ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL", 
    "dc\[Dagger]"*"GL"*"H"^2*"Q"*"Q\[Dagger]"*"uc"*"WL", 
    "ec\[Dagger]"*"GL"*"H"^2*"L\[Dagger]"*"Q"*"uc"*"WL", 
    "GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "dc"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q"*"WL", 
    "dc"*"GL"*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "dc\[Dagger]"^2*"GL"*"H"^2*"L"*"Q"*"WL", "GL"*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", "dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*
     "L"*"Q"*"uc\[Dagger]"*"WL", "GL"*"H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"^2*
     "WL", "ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "GL"*"H"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2*"WL", 
    "dc\[Dagger]"*"GL"*"H"^2*"uc"^2*"uc\[Dagger]"*"WL", 
    "GL"*"H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2*"WL", 
    "dc"*"dc\[Dagger]"^2*"GL"*"H"^2*"uc"*"WL", "dc"*"GL"*"H"*"H\[Dagger]"*
     "L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", "dc"*"dc\[Dagger]"*"GL"*"H"*
     "H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", "dc"*"GL"*"H\[Dagger]"^2*"uc"*
     "uc\[Dagger]"^2*"WL", "dc\[Dagger]"*"GL"*"H"^2*"L"*"L\[Dagger]"*"uc"*
     "WL", "GL"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"H"^2*"uc"*"WL", 
    "ec"*"GL"*"H"*"H\[Dagger]"*"Q\[Dagger]"^2*"uc"*"WL", 
    "ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "dc"^2*"dc\[Dagger]"^2*"GL"*"H"*"H\[Dagger]"*"WL", 
    "dc"^2*"GL"*"H\[Dagger]"^2*"L\[Dagger]"*"Q\[Dagger]"*"WL", 
    "dc"^2*"dc\[Dagger]"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "dc"*"GL"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"WL", 
    "dc"*"ec"*"GL"*"H\[Dagger]"^2*"Q\[Dagger]"^2*"WL", 
    "dc"*"ec"*"ec\[Dagger]"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "dc\[Dagger]"*"ec"*"GL"*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]"*"WL", 
    "ec"*"GL"*"H\[Dagger]"^2*"L"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"*"ec\[Dagger]"*"GL"*"H"^2*"Q"^2, 
    "BL"*"GL"*"H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, 
    "BL"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "BL"*"dc\[Dagger]"*"GL"*"H"^2*"Q"*"Q\[Dagger]"*"uc", 
    "BL"*"ec\[Dagger]"*"GL"*"H"^2*"L\[Dagger]"*"Q"*"uc", 
    "BL"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"dc"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q", 
    "BL"*"dc"*"GL"*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]", 
    "BL"*"dc\[Dagger]"^2*"GL"*"H"^2*"L"*"Q", "BL"*"GL"*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"*"Q\[Dagger]", "BL"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*
     "L"*"Q"*"uc\[Dagger]", "BL"*"GL"*"H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"^2, 
    "BL"*"ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"GL"*"H"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2, 
    "BL"*"dc\[Dagger]"*"GL"*"H"^2*"uc"^2*"uc\[Dagger]", 
    "BL"*"GL"*"H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "BL"*"dc"*"dc\[Dagger]"^2*"GL"*"H"^2*"uc", "BL"*"dc"*"GL"*"H"*
     "H\[Dagger]"*"L\[Dagger]"*"Q\[Dagger]"*"uc", "BL"*"dc"*"dc\[Dagger]"*
     "GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", "BL"*"dc"*"GL"*"H\[Dagger]"^2*
     "uc"*"uc\[Dagger]"^2, "BL"*"dc\[Dagger]"*"GL"*"H"^2*"L"*"L\[Dagger]"*
     "uc", "BL"*"GL"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"H"^2*"uc", 
    "BL"*"ec"*"GL"*"H"*"H\[Dagger]"*"Q\[Dagger]"^2*"uc", 
    "BL"*"ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"dc"^2*"dc\[Dagger]"^2*"GL"*"H"*"H\[Dagger]", 
    "BL"*"dc"^2*"GL"*"H\[Dagger]"^2*"L\[Dagger]"*"Q\[Dagger]", 
    "BL"*"dc"^2*"dc\[Dagger]"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"*"dc"*"GL"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]", 
    "BL"*"dc"*"ec"*"GL"*"H\[Dagger]"^2*"Q\[Dagger]"^2, 
    "BL"*"dc"*"ec"*"ec\[Dagger]"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "BL"*"dc\[Dagger]"*"ec"*"GL"*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]", 
    "BL"*"ec"*"GL"*"H\[Dagger]"^2*"L"*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"Q"^2*"WL"^2, 
    "H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2*"WL"^2, 
    "ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL"^2, 
    "dc\[Dagger]"*"H"^2*"Q"*"Q\[Dagger]"*"uc"*"WL"^2, 
    "ec\[Dagger]"*"H"^2*"L\[Dagger]"*"Q"*"uc"*"WL"^2, 
    "H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "dc"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q"*"WL"^2, 
    "dc"*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, 
    "dc\[Dagger]"^2*"H"^2*"L"*"Q"*"WL"^2, "H"*"H\[Dagger]"*"L"*"L\[Dagger]"*
     "Q"*"Q\[Dagger]"*"WL"^2, "dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"Q"*
     "uc\[Dagger]"*"WL"^2, "H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"^2*"WL"^2, 
    "ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"^2, 
    "H"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2*"WL"^2, 
    "dc\[Dagger]"*"H"^2*"uc"^2*"uc\[Dagger]"*"WL"^2, 
    "H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2*"WL"^2, 
    "dc"*"dc\[Dagger]"^2*"H"^2*"uc"*"WL"^2, "dc"*"H"*"H\[Dagger]"*
     "L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL"^2, "dc"*"dc\[Dagger]"*"H"*
     "H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, "dc"*"H\[Dagger]"^2*"uc"*
     "uc\[Dagger]"^2*"WL"^2, "dc\[Dagger]"*"H"^2*"L"*"L\[Dagger]"*"uc"*
     "WL"^2, "H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*"uc"*"WL"^2, 
    "ec"*"H"*"H\[Dagger]"*"Q\[Dagger]"^2*"uc"*"WL"^2, 
    "ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"^2, 
    "dc"^2*"dc\[Dagger]"^2*"H"*"H\[Dagger]"*"WL"^2, 
    "dc"^2*"H\[Dagger]"^2*"L\[Dagger]"*"Q\[Dagger]"*"WL"^2, 
    "dc"^2*"dc\[Dagger]"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL"^2, 
    "dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL"^2, 
    "dc"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc\[Dagger]"*"WL"^2, 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL"^2, 
    "dc"*"ec"*"H\[Dagger]"^2*"Q\[Dagger]"^2*"WL"^2, 
    "dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL"^2, 
    "H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2*"WL"^2, "dc\[Dagger]"*"ec"*"H"*
     "H\[Dagger]"*"L"*"Q\[Dagger]"*"WL"^2, "ec"*"ec\[Dagger]"*"H"*
     "H\[Dagger]"*"L"*"L\[Dagger]"*"WL"^2, "ec"*"H\[Dagger]"^2*"L"*
     "Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, "ec"^2*"ec\[Dagger]"^2*"H"*
     "H\[Dagger]"*"WL"^2, "BL"*"dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"Q"^2*"WL", 
    "BL"*"H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2*"WL", 
    "BL"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"*"H"^2*"Q"*"Q\[Dagger]"*"uc"*"WL", 
    "BL"*"ec\[Dagger]"*"H"^2*"L\[Dagger]"*"Q"*"uc"*"WL", 
    "BL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"dc"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q"*"WL", 
    "BL"*"dc"*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"^2*"H"^2*"L"*"Q"*"WL", "BL"*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", "BL"*"dc\[Dagger]"*"H"*"H\[Dagger]"*
     "L"*"Q"*"uc\[Dagger]"*"WL", "BL"*"H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"^2*
     "WL", "BL"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"H"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2*"WL", 
    "BL"*"dc\[Dagger]"*"H"^2*"uc"^2*"uc\[Dagger]"*"WL", 
    "BL"*"H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2*"WL", 
    "BL"*"dc"*"dc\[Dagger]"^2*"H"^2*"uc"*"WL", "BL"*"dc"*"H"*"H\[Dagger]"*
     "L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", "BL"*"dc"*"dc\[Dagger]"*"H"*
     "H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", "BL"*"dc"*"H\[Dagger]"^2*"uc"*
     "uc\[Dagger]"^2*"WL", "BL"*"dc\[Dagger]"*"H"^2*"L"*"L\[Dagger]"*"uc"*
     "WL", "BL"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*"uc"*"WL", 
    "BL"*"ec"*"H"*"H\[Dagger]"*"Q\[Dagger]"^2*"uc"*"WL", 
    "BL"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"dc"^2*"dc\[Dagger]"^2*"H"*"H\[Dagger]"*"WL", 
    "BL"*"dc"^2*"H\[Dagger]"^2*"L\[Dagger]"*"Q\[Dagger]"*"WL", 
    "BL"*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "BL"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "BL"*"dc"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL", 
    "BL"*"dc"*"ec"*"H\[Dagger]"^2*"Q\[Dagger]"^2*"WL", 
    "BL"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "BL"*"H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2*"WL", 
    "BL"*"dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]"*"WL", 
    "BL"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "BL"*"ec"*"H\[Dagger]"^2*"L"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"ec"^2*"ec\[Dagger]"^2*"H"*"H\[Dagger]"*"WL", 
    "BL"^2*"dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"Q"^2, 
    "BL"^2*"H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, "BL"^2*"ec\[Dagger]"*"H"*
     "H\[Dagger]"*"Q"^2*"uc\[Dagger]", "BL"^2*"dc\[Dagger]"*"H"^2*"Q"*
     "Q\[Dagger]"*"uc", "BL"^2*"ec\[Dagger]"*"H"^2*"L\[Dagger]"*"Q"*"uc", 
    "BL"^2*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"^2*"dc"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q", 
    "BL"^2*"dc"*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]", 
    "BL"^2*"dc\[Dagger]"^2*"H"^2*"L"*"Q", "BL"^2*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"*"Q\[Dagger]", "BL"^2*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*
     "Q"*"uc\[Dagger]", "BL"^2*"H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"^2, 
    "BL"^2*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"^2*"H"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2, 
    "BL"^2*"dc\[Dagger]"*"H"^2*"uc"^2*"uc\[Dagger]", 
    "BL"^2*"H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "BL"^2*"dc"*"dc\[Dagger]"^2*"H"^2*"uc", "BL"^2*"dc"*"H"*"H\[Dagger]"*
     "L\[Dagger]"*"Q\[Dagger]"*"uc", "BL"^2*"dc"*"dc\[Dagger]"*"H"*
     "H\[Dagger]"*"uc"*"uc\[Dagger]", "BL"^2*"dc"*"H\[Dagger]"^2*"uc"*
     "uc\[Dagger]"^2, "BL"^2*"dc\[Dagger]"*"H"^2*"L"*"L\[Dagger]"*"uc", 
    "BL"^2*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*"uc", 
    "BL"^2*"ec"*"H"*"H\[Dagger]"*"Q\[Dagger]"^2*"uc", 
    "BL"^2*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"^2*"dc"^2*"dc\[Dagger]"^2*"H"*"H\[Dagger]", 
    "BL"^2*"dc"^2*"H\[Dagger]"^2*"L\[Dagger]"*"Q\[Dagger]", 
    "BL"^2*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "BL"^2*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"^2*"dc"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc\[Dagger]", 
    "BL"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]", 
    "BL"^2*"dc"*"ec"*"H\[Dagger]"^2*"Q\[Dagger]"^2, 
    "BL"^2*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "BL"^2*"H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2, "BL"^2*"dc\[Dagger]"*"ec"*
     "H"*"H\[Dagger]"*"L"*"Q\[Dagger]", "BL"^2*"ec"*"ec\[Dagger]"*"H"*
     "H\[Dagger]"*"L"*"L\[Dagger]", "BL"^2*"ec"*"H\[Dagger]"^2*"L"*
     "Q\[Dagger]"*"uc\[Dagger]", "BL"^2*"ec"^2*"ec\[Dagger]"^2*"H"*
     "H\[Dagger]"}, FL^3*\[Phi]^3*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"*"GL"^3*"H"^2*"H\[Dagger]"*"Q\[Dagger]", 
    "ec\[Dagger]"*"GL"^3*"H"^2*"H\[Dagger]"*"L\[Dagger]", 
    "GL"^3*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"GL"^2*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"WL", 
    "ec\[Dagger]"*"GL"^2*"H"^2*"H\[Dagger]"*"L\[Dagger]"*"WL", 
    "GL"^2*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"*"GL"^2*"H"^2*"H\[Dagger]"*"Q\[Dagger]", 
    "BL"*"ec\[Dagger]"*"GL"^2*"H"^2*"H\[Dagger]"*"L\[Dagger]", 
    "BL"*"GL"^2*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"WL"^2, 
    "GL"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, 
    "BL"*"dc\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"WL", 
    "BL"*"GL"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"^2*"dc\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"*"Q\[Dagger]", 
    "BL"^2*"GL"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"WL"^3, 
    "ec\[Dagger]"*"H"^2*"H\[Dagger]"*"L\[Dagger]"*"WL"^3, 
    "H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^3, 
    "BL"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"WL"^2, 
    "BL"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"L\[Dagger]"*"WL"^2, 
    "BL"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, 
    "BL"^2*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"WL", 
    "BL"^2*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"L\[Dagger]"*"WL", 
    "BL"^2*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"^3*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"Q\[Dagger]", 
    "BL"^3*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"L\[Dagger]", 
    "BL"^3*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc\[Dagger]"}, 
  D*\[Phi]^2*\[Psi]^5*OverBar[\[Psi]] -> {"D"*"ec\[Dagger]"*"H"^2*"Q"^4*"uc", 
    "D"*"dc"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"^4, 
    "D"*"H"*"H\[Dagger]"*"L"*"Q"^4*"Q\[Dagger]", "D"*"H"^2*"Q"^3*"Q\[Dagger]"*
     "uc"^2, "D"*"dc"*"H"*"H\[Dagger]"*"Q"^3*"Q\[Dagger]"*"uc", 
    "D"*"dc\[Dagger]"*"H"^2*"L"*"Q"^3*"uc", "D"*"H"*"H\[Dagger]"*"L"*"Q"^3*
     "uc"*"uc\[Dagger]", "D"*"dc"^2*"H\[Dagger]"^2*"Q"^3*"Q\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"Q"^3, 
    "D"*"dc"*"H\[Dagger]"^2*"L"*"Q"^3*"uc\[Dagger]", 
    "D"*"H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"^3, 
    "D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"*"Q"^3, 
    "D"*"H"^2*"Q"^2*"uc"^3*"uc\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"H"^2*"Q"^2*
     "uc"^2, "D"*"dc"*"H"*"H\[Dagger]"*"Q"^2*"uc"^2*"uc\[Dagger]", 
    "D"*"H"^2*"L"*"L\[Dagger]"*"Q"^2*"uc"^2, "D"*"ec"*"ec\[Dagger]"*"H"^2*
     "Q"^2*"uc"^2, "D"*"dc"^2*"dc\[Dagger]"*"H"*"H\[Dagger]"*"Q"^2*"uc", 
    "D"*"dc"^2*"H\[Dagger]"^2*"Q"^2*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"^2*"uc", 
    "D"*"dc"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"^2*"uc", 
    "D"*"ec"*"H"*"H\[Dagger]"*"L"*"Q"^2*"Q\[Dagger]"*"uc", 
    "D"*"dc"^3*"dc\[Dagger]"*"H\[Dagger]"^2*"Q"^2, 
    "D"*"dc"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"Q"^2, 
    "D"*"dc"^2*"ec"*"ec\[Dagger]"*"H\[Dagger]"^2*"Q"^2, 
    "D"*"dc"*"ec"*"H\[Dagger]"^2*"L"*"Q"^2*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"*"L"^2*"Q"^2, 
    "D"*"ec"*"H\[Dagger]"^2*"L"^2*"Q"^2*"uc\[Dagger]", 
    "D"*"dc"*"H"^2*"L\[Dagger]"*"Q"*"uc"^3, "D"*"ec"*"H"^2*"Q"*"Q\[Dagger]"*
     "uc"^3, "D"*"dc"^2*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q"*"uc"^2, 
    "D"*"dc"*"ec"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"^2, 
    "D"*"dc\[Dagger]"*"ec"*"H"^2*"L"*"Q"*"uc"^2, "D"*"ec"*"H"*"H\[Dagger]"*
     "L"*"Q"*"uc"^2*"uc\[Dagger]", "D"*"dc"^3*"H\[Dagger]"^2*"L\[Dagger]"*"Q"*
     "uc", "D"*"dc"^2*"ec"*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"*"L"*"Q"*"uc", 
    "D"*"dc"*"ec"*"H\[Dagger]"^2*"L"*"Q"*"uc"*"uc\[Dagger]", 
    "D"*"ec"*"H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"*"uc", 
    "D"*"ec"^2*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"*"Q"*"uc", 
    "D"*"dc"^2*"dc\[Dagger]"*"ec"*"H\[Dagger]"^2*"L"*"Q", 
    "D"*"dc"*"ec"*"H\[Dagger]"^2*"L"^2*"L\[Dagger]"*"Q", 
    "D"*"dc"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"^2*"L"*"Q", 
    "D"*"ec"^2*"H\[Dagger]"^2*"L"^2*"Q"*"Q\[Dagger]", 
    "D"*"ec"*"H"^2*"uc"^4*"uc\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"ec"*"H"^2*
     "uc"^3, "D"*"dc"*"ec"*"H"*"H\[Dagger]"*"uc"^3*"uc\[Dagger]", 
    "D"*"ec"*"H"^2*"L"*"L\[Dagger]"*"uc"^3, "D"*"ec"^2*"ec\[Dagger]"*"H"^2*
     "uc"^3, "D"*"dc"^2*"dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"*"uc"^2, 
    "D"*"dc"^2*"ec"*"H\[Dagger]"^2*"uc"^2*"uc\[Dagger]", 
    "D"*"dc"*"ec"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"^2, 
    "D"*"dc"*"ec"^2*"ec\[Dagger]"*"H"*"H\[Dagger]"*"uc"^2, 
    "D"*"ec"^2*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]"*"uc"^2, 
    "D"*"dc"^3*"dc\[Dagger]"*"ec"*"H\[Dagger]"^2*"uc", 
    "D"*"dc"^2*"ec"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc", 
    "D"*"dc"^2*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"^2*"uc", 
    "D"*"dc"*"ec"^2*"H\[Dagger]"^2*"L"*"Q\[Dagger]"*"uc", 
    "D"*"dc\[Dagger]"*"ec"^2*"H"*"H\[Dagger]"*"L"^2*"uc", 
    "D"*"ec"^2*"H\[Dagger]"^2*"L"^2*"uc"*"uc\[Dagger]", 
    "D"*"dc"^3*"ec\[Dagger]"*"H"^2*"L"^2, "D"*"dc"^2*"H"^2*"L"^3*
     "Q\[Dagger]", "D"*"dc"*"H"^2*"L"^4*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"ec"^2*"H\[Dagger]"^2*"L"^2, 
    "D"*"ec"^2*"H\[Dagger]"^2*"L"^3*"L\[Dagger]", "D"*"ec"^3*"ec\[Dagger]"*
     "H\[Dagger]"^2*"L"^2}, D*FL*\[Phi]^3*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"*"ec\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"*"Q"^3, 
    "D"*"GL"*"H"^2*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc", 
    "D"*"dc"*"GL"*"H"*"H\[Dagger]"^2*"Q"^2*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"*"L"*"Q"^2, 
    "D"*"GL"*"H"*"H\[Dagger]"^2*"L"*"Q"^2*"uc\[Dagger]", 
    "D"*"dc\[Dagger]"*"GL"*"H"^3*"Q"*"uc"^2, "D"*"GL"*"H"^2*"H\[Dagger]"*"Q"*
     "uc"^2*"uc\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"*"Q"*
     "uc", "D"*"dc"*"GL"*"H"*"H\[Dagger]"^2*"Q"*"uc"*"uc\[Dagger]", 
    "D"*"GL"*"H"^2*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "D"*"ec"*"ec\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "D"*"dc"^2*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"^2*"Q", 
    "D"*"dc"^2*"GL"*"H\[Dagger]"^3*"Q"*"uc\[Dagger]", 
    "D"*"dc"*"GL"*"H"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"Q", 
    "D"*"dc"*"ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"^2*"Q", 
    "D"*"ec"*"GL"*"H"*"H\[Dagger]"^2*"L"*"Q"*"Q\[Dagger]", 
    "D"*"GL"*"H"^3*"L\[Dagger]"*"uc"^3, "D"*"dc"*"GL"*"H"^2*"H\[Dagger]"*
     "L\[Dagger]"*"uc"^2, "D"*"ec"*"GL"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*
     "uc"^2, "D"*"dc"^2*"GL"*"H"*"H\[Dagger]"^2*"L\[Dagger]"*"uc", 
    "D"*"dc"*"ec"*"GL"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc", 
    "D"*"dc\[Dagger]"*"ec"*"GL"*"H"^2*"H\[Dagger]"*"L"*"uc", 
    "D"*"ec"*"GL"*"H"*"H\[Dagger]"^2*"L"*"uc"*"uc\[Dagger]", 
    "D"*"dc"^3*"GL"*"H\[Dagger]"^3*"L\[Dagger]", "D"*"dc"^2*"ec"*"GL"*
     "H\[Dagger]"^3*"Q\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"ec"*"GL"*"H"*
     "H\[Dagger]"^2*"L", "D"*"dc"*"ec"*"GL"*"H\[Dagger]"^3*"L"*"uc\[Dagger]", 
    "D"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"^3*"WL", 
    "D"*"H"^2*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc"*"WL", 
    "D"*"dc"*"H"*"H\[Dagger]"^2*"Q"^2*"Q\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"L"*"Q"^2*"WL", 
    "D"*"H"*"H\[Dagger]"^2*"L"*"Q"^2*"uc\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"H"^3*"Q"*"uc"^2*"WL", "D"*"H"^2*"H\[Dagger]"*"Q"*
     "uc"^2*"uc\[Dagger]"*"WL", "D"*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"*
     "uc"*"WL", "D"*"dc"*"H"*"H\[Dagger]"^2*"Q"*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"H"^2*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"uc"*"WL", 
    "D"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WL", 
    "D"*"dc"^2*"dc\[Dagger]"*"H"*"H\[Dagger]"^2*"Q"*"WL", 
    "D"*"dc"^2*"H\[Dagger]"^3*"Q"*"uc\[Dagger]"*"WL", 
    "D"*"dc"*"H"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"Q"*"WL", 
    "D"*"dc"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"Q"*"WL", 
    "D"*"ec"*"H"*"H\[Dagger]"^2*"L"*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"H"^3*"L\[Dagger]"*"uc"^3*"WL", "D"*"dc"*"H"^2*"H\[Dagger]"*
     "L\[Dagger]"*"uc"^2*"WL", "D"*"ec"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*
     "uc"^2*"WL", "D"*"dc"^2*"H"*"H\[Dagger]"^2*"L\[Dagger]"*"uc"*"WL", 
    "D"*"dc"*"ec"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc"*"WL", 
    "D"*"dc\[Dagger]"*"ec"*"H"^2*"H\[Dagger]"*"L"*"uc"*"WL", 
    "D"*"ec"*"H"*"H\[Dagger]"^2*"L"*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"dc"^3*"H\[Dagger]"^3*"L\[Dagger]"*"WL", 
    "D"*"dc"^2*"ec"*"H\[Dagger]"^3*"Q\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"^2*"L"*"WL", 
    "D"*"dc"*"ec"*"H\[Dagger]"^3*"L"*"uc\[Dagger]"*"WL", 
    "D"*"ec"*"H"*"H\[Dagger]"^2*"L"^2*"L\[Dagger]"*"WL", 
    "D"*"ec"^2*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"L"*"WL", 
    "BL"*"D"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"^3, 
    "BL"*"D"*"H"^2*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc", 
    "BL"*"D"*"dc"*"H"*"H\[Dagger]"^2*"Q"^2*"Q\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"L"*"Q"^2, 
    "BL"*"D"*"H"*"H\[Dagger]"^2*"L"*"Q"^2*"uc\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"*"H"^3*"Q"*"uc"^2, "BL"*"D"*"H"^2*"H\[Dagger]"*"Q"*
     "uc"^2*"uc\[Dagger]", "BL"*"D"*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"*
     "uc", "BL"*"D"*"dc"*"H"*"H\[Dagger]"^2*"Q"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"H"^2*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "BL"*"D"*"dc"^2*"dc\[Dagger]"*"H"*"H\[Dagger]"^2*"Q", 
    "BL"*"D"*"dc"^2*"H\[Dagger]"^3*"Q"*"uc\[Dagger]", 
    "BL"*"D"*"dc"*"H"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"Q", 
    "BL"*"D"*"dc"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"Q", 
    "BL"*"D"*"ec"*"H"*"H\[Dagger]"^2*"L"*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"H"^3*"L\[Dagger]"*"uc"^3, "BL"*"D"*"dc"*"H"^2*"H\[Dagger]"*
     "L\[Dagger]"*"uc"^2, "BL"*"D"*"ec"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*
     "uc"^2, "BL"*"D"*"dc"^2*"H"*"H\[Dagger]"^2*"L\[Dagger]"*"uc", 
    "BL"*"D"*"dc"*"ec"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc", 
    "BL"*"D"*"dc\[Dagger]"*"ec"*"H"^2*"H\[Dagger]"*"L"*"uc", 
    "BL"*"D"*"ec"*"H"*"H\[Dagger]"^2*"L"*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"dc"^3*"H\[Dagger]"^3*"L\[Dagger]", "BL"*"D"*"dc"^2*"ec"*
     "H\[Dagger]"^3*"Q\[Dagger]", "BL"*"D"*"dc"*"dc\[Dagger]"*"ec"*"H"*
     "H\[Dagger]"^2*"L", "BL"*"D"*"dc"*"ec"*"H\[Dagger]"^3*"L"*"uc\[Dagger]", 
    "BL"*"D"*"ec"*"H"*"H\[Dagger]"^2*"L"^2*"L\[Dagger]", 
    "BL"*"D"*"ec"^2*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"L"}, 
  D*FL^2*\[Phi]^4*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"GL"^2*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"*"GL"^2*"H"^3*"H\[Dagger]"*"uc", 
    "D"*"GL"^2*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"^2*"H"^2*"H\[Dagger]"^2, 
    "D"*"dc"*"GL"^2*"H"*"H\[Dagger]"^3*"uc\[Dagger]", 
    "D"*"GL"^2*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]", 
    "D"*"ec"*"ec\[Dagger]"*"GL"^2*"H"^2*"H\[Dagger]"^2, 
    "D"*"GL"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"GL"*"H"^3*"H\[Dagger]"*"uc"*"WL", 
    "D"*"GL"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"^2*"WL", 
    "D"*"dc"*"GL"*"H"*"H\[Dagger]"^3*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"GL"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"*"GL"*"H"^3*"H\[Dagger]"*"uc", 
    "BL"*"D"*"GL"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"^2, 
    "BL"*"D"*"dc"*"GL"*"H"*"H\[Dagger]"^3*"uc\[Dagger]", 
    "D"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"WL"^2, 
    "D"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"*"uc"*"WL"^2, 
    "D"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]"*"WL"^2, 
    "D"*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2*"WL"^2, 
    "D"*"dc"*"H"*"H\[Dagger]"^3*"uc\[Dagger]"*"WL"^2, 
    "D"*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"WL"^2, 
    "D"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"WL"^2, 
    "BL"*"D"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"WL", 
    "BL"*"D"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"*"uc"*"WL", 
    "BL"*"D"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2*"WL", 
    "BL"*"D"*"dc"*"H"*"H\[Dagger]"^3*"uc\[Dagger]"*"WL", 
    "BL"*"D"*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"WL", 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"WL", 
    "BL"^2*"D"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "BL"^2*"D"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"*"uc", 
    "BL"^2*"D"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "BL"^2*"D"*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2, 
    "BL"^2*"D"*"dc"*"H"*"H\[Dagger]"^3*"uc\[Dagger]", 
    "BL"^2*"D"*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]", 
    "BL"^2*"D"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2}, 
  D^2*\[Phi]^4*\[Psi]^4 -> {"D"^2*"H"^2*"H\[Dagger]"^2*"L"*"Q"^3, 
    "D"^2*"H"^3*"H\[Dagger]"*"Q"^2*"uc"^2, "D"^2*"dc"*"H"^2*"H\[Dagger]"^2*
     "Q"^2*"uc", "D"^2*"dc"^2*"H"*"H\[Dagger]"^3*"Q"^2, 
    "D"^2*"ec"*"H"^2*"H\[Dagger]"^2*"L"*"Q"*"uc", 
    "D"^2*"dc"*"ec"*"H"*"H\[Dagger]"^3*"L"*"Q", "D"^2*"ec"*"H"^3*"H\[Dagger]"*
     "uc"^3, "D"^2*"dc"*"ec"*"H"^2*"H\[Dagger]"^2*"uc"^2, 
    "D"^2*"dc"^2*"ec"*"H"*"H\[Dagger]"^3*"uc", "D"^2*"dc"^3*"ec"*
     "H\[Dagger]"^4, "D"^2*"H"^4*"L"^4, "D"^2*"ec"^2*"H"*"H\[Dagger]"^3*
     "L"^2}, D^2*FL*\[Phi]^5*\[Psi]^2 -> 
   {"D"^2*"GL"*"H"^3*"H\[Dagger]"^2*"Q"*"uc", "D"^2*"dc"*"GL"*"H"^2*
     "H\[Dagger]"^3*"Q", "D"^2*"H"^3*"H\[Dagger]"^2*"Q"*"uc"*"WL", 
    "D"^2*"dc"*"H"^2*"H\[Dagger]"^3*"Q"*"WL", "D"^2*"ec"*"H"^2*"H\[Dagger]"^3*
     "L"*"WL", "BL"*"D"^2*"H"^3*"H\[Dagger]"^2*"Q"*"uc", 
    "BL"*"D"^2*"dc"*"H"^2*"H\[Dagger]"^3*"Q", "BL"*"D"^2*"ec"*"H"^2*
     "H\[Dagger]"^3*"L"}, D^2*FL^2*\[Phi]^6 -> 
   {"D"^2*"GL"^2*"H"^3*"H\[Dagger]"^3, "D"^2*"H"^3*"H\[Dagger]"^3*"WL"^2, 
    "BL"*"D"^2*"H"^3*"H\[Dagger]"^3*"WL", "BL"^2*"D"^2*"H"^3*"H\[Dagger]"^3}, 
  \[Psi]^4*OverBar[\[Psi]]^4 -> {"Q"^4*"Q\[Dagger]"^4, 
    "ec\[Dagger]"*"Q"^4*"Q\[Dagger]"^2*"uc\[Dagger]", 
    "ec\[Dagger]"^2*"Q"^4*"uc\[Dagger]"^2, "Q"^3*"Q\[Dagger]"^3*"uc"*
     "uc\[Dagger]", "ec\[Dagger]"*"Q"^3*"Q\[Dagger]"*"uc"*"uc\[Dagger]"^2, 
    "dc"*"dc\[Dagger]"*"Q"^3*"Q\[Dagger]"^3, "dc"*"ec\[Dagger]"*"L\[Dagger]"*
     "Q"^3*"Q\[Dagger]"^2, "dc"*"dc\[Dagger]"*"ec\[Dagger]"*"Q"^3*
     "Q\[Dagger]"*"uc\[Dagger]", "dc"*"ec\[Dagger]"^2*"L\[Dagger]"*"Q"^3*
     "uc\[Dagger]", "L"*"L\[Dagger]"*"Q"^3*"Q\[Dagger]"^3, 
    "dc\[Dagger]"*"L"*"Q"^3*"Q\[Dagger]"^2*"uc\[Dagger]", 
    "ec\[Dagger]"*"L"*"L\[Dagger]"*"Q"^3*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"ec\[Dagger]"*"L"*"Q"^3*"uc\[Dagger]"^2, 
    "ec"*"ec\[Dagger]"*"Q"^3*"Q\[Dagger]"^3, "ec"*"ec\[Dagger]"^2*"Q"^3*
     "Q\[Dagger]"*"uc\[Dagger]", "Q"^2*"Q\[Dagger]"^2*"uc"^2*"uc\[Dagger]"^2, 
    "ec\[Dagger]"*"Q"^2*"uc"^2*"uc\[Dagger]"^3, "dc"*"dc\[Dagger]"*"Q"^2*
     "Q\[Dagger]"^2*"uc"*"uc\[Dagger]", "dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"^2*
     "Q\[Dagger]"*"uc"*"uc\[Dagger]", "dc"*"dc\[Dagger]"*"ec\[Dagger]"*"Q"^2*
     "uc"*"uc\[Dagger]"^2, "L"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"^2*"uc"*
     "uc\[Dagger]", "dc\[Dagger]"*"L"*"Q"^2*"Q\[Dagger]"*"uc"*
     "uc\[Dagger]"^2, "ec\[Dagger]"*"L"*"L\[Dagger]"*"Q"^2*"uc"*
     "uc\[Dagger]"^2, "ec"*"ec\[Dagger]"*"Q"^2*"Q\[Dagger]"^2*"uc"*
     "uc\[Dagger]", "ec"*"ec\[Dagger]"^2*"Q"^2*"uc"*"uc\[Dagger]"^2, 
    "dc"^2*"dc\[Dagger]"^2*"Q"^2*"Q\[Dagger]"^2, "dc"^2*"dc\[Dagger]"*
     "ec\[Dagger]"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2*"ec\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "dc"^2*"ec\[Dagger]"^2*"L\[Dagger]"^2*"Q"^2, "dc"*"dc\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, "dc"*"dc\[Dagger]"^2*"L"*"Q"^2*
     "Q\[Dagger]"*"uc\[Dagger]", "dc"*"ec\[Dagger]"*"L"*"L\[Dagger]"^2*"Q"^2*
     "Q\[Dagger]", "dc"*"dc\[Dagger]"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"Q"^2*
     "uc\[Dagger]", "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"Q"^2*
     "Q\[Dagger]"^2, "dc"*"ec"*"ec\[Dagger]"^2*"L\[Dagger]"*"Q"^2*
     "Q\[Dagger]", "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"^2*"Q"^2*
     "uc\[Dagger]", "L"^2*"L\[Dagger]"^2*"Q"^2*"Q\[Dagger]"^2, 
    "dc\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"^2*"L"^2*"Q"^2*"uc\[Dagger]"^2, "ec\[Dagger]"*"L"^2*
     "L\[Dagger]"^2*"Q"^2*"uc\[Dagger]", "ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*
     "Q"^2*"Q\[Dagger]"^2, "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"L"*"Q"^2*
     "Q\[Dagger]"*"uc\[Dagger]", "ec"*"ec\[Dagger]"^2*"L"*"L\[Dagger]"*"Q"^2*
     "uc\[Dagger]", "ec"^2*"ec\[Dagger]"^2*"Q"^2*"Q\[Dagger]"^2, 
    "ec"^2*"ec\[Dagger]"^3*"Q"^2*"uc\[Dagger]", "Q"*"Q\[Dagger]"*"uc"^3*
     "uc\[Dagger]"^3, "dc"*"dc\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"^2*
     "uc\[Dagger]"^2, "dc"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"uc"^2*
     "uc\[Dagger]"^2, "L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"^2*
     "uc\[Dagger]"^2, "dc\[Dagger]"*"L"*"Q"*"uc"^2*"uc\[Dagger]"^3, 
    "ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "dc"^2*"dc\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"^2*"ec\[Dagger]"*"L\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc", 
    "dc"^2*"dc\[Dagger]"*"ec\[Dagger]"*"L\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"^2*"L"*"Q"*"uc"*"uc\[Dagger]"^2, 
    "dc"*"ec\[Dagger]"*"L"*"L\[Dagger]"^2*"Q"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*
     "uc\[Dagger]", "dc"*"ec"*"ec\[Dagger]"^2*"L\[Dagger]"*"Q"*"uc"*
     "uc\[Dagger]", "L"^2*"L\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"*"uc"*"uc\[Dagger]"^2, 
    "ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"L"*"Q"*"uc"*"uc\[Dagger]"^2, 
    "ec"^2*"ec\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"^3*"dc\[Dagger]"^3*"Q"*"Q\[Dagger]", "dc"^3*"dc\[Dagger]"^2*
     "ec\[Dagger]"*"L\[Dagger]"*"Q", "dc"^2*"dc\[Dagger]"^2*"L"*"L\[Dagger]"*
     "Q"*"Q\[Dagger]", "dc"^2*"dc\[Dagger]"^3*"L"*"Q"*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"*"ec\[Dagger]"*"L"*"L\[Dagger]"^2*"Q", 
    "dc"^2*"dc\[Dagger]"^2*"ec"*"ec\[Dagger]"*"Q"*"Q\[Dagger]", 
    "dc"^2*"dc\[Dagger]"*"ec"*"ec\[Dagger]"^2*"L\[Dagger]"*"Q", 
    "dc"*"dc\[Dagger]"*"L"^2*"L\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "dc"*"dc\[Dagger]"^2*"L"^2*"L\[Dagger]"*"Q"*"uc\[Dagger]", 
    "dc"*"ec\[Dagger]"*"L"^2*"L\[Dagger]"^3*"Q", "dc"*"dc\[Dagger]"*"ec"*
     "ec\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "dc"*"dc\[Dagger]"^2*"ec"*"ec\[Dagger]"*"L"*"Q"*"uc\[Dagger]", 
    "dc"*"ec"*"ec\[Dagger]"^2*"L"*"L\[Dagger]"^2*"Q", 
    "dc"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "dc"*"ec"^2*"ec\[Dagger]"^3*"L\[Dagger]"*"Q", "L"^3*"L\[Dagger]"^3*"Q"*
     "Q\[Dagger]", "dc\[Dagger]"*"L"^3*"L\[Dagger]"^2*"Q"*"uc\[Dagger]", 
    "ec"*"ec\[Dagger]"*"L"^2*"L\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"*"uc\[Dagger]", 
    "ec"^2*"ec\[Dagger]"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "dc\[Dagger]"*"ec"^2*"ec\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]", 
    "ec"^3*"ec\[Dagger]"^3*"Q"*"Q\[Dagger]", "uc"^4*"uc\[Dagger]"^4, 
    "dc"*"dc\[Dagger]"*"uc"^3*"uc\[Dagger]"^3, "L"*"L\[Dagger]"*"uc"^3*
     "uc\[Dagger]"^3, "ec"*"ec\[Dagger]"*"uc"^3*"uc\[Dagger]"^3, 
    "dc"^2*"dc\[Dagger]"^2*"uc"^2*"uc\[Dagger]"^2, 
    "dc"^2*"ec\[Dagger]"*"L\[Dagger]"^2*"uc"^2*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"L"*"L\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "L"^2*"L\[Dagger]"^2*"uc"^2*"uc\[Dagger]"^2, "ec"*"ec\[Dagger]"*"L"*
     "L\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, "ec"^2*"ec\[Dagger]"^2*"uc"^2*
     "uc\[Dagger]"^2, "dc"^3*"dc\[Dagger]"^3*"uc"*"uc\[Dagger]", 
    "dc"^3*"dc\[Dagger]"*"ec\[Dagger]"*"L\[Dagger]"^2*"uc", 
    "dc"^2*"dc\[Dagger]"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"^2*"ec\[Dagger]"*"L"*"L\[Dagger]"^3*"uc", "dc"^2*"dc\[Dagger]"^2*"ec"*
     "ec\[Dagger]"*"uc"*"uc\[Dagger]", "dc"^2*"ec"*"ec\[Dagger]"^2*
     "L\[Dagger]"^2*"uc", "dc"*"dc\[Dagger]"*"L"^2*"L\[Dagger]"^2*"uc"*
     "uc\[Dagger]", "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]"*
     "uc"*"uc\[Dagger]", "dc"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"^2*"uc"*
     "uc\[Dagger]", "L"^3*"L\[Dagger]"^3*"uc"*"uc\[Dagger]", 
    "ec"*"ec\[Dagger]"*"L"^2*"L\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "ec"^2*"ec\[Dagger]"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "ec"^3*"ec\[Dagger]"^3*"uc"*"uc\[Dagger]", "dc"^4*"dc\[Dagger]"^4, 
    "dc"^3*"dc\[Dagger]"^3*"L"*"L\[Dagger]", "dc"^3*"dc\[Dagger]"^3*"ec"*
     "ec\[Dagger]", "dc"^2*"dc\[Dagger]"^2*"L"^2*"L\[Dagger]"^2, 
    "dc"^2*"dc\[Dagger]"^2*"ec"*"ec\[Dagger]"*"L"*"L\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2*"ec"^2*"ec\[Dagger]"^2, 
    "dc"*"dc\[Dagger]"*"L"^3*"L\[Dagger]"^3, "dc"*"dc\[Dagger]"*"ec"*
     "ec\[Dagger]"*"L"^2*"L\[Dagger]"^2, "dc"*"dc\[Dagger]"*"ec"^2*
     "ec\[Dagger]"^2*"L"*"L\[Dagger]", "dc"*"dc\[Dagger]"*"ec"^3*
     "ec\[Dagger]"^3, "L"^4*"L\[Dagger]"^4, "ec"*"ec\[Dagger]"*"L"^3*
     "L\[Dagger]"^3, "ec"^2*"ec\[Dagger]"^2*"L"^2*"L\[Dagger]"^2, 
    "ec"^3*"ec\[Dagger]"^3*"L"*"L\[Dagger]", "ec"^4*"ec\[Dagger]"^4}, 
  FR*\[Phi]*\[Psi]^4*OverBar[\[Psi]]^2 -> 
   {"ec\[Dagger]"*"GR"*"H"*"Q"^4*"Q\[Dagger]", "ec\[Dagger]"*"H"*"Q"^4*
     "Q\[Dagger]"*"WR", "BR"*"ec\[Dagger]"*"H"*"Q"^4*"Q\[Dagger]", 
    "GR"*"H"*"Q"^3*"Q\[Dagger]"^2*"uc", "H"*"Q"^3*"Q\[Dagger]"^2*"uc"*"WR", 
    "BR"*"H"*"Q"^3*"Q\[Dagger]"^2*"uc", "ec\[Dagger]"*"GR"*"H"*"Q"^3*"uc"*
     "uc\[Dagger]", "ec\[Dagger]"*"H"*"Q"^3*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"ec\[Dagger]"*"H"*"Q"^3*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec\[Dagger]"*"GR"*"H"*"Q"^3, 
    "dc"*"dc\[Dagger]"*"ec\[Dagger]"*"H"*"Q"^3*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"ec\[Dagger]"*"H"*"Q"^3, 
    "dc"*"GR"*"H\[Dagger]"*"Q"^3*"Q\[Dagger]"^2, "dc"*"H\[Dagger]"*"Q"^3*
     "Q\[Dagger]"^2*"WR", "BR"*"dc"*"H\[Dagger]"*"Q"^3*"Q\[Dagger]"^2, 
    "dc"*"ec\[Dagger]"*"GR"*"H\[Dagger]"*"Q"^3*"uc\[Dagger]", 
    "dc"*"ec\[Dagger]"*"H\[Dagger]"*"Q"^3*"uc\[Dagger]"*"WR", 
    "BR"*"dc"*"ec\[Dagger]"*"H\[Dagger]"*"Q"^3*"uc\[Dagger]", 
    "dc\[Dagger]"*"GR"*"H"*"L"*"Q"^3*"Q\[Dagger]", 
    "dc\[Dagger]"*"H"*"L"*"Q"^3*"Q\[Dagger]"*"WR", 
    "BR"*"dc\[Dagger]"*"H"*"L"*"Q"^3*"Q\[Dagger]", 
    "ec\[Dagger]"*"GR"*"H"*"L"*"L\[Dagger]"*"Q"^3, 
    "ec\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q"^3*"WR", 
    "BR"*"ec\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q"^3, 
    "GR"*"H\[Dagger]"*"L"*"Q"^3*"Q\[Dagger]"*"uc\[Dagger]", 
    "H\[Dagger]"*"L"*"Q"^3*"Q\[Dagger]"*"uc\[Dagger]"*"WR", 
    "BR"*"H\[Dagger]"*"L"*"Q"^3*"Q\[Dagger]"*"uc\[Dagger]", 
    "ec"*"ec\[Dagger]"^2*"GR"*"H"*"Q"^3, "ec"*"ec\[Dagger]"^2*"H"*"Q"^3*"WR", 
    "BR"*"ec"*"ec\[Dagger]"^2*"H"*"Q"^3, "GR"*"H"*"Q"^2*"Q\[Dagger]"*"uc"^2*
     "uc\[Dagger]", "H"*"Q"^2*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]"*"WR", 
    "BR"*"H"*"Q"^2*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"GR"*"H"*"Q"^2*"Q\[Dagger]"*"uc", 
    "dc"*"dc\[Dagger]"*"H"*"Q"^2*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"H"*"Q"^2*"Q\[Dagger]"*"uc", 
    "dc"*"ec\[Dagger]"*"GR"*"H"*"L\[Dagger]"*"Q"^2*"uc", 
    "dc"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"Q"^2*"uc"*"WR", 
    "BR"*"dc"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"Q"^2*"uc", 
    "dc"*"GR"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"dc"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "GR"*"H"*"L"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc", 
    "H"*"L"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"H"*"L"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc", 
    "dc\[Dagger]"*"GR"*"H"*"L"*"Q"^2*"uc"*"uc\[Dagger]", 
    "dc\[Dagger]"*"H"*"L"*"Q"^2*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"dc\[Dagger]"*"H"*"L"*"Q"^2*"uc"*"uc\[Dagger]", 
    "GR"*"H\[Dagger]"*"L"*"Q"^2*"uc"*"uc\[Dagger]"^2, 
    "H\[Dagger]"*"L"*"Q"^2*"uc"*"uc\[Dagger]"^2*"WR", 
    "BR"*"H\[Dagger]"*"L"*"Q"^2*"uc"*"uc\[Dagger]"^2, 
    "ec"*"ec\[Dagger]"*"GR"*"H"*"Q"^2*"Q\[Dagger]"*"uc", 
    "ec"*"ec\[Dagger]"*"H"*"Q"^2*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"ec"*"ec\[Dagger]"*"H"*"Q"^2*"Q\[Dagger]"*"uc", 
    "dc"^2*"dc\[Dagger]"*"GR"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"WR", 
    "BR"*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "dc"^2*"ec\[Dagger]"*"GR"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "dc"^2*"ec\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2*"WR", 
    "BR"*"dc"^2*"ec\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2, 
    "dc"*"dc\[Dagger]"^2*"GR"*"H"*"L"*"Q"^2, "dc"*"dc\[Dagger]"^2*"H"*"L"*
     "Q"^2*"WR", "BR"*"dc"*"dc\[Dagger]"^2*"H"*"L"*"Q"^2, 
    "dc"*"GR"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"*"WR", 
    "BR"*"dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "dc"*"dc\[Dagger]"*"GR"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]", 
    "dc"*"ec"*"ec\[Dagger]"*"GR"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"WR", 
    "BR"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "dc\[Dagger]"*"GR"*"H"*"L"^2*"L\[Dagger]"*"Q"^2, 
    "dc\[Dagger]"*"H"*"L"^2*"L\[Dagger]"*"Q"^2*"WR", 
    "BR"*"dc\[Dagger]"*"H"*"L"^2*"L\[Dagger]"*"Q"^2, 
    "GR"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "H\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WR", 
    "BR"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GR"*"H"*"L"*"Q"^2, 
    "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"L"*"Q"^2*"WR", 
    "BR"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"L"*"Q"^2, 
    "ec"*"GR"*"H\[Dagger]"*"L"*"Q"^2*"Q\[Dagger]"^2, 
    "ec"*"H\[Dagger]"*"L"*"Q"^2*"Q\[Dagger]"^2*"WR", 
    "BR"*"ec"*"H\[Dagger]"*"L"*"Q"^2*"Q\[Dagger]"^2, 
    "ec"*"ec\[Dagger]"*"GR"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]", 
    "ec"*"ec\[Dagger]"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]"*"WR", 
    "BR"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"L"*"Q"^2*"uc\[Dagger]", 
    "GR"*"H"*"Q"*"uc"^3*"uc\[Dagger]"^2, "H"*"Q"*"uc"^3*"uc\[Dagger]"^2*"WR", 
    "BR"*"H"*"Q"*"uc"^3*"uc\[Dagger]"^2, "dc"*"GR"*"H"*"L\[Dagger]"*"Q"*
     "Q\[Dagger]"*"uc"^2, "dc"*"H"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"^2*"WR", 
    "BR"*"dc"*"H"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"^2, 
    "dc"*"dc\[Dagger]"*"GR"*"H"*"Q"*"uc"^2*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"H"*"Q"*"uc"^2*"uc\[Dagger]"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"H"*"Q"*"uc"^2*"uc\[Dagger]", 
    "dc"*"GR"*"H\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]"^2, 
    "dc"*"H\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]"^2*"WR", 
    "BR"*"dc"*"H\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]"^2, 
    "GR"*"H"*"L"*"L\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]", 
    "H"*"L"*"L\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]"*"WR", 
    "BR"*"H"*"L"*"L\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]", 
    "ec"*"GR"*"H"*"Q"*"Q\[Dagger]"^2*"uc"^2, "ec"*"H"*"Q"*"Q\[Dagger]"^2*
     "uc"^2*"WR", "BR"*"ec"*"H"*"Q"*"Q\[Dagger]"^2*"uc"^2, 
    "ec"*"ec\[Dagger]"*"GR"*"H"*"Q"*"uc"^2*"uc\[Dagger]", 
    "ec"*"ec\[Dagger]"*"H"*"Q"*"uc"^2*"uc\[Dagger]"*"WR", 
    "BR"*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc"^2*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2*"GR"*"H"*"Q"*"uc", "dc"^2*"dc\[Dagger]"^2*"H"*"Q"*
     "uc"*"WR", "BR"*"dc"^2*"dc\[Dagger]"^2*"H"*"Q"*"uc", 
    "dc"^2*"GR"*"H\[Dagger]"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc", 
    "dc"^2*"H\[Dagger]"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc", 
    "dc"^2*"dc\[Dagger]"*"GR"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"GR"*"H"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "dc"*"dc\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q"*"uc"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "dc"*"GR"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"dc"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GR"*"H"*"Q"*"uc", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"Q"*"uc", 
    "dc"*"ec"*"GR"*"H\[Dagger]"*"Q"*"Q\[Dagger]"^2*"uc", 
    "dc"*"ec"*"H\[Dagger]"*"Q"*"Q\[Dagger]"^2*"uc"*"WR", 
    "BR"*"dc"*"ec"*"H\[Dagger]"*"Q"*"Q\[Dagger]"^2*"uc", 
    "dc"*"ec"*"ec\[Dagger]"*"GR"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "GR"*"H"*"L"^2*"L\[Dagger]"^2*"Q"*"uc", "H"*"L"^2*"L\[Dagger]"^2*"Q"*"uc"*
     "WR", "BR"*"H"*"L"^2*"L\[Dagger]"^2*"Q"*"uc", 
    "dc\[Dagger]"*"ec"*"GR"*"H"*"L"*"Q"*"Q\[Dagger]"*"uc", 
    "dc\[Dagger]"*"ec"*"H"*"L"*"Q"*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"dc\[Dagger]"*"ec"*"H"*"L"*"Q"*"Q\[Dagger]"*"uc", 
    "ec"*"ec\[Dagger]"*"GR"*"H"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "ec"*"ec\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q"*"uc"*"WR", 
    "BR"*"ec"*"ec\[Dagger]"*"H"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "ec"*"GR"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "ec"^2*"ec\[Dagger]"^2*"GR"*"H"*"Q"*"uc", "ec"^2*"ec\[Dagger]"^2*"H"*"Q"*
     "uc"*"WR", "BR"*"ec"^2*"ec\[Dagger]"^2*"H"*"Q"*"uc", 
    "dc"^3*"dc\[Dagger]"^2*"GR"*"H\[Dagger]"*"Q", "dc"^3*"dc\[Dagger]"^2*
     "H\[Dagger]"*"Q"*"WR", "BR"*"dc"^3*"dc\[Dagger]"^2*"H\[Dagger]"*"Q", 
    "dc"^2*"dc\[Dagger]"*"GR"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"WR", 
    "BR"*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "dc"^2*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GR"*"H\[Dagger]"*"Q", 
    "dc"^2*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q"*"WR", 
    "BR"*"dc"^2*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"Q", 
    "dc"*"GR"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2*"Q", 
    "dc"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2*"Q"*"WR", 
    "BR"*"dc"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2*"Q", 
    "dc"*"dc\[Dagger]"*"ec"*"GR"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "dc"*"ec"*"ec\[Dagger]"*"GR"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"WR", 
    "BR"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q", 
    "dc"*"ec"^2*"ec\[Dagger]"^2*"GR"*"H\[Dagger]"*"Q", 
    "dc"*"ec"^2*"ec\[Dagger]"^2*"H\[Dagger]"*"Q"*"WR", 
    "BR"*"dc"*"ec"^2*"ec\[Dagger]"^2*"H\[Dagger]"*"Q", 
    "dc\[Dagger]"^2*"ec"*"GR"*"H"*"L"^2*"Q", "dc\[Dagger]"^2*"ec"*"H"*"L"^2*
     "Q"*"WR", "BR"*"dc\[Dagger]"^2*"ec"*"H"*"L"^2*"Q", 
    "ec"*"GR"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "dc\[Dagger]"*"ec"*"GR"*"H\[Dagger]"*"L"^2*"Q"*"uc\[Dagger]", 
    "dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"^2*"Q"*"uc\[Dagger]"*"WR", 
    "BR"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"^2*"Q"*"uc\[Dagger]", 
    "ec"^2*"ec\[Dagger]"*"GR"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]", 
    "dc"*"GR"*"H"*"L\[Dagger]"*"uc"^3*"uc\[Dagger]", 
    "dc"*"H"*"L\[Dagger]"*"uc"^3*"uc\[Dagger]"*"WR", 
    "BR"*"dc"*"H"*"L\[Dagger]"*"uc"^3*"uc\[Dagger]", 
    "ec"*"GR"*"H"*"Q\[Dagger]"*"uc"^3*"uc\[Dagger]", 
    "ec"*"H"*"Q\[Dagger]"*"uc"^3*"uc\[Dagger]"*"WR", 
    "BR"*"ec"*"H"*"Q\[Dagger]"*"uc"^3*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"*"GR"*"H"*"L\[Dagger]"*"uc"^2, 
    "dc"^2*"dc\[Dagger]"*"H"*"L\[Dagger]"*"uc"^2*"WR", 
    "BR"*"dc"^2*"dc\[Dagger]"*"H"*"L\[Dagger]"*"uc"^2, 
    "dc"^2*"GR"*"H\[Dagger]"*"L\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"^2*"uc\[Dagger]"*"WR", 
    "BR"*"dc"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "dc"*"GR"*"H"*"L"*"L\[Dagger]"^2*"uc"^2, "dc"*"H"*"L"*"L\[Dagger]"^2*
     "uc"^2*"WR", "BR"*"dc"*"H"*"L"*"L\[Dagger]"^2*"uc"^2, 
    "dc"*"dc\[Dagger]"*"ec"*"GR"*"H"*"Q\[Dagger]"*"uc"^2, 
    "dc"*"dc\[Dagger]"*"ec"*"H"*"Q\[Dagger]"*"uc"^2*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"ec"*"H"*"Q\[Dagger]"*"uc"^2, 
    "dc"*"ec"*"ec\[Dagger]"*"GR"*"H"*"L\[Dagger]"*"uc"^2, 
    "dc"*"ec"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"uc"^2*"WR", 
    "BR"*"dc"*"ec"*"ec\[Dagger]"*"H"*"L\[Dagger]"*"uc"^2, 
    "dc"*"ec"*"GR"*"H\[Dagger]"*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]"*"WR", 
    "BR"*"dc"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "ec"*"GR"*"H"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2, 
    "ec"*"H"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2*"WR", 
    "BR"*"ec"*"H"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2, 
    "dc\[Dagger]"*"ec"*"GR"*"H"*"L"*"uc"^2*"uc\[Dagger]", 
    "dc\[Dagger]"*"ec"*"H"*"L"*"uc"^2*"uc\[Dagger]"*"WR", 
    "BR"*"dc\[Dagger]"*"ec"*"H"*"L"*"uc"^2*"uc\[Dagger]", 
    "ec"*"GR"*"H\[Dagger]"*"L"*"uc"^2*"uc\[Dagger]"^2, 
    "ec"*"H\[Dagger]"*"L"*"uc"^2*"uc\[Dagger]"^2*"WR", 
    "BR"*"ec"*"H\[Dagger]"*"L"*"uc"^2*"uc\[Dagger]"^2, 
    "ec"^2*"ec\[Dagger]"*"GR"*"H"*"Q\[Dagger]"*"uc"^2, 
    "ec"^2*"ec\[Dagger]"*"H"*"Q\[Dagger]"*"uc"^2*"WR", 
    "BR"*"ec"^2*"ec\[Dagger]"*"H"*"Q\[Dagger]"*"uc"^2, 
    "dc"^3*"dc\[Dagger]"*"GR"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "dc"^3*"dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WR", 
    "BR"*"dc"^3*"dc\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "dc"^2*"GR"*"H\[Dagger]"*"L"*"L\[Dagger]"^2*"uc", 
    "dc"^2*"H\[Dagger]"*"L"*"L\[Dagger]"^2*"uc"*"WR", 
    "BR"*"dc"^2*"H\[Dagger]"*"L"*"L\[Dagger]"^2*"uc", 
    "dc"^2*"dc\[Dagger]"*"ec"*"GR"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "dc"^2*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"dc"^2*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "dc"^2*"ec"*"ec\[Dagger]"*"GR"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "dc"^2*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"uc"*"WR", 
    "BR"*"dc"^2*"ec"*"ec\[Dagger]"*"H\[Dagger]"*"L\[Dagger]"*"uc", 
    "dc"*"dc\[Dagger]"^2*"ec"*"GR"*"H"*"L"*"uc", "dc"*"dc\[Dagger]"^2*"ec"*
     "H"*"L"*"uc"*"WR", "BR"*"dc"*"dc\[Dagger]"^2*"ec"*"H"*"L"*"uc", 
    "dc"*"ec"*"GR"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "dc"*"ec"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"dc"*"ec"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "dc"*"dc\[Dagger]"*"ec"*"GR"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", 
    "dc"*"ec"^2*"ec\[Dagger]"*"GR"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "dc"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"dc"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"Q\[Dagger]"*"uc", 
    "dc\[Dagger]"*"ec"*"GR"*"H"*"L"^2*"L\[Dagger]"*"uc", 
    "dc\[Dagger]"*"ec"*"H"*"L"^2*"L\[Dagger]"*"uc"*"WR", 
    "BR"*"dc\[Dagger]"*"ec"*"H"*"L"^2*"L\[Dagger]"*"uc", 
    "ec"*"GR"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"GR"*"H"*"L"*"uc", 
    "dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"H"*"L"*"uc"*"WR", 
    "BR"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"H"*"L"*"uc", 
    "ec"^2*"GR"*"H\[Dagger]"*"L"*"Q\[Dagger]"^2*"uc", 
    "ec"^2*"H\[Dagger]"*"L"*"Q\[Dagger]"^2*"uc"*"WR", 
    "BR"*"ec"^2*"H\[Dagger]"*"L"*"Q\[Dagger]"^2*"uc", 
    "ec"^2*"ec\[Dagger]"*"GR"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", 
    "ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"uc"*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2*"ec"*"GR"*"H\[Dagger]"*"L", 
    "dc"^2*"dc\[Dagger]"^2*"ec"*"H\[Dagger]"*"L"*"WR", 
    "BR"*"dc"^2*"dc\[Dagger]"^2*"ec"*"H\[Dagger]"*"L", 
    "dc"*"dc\[Dagger]"*"ec"*"GR"*"H\[Dagger]"*"L"^2*"L\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"ec"*"H\[Dagger]"*"L"^2*"L\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"GR"*"H\[Dagger]"*"L", 
    "dc"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L", 
    "ec"*"H\[Dagger]"*"L"^3*"L\[Dagger]"^2*"WR", "BR"*"ec"*"H\[Dagger]"*"L"^3*
     "L\[Dagger]"^2, "dc\[Dagger]"*"ec"^2*"GR"*"H\[Dagger]"*"L"^2*
     "Q\[Dagger]", "dc\[Dagger]"*"ec"^2*"H\[Dagger]"*"L"^2*"Q\[Dagger]"*"WR", 
    "BR"*"dc\[Dagger]"*"ec"^2*"H\[Dagger]"*"L"^2*"Q\[Dagger]", 
    "ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"WR", 
    "BR"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"*"L"^2*"L\[Dagger]", 
    "ec"^3*"ec\[Dagger]"^2*"H\[Dagger]"*"L"*"WR", "BR"*"ec"^3*"ec\[Dagger]"^2*
     "H\[Dagger]"*"L"}, FR^2*\[Phi]^2*\[Psi]^4 -> 
   {"GR"^2*"H"*"H\[Dagger]"*"L"*"Q"^3, "GR"*"H"*"H\[Dagger]"*"L"*"Q"^3*"WR", 
    "BR"*"GR"*"H"*"H\[Dagger]"*"L"*"Q"^3, "H"*"H\[Dagger]"*"L"*"Q"^3*"WR"^2, 
    "BR"*"H"*"H\[Dagger]"*"L"*"Q"^3*"WR", "BR"^2*"H"*"H\[Dagger]"*"L"*"Q"^3, 
    "GR"^2*"H"^2*"Q"^2*"uc"^2, "GR"*"H"^2*"Q"^2*"uc"^2*"WR", 
    "BR"*"GR"*"H"^2*"Q"^2*"uc"^2, "H"^2*"Q"^2*"uc"^2*"WR"^2, 
    "BR"*"H"^2*"Q"^2*"uc"^2*"WR", "BR"^2*"H"^2*"Q"^2*"uc"^2, 
    "dc"*"GR"^2*"H"*"H\[Dagger]"*"Q"^2*"uc", "dc"*"GR"*"H"*"H\[Dagger]"*"Q"^2*
     "uc"*"WR", "BR"*"dc"*"GR"*"H"*"H\[Dagger]"*"Q"^2*"uc", 
    "dc"*"H"*"H\[Dagger]"*"Q"^2*"uc"*"WR"^2, "BR"*"dc"*"H"*"H\[Dagger]"*"Q"^2*
     "uc"*"WR", "BR"^2*"dc"*"H"*"H\[Dagger]"*"Q"^2*"uc", 
    "dc"^2*"GR"^2*"H\[Dagger]"^2*"Q"^2, "dc"^2*"GR"*"H\[Dagger]"^2*"Q"^2*
     "WR", "BR"*"dc"^2*"GR"*"H\[Dagger]"^2*"Q"^2, "dc"^2*"H\[Dagger]"^2*"Q"^2*
     "WR"^2, "BR"*"dc"^2*"H\[Dagger]"^2*"Q"^2*"WR", 
    "BR"^2*"dc"^2*"H\[Dagger]"^2*"Q"^2, "ec"*"GR"^2*"H"*"H\[Dagger]"*"L"*"Q"*
     "uc", "ec"*"GR"*"H"*"H\[Dagger]"*"L"*"Q"*"uc"*"WR", 
    "BR"*"ec"*"GR"*"H"*"H\[Dagger]"*"L"*"Q"*"uc", "ec"*"H"*"H\[Dagger]"*"L"*
     "Q"*"uc"*"WR"^2, "BR"*"ec"*"H"*"H\[Dagger]"*"L"*"Q"*"uc"*"WR", 
    "BR"^2*"ec"*"H"*"H\[Dagger]"*"L"*"Q"*"uc", "dc"*"ec"*"GR"^2*
     "H\[Dagger]"^2*"L"*"Q", "dc"*"ec"*"GR"*"H\[Dagger]"^2*"L"*"Q"*"WR", 
    "BR"*"dc"*"ec"*"GR"*"H\[Dagger]"^2*"L"*"Q", "dc"*"ec"*"H\[Dagger]"^2*"L"*
     "Q"*"WR"^2, "BR"*"dc"*"ec"*"H\[Dagger]"^2*"L"*"Q"*"WR", 
    "BR"^2*"dc"*"ec"*"H\[Dagger]"^2*"L"*"Q", "ec"*"GR"^2*"H"^2*"uc"^3, 
    "ec"*"GR"*"H"^2*"uc"^3*"WR", "BR"*"ec"*"GR"*"H"^2*"uc"^3, 
    "ec"*"H"^2*"uc"^3*"WR"^2, "BR"*"ec"*"H"^2*"uc"^3*"WR", 
    "BR"^2*"ec"*"H"^2*"uc"^3, "dc"*"ec"*"GR"^2*"H"*"H\[Dagger]"*"uc"^2, 
    "dc"*"ec"*"GR"*"H"*"H\[Dagger]"*"uc"^2*"WR", "BR"*"dc"*"ec"*"GR"*"H"*
     "H\[Dagger]"*"uc"^2, "dc"*"ec"*"H"*"H\[Dagger]"*"uc"^2*"WR"^2, 
    "BR"*"dc"*"ec"*"H"*"H\[Dagger]"*"uc"^2*"WR", "BR"^2*"dc"*"ec"*"H"*
     "H\[Dagger]"*"uc"^2, "dc"^2*"ec"*"GR"^2*"H\[Dagger]"^2*"uc", 
    "dc"^2*"ec"*"GR"*"H\[Dagger]"^2*"uc"*"WR", "BR"*"dc"^2*"ec"*"GR"*
     "H\[Dagger]"^2*"uc", "dc"^2*"ec"*"H\[Dagger]"^2*"uc"*"WR"^2, 
    "BR"*"dc"^2*"ec"*"H\[Dagger]"^2*"uc"*"WR", "BR"^2*"dc"^2*"ec"*
     "H\[Dagger]"^2*"uc", "ec"^2*"GR"^2*"H\[Dagger]"^2*"L"^2, 
    "ec"^2*"H\[Dagger]"^2*"L"^2*"WR"^2, "BR"*"ec"^2*"H\[Dagger]"^2*"L"^2*
     "WR", "BR"^2*"ec"^2*"H\[Dagger]"^2*"L"^2}, 
  FL*FR*\[Phi]^2*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"*"ec\[Dagger]"*"GL"*"GR"*"H"^2*"Q"^2, 
    "dc\[Dagger]"*"ec\[Dagger]"*"GL"*"H"^2*"Q"^2*"WR", 
    "BR"*"dc\[Dagger]"*"ec\[Dagger]"*"GL"*"H"^2*"Q"^2, 
    "GL"*"GR"*"H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, 
    "GL"*"H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2*"WR", 
    "BR"*"GL"*"H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, 
    "ec\[Dagger]"*"GL"*"GR"*"H"*"H\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WR", 
    "BR"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "dc\[Dagger]"*"GL"*"GR"*"H"^2*"Q"*"Q\[Dagger]"*"uc", 
    "dc\[Dagger]"*"GL"*"H"^2*"Q"*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"dc\[Dagger]"*"GL"*"H"^2*"Q"*"Q\[Dagger]"*"uc", 
    "ec\[Dagger]"*"GL"*"GR"*"H"^2*"L\[Dagger]"*"Q"*"uc", 
    "ec\[Dagger]"*"GL"*"H"^2*"L\[Dagger]"*"Q"*"uc"*"WR", 
    "BR"*"ec\[Dagger]"*"GL"*"H"^2*"L\[Dagger]"*"Q"*"uc", 
    "GL"*"GR"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"GL"*"GR"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "dc"*"ec\[Dagger]"*"GL"*"GR"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q", 
    "dc"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q"*"WR", 
    "BR"*"dc"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q", 
    "dc"*"GL"*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]"*"WR", 
    "BR"*"dc"*"GL"*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"^2*"GL"*"GR"*"H"^2*"L"*"Q", "dc\[Dagger]"^2*"GL"*"H"^2*"L"*
     "Q"*"WR", "BR"*"dc\[Dagger]"^2*"GL"*"H"^2*"L"*"Q", 
    "GL"*"GR"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "GL"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"GL"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "dc\[Dagger]"*"GL"*"GR"*"H"*"H\[Dagger]"*"L"*"Q"*"uc\[Dagger]", 
    "dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*"WR", 
    "BR"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"L"*"Q"*"uc\[Dagger]", 
    "GL"*"GR"*"H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"^2, 
    "GL"*"H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"^2*"WR", 
    "BR"*"GL"*"H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"^2, 
    "ec"*"ec\[Dagger]"*"GL"*"GR"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "GL"*"H"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2*"WR", 
    "BR"*"GL"*"H"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2, 
    "dc\[Dagger]"*"GL"*"GR"*"H"^2*"uc"^2*"uc\[Dagger]", 
    "dc\[Dagger]"*"GL"*"H"^2*"uc"^2*"uc\[Dagger]"*"WR", 
    "BR"*"dc\[Dagger]"*"GL"*"H"^2*"uc"^2*"uc\[Dagger]", 
    "GL"*"GR"*"H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "GL"*"H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2*"WR", 
    "BR"*"GL"*"H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "dc"*"dc\[Dagger]"^2*"GL"*"GR"*"H"^2*"uc", "dc"*"dc\[Dagger]"^2*"GL"*
     "H"^2*"uc"*"WR", "BR"*"dc"*"dc\[Dagger]"^2*"GL"*"H"^2*"uc", 
    "dc"*"GL"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"dc"*"GL"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "dc"*"dc\[Dagger]"*"GL"*"GR"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"*"GL"*"H\[Dagger]"^2*"uc"*"uc\[Dagger]"^2*"WR", 
    "BR"*"dc"*"GL"*"H\[Dagger]"^2*"uc"*"uc\[Dagger]"^2, 
    "dc\[Dagger]"*"GL"*"GR"*"H"^2*"L"*"L\[Dagger]"*"uc", 
    "dc\[Dagger]"*"GL"*"H"^2*"L"*"L\[Dagger]"*"uc"*"WR", 
    "BR"*"dc\[Dagger]"*"GL"*"H"^2*"L"*"L\[Dagger]"*"uc", 
    "GL"*"GR"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "GL"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"GL"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"GR"*"H"^2*"uc", 
    "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"H"^2*"uc"*"WR", 
    "BR"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"H"^2*"uc", 
    "ec"*"GL"*"H"*"H\[Dagger]"*"Q\[Dagger]"^2*"uc"*"WR", 
    "BR"*"ec"*"GL"*"H"*"H\[Dagger]"*"Q\[Dagger]"^2*"uc", 
    "ec"*"ec\[Dagger]"*"GL"*"GR"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2*"GL"*"GR"*"H"*"H\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2*"GL"*"H"*"H\[Dagger]"*"WR", 
    "BR"*"dc"^2*"dc\[Dagger]"^2*"GL"*"H"*"H\[Dagger]", 
    "dc"^2*"GL"*"H\[Dagger]"^2*"L\[Dagger]"*"Q\[Dagger]"*"WR", 
    "BR"*"dc"^2*"GL"*"H\[Dagger]"^2*"L\[Dagger]"*"Q\[Dagger]", 
    "dc"^2*"dc\[Dagger]"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]"*"WR", 
    "BR"*"dc"^2*"dc\[Dagger]"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"GL"*"GR"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "dc"*"GL"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc\[Dagger]"*"WR", 
    "BR"*"dc"*"GL"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"GR"*"H"*"H\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]", 
    "dc"*"ec"*"GL"*"H\[Dagger]"^2*"Q\[Dagger]"^2*"WR", 
    "BR"*"dc"*"ec"*"GL"*"H\[Dagger]"^2*"Q\[Dagger]"^2, 
    "dc"*"ec"*"ec\[Dagger]"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]"*"WR", 
    "BR"*"dc"*"ec"*"ec\[Dagger]"*"GL"*"H\[Dagger]"^2*"uc\[Dagger]", 
    "GL"*"GR"*"H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2, 
    "dc\[Dagger]"*"ec"*"GL"*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]"*"WR", 
    "BR"*"dc\[Dagger]"*"ec"*"GL"*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]", 
    "ec"*"ec\[Dagger]"*"GL"*"GR"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "ec"*"GL"*"H\[Dagger]"^2*"L"*"Q\[Dagger]"*"uc\[Dagger]"*"WR", 
    "BR"*"ec"*"GL"*"H\[Dagger]"^2*"L"*"Q\[Dagger]"*"uc\[Dagger]", 
    "ec"^2*"ec\[Dagger]"^2*"GL"*"GR"*"H"*"H\[Dagger]", 
    "dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"Q"^2*"WL"*"WR", 
    "BR"*"dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"Q"^2*"WL", 
    "H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2*"WL"*"WR", 
    "BR"*"H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2*"WL", 
    "ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"^2*"uc\[Dagger]"*"WL", 
    "dc\[Dagger]"*"H"^2*"Q"*"Q\[Dagger]"*"uc"*"WL"*"WR", 
    "BR"*"dc\[Dagger]"*"H"^2*"Q"*"Q\[Dagger]"*"uc"*"WL", 
    "ec\[Dagger]"*"H"^2*"L\[Dagger]"*"Q"*"uc"*"WL"*"WR", 
    "BR"*"ec\[Dagger]"*"H"^2*"L\[Dagger]"*"Q"*"uc"*"WL", 
    "H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "dc"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q"*"WL"*"WR", 
    "BR"*"dc"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q"*"WL", 
    "BR"*"dc"*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "dc\[Dagger]"^2*"H"^2*"L"*"Q"*"WL"*"WR", "BR"*"dc\[Dagger]"^2*"H"^2*"L"*
     "Q"*"WL", "H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BR"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"Q"*"uc\[Dagger]"*"WL", 
    "H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"^2*"WL"*"WR", 
    "BR"*"H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"^2*"WL", 
    "ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BR"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "BR"*"H"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc"^2*"WL", 
    "dc\[Dagger]"*"H"^2*"uc"^2*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"dc\[Dagger]"*"H"^2*"uc"^2*"uc\[Dagger]"*"WL", 
    "H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2*"WL"*"WR", 
    "BR"*"H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2*"WL", 
    "dc"*"dc\[Dagger]"^2*"H"^2*"uc"*"WL"*"WR", "BR"*"dc"*"dc\[Dagger]"^2*
     "H"^2*"uc"*"WL", "BR"*"dc"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q\[Dagger]"*
     "uc"*"WL", "dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*
     "WR", "BR"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "BR"*"dc"*"H\[Dagger]"^2*"uc"*"uc\[Dagger]"^2*"WL", 
    "dc\[Dagger]"*"H"^2*"L"*"L\[Dagger]"*"uc"*"WL"*"WR", 
    "BR"*"dc\[Dagger]"*"H"^2*"L"*"L\[Dagger]"*"uc"*"WL", 
    "H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*"uc"*"WL"*"WR", 
    "BR"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*"uc"*"WL", 
    "BR"*"ec"*"H"*"H\[Dagger]"*"Q\[Dagger]"^2*"uc"*"WL", 
    "ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "dc"^2*"dc\[Dagger]"^2*"H"*"H\[Dagger]"*"WL"*"WR", 
    "BR"*"dc"^2*"dc\[Dagger]"^2*"H"*"H\[Dagger]"*"WL", 
    "BR"*"dc"^2*"H\[Dagger]"^2*"L\[Dagger]"*"Q\[Dagger]"*"WL", 
    "BR"*"dc"^2*"dc\[Dagger]"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "BR"*"dc"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL"*"WR", 
    "BR"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"WL", 
    "BR"*"dc"*"ec"*"H\[Dagger]"^2*"Q\[Dagger]"^2*"WL", 
    "BR"*"dc"*"ec"*"ec\[Dagger]"*"H\[Dagger]"^2*"uc\[Dagger]"*"WL", 
    "H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2*"WL"*"WR", 
    "BR"*"H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2*"WL", 
    "BR"*"dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"*"L"*"Q\[Dagger]"*"WL", 
    "ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL"*"WR", 
    "BR"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"WL", 
    "BR"*"ec"*"H\[Dagger]"^2*"L"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "ec"^2*"ec\[Dagger]"^2*"H"*"H\[Dagger]"*"WL"*"WR", 
    "BR"*"ec"^2*"ec\[Dagger]"^2*"H"*"H\[Dagger]"*"WL", 
    "BL"*"BR"*"dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"Q"^2, 
    "BL"*"BR"*"H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, 
    "BL"*"BR"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "BL"*"BR"*"dc\[Dagger]"*"H"^2*"Q"*"Q\[Dagger]"*"uc", 
    "BL"*"BR"*"ec\[Dagger]"*"H"^2*"L\[Dagger]"*"Q"*"uc", 
    "BL"*"BR"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"BR"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"BR"*"dc"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q", 
    "BL"*"BR"*"dc\[Dagger]"^2*"H"^2*"L"*"Q", "BL"*"BR"*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q"*"Q\[Dagger]", "BL"*"BR"*"dc\[Dagger]"*"H"*"H\[Dagger]"*
     "L"*"Q"*"uc\[Dagger]", "BL"*"BR"*"H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"^2, 
    "BL"*"BR"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"BR"*"dc\[Dagger]"*"H"^2*"uc"^2*"uc\[Dagger]", 
    "BL"*"BR"*"H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "BL"*"BR"*"dc"*"dc\[Dagger]"^2*"H"^2*"uc", "BL"*"BR"*"dc"*"dc\[Dagger]"*
     "H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", "BL"*"BR"*"dc\[Dagger]"*"H"^2*"L"*
     "L\[Dagger]"*"uc", "BL"*"BR"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*
     "uc\[Dagger]", "BL"*"BR"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*"uc", 
    "BL"*"BR"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"BR"*"dc"^2*"dc\[Dagger]"^2*"H"*"H\[Dagger]", 
    "BL"*"BR"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"*"BR"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]", 
    "BL"*"BR"*"H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2, 
    "BL"*"BR"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "BL"*"BR"*"ec"^2*"ec\[Dagger]"^2*"H"*"H\[Dagger]"}, 
  FL*FR^2*\[Phi]^3*\[Psi]^2 -> {"GL"*"GR"^2*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "GL"*"GR"*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WR", "BR"*"GL"*"GR"*"H"^2*
     "H\[Dagger]"*"Q"*"uc", "GL"*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WR"^2, 
    "BR"*"GL"*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WR", "BR"^2*"GL"*"H"^2*
     "H\[Dagger]"*"Q"*"uc", "dc"*"GL"*"GR"^2*"H"*"H\[Dagger]"^2*"Q", 
    "dc"*"GL"*"GR"*"H"*"H\[Dagger]"^2*"Q"*"WR", "BR"*"dc"*"GL"*"GR"*"H"*
     "H\[Dagger]"^2*"Q", "dc"*"GL"*"H"*"H\[Dagger]"^2*"Q"*"WR"^2, 
    "BR"*"dc"*"GL"*"H"*"H\[Dagger]"^2*"Q"*"WR", "BR"^2*"dc"*"GL"*"H"*
     "H\[Dagger]"^2*"Q", "ec"*"GL"*"GR"^2*"H"*"H\[Dagger]"^2*"L", 
    "ec"*"GL"*"GR"*"H"*"H\[Dagger]"^2*"L"*"WR", "BR"*"ec"*"GL"*"GR"*"H"*
     "H\[Dagger]"^2*"L", "GR"^2*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WL", 
    "GR"*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WL"*"WR", "BR"*"GR"*"H"^2*"H\[Dagger]"*
     "Q"*"uc"*"WL", "H"^2*"H\[Dagger]"*"Q"*"uc"*"WL"*"WR"^2, 
    "BR"*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WL"*"WR", "BR"^2*"H"^2*"H\[Dagger]"*"Q"*
     "uc"*"WL", "dc"*"GR"^2*"H"*"H\[Dagger]"^2*"Q"*"WL", 
    "dc"*"GR"*"H"*"H\[Dagger]"^2*"Q"*"WL"*"WR", "BR"*"dc"*"GR"*"H"*
     "H\[Dagger]"^2*"Q"*"WL", "dc"*"H"*"H\[Dagger]"^2*"Q"*"WL"*"WR"^2, 
    "BR"*"dc"*"H"*"H\[Dagger]"^2*"Q"*"WL"*"WR", 
    "BR"^2*"dc"*"H"*"H\[Dagger]"^2*"Q"*"WL", "ec"*"GR"^2*"H"*"H\[Dagger]"^2*
     "L"*"WL", "ec"*"H"*"H\[Dagger]"^2*"L"*"WL"*"WR"^2, 
    "BR"*"ec"*"H"*"H\[Dagger]"^2*"L"*"WL"*"WR", 
    "BR"^2*"ec"*"H"*"H\[Dagger]"^2*"L"*"WL", "BL"*"GR"^2*"H"^2*"H\[Dagger]"*
     "Q"*"uc", "BL"*"GR"*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WR", 
    "BL"*"BR"*"GR"*"H"^2*"H\[Dagger]"*"Q"*"uc", "BL"*"H"^2*"H\[Dagger]"*"Q"*
     "uc"*"WR"^2, "BL"*"BR"*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WR", 
    "BL"*"BR"^2*"H"^2*"H\[Dagger]"*"Q"*"uc", "BL"*"dc"*"GR"^2*"H"*
     "H\[Dagger]"^2*"Q", "BL"*"dc"*"GR"*"H"*"H\[Dagger]"^2*"Q"*"WR", 
    "BL"*"BR"*"dc"*"GR"*"H"*"H\[Dagger]"^2*"Q", "BL"*"dc"*"H"*"H\[Dagger]"^2*
     "Q"*"WR"^2, "BL"*"BR"*"dc"*"H"*"H\[Dagger]"^2*"Q"*"WR", 
    "BL"*"BR"^2*"dc"*"H"*"H\[Dagger]"^2*"Q", "BL"*"ec"*"GR"^2*"H"*
     "H\[Dagger]"^2*"L", "BL"*"ec"*"H"*"H\[Dagger]"^2*"L"*"WR"^2, 
    "BL"*"BR"*"ec"*"H"*"H\[Dagger]"^2*"L"*"WR", "BL"*"BR"^2*"ec"*"H"*
     "H\[Dagger]"^2*"L"}, FL^2*FR^2*\[Phi]^4 -> 
   {"GL"^2*"GR"^2*"H"^2*"H\[Dagger]"^2, "GL"^2*"GR"*"H"^2*"H\[Dagger]"^2*
     "WR", "BR"*"GL"^2*"GR"*"H"^2*"H\[Dagger]"^2, "GL"^2*"H"^2*"H\[Dagger]"^2*
     "WR"^2, "BR"*"GL"^2*"H"^2*"H\[Dagger]"^2*"WR", 
    "BR"^2*"GL"^2*"H"^2*"H\[Dagger]"^2, "GL"*"GR"*"H"^2*"H\[Dagger]"^2*"WL"*
     "WR", "BR"*"GL"*"GR"*"H"^2*"H\[Dagger]"^2*"WL", 
    "BL"*"BR"*"GL"*"GR"*"H"^2*"H\[Dagger]"^2, "H"^2*"H\[Dagger]"^2*"WL"^2*
     "WR"^2, "BR"*"H"^2*"H\[Dagger]"^2*"WL"^2*"WR", 
    "BR"^2*"H"^2*"H\[Dagger]"^2*"WL"^2, "BL"*"BR"*"H"^2*"H\[Dagger]"^2*"WL"*
     "WR", "BL"*"BR"^2*"H"^2*"H\[Dagger]"^2*"WL", 
    "BL"^2*"BR"^2*"H"^2*"H\[Dagger]"^2}, 
  D*\[Phi]^2*\[Psi]^3*OverBar[\[Psi]]^3 -> 
   {"D"*"dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"Q"^3*"Q\[Dagger]", 
    "D"*"ec\[Dagger]"^2*"H"^2*"L\[Dagger]"*"Q"^3, "D"*"H"*"H\[Dagger]"*"Q"^3*
     "Q\[Dagger]"^3, "D"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"^3*"Q\[Dagger]"*
     "uc\[Dagger]", "D"*"dc\[Dagger]"*"H"^2*"Q"^2*"Q\[Dagger]"^2*"uc", 
    "D"*"ec\[Dagger]"*"H"^2*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc", 
    "D"*"dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"Q"^2*"uc"*"uc\[Dagger]", 
    "D"*"H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"^2*"uc"*"uc\[Dagger]"^2, 
    "D"*"dc"*"dc\[Dagger]"^2*"ec\[Dagger]"*"H"^2*"Q"^2, 
    "D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, 
    "D"*"dc"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"^2*
     "uc\[Dagger]", "D"*"dc"*"ec\[Dagger]"*"H\[Dagger]"^2*"Q"^2*
     "uc\[Dagger]"^2, "D"*"dc\[Dagger]"^2*"H"^2*"L"*"Q"^2*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"L"*"L\[Dagger]"*"Q"^2, 
    "D"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, 
    "D"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"Q"^2*"Q\[Dagger]"*"uc\[Dagger]", 
    "D"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "D"*"H\[Dagger]"^2*"L"*"Q"^2*"Q\[Dagger]"*"uc\[Dagger]"^2, 
    "D"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"^2*"H"^2*"Q"^2, 
    "D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"^2, 
    "D"*"ec"*"ec\[Dagger]"^2*"H"*"H\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "D"*"dc\[Dagger]"*"H"^2*"Q"*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "D"*"ec\[Dagger]"*"H"^2*"L\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]", 
    "D"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "D"*"dc"*"dc\[Dagger]"^2*"H"^2*"Q"*"Q\[Dagger]"*"uc", 
    "D"*"dc"*"dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"L\[Dagger]"*"Q"*"uc", 
    "D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*
     "uc\[Dagger]", "D"*"dc"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L\[Dagger]"*"Q"*
     "uc"*"uc\[Dagger]", "D"*"dc\[Dagger]"*"H"^2*"L"*"L\[Dagger]"*"Q"*
     "Q\[Dagger]"*"uc", "D"*"dc\[Dagger]"^2*"H"^2*"L"*"Q"*"uc"*"uc\[Dagger]", 
    "D"*"ec\[Dagger]"*"H"^2*"L"*"L\[Dagger]"^2*"Q"*"uc", 
    "D"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*
     "uc\[Dagger]", "D"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"Q"*"uc"*
     "uc\[Dagger]"^2, "D"*"H\[Dagger]"^2*"L"*"Q"*"uc"*"uc\[Dagger]"^3, 
    "D"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*"Q"*"Q\[Dagger]"*"uc", 
    "D"*"ec"*"ec\[Dagger]"^2*"H"^2*"L\[Dagger]"*"Q"*"uc", 
    "D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*
     "uc\[Dagger]", "D"*"dc"^2*"dc\[Dagger]"^2*"H"*"H\[Dagger]"*"Q"*
     "Q\[Dagger]", "D"*"dc"^2*"dc\[Dagger]"*"ec\[Dagger]"*"H"*"H\[Dagger]"*
     "L\[Dagger]"*"Q", "D"*"dc"^2*"ec\[Dagger]"*"H\[Dagger]"^2*"L\[Dagger]"*
     "Q"*"uc\[Dagger]", "D"*"dc"*"dc\[Dagger]"^3*"H"^2*"L"*"Q", 
    "D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*
     "Q\[Dagger]", "D"*"dc"*"dc\[Dagger]"^2*"H"*"H\[Dagger]"*"L"*"Q"*
     "uc\[Dagger]", "D"*"dc"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"^2*"Q", "D"*"dc"*"dc\[Dagger]"*"H\[Dagger]"^2*"L"*"Q"*
     "uc\[Dagger]"^2, "D"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*
     "H\[Dagger]"*"Q"*"Q\[Dagger]", "D"*"dc"*"ec"*"ec\[Dagger]"^2*"H"*
     "H\[Dagger]"*"L\[Dagger]"*"Q", "D"*"dc\[Dagger]"^2*"H"^2*"L"^2*
     "L\[Dagger]"*"Q", "D"*"H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2*"Q"*
     "Q\[Dagger]", "D"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"*
     "uc\[Dagger]", "D"*"H\[Dagger]"^2*"L"^2*"L\[Dagger]"*"Q"*
     "uc\[Dagger]"^2, "D"*"dc\[Dagger]"^2*"ec"*"ec\[Dagger]"*"H"^2*"L"*"Q", 
    "D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*
     "Q\[Dagger]", "D"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"*
     "Q"*"uc\[Dagger]", "D"*"ec"*"ec\[Dagger]"*"H\[Dagger]"^2*"L"*"Q"*
     "uc\[Dagger]"^2, "D"*"ec"^2*"ec\[Dagger]"^2*"H"*"H\[Dagger]"*"Q"*
     "Q\[Dagger]", "D"*"dc\[Dagger]"*"H"^2*"uc"^3*"uc\[Dagger]"^2, 
    "D"*"H"*"H\[Dagger]"*"uc"^3*"uc\[Dagger]"^3, "D"*"dc"*"dc\[Dagger]"^2*
     "H"^2*"uc"^2*"uc\[Dagger]", "D"*"dc"*"ec\[Dagger]"*"H"^2*"L\[Dagger]"^2*
     "uc"^2, "D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "D"*"dc\[Dagger]"*"H"^2*"L"*"L\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "D"*"H"*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "D"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*"uc"^2*"uc\[Dagger]", 
    "D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"uc"^2*"uc\[Dagger]"^2, 
    "D"*"dc"^2*"dc\[Dagger]"^3*"H"^2*"uc", "D"*"dc"^2*"dc\[Dagger]"^2*"H"*
     "H\[Dagger]"*"uc"*"uc\[Dagger]", "D"*"dc"^2*"ec\[Dagger]"*"H"*
     "H\[Dagger]"*"L\[Dagger]"^2*"uc", "D"*"dc"*"dc\[Dagger]"^2*"H"^2*"L"*
     "L\[Dagger]"*"uc", "D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"uc"*"uc\[Dagger]", "D"*"dc"*"dc\[Dagger]"^2*"ec"*
     "ec\[Dagger]"*"H"^2*"uc", "D"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*
     "H\[Dagger]"*"uc"*"uc\[Dagger]", "D"*"dc\[Dagger]"*"H"^2*"L"^2*
     "L\[Dagger]"^2*"uc", "D"*"H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2*"uc"*
     "uc\[Dagger]", "D"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*"L"*
     "L\[Dagger]"*"uc", "D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"uc"*"uc\[Dagger]", "D"*"dc\[Dagger]"*"ec"^2*
     "ec\[Dagger]"^2*"H"^2*"uc", "D"*"ec"^2*"ec\[Dagger]"^2*"H"*"H\[Dagger]"*
     "uc"*"uc\[Dagger]", "D"*"dc"^3*"dc\[Dagger]"^3*"H"*"H\[Dagger]", 
    "D"*"dc"^3*"ec\[Dagger]"*"H\[Dagger]"^2*"L\[Dagger]"^2, 
    "D"*"dc"^2*"dc\[Dagger]"^2*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "D"*"dc"^2*"dc\[Dagger]"^2*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2, 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"*
     "L\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"^2*"H"*
     "H\[Dagger]", "D"*"H"*"H\[Dagger]"*"L"^3*"L\[Dagger]"^3, 
    "D"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2, 
    "D"*"ec"^2*"ec\[Dagger]"^2*"H"*"H\[Dagger]"*"L"*"L\[Dagger]", 
    "D"*"ec"^3*"ec\[Dagger]"^3*"H"*"H\[Dagger]"}, 
  D*FR*\[Phi]^3*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"*"ec\[Dagger]"*"GR"*"H"^2*"H\[Dagger]"*"Q"^3, 
    "D"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"^3*"WR", 
    "BR"*"D"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"^3, 
    "D"*"GR"*"H"^2*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc", 
    "D"*"H"^2*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"D"*"H"^2*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc", 
    "D"*"dc"*"GR"*"H"*"H\[Dagger]"^2*"Q"^2*"Q\[Dagger]", 
    "D"*"dc"*"H"*"H\[Dagger]"^2*"Q"^2*"Q\[Dagger]"*"WR", 
    "BR"*"D"*"dc"*"H"*"H\[Dagger]"^2*"Q"^2*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"*"GR"*"H"^2*"H\[Dagger]"*"L"*"Q"^2, 
    "D"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"L"*"Q"^2*"WR", 
    "BR"*"D"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"L"*"Q"^2, 
    "D"*"GR"*"H"*"H\[Dagger]"^2*"L"*"Q"^2*"uc\[Dagger]", 
    "D"*"H"*"H\[Dagger]"^2*"L"*"Q"^2*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"H"*"H\[Dagger]"^2*"L"*"Q"^2*"uc\[Dagger]", 
    "D"*"dc\[Dagger]"*"GR"*"H"^3*"Q"*"uc"^2, "D"*"dc\[Dagger]"*"H"^3*"Q"*
     "uc"^2*"WR", "BR"*"D"*"dc\[Dagger]"*"H"^3*"Q"*"uc"^2, 
    "D"*"GR"*"H"^2*"H\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]", 
    "D"*"H"^2*"H\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"H"^2*"H\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GR"*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "D"*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WR", 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "D"*"dc"*"GR"*"H"*"H\[Dagger]"^2*"Q"*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"H"*"H\[Dagger]"^2*"Q"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"dc"*"H"*"H\[Dagger]"^2*"Q"*"uc"*"uc\[Dagger]", 
    "D"*"GR"*"H"^2*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "D"*"H"^2*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"uc"*"WR", 
    "BR"*"D"*"H"^2*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "D"*"ec"*"ec\[Dagger]"*"GR"*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "D"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"*"uc"*"WR", 
    "BR"*"D"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "D"*"dc"^2*"dc\[Dagger]"*"GR"*"H"*"H\[Dagger]"^2*"Q", 
    "D"*"dc"^2*"dc\[Dagger]"*"H"*"H\[Dagger]"^2*"Q"*"WR", 
    "BR"*"D"*"dc"^2*"dc\[Dagger]"*"H"*"H\[Dagger]"^2*"Q", 
    "D"*"dc"^2*"GR"*"H\[Dagger]"^3*"Q"*"uc\[Dagger]", 
    "D"*"dc"^2*"H\[Dagger]"^3*"Q"*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"dc"^2*"H\[Dagger]"^3*"Q"*"uc\[Dagger]", 
    "D"*"dc"*"GR"*"H"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"Q", 
    "D"*"dc"*"H"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"Q"*"WR", 
    "BR"*"D"*"dc"*"H"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"Q", 
    "D"*"dc"*"ec"*"ec\[Dagger]"*"GR"*"H"*"H\[Dagger]"^2*"Q", 
    "D"*"dc"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"Q"*"WR", 
    "BR"*"D"*"dc"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"Q", 
    "D"*"ec"*"GR"*"H"*"H\[Dagger]"^2*"L"*"Q"*"Q\[Dagger]", 
    "D"*"ec"*"H"*"H\[Dagger]"^2*"L"*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"D"*"ec"*"H"*"H\[Dagger]"^2*"L"*"Q"*"Q\[Dagger]", 
    "D"*"GR"*"H"^3*"L\[Dagger]"*"uc"^3, "D"*"H"^3*"L\[Dagger]"*"uc"^3*"WR", 
    "BR"*"D"*"H"^3*"L\[Dagger]"*"uc"^3, "D"*"dc"*"GR"*"H"^2*"H\[Dagger]"*
     "L\[Dagger]"*"uc"^2, "D"*"dc"*"H"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"^2*
     "WR", "BR"*"D"*"dc"*"H"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"^2, 
    "D"*"ec"*"GR"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc"^2, 
    "D"*"ec"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc"^2*"WR", 
    "BR"*"D"*"ec"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc"^2, 
    "D"*"dc"^2*"GR"*"H"*"H\[Dagger]"^2*"L\[Dagger]"*"uc", 
    "D"*"dc"^2*"H"*"H\[Dagger]"^2*"L\[Dagger]"*"uc"*"WR", 
    "BR"*"D"*"dc"^2*"H"*"H\[Dagger]"^2*"L\[Dagger]"*"uc", 
    "D"*"dc"*"ec"*"GR"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc", 
    "D"*"dc"*"ec"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc"*"WR", 
    "BR"*"D"*"dc"*"ec"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc", 
    "D"*"dc\[Dagger]"*"ec"*"GR"*"H"^2*"H\[Dagger]"*"L"*"uc", 
    "D"*"dc\[Dagger]"*"ec"*"H"^2*"H\[Dagger]"*"L"*"uc"*"WR", 
    "BR"*"D"*"dc\[Dagger]"*"ec"*"H"^2*"H\[Dagger]"*"L"*"uc", 
    "D"*"ec"*"GR"*"H"*"H\[Dagger]"^2*"L"*"uc"*"uc\[Dagger]", 
    "D"*"ec"*"H"*"H\[Dagger]"^2*"L"*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"ec"*"H"*"H\[Dagger]"^2*"L"*"uc"*"uc\[Dagger]", 
    "D"*"dc"^3*"GR"*"H\[Dagger]"^3*"L\[Dagger]", "D"*"dc"^3*"H\[Dagger]"^3*
     "L\[Dagger]"*"WR", "BR"*"D"*"dc"^3*"H\[Dagger]"^3*"L\[Dagger]", 
    "D"*"dc"^2*"ec"*"GR"*"H\[Dagger]"^3*"Q\[Dagger]", 
    "D"*"dc"^2*"ec"*"H\[Dagger]"^3*"Q\[Dagger]"*"WR", 
    "BR"*"D"*"dc"^2*"ec"*"H\[Dagger]"^3*"Q\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"GR"*"H"*"H\[Dagger]"^2*"L", 
    "D"*"dc"*"dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"^2*"L"*"WR", 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"^2*"L", 
    "D"*"dc"*"ec"*"GR"*"H\[Dagger]"^3*"L"*"uc\[Dagger]", 
    "D"*"dc"*"ec"*"H\[Dagger]"^3*"L"*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"dc"*"ec"*"H\[Dagger]"^3*"L"*"uc\[Dagger]", 
    "D"*"ec"*"H"*"H\[Dagger]"^2*"L"^2*"L\[Dagger]"*"WR", 
    "BR"*"D"*"ec"*"H"*"H\[Dagger]"^2*"L"^2*"L\[Dagger]", 
    "D"*"ec"^2*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"L"*"WR", 
    "BR"*"D"*"ec"^2*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"L"}, 
  D*FL*FR*\[Phi]^4*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"GL"*"GR"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "D"*"GL"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"WR", 
    "BR"*"D"*"GL"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"*"GL"*"GR"*"H"^3*"H\[Dagger]"*"uc", 
    "D"*"dc\[Dagger]"*"GL"*"H"^3*"H\[Dagger]"*"uc"*"WR", 
    "BR"*"D"*"dc\[Dagger]"*"GL"*"H"^3*"H\[Dagger]"*"uc", 
    "D"*"GL"*"GR"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"*"GL"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"GL"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"GR"*"H"^2*"H\[Dagger]"^2, 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"^2*"WR", 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"^2, 
    "D"*"dc"*"GL"*"H"*"H\[Dagger]"^3*"uc\[Dagger]"*"WR", 
    "BR"*"D"*"dc"*"GL"*"H"*"H\[Dagger]"^3*"uc\[Dagger]", 
    "D"*"GL"*"GR"*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]", 
    "D"*"ec"*"ec\[Dagger]"*"GL"*"GR"*"H"^2*"H\[Dagger]"^2, 
    "D"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"WL"*"WR", 
    "BR"*"D"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"*"uc"*"WL"*"WR", 
    "BR"*"D"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"*"uc"*"WL", 
    "D"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]"*"WL"*"WR", 
    "BR"*"D"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2*"WL"*"WR", 
    "BR"*"D"*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2*"WL", 
    "BR"*"D"*"dc"*"H"*"H\[Dagger]"^3*"uc\[Dagger]"*"WL", 
    "D"*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"WL"*"WR", 
    "BR"*"D"*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"WL", 
    "D"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"WL"*"WR", 
    "BR"*"D"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"WL", 
    "BL"*"BR"*"D"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "BL"*"BR"*"D"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"*"uc", 
    "BL"*"BR"*"D"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "BL"*"BR"*"D"*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2, 
    "BL"*"BR"*"D"*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]", 
    "BL"*"BR"*"D"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2}, 
  D^2*\[Phi]^4*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"D"^2*"dc\[Dagger]"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"*"Q"^2, 
    "D"^2*"H"^2*"H\[Dagger]"^2*"Q"^2*"Q\[Dagger]"^2, 
    "D"^2*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"Q"^2*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"H"^3*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc", 
    "D"^2*"ec\[Dagger]"*"H"^3*"H\[Dagger]"*"L\[Dagger]"*"Q"*"uc", 
    "D"^2*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "D"^2*"dc"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"L\[Dagger]"*"Q", 
    "D"^2*"dc\[Dagger]"^2*"H"^3*"H\[Dagger]"*"L"*"Q", 
    "D"^2*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]", 
    "D"^2*"H"*"H\[Dagger]"^3*"L"*"Q"*"uc\[Dagger]"^2, 
    "D"^2*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "D"^2*"dc\[Dagger]"^2*"H"^4*"uc"^2, "D"^2*"dc\[Dagger]"*"H"^3*
     "H\[Dagger]"*"uc"^2*"uc\[Dagger]", "D"^2*"H"^2*"H\[Dagger]"^2*"uc"^2*
     "uc\[Dagger]"^2, "D"^2*"dc"*"dc\[Dagger]"^2*"H"^3*"H\[Dagger]"*"uc", 
    "D"^2*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"H"^3*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc", 
    "D"^2*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "D"^2*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"*"uc", 
    "D"^2*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "D"^2*"dc"^2*"dc\[Dagger]"^2*"H"^2*"H\[Dagger]"^2, 
    "D"^2*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]", 
    "D"^2*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2, 
    "D"^2*"H"^2*"H\[Dagger]"^2*"L"^2*"L\[Dagger]"^2, 
    "D"^2*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]", 
    "D"^2*"ec"^2*"ec\[Dagger]"^2*"H"^2*"H\[Dagger]"^2}, 
  D^2*FR*\[Phi]^5*\[Psi]^2 -> {"D"^2*"GR"*"H"^3*"H\[Dagger]"^2*"Q"*"uc", 
    "D"^2*"H"^3*"H\[Dagger]"^2*"Q"*"uc"*"WR", "BR"*"D"^2*"H"^3*"H\[Dagger]"^2*
     "Q"*"uc", "D"^2*"dc"*"GR"*"H"^2*"H\[Dagger]"^3*"Q", 
    "D"^2*"dc"*"H"^2*"H\[Dagger]"^3*"Q"*"WR", "BR"*"D"^2*"dc"*"H"^2*
     "H\[Dagger]"^3*"Q", "D"^2*"ec"*"H"^2*"H\[Dagger]"^3*"L"*"WR", 
    "BR"*"D"^2*"ec"*"H"^2*"H\[Dagger]"^3*"L"}, 
  D^2*FL*FR*\[Phi]^6 -> {"D"^2*"GL"*"GR"*"H"^3*"H\[Dagger]"^3, 
    "D"^2*"H"^3*"H\[Dagger]"^3*"WL"*"WR", "BR"*"D"^2*"H"^3*"H\[Dagger]"^3*
     "WL", "BL"*"BR"*"D"^2*"H"^3*"H\[Dagger]"^3}, 
  D^3*\[Phi]^6*\[Psi]*OverBar[\[Psi]] -> 
   {"D"^3*"H"^3*"H\[Dagger]"^3*"Q"*"Q\[Dagger]", "D"^3*"dc\[Dagger]"*"H"^4*
     "H\[Dagger]"^2*"uc", "D"^3*"H"^3*"H\[Dagger]"^3*"uc"*"uc\[Dagger]", 
    "D"^3*"dc"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"^3, 
    "D"^3*"H"^3*"H\[Dagger]"^3*"L"*"L\[Dagger]", "D"^3*"ec"*"ec\[Dagger]"*
     "H"^3*"H\[Dagger]"^3}, D^4*\[Phi]^8 -> {"D"^4*"H"^4*"H\[Dagger]"^4}, 
  \[Phi]^3*\[Psi]^6 -> {"H"^2*"H\[Dagger]"*"L"*"Q"^4*"uc", 
    "dc"*"H"*"H\[Dagger]"^2*"L"*"Q"^4, "H"^3*"Q"^3*"uc"^3, 
    "dc"*"H"^2*"H\[Dagger]"*"Q"^3*"uc"^2, "dc"^2*"H"*"H\[Dagger]"^2*"Q"^3*
     "uc", "dc"^3*"H\[Dagger]"^3*"Q"^3, "ec"*"H"*"H\[Dagger]"^2*"L"^2*"Q"^3, 
    "ec"*"H"^2*"H\[Dagger]"*"L"*"Q"^2*"uc"^2, "dc"*"ec"*"H"*"H\[Dagger]"^2*
     "L"*"Q"^2*"uc", "dc"^2*"ec"*"H\[Dagger]"^3*"L"*"Q"^2, 
    "ec"*"H"^3*"Q"*"uc"^4, "dc"*"ec"*"H"^2*"H\[Dagger]"*"Q"*"uc"^3, 
    "dc"^2*"ec"*"H"*"H\[Dagger]"^2*"Q"*"uc"^2, "dc"^3*"ec"*"H\[Dagger]"^3*"Q"*
     "uc", "ec"^2*"H"*"H\[Dagger]"^2*"L"^2*"Q"*"uc", "dc"*"H"^3*"L"^4*"Q", 
    "dc"*"ec"^2*"H\[Dagger]"^3*"L"^2*"Q", "ec"^2*"H"^2*"H\[Dagger]"*"L"*
     "uc"^3, "dc"*"ec"^2*"H"*"H\[Dagger]"^2*"L"*"uc"^2, 
    "dc"^2*"H"^3*"L"^3*"uc", "dc"^2*"ec"^2*"H\[Dagger]"^3*"L"*"uc", 
    "dc"^3*"H"^2*"H\[Dagger]"*"L"^3, "ec"*"H"^3*"L"^5, 
    "ec"^3*"H\[Dagger]"^3*"L"^3}, FL*\[Phi]^4*\[Psi]^4 -> 
   {"GL"*"H"^2*"H\[Dagger]"^2*"L"*"Q"^3, "GL"*"H"^3*"H\[Dagger]"*"Q"^2*
     "uc"^2, "dc"*"GL"*"H"^2*"H\[Dagger]"^2*"Q"^2*"uc", 
    "dc"^2*"GL"*"H"*"H\[Dagger]"^3*"Q"^2, "ec"*"GL"*"H"^2*"H\[Dagger]"^2*"L"*
     "Q"*"uc", "dc"*"ec"*"GL"*"H"*"H\[Dagger]"^3*"L"*"Q", 
    "ec"*"GL"*"H"^3*"H\[Dagger]"*"uc"^3, "dc"*"ec"*"GL"*"H"^2*"H\[Dagger]"^2*
     "uc"^2, "dc"^2*"ec"*"GL"*"H"*"H\[Dagger]"^3*"uc", 
    "dc"^3*"ec"*"GL"*"H\[Dagger]"^4, "H"^2*"H\[Dagger]"^2*"L"*"Q"^3*"WL", 
    "H"^3*"H\[Dagger]"*"Q"^2*"uc"^2*"WL", "dc"*"H"^2*"H\[Dagger]"^2*"Q"^2*
     "uc"*"WL", "dc"^2*"H"*"H\[Dagger]"^3*"Q"^2*"WL", 
    "ec"*"H"^2*"H\[Dagger]"^2*"L"*"Q"*"uc"*"WL", "dc"*"ec"*"H"*"H\[Dagger]"^3*
     "L"*"Q"*"WL", "ec"*"H"^3*"H\[Dagger]"*"uc"^3*"WL", 
    "dc"*"ec"*"H"^2*"H\[Dagger]"^2*"uc"^2*"WL", 
    "dc"^2*"ec"*"H"*"H\[Dagger]"^3*"uc"*"WL", "dc"^3*"ec"*"H\[Dagger]"^4*
     "WL", "H"^4*"L"^4*"WL", "ec"^2*"H"*"H\[Dagger]"^3*"L"^2*"WL", 
    "BL"*"H"^2*"H\[Dagger]"^2*"L"*"Q"^3, "BL"*"H"^3*"H\[Dagger]"*"Q"^2*
     "uc"^2, "BL"*"dc"*"H"^2*"H\[Dagger]"^2*"Q"^2*"uc", 
    "BL"*"dc"^2*"H"*"H\[Dagger]"^3*"Q"^2, "BL"*"ec"*"H"^2*"H\[Dagger]"^2*"L"*
     "Q"*"uc", "BL"*"dc"*"ec"*"H"*"H\[Dagger]"^3*"L"*"Q", 
    "BL"*"ec"*"H"^3*"H\[Dagger]"*"uc"^3, "BL"*"dc"*"ec"*"H"^2*"H\[Dagger]"^2*
     "uc"^2, "BL"*"dc"^2*"ec"*"H"*"H\[Dagger]"^3*"uc", 
    "BL"*"dc"^3*"ec"*"H\[Dagger]"^4, "BL"*"H"^4*"L"^4, 
    "BL"*"ec"^2*"H"*"H\[Dagger]"^3*"L"^2}, FL^2*\[Phi]^5*\[Psi]^2 -> 
   {"GL"^2*"H"^3*"H\[Dagger]"^2*"Q"*"uc", "dc"*"GL"^2*"H"^2*"H\[Dagger]"^3*
     "Q", "ec"*"GL"^2*"H"^2*"H\[Dagger]"^3*"L", "GL"*"H"^3*"H\[Dagger]"^2*"Q"*
     "uc"*"WL", "dc"*"GL"*"H"^2*"H\[Dagger]"^3*"Q"*"WL", 
    "BL"*"GL"*"H"^3*"H\[Dagger]"^2*"Q"*"uc", "BL"*"dc"*"GL"*"H"^2*
     "H\[Dagger]"^3*"Q", "H"^3*"H\[Dagger]"^2*"Q"*"uc"*"WL"^2, 
    "dc"*"H"^2*"H\[Dagger]"^3*"Q"*"WL"^2, "ec"*"H"^2*"H\[Dagger]"^3*"L"*
     "WL"^2, "BL"*"H"^3*"H\[Dagger]"^2*"Q"*"uc"*"WL", 
    "BL"*"dc"*"H"^2*"H\[Dagger]"^3*"Q"*"WL", "BL"*"ec"*"H"^2*"H\[Dagger]"^3*
     "L"*"WL", "BL"^2*"H"^3*"H\[Dagger]"^2*"Q"*"uc", 
    "BL"^2*"dc"*"H"^2*"H\[Dagger]"^3*"Q", "BL"^2*"ec"*"H"^2*"H\[Dagger]"^3*
     "L"}, FL^3*\[Phi]^6 -> {"GL"^3*"H"^3*"H\[Dagger]"^3, 
    "GL"^2*"H"^3*"H\[Dagger]"^3*"WL", "BL"*"GL"^2*"H"^3*"H\[Dagger]"^3, 
    "H"^3*"H\[Dagger]"^3*"WL"^3, "BL"*"H"^3*"H\[Dagger]"^3*"WL"^2, 
    "BL"^2*"H"^3*"H\[Dagger]"^3*"WL", "BL"^3*"H"^3*"H\[Dagger]"^3}, 
  \[Phi]^3*\[Psi]^4*OverBar[\[Psi]]^2 -> 
   {"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"^4*"Q\[Dagger]", 
    "dc\[Dagger]"*"ec\[Dagger]"*"H"^3*"Q"^3*"uc", "H"^2*"H\[Dagger]"*"Q"^3*
     "Q\[Dagger]"^2*"uc", "ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"^3*"uc"*
     "uc\[Dagger]", "dc"*"dc\[Dagger]"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*
     "Q"^3, "dc"*"H"*"H\[Dagger]"^2*"Q"^3*"Q\[Dagger]"^2, 
    "dc"*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"Q"^3*"uc\[Dagger]", 
    "dc\[Dagger]"*"H"^2*"H\[Dagger]"*"L"*"Q"^3*"Q\[Dagger]", 
    "ec\[Dagger]"*"H"^2*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"^3, 
    "H"*"H\[Dagger]"^2*"L"*"Q"^3*"Q\[Dagger]"*"uc\[Dagger]", 
    "ec"*"ec\[Dagger]"^2*"H"^2*"H\[Dagger]"*"Q"^3, 
    "dc\[Dagger]"*"H"^3*"Q"^2*"Q\[Dagger]"*"uc"^2, 
    "ec\[Dagger]"*"H"^3*"L\[Dagger]"*"Q"^2*"uc"^2, 
    "H"^2*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc", 
    "dc"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"L\[Dagger]"*"Q"^2*"uc", 
    "dc"*"H"*"H\[Dagger]"^2*"Q"^2*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc\[Dagger]"^2*"H"^3*"L"*"Q"^2*"uc", "H"^2*"H\[Dagger]"*"L"*"L\[Dagger]"*
     "Q"^2*"Q\[Dagger]"*"uc", "dc\[Dagger]"*"H"^2*"H\[Dagger]"*"L"*"Q"^2*"uc"*
     "uc\[Dagger]", "H"*"H\[Dagger]"^2*"L"*"Q"^2*"uc"*"uc\[Dagger]"^2, 
    "ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"^2*"Q\[Dagger]"*"uc", 
    "dc"^2*"dc\[Dagger]"*"H"*"H\[Dagger]"^2*"Q"^2*"Q\[Dagger]", 
    "dc"^2*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"^2, 
    "dc"^2*"H\[Dagger]"^3*"Q"^2*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"^2*"H"^2*"H\[Dagger]"*"L"*"Q"^2, 
    "dc"*"H"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"Q"^2*"Q\[Dagger]", 
    "dc"*"dc\[Dagger]"*"H"*"H\[Dagger]"^2*"L"*"Q"^2*"uc\[Dagger]", 
    "dc"*"H\[Dagger]"^3*"L"*"Q"^2*"uc\[Dagger]"^2, 
    "dc"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"Q"^2*"Q\[Dagger]", 
    "dc\[Dagger]"*"H"^2*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"Q"^2, 
    "H"*"H\[Dagger]"^2*"L"^2*"L\[Dagger]"*"Q"^2*"uc\[Dagger]", 
    "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"L"*"Q"^2, 
    "ec"*"H"*"H\[Dagger]"^2*"L"*"Q"^2*"Q\[Dagger]"^2, 
    "ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"L"*"Q"^2*"uc\[Dagger]", 
    "H"^3*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"^3, "dc\[Dagger]"*"H"^3*"Q"*
     "uc"^3*"uc\[Dagger]", "H"^2*"H\[Dagger]"*"Q"*"uc"^3*"uc\[Dagger]"^2, 
    "dc"*"dc\[Dagger]"^2*"H"^3*"Q"*"uc"^2, "dc"*"H"^2*"H\[Dagger]"*
     "L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"^2, "dc"*"dc\[Dagger]"*"H"^2*
     "H\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]", "dc"*"H"*"H\[Dagger]"^2*"Q"*
     "uc"^2*"uc\[Dagger]"^2, "dc\[Dagger]"*"H"^3*"L"*"L\[Dagger]"*"Q"*"uc"^2, 
    "H"^2*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]", 
    "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^3*"Q"*"uc"^2, 
    "ec"*"H"^2*"H\[Dagger]"*"Q"*"Q\[Dagger]"^2*"uc"^2, 
    "ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"*"uc"^2*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "dc"^2*"H"*"H\[Dagger]"^2*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"uc", 
    "dc"^2*"dc\[Dagger]"*"H"*"H\[Dagger]"^2*"Q"*"uc"*"uc\[Dagger]", 
    "dc"^2*"H\[Dagger]"^3*"Q"*"uc"*"uc\[Dagger]"^2, 
    "dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "dc"*"H"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"Q"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "dc"*"ec"*"H"*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"^2*"uc", 
    "dc"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"Q"*"uc"*"uc\[Dagger]", 
    "H"^2*"H\[Dagger]"*"L"^2*"L\[Dagger]"^2*"Q"*"uc", 
    "dc\[Dagger]"*"ec"*"H"^2*"H\[Dagger]"*"L"*"Q"*"Q\[Dagger]"*"uc", 
    "ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"L"*"L\[Dagger]"*"Q"*"uc", 
    "ec"*"H"*"H\[Dagger]"^2*"L"*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "ec"^2*"ec\[Dagger]"^2*"H"^2*"H\[Dagger]"*"Q"*"uc", 
    "dc"^3*"dc\[Dagger]"^2*"H"*"H\[Dagger]"^2*"Q", 
    "dc"^3*"H\[Dagger]"^3*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "dc"^3*"dc\[Dagger]"*"H\[Dagger]"^3*"Q"*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"*"H"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"Q", 
    "dc"^2*"H\[Dagger]"^3*"L"*"L\[Dagger]"*"Q"*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"Q", 
    "dc"^2*"ec"*"H\[Dagger]"^3*"Q"*"Q\[Dagger]"^2, 
    "dc"^2*"ec"*"ec\[Dagger]"*"H\[Dagger]"^3*"Q"*"uc\[Dagger]", 
    "dc"*"H"*"H\[Dagger]"^2*"L"^2*"L\[Dagger]"^2*"Q", 
    "dc"*"dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"^2*"L"*"Q"*"Q\[Dagger]", 
    "dc"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"Q", 
    "dc"*"ec"*"H\[Dagger]"^3*"L"*"Q"*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc"*"ec"^2*"ec\[Dagger]"^2*"H"*"H\[Dagger]"^2*"Q", 
    "dc\[Dagger]"^2*"ec"*"H"^2*"H\[Dagger]"*"L"^2*"Q", 
    "ec"*"H"*"H\[Dagger]"^2*"L"^2*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"^2*"L"^2*"Q"*"uc\[Dagger]", 
    "ec"*"H\[Dagger]"^3*"L"^2*"Q"*"uc\[Dagger]"^2, 
    "ec"^2*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"L"*"Q"*"Q\[Dagger]", 
    "H"^3*"L\[Dagger]"*"uc"^4*"uc\[Dagger]", "dc"*"dc\[Dagger]"*"H"^3*
     "L\[Dagger]"*"uc"^3, "dc"*"H"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"^3*
     "uc\[Dagger]", "H"^3*"L"*"L\[Dagger]"^2*"uc"^3, 
    "dc\[Dagger]"*"ec"*"H"^3*"Q\[Dagger]"*"uc"^3, "ec"*"ec\[Dagger]"*"H"^3*
     "L\[Dagger]"*"uc"^3, "ec"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc"^3*
     "uc\[Dagger]", "dc"^2*"dc\[Dagger]"*"H"^2*"H\[Dagger]"*"L\[Dagger]"*
     "uc"^2, "dc"^2*"H"*"H\[Dagger]"^2*"L\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "dc"*"H"^2*"H\[Dagger]"*"L"*"L\[Dagger]"^2*"uc"^2, 
    "dc"*"dc\[Dagger]"*"ec"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*"uc"^2, 
    "dc"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"L\[Dagger]"*"uc"^2, 
    "dc"*"ec"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc"^2*"uc\[Dagger]", 
    "dc\[Dagger]"^2*"ec"*"H"^3*"L"*"uc"^2, "ec"*"H"^2*"H\[Dagger]"*"L"*
     "L\[Dagger]"*"Q\[Dagger]"*"uc"^2, "dc\[Dagger]"*"ec"*"H"^2*"H\[Dagger]"*
     "L"*"uc"^2*"uc\[Dagger]", "ec"*"H"*"H\[Dagger]"^2*"L"*"uc"^2*
     "uc\[Dagger]"^2, "ec"^2*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"Q\[Dagger]"*
     "uc"^2, "dc"^3*"dc\[Dagger]"*"H"*"H\[Dagger]"^2*"L\[Dagger]"*"uc", 
    "dc"^3*"H\[Dagger]"^3*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"^2*"H"*"H\[Dagger]"^2*"L"*"L\[Dagger]"^2*"uc", 
    "dc"^2*"dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc", 
    "dc"^2*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"L\[Dagger]"*"uc", 
    "dc"^2*"ec"*"H\[Dagger]"^3*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"^2*"ec"*"H"^2*"H\[Dagger]"*"L"*"uc", 
    "dc"*"ec"*"H"*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "dc"*"dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"^2*"L"*"uc"*"uc\[Dagger]", 
    "dc"*"ec"*"H\[Dagger]"^3*"L"*"uc"*"uc\[Dagger]"^2, 
    "dc"*"ec"^2*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"Q\[Dagger]"*"uc", 
    "dc\[Dagger]"*"ec"*"H"^2*"H\[Dagger]"*"L"^2*"L\[Dagger]"*"uc", 
    "ec"*"H"*"H\[Dagger]"^2*"L"^2*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"H"^2*"H\[Dagger]"*"L"*"uc", 
    "ec"^2*"H"*"H\[Dagger]"^2*"L"*"Q\[Dagger]"^2*"uc", 
    "ec"^2*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"L"*"uc"*"uc\[Dagger]", 
    "dc"^4*"dc\[Dagger]"*"H\[Dagger]"^3*"L\[Dagger]", 
    "dc"^3*"ec\[Dagger]"^2*"H"^3*"L", "dc"^3*"H\[Dagger]"^3*"L"*
     "L\[Dagger]"^2, "dc"^3*"dc\[Dagger]"*"ec"*"H\[Dagger]"^3*"Q\[Dagger]", 
    "dc"^3*"ec"*"ec\[Dagger]"*"H\[Dagger]"^3*"L\[Dagger]", 
    "dc"^2*"ec\[Dagger]"*"H"^3*"L"^2*"Q\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2*"ec"*"H"*"H\[Dagger]"^2*"L", 
    "dc"^2*"ec"*"H\[Dagger]"^3*"L"*"L\[Dagger]"*"Q\[Dagger]", 
    "dc"^2*"dc\[Dagger]"*"ec"*"H\[Dagger]"^3*"L"*"uc\[Dagger]", 
    "dc"^2*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"^3*"Q\[Dagger]", 
    "dc"*"H"^3*"L"^3*"Q\[Dagger]"^2, "dc"*"ec\[Dagger]"*"H"^3*"L"^3*
     "uc\[Dagger]", "dc"*"dc\[Dagger]"*"ec"*"H"*"H\[Dagger]"^2*"L"^2*
     "L\[Dagger]", "dc"*"ec"*"H\[Dagger]"^3*"L"^2*"L\[Dagger]"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"ec"^2*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"L", 
    "dc"*"ec"^2*"H\[Dagger]"^3*"L"*"Q\[Dagger]"^2, 
    "dc"*"ec"^2*"ec\[Dagger]"*"H\[Dagger]"^3*"L"*"uc\[Dagger]", 
    "H"^3*"L"^4*"Q\[Dagger]"*"uc\[Dagger]", "ec"*"H"*"H\[Dagger]"^2*"L"^3*
     "L\[Dagger]"^2, "dc\[Dagger]"*"ec"^2*"H"*"H\[Dagger]"^2*"L"^2*
     "Q\[Dagger]", "ec"^2*"ec\[Dagger]"*"H"*"H\[Dagger]"^2*"L"^2*
     "L\[Dagger]", "ec"^2*"H\[Dagger]"^3*"L"^2*"Q\[Dagger]"*"uc\[Dagger]", 
    "ec"^3*"ec\[Dagger]"^2*"H"*"H\[Dagger]"^2*"L"}, 
  FL*\[Phi]^4*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"*"ec\[Dagger]"*"GL"*"H"^3*"H\[Dagger]"*"Q"^2, 
    "GL"*"H"^2*"H\[Dagger]"^2*"Q"^2*"Q\[Dagger]"^2, 
    "ec\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"^2*"Q"^2*"uc\[Dagger]", 
    "dc\[Dagger]"*"GL"*"H"^3*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc", 
    "ec\[Dagger]"*"GL"*"H"^3*"H\[Dagger]"*"L\[Dagger]"*"Q"*"uc", 
    "GL"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "dc"*"ec\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"^2*"L\[Dagger]"*"Q", 
    "dc"*"GL"*"H"*"H\[Dagger]"^3*"Q"*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"^2*"GL"*"H"^3*"H\[Dagger]"*"L"*"Q", 
    "GL"*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "dc\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]", 
    "GL"*"H"*"H\[Dagger]"^3*"L"*"Q"*"uc\[Dagger]"^2, 
    "ec"*"ec\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "dc\[Dagger]"^2*"GL"*"H"^4*"uc"^2, "GL"*"H"^3*"H\[Dagger]"*"L\[Dagger]"*
     "Q\[Dagger]"*"uc"^2, "dc\[Dagger]"*"GL"*"H"^3*"H\[Dagger]"*"uc"^2*
     "uc\[Dagger]", "GL"*"H"^2*"H\[Dagger]"^2*"uc"^2*"uc\[Dagger]"^2, 
    "dc"*"dc\[Dagger]"^2*"GL"*"H"^3*"H\[Dagger]"*"uc", 
    "dc"*"GL"*"H"^2*"H\[Dagger]"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "dc"*"dc\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "dc"*"GL"*"H"*"H\[Dagger]"^3*"uc"*"uc\[Dagger]"^2, 
    "dc\[Dagger]"*"GL"*"H"^3*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc", 
    "GL"*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*"H"^3*"H\[Dagger]"*"uc", 
    "ec"*"GL"*"H"^2*"H\[Dagger]"^2*"Q\[Dagger]"^2*"uc", 
    "ec"*"ec\[Dagger]"*"GL"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2*"GL"*"H"^2*"H\[Dagger]"^2, 
    "dc"^2*"GL"*"H"*"H\[Dagger]"^3*"L\[Dagger]"*"Q\[Dagger]", 
    "dc"^2*"dc\[Dagger]"*"GL"*"H"*"H\[Dagger]"^3*"uc\[Dagger]", 
    "dc"^2*"GL"*"H\[Dagger]"^4*"uc\[Dagger]"^2, "dc"*"dc\[Dagger]"*"GL"*"H"^2*
     "H\[Dagger]"^2*"L"*"L\[Dagger]", "dc"*"GL"*"H"*"H\[Dagger]"^3*"L"*
     "L\[Dagger]"*"uc\[Dagger]", "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"GL"*
     "H"^2*"H\[Dagger]"^2, "dc"*"ec"*"GL"*"H"*"H\[Dagger]"^3*"Q\[Dagger]"^2, 
    "dc"*"ec"*"ec\[Dagger]"*"GL"*"H"*"H\[Dagger]"^3*"uc\[Dagger]", 
    "dc\[Dagger]"*"ec"*"GL"*"H"^2*"H\[Dagger]"^2*"L"*"Q\[Dagger]", 
    "ec"*"GL"*"H"*"H\[Dagger]"^3*"L"*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"*"Q"^2*"WL", 
    "H"^2*"H\[Dagger]"^2*"Q"^2*"Q\[Dagger]"^2*"WL", 
    "ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"Q"^2*"uc\[Dagger]"*"WL", 
    "dc\[Dagger]"*"H"^3*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc"*"WL", 
    "ec\[Dagger]"*"H"^3*"H\[Dagger]"*"L\[Dagger]"*"Q"*"uc"*"WL", 
    "H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"WL", 
    "dc"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"L\[Dagger]"*"Q"*"WL", 
    "dc"*"H"*"H\[Dagger]"^3*"Q"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "dc\[Dagger]"^2*"H"^3*"H\[Dagger]"*"L"*"Q"*"WL", 
    "H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]"*"WL", 
    "dc\[Dagger]"*"H"^2*"H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]"*"WL", 
    "H"*"H\[Dagger]"^3*"L"*"Q"*"uc\[Dagger]"^2*"WL", 
    "ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"WL", 
    "dc\[Dagger]"^2*"H"^4*"uc"^2*"WL", "H"^3*"H\[Dagger]"*"L\[Dagger]"*
     "Q\[Dagger]"*"uc"^2*"WL", "dc\[Dagger]"*"H"^3*"H\[Dagger]"*"uc"^2*
     "uc\[Dagger]"*"WL", "H"^2*"H\[Dagger]"^2*"uc"^2*"uc\[Dagger]"^2*"WL", 
    "dc"*"dc\[Dagger]"^2*"H"^3*"H\[Dagger]"*"uc"*"WL", 
    "dc"*"H"^2*"H\[Dagger]"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc"*"WL", 
    "dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]"*"WL", 
    "dc"*"H"*"H\[Dagger]"^3*"uc"*"uc\[Dagger]"^2*"WL", 
    "dc\[Dagger]"*"H"^3*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc"*"WL", 
    "H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]"*"WL", 
    "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"*"uc"*"WL", 
    "ec"*"H"^2*"H\[Dagger]"^2*"Q\[Dagger]"^2*"uc"*"WL", 
    "ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]"*"WL", 
    "dc"^2*"dc\[Dagger]"^2*"H"^2*"H\[Dagger]"^2*"WL", 
    "dc"^2*"H"*"H\[Dagger]"^3*"L\[Dagger]"*"Q\[Dagger]"*"WL", 
    "dc"^2*"dc\[Dagger]"*"H"*"H\[Dagger]"^3*"uc\[Dagger]"*"WL", 
    "dc"^2*"H\[Dagger]"^4*"uc\[Dagger]"^2*"WL", "dc"*"dc\[Dagger]"*"H"^2*
     "H\[Dagger]"^2*"L"*"L\[Dagger]"*"WL", "dc"*"H"*"H\[Dagger]"^3*"L"*
     "L\[Dagger]"*"uc\[Dagger]"*"WL", "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*
     "H"^2*"H\[Dagger]"^2*"WL", "dc"*"ec"*"H"*"H\[Dagger]"^3*"Q\[Dagger]"^2*
     "WL", "dc"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"^3*"uc\[Dagger]"*"WL", 
    "H"^2*"H\[Dagger]"^2*"L"^2*"L\[Dagger]"^2*"WL", 
    "dc\[Dagger]"*"ec"*"H"^2*"H\[Dagger]"^2*"L"*"Q\[Dagger]"*"WL", 
    "ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"WL", 
    "ec"*"H"*"H\[Dagger]"^3*"L"*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "ec"^2*"ec\[Dagger]"^2*"H"^2*"H\[Dagger]"^2*"WL", 
    "BL"*"dc\[Dagger]"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"*"Q"^2, 
    "BL"*"H"^2*"H\[Dagger]"^2*"Q"^2*"Q\[Dagger]"^2, 
    "BL"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"Q"^2*"uc\[Dagger]", 
    "BL"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"*"Q"*"Q\[Dagger]"*"uc", 
    "BL"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"*"L\[Dagger]"*"Q"*"uc", 
    "BL"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "BL"*"dc"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"L\[Dagger]"*"Q", 
    "BL"*"dc"*"H"*"H\[Dagger]"^3*"Q"*"Q\[Dagger]"*"uc\[Dagger]", 
    "BL"*"dc\[Dagger]"^2*"H"^3*"H\[Dagger]"*"L"*"Q", 
    "BL"*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"Q"*"Q\[Dagger]", 
    "BL"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2*"L"*"Q"*"uc\[Dagger]", 
    "BL"*"H"*"H\[Dagger]"^3*"L"*"Q"*"uc\[Dagger]"^2, 
    "BL"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"Q"*"Q\[Dagger]", 
    "BL"*"dc\[Dagger]"^2*"H"^4*"uc"^2, "BL"*"H"^3*"H\[Dagger]"*"L\[Dagger]"*
     "Q\[Dagger]"*"uc"^2, "BL"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"*"uc"^2*
     "uc\[Dagger]", "BL"*"H"^2*"H\[Dagger]"^2*"uc"^2*"uc\[Dagger]"^2, 
    "BL"*"dc"*"dc\[Dagger]"^2*"H"^3*"H\[Dagger]"*"uc", 
    "BL"*"dc"*"H"^2*"H\[Dagger]"^2*"L\[Dagger]"*"Q\[Dagger]"*"uc", 
    "BL"*"dc"*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "BL"*"dc"*"H"*"H\[Dagger]"^3*"uc"*"uc\[Dagger]"^2, 
    "BL"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"*"L"*"L\[Dagger]"*"uc", 
    "BL"*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "BL"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"*"uc", 
    "BL"*"ec"*"H"^2*"H\[Dagger]"^2*"Q\[Dagger]"^2*"uc", 
    "BL"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"uc"*"uc\[Dagger]", 
    "BL"*"dc"^2*"dc\[Dagger]"^2*"H"^2*"H\[Dagger]"^2, 
    "BL"*"dc"^2*"H"*"H\[Dagger]"^3*"L\[Dagger]"*"Q\[Dagger]", 
    "BL"*"dc"^2*"dc\[Dagger]"*"H"*"H\[Dagger]"^3*"uc\[Dagger]", 
    "BL"*"dc"^2*"H\[Dagger]"^4*"uc\[Dagger]"^2, "BL"*"dc"*"dc\[Dagger]"*"H"^2*
     "H\[Dagger]"^2*"L"*"L\[Dagger]", "BL"*"dc"*"H"*"H\[Dagger]"^3*"L"*
     "L\[Dagger]"*"uc\[Dagger]", "BL"*"dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*
     "H"^2*"H\[Dagger]"^2, "BL"*"dc"*"ec"*"H"*"H\[Dagger]"^3*"Q\[Dagger]"^2, 
    "BL"*"dc"*"ec"*"ec\[Dagger]"*"H"*"H\[Dagger]"^3*"uc\[Dagger]", 
    "BL"*"H"^2*"H\[Dagger]"^2*"L"^2*"L\[Dagger]"^2, 
    "BL"*"dc\[Dagger]"*"ec"*"H"^2*"H\[Dagger]"^2*"L"*"Q\[Dagger]", 
    "BL"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^2*"L"*"L\[Dagger]", 
    "BL"*"ec"*"H"*"H\[Dagger]"^3*"L"*"Q\[Dagger]"*"uc\[Dagger]", 
    "BL"*"ec"^2*"ec\[Dagger]"^2*"H"^2*"H\[Dagger]"^2}, 
  FL^2*\[Phi]^5*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"*"GL"^2*"H"^3*"H\[Dagger]"^2*"Q\[Dagger]", 
    "ec\[Dagger]"*"GL"^2*"H"^3*"H\[Dagger]"^2*"L\[Dagger]", 
    "GL"^2*"H"^2*"H\[Dagger]"^3*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"GL"*"H"^3*"H\[Dagger]"^2*"Q\[Dagger]"*"WL", 
    "GL"*"H"^2*"H\[Dagger]"^3*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"*"dc\[Dagger]"*"GL"*"H"^3*"H\[Dagger]"^2*"Q\[Dagger]", 
    "BL"*"GL"*"H"^2*"H\[Dagger]"^3*"Q\[Dagger]"*"uc\[Dagger]", 
    "dc\[Dagger]"*"H"^3*"H\[Dagger]"^2*"Q\[Dagger]"*"WL"^2, 
    "ec\[Dagger]"*"H"^3*"H\[Dagger]"^2*"L\[Dagger]"*"WL"^2, 
    "H"^2*"H\[Dagger]"^3*"Q\[Dagger]"*"uc\[Dagger]"*"WL"^2, 
    "BL"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"^2*"Q\[Dagger]"*"WL", 
    "BL"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"^2*"L\[Dagger]"*"WL", 
    "BL"*"H"^2*"H\[Dagger]"^3*"Q\[Dagger]"*"uc\[Dagger]"*"WL", 
    "BL"^2*"dc\[Dagger]"*"H"^3*"H\[Dagger]"^2*"Q\[Dagger]", 
    "BL"^2*"ec\[Dagger]"*"H"^3*"H\[Dagger]"^2*"L\[Dagger]", 
    "BL"^2*"H"^2*"H\[Dagger]"^3*"Q\[Dagger]"*"uc\[Dagger]"}, 
  D*\[Phi]^5*\[Psi]^3*OverBar[\[Psi]] -> 
   {"D"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"^2*"Q"^3, "D"*"H"^3*"H\[Dagger]"^2*
     "Q"^2*"Q\[Dagger]"*"uc", "D"*"dc"*"H"^2*"H\[Dagger]"^3*"Q"^2*
     "Q\[Dagger]", "D"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"^2*"L"*"Q"^2, 
    "D"*"H"^2*"H\[Dagger]"^3*"L"*"Q"^2*"uc\[Dagger]", 
    "D"*"dc\[Dagger]"*"H"^4*"H\[Dagger]"*"Q"*"uc"^2, 
    "D"*"H"^3*"H\[Dagger]"^2*"Q"*"uc"^2*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"^2*"Q"*"uc", 
    "D"*"dc"*"H"^2*"H\[Dagger]"^3*"Q"*"uc"*"uc\[Dagger]", 
    "D"*"H"^3*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"Q"*"uc", 
    "D"*"ec"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"^2*"Q"*"uc", 
    "D"*"dc"^2*"dc\[Dagger]"*"H"^2*"H\[Dagger]"^3*"Q", 
    "D"*"dc"^2*"H"*"H\[Dagger]"^4*"Q"*"uc\[Dagger]", 
    "D"*"dc"*"H"^2*"H\[Dagger]"^3*"L"*"L\[Dagger]"*"Q", 
    "D"*"dc"*"ec"*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^3*"Q", 
    "D"*"ec"*"H"^2*"H\[Dagger]"^3*"L"*"Q"*"Q\[Dagger]", 
    "D"*"H"^4*"H\[Dagger]"*"L\[Dagger]"*"uc"^3, "D"*"dc"*"H"^3*"H\[Dagger]"^2*
     "L\[Dagger]"*"uc"^2, "D"*"ec"*"H"^3*"H\[Dagger]"^2*"Q\[Dagger]"*"uc"^2, 
    "D"*"dc"^2*"H"^2*"H\[Dagger]"^3*"L\[Dagger]"*"uc", 
    "D"*"dc"*"ec"*"H"^2*"H\[Dagger]"^3*"Q\[Dagger]"*"uc", 
    "D"*"dc\[Dagger]"*"ec"*"H"^3*"H\[Dagger]"^2*"L"*"uc", 
    "D"*"ec"*"H"^2*"H\[Dagger]"^3*"L"*"uc"*"uc\[Dagger]", 
    "D"*"dc"^3*"H"*"H\[Dagger]"^4*"L\[Dagger]", "D"*"dc"^2*"ec"*"H"*
     "H\[Dagger]"^4*"Q\[Dagger]", "D"*"dc"*"dc\[Dagger]"*"ec"*"H"^2*
     "H\[Dagger]"^3*"L", "D"*"dc"*"ec"*"H"*"H\[Dagger]"^4*"L"*"uc\[Dagger]", 
    "D"*"ec\[Dagger]"*"H"^5*"L"^3, "D"*"ec"*"H"^2*"H\[Dagger]"^3*"L"^2*
     "L\[Dagger]", "D"*"ec"^2*"ec\[Dagger]"*"H"^2*"H\[Dagger]"^3*"L"}, 
  D*FL*\[Phi]^6*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"GL"*"H"^3*"H\[Dagger]"^3*"Q"*"Q\[Dagger]", 
    "D"*"dc\[Dagger]"*"GL"*"H"^4*"H\[Dagger]"^2*"uc", 
    "D"*"GL"*"H"^3*"H\[Dagger]"^3*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"GL"*"H"^3*"H\[Dagger]"^3, 
    "D"*"dc"*"GL"*"H"^2*"H\[Dagger]"^4*"uc\[Dagger]", 
    "D"*"H"^3*"H\[Dagger]"^3*"Q"*"Q\[Dagger]"*"WL", 
    "D"*"dc\[Dagger]"*"H"^4*"H\[Dagger]"^2*"uc"*"WL", 
    "D"*"H"^3*"H\[Dagger]"^3*"uc"*"uc\[Dagger]"*"WL", 
    "D"*"dc"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"^3*"WL", 
    "D"*"dc"*"H"^2*"H\[Dagger]"^4*"uc\[Dagger]"*"WL", 
    "D"*"H"^3*"H\[Dagger]"^3*"L"*"L\[Dagger]"*"WL", 
    "D"*"ec"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"^3*"WL", 
    "BL"*"D"*"H"^3*"H\[Dagger]"^3*"Q"*"Q\[Dagger]", 
    "BL"*"D"*"dc\[Dagger]"*"H"^4*"H\[Dagger]"^2*"uc", 
    "BL"*"D"*"H"^3*"H\[Dagger]"^3*"uc"*"uc\[Dagger]", 
    "BL"*"D"*"dc"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"^3, 
    "BL"*"D"*"dc"*"H"^2*"H\[Dagger]"^4*"uc\[Dagger]", 
    "BL"*"D"*"H"^3*"H\[Dagger]"^3*"L"*"L\[Dagger]", 
    "BL"*"D"*"ec"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"^3}, 
  D^2*\[Phi]^7*\[Psi]^2 -> {"D"^2*"H"^4*"H\[Dagger]"^3*"Q"*"uc", 
    "D"^2*"dc"*"H"^3*"H\[Dagger]"^4*"Q", "D"^2*"ec"*"H"^3*"H\[Dagger]"^4*
     "L"}, D^2*FL*\[Phi]^8 -> {"D"^2*"H"^4*"H\[Dagger]"^4*"WL", 
    "BL"*"D"^2*"H"^4*"H\[Dagger]"^4}, \[Phi]^6*\[Psi]^4 -> 
   {"H"^3*"H\[Dagger]"^3*"L"*"Q"^3, "H"^4*"H\[Dagger]"^2*"Q"^2*"uc"^2, 
    "dc"*"H"^3*"H\[Dagger]"^3*"Q"^2*"uc", "dc"^2*"H"^2*"H\[Dagger]"^4*"Q"^2, 
    "ec"*"H"^3*"H\[Dagger]"^3*"L"*"Q"*"uc", "dc"*"ec"*"H"^2*"H\[Dagger]"^4*
     "L"*"Q", "ec"*"H"^4*"H\[Dagger]"^2*"uc"^3, 
    "dc"*"ec"*"H"^3*"H\[Dagger]"^3*"uc"^2, "dc"^2*"ec"*"H"^2*"H\[Dagger]"^4*
     "uc", "dc"^3*"ec"*"H"*"H\[Dagger]"^5, "H"^5*"H\[Dagger]"*"L"^4, 
    "ec"^2*"H"^2*"H\[Dagger]"^4*"L"^2}, FL*\[Phi]^7*\[Psi]^2 -> 
   {"GL"*"H"^4*"H\[Dagger]"^3*"Q"*"uc", "dc"*"GL"*"H"^3*"H\[Dagger]"^4*"Q", 
    "H"^4*"H\[Dagger]"^3*"Q"*"uc"*"WL", "dc"*"H"^3*"H\[Dagger]"^4*"Q"*"WL", 
    "ec"*"H"^3*"H\[Dagger]"^4*"L"*"WL", "BL"*"H"^4*"H\[Dagger]"^3*"Q"*"uc", 
    "BL"*"dc"*"H"^3*"H\[Dagger]"^4*"Q", "BL"*"ec"*"H"^3*"H\[Dagger]"^4*"L"}, 
  FL^2*\[Phi]^8 -> {"GL"^2*"H"^4*"H\[Dagger]"^4, "H"^4*"H\[Dagger]"^4*"WL"^2, 
    "BL"*"H"^4*"H\[Dagger]"^4*"WL", "BL"^2*"H"^4*"H\[Dagger]"^4}, 
  \[Phi]^6*\[Psi]^2*OverBar[\[Psi]]^2 -> 
   {"dc\[Dagger]"*"ec\[Dagger]"*"H"^4*"H\[Dagger]"^2*"Q"^2, 
    "H"^3*"H\[Dagger]"^3*"Q"^2*"Q\[Dagger]"^2, "ec\[Dagger]"*"H"^3*
     "H\[Dagger]"^3*"Q"^2*"uc\[Dagger]", "dc\[Dagger]"*"H"^4*"H\[Dagger]"^2*
     "Q"*"Q\[Dagger]"*"uc", "ec\[Dagger]"*"H"^4*"H\[Dagger]"^2*"L\[Dagger]"*
     "Q"*"uc", "H"^3*"H\[Dagger]"^3*"Q"*"Q\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"^3*"Q"*"Q\[Dagger]", 
    "dc"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"^3*"L\[Dagger]"*"Q", 
    "dc\[Dagger]"^2*"H"^4*"H\[Dagger]"^2*"L"*"Q", "H"^3*"H\[Dagger]"^3*"L"*
     "L\[Dagger]"*"Q"*"Q\[Dagger]", "dc\[Dagger]"*"H"^3*"H\[Dagger]"^3*"L"*
     "Q"*"uc\[Dagger]", "H"^2*"H\[Dagger]"^4*"L"*"Q"*"uc\[Dagger]"^2, 
    "ec"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"^3*"Q"*"Q\[Dagger]", 
    "dc\[Dagger]"^2*"H"^5*"H\[Dagger]"*"uc"^2, "dc\[Dagger]"*"H"^4*
     "H\[Dagger]"^2*"uc"^2*"uc\[Dagger]", "H"^3*"H\[Dagger]"^3*"uc"^2*
     "uc\[Dagger]"^2, "dc"*"dc\[Dagger]"^2*"H"^4*"H\[Dagger]"^2*"uc", 
    "dc"*"dc\[Dagger]"*"H"^3*"H\[Dagger]"^3*"uc"*"uc\[Dagger]", 
    "dc\[Dagger]"*"H"^4*"H\[Dagger]"^2*"L"*"L\[Dagger]"*"uc", 
    "H"^3*"H\[Dagger]"^3*"L"*"L\[Dagger]"*"uc"*"uc\[Dagger]", 
    "dc\[Dagger]"*"ec"*"ec\[Dagger]"*"H"^4*"H\[Dagger]"^2*"uc", 
    "ec"*"ec\[Dagger]"*"H"^3*"H\[Dagger]"^3*"uc"*"uc\[Dagger]", 
    "dc"^2*"dc\[Dagger]"^2*"H"^3*"H\[Dagger]"^3, "dc"*"dc\[Dagger]"*"H"^3*
     "H\[Dagger]"^3*"L"*"L\[Dagger]", "dc"*"dc\[Dagger]"*"ec"*"ec\[Dagger]"*
     "H"^3*"H\[Dagger]"^3, "ec\[Dagger]"^2*"H"^6*"L"^2, 
    "H"^3*"H\[Dagger]"^3*"L"^2*"L\[Dagger]"^2, "ec"*"ec\[Dagger]"*"H"^3*
     "H\[Dagger]"^3*"L"*"L\[Dagger]", "ec"^2*"ec\[Dagger]"^2*"H"^3*
     "H\[Dagger]"^3}, D*\[Phi]^8*\[Psi]*OverBar[\[Psi]] -> 
   {"D"*"H"^4*"H\[Dagger]"^4*"Q"*"Q\[Dagger]", "D"*"dc\[Dagger]"*"H"^5*
     "H\[Dagger]"^3*"uc", "D"*"H"^4*"H\[Dagger]"^4*"uc"*"uc\[Dagger]", 
    "D"*"dc"*"dc\[Dagger]"*"H"^4*"H\[Dagger]"^4, "D"*"H"^4*"H\[Dagger]"^4*"L"*
     "L\[Dagger]", "D"*"ec"*"ec\[Dagger]"*"H"^4*"H\[Dagger]"^4}, 
  D^2*\[Phi]^10 -> {"D"^2*"H"^5*"H\[Dagger]"^5}, 
  \[Phi]^9*\[Psi]^2 -> {"H"^5*"H\[Dagger]"^4*"Q"*"uc", 
    "dc"*"H"^4*"H\[Dagger]"^5*"Q", "ec"*"H"^4*"H\[Dagger]"^5*"L"}, 
  \[Phi]^12 -> {"H"^6*"H\[Dagger]"^6}|>}
